function getBaseUrl() {
  var urlMatch = location.pathname.match(/(\/(?:\d+\.){2}\d\/docs\/)/);
  return urlMatch ? urlMatch[0] : '/';
}
// helper scripts for examples
function getJSON(url, success, error) {
  'use strict';
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
      if (xhr.status === 200) {
        success(JSON.parse(xhr.responseText));
      } else {
        error(xhr.responseText);
      }
    }
  };
  xhr.open('GET', url);
  xhr.send();
}

function asyncSuggest(value, cb, config) {
  getJSON(getBaseUrl() + 'assets/js/jobs.json', function (json) {
    var rx = new RegExp((config.data.search === '^' ? '^' : '') + B8.escapeRegExp(value || ''), 'i')
    cb(json.jobPosts.filter(function (v, i) {
      return v.jobTitle.match(rx) != null
    }) || [], value)
  }, function (error) {
    cb([], value)
  })
}




var jobsCache;
function asyncSuggestCached(value, cb, config) {
  if (!jobsCache) {
    getJSON(getBaseUrl() + 'assets/jobs.json', function (json) {
      jobsCache = json
      cachedSuggest(value, cb, config)
    }, function (error) {
      cb([], value)
    })
  } else {
    cachedSuggest(value, cb, config)
  }
}
function cachedSuggest(value, cb, config) {
  if (value === '') {
    cb([], value)
  } else {
    var rx = new RegExp((config.data.search === '^' ? '^' : '') + B8.escapeRegExp(value || ''), 'i')
    cb(jobsCache.jobPosts.filter(function (v, i) {
      return v.jobTitle.match(rx) != null
    }) || [], value)
  }
}

// Advanced Searchable Example Helpers
function asyncFetch(value, callback) {
  getJSON(getBaseUrl() + 'assets/users.json', function (json) {
    callback(json.filter(function (v, i) {
      var rx = new RegExp(B8.escapeRegExp(value || ''), 'ig')
      return v.Name.match(rx) != null || v.Email.match(rx) != null
    }) || [], value)
  }, function (error) {
    callback([], value)
  })
}
function filterContacts(term, data, config) {
  var rx = new RegExp(B8.escapeRegExp(term), 'ig')
  return data.filter(function (v) {
    return v.Name.match(rx) != null || v.Email.match(rx) != null
  })
}
function renderContact(record, textKey, valueKey) {
  return [
    '<div class="media">',
    ' <img src="',
    getBaseUrl(),
    'assets/1440x460.png" class="img-40 is-circular">',
    ' <div>',
    '   <p class="m0 t-small" data-highlight>' + record[textKey] + '</p>',
    '   <p class="m0 t-mute t-xsmall"  data-highlight> ' + record.Email + ' </p>',
    ' </div>',
    '</div>'
  ].join('')
}

function showMobApp() {
  B8.snackbar.attach({
    html: '<div class="row no-wrap bg-primary t-inverse is-m v-align-center t-small p10"><div class="col "><a class="b-close t-xsmall is-inverse" data-snack-close href="#"></a></div><div><a class="btn is-outline is-inverse u-rounded p10 u-left m10x" href="www.bayt.com"><img class="img-apps is-b-inverse" width="40" height="40" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="></a></div><span class="">Download Bayt.com mobile App for FREE</span><div class="col t-right"><a class=" t-small is-inverse  " href="#"><b>Download</b></a></div></div>',
    timeout: 5000000, positionD: "b",
    positionM: "b", close: true
  });
}
function showCallmeback() {
  B8.snackbar.attach({
    html: '<div class="card is-compact p0 u-shadow " data-snack-close> <ul class="list is-basic t-center m0 d"><li><button class="btn u-expanded is-clear p20" ><i class="icon is-call-out t-primary u-block p10"></i>Call me Back</button><li><button class="btn u-expanded is-clear p20" data-snack-close><i class="icon is-envelope t-primary u-block p10"></i>Email Us</button></li></ul><ul class="bg-primary list is-basic t-center m0 m"><li><button class="btn is-large u-expanded"><i class="icon is-call-out"></i>Call me Back</button><li><button class="btn is-large u-expanded"><i class="icon is-envelope"></i>Email Us</button></li></ul></div>', timeout: 5000000, positionD: "rc", positionM: "b", close: true
  });
}


function customDateValidator(value, messages, attribute, config) {
  var day = value || 0, //assuming validator is added to the day dropdown.
    month = 0, year = 0

  //find the month dropdown and grab its value
  B8.find('#' + attribute.related[0], function (mDropdown) {
    month = B8.ValidateForm.getValue(mDropdown)
  })
  //find the year dropdown and grab its value
  B8.find('#' + attribute.related[1], function (yDropdown) {
    year = B8.ValidateForm.getValue(yDropdown)
  })

  var date = parseInt(year + month + day)
  if (!(year || month || day) || parseInt(config.date) > date) {
    messages.push(config.msg)
  }
}
// baytAfterValidate = function (form, msgs, hasError) {
//   hasError && this.config.attrs.find(function (attr) {
//     if (attr.id === 'Birth_day') {
//       attr.config.find(function (config) {
//         if (config.fn === 'baytDateValidator') {
//           //find the month dropdown and grab its value
//           B8.find('#' + config.monthID, function (m) {
//             hasError ? B8.addClass(attr.css.error, m) : B8.remClass(attr.css.error, m)
//           })
//           //find the year dropdown and grab its value
//           B8.find('#' + config.yearID, function (y) {
//             hasError ? B8.addClass(attr.css.error, y) : B8.remClass(attr.css.error, y)
//           })
//         }
//       })
//     }
//   })
//   return !hasError
// }
// baytDateValidatorAfterValidate = function (form, attr, msgs, hasError) {
//   var self = this
//   attr.config.find(function (config) {
//     if (config.fn === "baytDateValidator") {
//       var messages = {}
//       messages[attr.id] = msgs
//       self.updateInput(Object.assign({}, attr, { inputID: config.monthID }), messages)
//       self.updateInput(Object.assign({}, attr, { inputID: config.yearID }), messages)
//     }
//   })

//   // attr.config.find(function (config) {
//   //   if (config.fn === "baytDateValidator") {
//   //     //find the month dropdown and grab its value
//   //     B8.find('#' + config.monthID, function (m) {
//   //       hasError ? B8.addClass(attr.css.error, m) : B8.remClass(attr.css.error, m)
//   //     })
//   //     //find the year dropdown and grab its value
//   //     B8.find('#' + config.yearID, function (y) {
//   //       hasError ? B8.addClass(attr.css.error, y) : B8.remClass(attr.css.error, y)
//   //     })
//   //   }
//   // })

// }
var fileUrl;
var cropper , minCropBoxHeight =100,minCropBoxWidth =100;
function attachCropper(elm) {
	var form = elm.closest('form'),
  cropContainer= B8.get('[data-js-cropper]', form),
  files = []
  if(cropper){
    cropper.destroy()
    cropContainer.innerHTML = "";
  }
//init
  files = elm.files;
  if(files.length){
      if (fileUrl) {
      URL.revokeObjectURL(fileUrl);//revoke old url
    }
    fileUrl = URL.createObjectURL(files[0]);
    cropContainer.style.maxHeight = Math.max(200,minCropBoxHeight/2) + 'px';
    cropContainer.style.overflow = 'hidden';
    var img = document.createElement('img');
    img.src = fileUrl;
    cropContainer.appendChild(img);
    cropper = new Cropper(img, {
      autoCropArea: .5,
      aspectRatio: 1,
        viewMode: 1, // restrict the minimum canvas size to fill fit the container.
        guides: false,
        center: true,
        dragMode: 'move',
        cropBoxResizable: false,
        minCropBoxWidth: minCropBoxWidth/2,
        minCropBoxHeight: minCropBoxHeight/2,
        background: false,
      crop: function (e) {
        var json = {
            x: e.detail.x,
            y: e.detail.y,
            height: e.detail.height,
            width: e.detail.width,
            rotate: e.detail.rotate
        }
          let store = B8.get('[data-js-value]', form)
        if (store) {
          store.value = JSON.stringify(json)
        }
      }
    });
  }
}

var dependsOnCache = {
  'A': [
    {
      'value': 'A1',
      'text': 'Item A-1'
    },
    {
      'value': 'A2',
      'text': 'Item A-2'
    }
  ],
  'B': [
    {
      'value': 'B1',
      'text': 'Item B-1'
    },
    {
      'value': 'B2',
      'text': 'Item B-2'
    }
  ],
  'C': [
    {
      'value': 'C1',
      'text': 'Item C-1'
    },
    {
      'value': 'C2',
      'text': 'Item C-2'
    }
  ]
}, dependsOnItems = []

function fetchCascadedData(value, callback) {
  if (typeof value === "object") {
    //fetch
    setTimeout(function() {
      callback(dependsOnItems = dependsOnCache[value.value] || [], "")
    }, 100);
  } else {
    //fetch children
    callback(dependsOnItems.filter(function (v, i) {
      var rx = new RegExp(B8.escapeRegExp(value), 'ig')
      return v.text.match(rx) != null
    }) || [], value)
  }
}
