/*! BaytUI v1.59.0 */

var B8 =
/******/ (function(modules) { // webpackBootstrap
/******/ 	function hotDisposeChunk(chunkId) {
/******/ 		delete installedChunks[chunkId];
/******/ 	}
/******/ 	var parentHotUpdateCallback = window["webpackHotUpdate_name_"];
/******/ 	window["webpackHotUpdate_name_"] = 
/******/ 	function webpackHotUpdateCallback(chunkId, moreModules) { // eslint-disable-line no-unused-vars
/******/ 		hotAddUpdateChunk(chunkId, moreModules);
/******/ 		if(parentHotUpdateCallback) parentHotUpdateCallback(chunkId, moreModules);
/******/ 	} ;
/******/ 	
/******/ 	function hotDownloadUpdateChunk(chunkId) { // eslint-disable-line no-unused-vars
/******/ 		var head = document.getElementsByTagName("head")[0];
/******/ 		var script = document.createElement("script");
/******/ 		script.type = "text/javascript";
/******/ 		script.charset = "utf-8";
/******/ 		script.src = __webpack_require__.p + "" + chunkId + "." + hotCurrentHash + ".hot-update.js";
/******/ 		;
/******/ 		head.appendChild(script);
/******/ 	}
/******/ 	
/******/ 	function hotDownloadManifest(requestTimeout) { // eslint-disable-line no-unused-vars
/******/ 		requestTimeout = requestTimeout || 10000;
/******/ 		return new Promise(function(resolve, reject) {
/******/ 			if(typeof XMLHttpRequest === "undefined")
/******/ 				return reject(new Error("No browser support"));
/******/ 			try {
/******/ 				var request = new XMLHttpRequest();
/******/ 				var requestPath = __webpack_require__.p + "" + hotCurrentHash + ".hot-update.json";
/******/ 				request.open("GET", requestPath, true);
/******/ 				request.timeout = requestTimeout;
/******/ 				request.send(null);
/******/ 			} catch(err) {
/******/ 				return reject(err);
/******/ 			}
/******/ 			request.onreadystatechange = function() {
/******/ 				if(request.readyState !== 4) return;
/******/ 				if(request.status === 0) {
/******/ 					// timeout
/******/ 					reject(new Error("Manifest request to " + requestPath + " timed out."));
/******/ 				} else if(request.status === 404) {
/******/ 					// no update available
/******/ 					resolve();
/******/ 				} else if(request.status !== 200 && request.status !== 304) {
/******/ 					// other failure
/******/ 					reject(new Error("Manifest request to " + requestPath + " failed."));
/******/ 				} else {
/******/ 					// success
/******/ 					try {
/******/ 						var update = JSON.parse(request.responseText);
/******/ 					} catch(e) {
/******/ 						reject(e);
/******/ 						return;
/******/ 					}
/******/ 					resolve(update);
/******/ 				}
/******/ 			};
/******/ 		});
/******/ 	}
/******/
/******/ 	
/******/ 	
/******/ 	var hotApplyOnUpdate = true;
/******/ 	var hotCurrentHash = "f694bd51f71b2336ec09"; // eslint-disable-line no-unused-vars
/******/ 	var hotRequestTimeout = 10000;
/******/ 	var hotCurrentModuleData = {};
/******/ 	var hotCurrentChildModule; // eslint-disable-line no-unused-vars
/******/ 	var hotCurrentParents = []; // eslint-disable-line no-unused-vars
/******/ 	var hotCurrentParentsTemp = []; // eslint-disable-line no-unused-vars
/******/ 	
/******/ 	function hotCreateRequire(moduleId) { // eslint-disable-line no-unused-vars
/******/ 		var me = installedModules[moduleId];
/******/ 		if(!me) return __webpack_require__;
/******/ 		var fn = function(request) {
/******/ 			if(me.hot.active) {
/******/ 				if(installedModules[request]) {
/******/ 					if(installedModules[request].parents.indexOf(moduleId) < 0)
/******/ 						installedModules[request].parents.push(moduleId);
/******/ 				} else {
/******/ 					hotCurrentParents = [moduleId];
/******/ 					hotCurrentChildModule = request;
/******/ 				}
/******/ 				if(me.children.indexOf(request) < 0)
/******/ 					me.children.push(request);
/******/ 			} else {
/******/ 				console.warn("[HMR] unexpected require(" + request + ") from disposed module " + moduleId);
/******/ 				hotCurrentParents = [];
/******/ 			}
/******/ 			return __webpack_require__(request);
/******/ 		};
/******/ 		var ObjectFactory = function ObjectFactory(name) {
/******/ 			return {
/******/ 				configurable: true,
/******/ 				enumerable: true,
/******/ 				get: function() {
/******/ 					return __webpack_require__[name];
/******/ 				},
/******/ 				set: function(value) {
/******/ 					__webpack_require__[name] = value;
/******/ 				}
/******/ 			};
/******/ 		};
/******/ 		for(var name in __webpack_require__) {
/******/ 			if(Object.prototype.hasOwnProperty.call(__webpack_require__, name) && name !== "e") {
/******/ 				Object.defineProperty(fn, name, ObjectFactory(name));
/******/ 			}
/******/ 		}
/******/ 		fn.e = function(chunkId) {
/******/ 			if(hotStatus === "ready")
/******/ 				hotSetStatus("prepare");
/******/ 			hotChunksLoading++;
/******/ 			return __webpack_require__.e(chunkId).then(finishChunkLoading, function(err) {
/******/ 				finishChunkLoading();
/******/ 				throw err;
/******/ 			});
/******/ 	
/******/ 			function finishChunkLoading() {
/******/ 				hotChunksLoading--;
/******/ 				if(hotStatus === "prepare") {
/******/ 					if(!hotWaitingFilesMap[chunkId]) {
/******/ 						hotEnsureUpdateChunk(chunkId);
/******/ 					}
/******/ 					if(hotChunksLoading === 0 && hotWaitingFiles === 0) {
/******/ 						hotUpdateDownloaded();
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 		return fn;
/******/ 	}
/******/ 	
/******/ 	function hotCreateModule(moduleId) { // eslint-disable-line no-unused-vars
/******/ 		var hot = {
/******/ 			// private stuff
/******/ 			_acceptedDependencies: {},
/******/ 			_declinedDependencies: {},
/******/ 			_selfAccepted: false,
/******/ 			_selfDeclined: false,
/******/ 			_disposeHandlers: [],
/******/ 			_main: hotCurrentChildModule !== moduleId,
/******/ 	
/******/ 			// Module API
/******/ 			active: true,
/******/ 			accept: function(dep, callback) {
/******/ 				if(typeof dep === "undefined")
/******/ 					hot._selfAccepted = true;
/******/ 				else if(typeof dep === "function")
/******/ 					hot._selfAccepted = dep;
/******/ 				else if(typeof dep === "object")
/******/ 					for(var i = 0; i < dep.length; i++)
/******/ 						hot._acceptedDependencies[dep[i]] = callback || function() {};
/******/ 				else
/******/ 					hot._acceptedDependencies[dep] = callback || function() {};
/******/ 			},
/******/ 			decline: function(dep) {
/******/ 				if(typeof dep === "undefined")
/******/ 					hot._selfDeclined = true;
/******/ 				else if(typeof dep === "object")
/******/ 					for(var i = 0; i < dep.length; i++)
/******/ 						hot._declinedDependencies[dep[i]] = true;
/******/ 				else
/******/ 					hot._declinedDependencies[dep] = true;
/******/ 			},
/******/ 			dispose: function(callback) {
/******/ 				hot._disposeHandlers.push(callback);
/******/ 			},
/******/ 			addDisposeHandler: function(callback) {
/******/ 				hot._disposeHandlers.push(callback);
/******/ 			},
/******/ 			removeDisposeHandler: function(callback) {
/******/ 				var idx = hot._disposeHandlers.indexOf(callback);
/******/ 				if(idx >= 0) hot._disposeHandlers.splice(idx, 1);
/******/ 			},
/******/ 	
/******/ 			// Management API
/******/ 			check: hotCheck,
/******/ 			apply: hotApply,
/******/ 			status: function(l) {
/******/ 				if(!l) return hotStatus;
/******/ 				hotStatusHandlers.push(l);
/******/ 			},
/******/ 			addStatusHandler: function(l) {
/******/ 				hotStatusHandlers.push(l);
/******/ 			},
/******/ 			removeStatusHandler: function(l) {
/******/ 				var idx = hotStatusHandlers.indexOf(l);
/******/ 				if(idx >= 0) hotStatusHandlers.splice(idx, 1);
/******/ 			},
/******/ 	
/******/ 			//inherit from previous dispose call
/******/ 			data: hotCurrentModuleData[moduleId]
/******/ 		};
/******/ 		hotCurrentChildModule = undefined;
/******/ 		return hot;
/******/ 	}
/******/ 	
/******/ 	var hotStatusHandlers = [];
/******/ 	var hotStatus = "idle";
/******/ 	
/******/ 	function hotSetStatus(newStatus) {
/******/ 		hotStatus = newStatus;
/******/ 		for(var i = 0; i < hotStatusHandlers.length; i++)
/******/ 			hotStatusHandlers[i].call(null, newStatus);
/******/ 	}
/******/ 	
/******/ 	// while downloading
/******/ 	var hotWaitingFiles = 0;
/******/ 	var hotChunksLoading = 0;
/******/ 	var hotWaitingFilesMap = {};
/******/ 	var hotRequestedFilesMap = {};
/******/ 	var hotAvailableFilesMap = {};
/******/ 	var hotDeferred;
/******/ 	
/******/ 	// The update info
/******/ 	var hotUpdate, hotUpdateNewHash;
/******/ 	
/******/ 	function toModuleId(id) {
/******/ 		var isNumber = (+id) + "" === id;
/******/ 		return isNumber ? +id : id;
/******/ 	}
/******/ 	
/******/ 	function hotCheck(apply) {
/******/ 		if(hotStatus !== "idle") throw new Error("check() is only allowed in idle status");
/******/ 		hotApplyOnUpdate = apply;
/******/ 		hotSetStatus("check");
/******/ 		return hotDownloadManifest(hotRequestTimeout).then(function(update) {
/******/ 			if(!update) {
/******/ 				hotSetStatus("idle");
/******/ 				return null;
/******/ 			}
/******/ 			hotRequestedFilesMap = {};
/******/ 			hotWaitingFilesMap = {};
/******/ 			hotAvailableFilesMap = update.c;
/******/ 			hotUpdateNewHash = update.h;
/******/ 	
/******/ 			hotSetStatus("prepare");
/******/ 			var promise = new Promise(function(resolve, reject) {
/******/ 				hotDeferred = {
/******/ 					resolve: resolve,
/******/ 					reject: reject
/******/ 				};
/******/ 			});
/******/ 			hotUpdate = {};
/******/ 			var chunkId = 0;
/******/ 			{ // eslint-disable-line no-lone-blocks
/******/ 				/*globals chunkId */
/******/ 				hotEnsureUpdateChunk(chunkId);
/******/ 			}
/******/ 			if(hotStatus === "prepare" && hotChunksLoading === 0 && hotWaitingFiles === 0) {
/******/ 				hotUpdateDownloaded();
/******/ 			}
/******/ 			return promise;
/******/ 		});
/******/ 	}
/******/ 	
/******/ 	function hotAddUpdateChunk(chunkId, moreModules) { // eslint-disable-line no-unused-vars
/******/ 		if(!hotAvailableFilesMap[chunkId] || !hotRequestedFilesMap[chunkId])
/******/ 			return;
/******/ 		hotRequestedFilesMap[chunkId] = false;
/******/ 		for(var moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				hotUpdate[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(--hotWaitingFiles === 0 && hotChunksLoading === 0) {
/******/ 			hotUpdateDownloaded();
/******/ 		}
/******/ 	}
/******/ 	
/******/ 	function hotEnsureUpdateChunk(chunkId) {
/******/ 		if(!hotAvailableFilesMap[chunkId]) {
/******/ 			hotWaitingFilesMap[chunkId] = true;
/******/ 		} else {
/******/ 			hotRequestedFilesMap[chunkId] = true;
/******/ 			hotWaitingFiles++;
/******/ 			hotDownloadUpdateChunk(chunkId);
/******/ 		}
/******/ 	}
/******/ 	
/******/ 	function hotUpdateDownloaded() {
/******/ 		hotSetStatus("ready");
/******/ 		var deferred = hotDeferred;
/******/ 		hotDeferred = null;
/******/ 		if(!deferred) return;
/******/ 		if(hotApplyOnUpdate) {
/******/ 			// Wrap deferred object in Promise to mark it as a well-handled Promise to
/******/ 			// avoid triggering uncaught exception warning in Chrome.
/******/ 			// See https://bugs.chromium.org/p/chromium/issues/detail?id=465666
/******/ 			Promise.resolve().then(function() {
/******/ 				return hotApply(hotApplyOnUpdate);
/******/ 			}).then(
/******/ 				function(result) {
/******/ 					deferred.resolve(result);
/******/ 				},
/******/ 				function(err) {
/******/ 					deferred.reject(err);
/******/ 				}
/******/ 			);
/******/ 		} else {
/******/ 			var outdatedModules = [];
/******/ 			for(var id in hotUpdate) {
/******/ 				if(Object.prototype.hasOwnProperty.call(hotUpdate, id)) {
/******/ 					outdatedModules.push(toModuleId(id));
/******/ 				}
/******/ 			}
/******/ 			deferred.resolve(outdatedModules);
/******/ 		}
/******/ 	}
/******/ 	
/******/ 	function hotApply(options) {
/******/ 		if(hotStatus !== "ready") throw new Error("apply() is only allowed in ready status");
/******/ 		options = options || {};
/******/ 	
/******/ 		var cb;
/******/ 		var i;
/******/ 		var j;
/******/ 		var module;
/******/ 		var moduleId;
/******/ 	
/******/ 		function getAffectedStuff(updateModuleId) {
/******/ 			var outdatedModules = [updateModuleId];
/******/ 			var outdatedDependencies = {};
/******/ 	
/******/ 			var queue = outdatedModules.slice().map(function(id) {
/******/ 				return {
/******/ 					chain: [id],
/******/ 					id: id
/******/ 				};
/******/ 			});
/******/ 			while(queue.length > 0) {
/******/ 				var queueItem = queue.pop();
/******/ 				var moduleId = queueItem.id;
/******/ 				var chain = queueItem.chain;
/******/ 				module = installedModules[moduleId];
/******/ 				if(!module || module.hot._selfAccepted)
/******/ 					continue;
/******/ 				if(module.hot._selfDeclined) {
/******/ 					return {
/******/ 						type: "self-declined",
/******/ 						chain: chain,
/******/ 						moduleId: moduleId
/******/ 					};
/******/ 				}
/******/ 				if(module.hot._main) {
/******/ 					return {
/******/ 						type: "unaccepted",
/******/ 						chain: chain,
/******/ 						moduleId: moduleId
/******/ 					};
/******/ 				}
/******/ 				for(var i = 0; i < module.parents.length; i++) {
/******/ 					var parentId = module.parents[i];
/******/ 					var parent = installedModules[parentId];
/******/ 					if(!parent) continue;
/******/ 					if(parent.hot._declinedDependencies[moduleId]) {
/******/ 						return {
/******/ 							type: "declined",
/******/ 							chain: chain.concat([parentId]),
/******/ 							moduleId: moduleId,
/******/ 							parentId: parentId
/******/ 						};
/******/ 					}
/******/ 					if(outdatedModules.indexOf(parentId) >= 0) continue;
/******/ 					if(parent.hot._acceptedDependencies[moduleId]) {
/******/ 						if(!outdatedDependencies[parentId])
/******/ 							outdatedDependencies[parentId] = [];
/******/ 						addAllToSet(outdatedDependencies[parentId], [moduleId]);
/******/ 						continue;
/******/ 					}
/******/ 					delete outdatedDependencies[parentId];
/******/ 					outdatedModules.push(parentId);
/******/ 					queue.push({
/******/ 						chain: chain.concat([parentId]),
/******/ 						id: parentId
/******/ 					});
/******/ 				}
/******/ 			}
/******/ 	
/******/ 			return {
/******/ 				type: "accepted",
/******/ 				moduleId: updateModuleId,
/******/ 				outdatedModules: outdatedModules,
/******/ 				outdatedDependencies: outdatedDependencies
/******/ 			};
/******/ 		}
/******/ 	
/******/ 		function addAllToSet(a, b) {
/******/ 			for(var i = 0; i < b.length; i++) {
/******/ 				var item = b[i];
/******/ 				if(a.indexOf(item) < 0)
/******/ 					a.push(item);
/******/ 			}
/******/ 		}
/******/ 	
/******/ 		// at begin all updates modules are outdated
/******/ 		// the "outdated" status can propagate to parents if they don't accept the children
/******/ 		var outdatedDependencies = {};
/******/ 		var outdatedModules = [];
/******/ 		var appliedUpdate = {};
/******/ 	
/******/ 		var warnUnexpectedRequire = function warnUnexpectedRequire() {
/******/ 			console.warn("[HMR] unexpected require(" + result.moduleId + ") to disposed module");
/******/ 		};
/******/ 	
/******/ 		for(var id in hotUpdate) {
/******/ 			if(Object.prototype.hasOwnProperty.call(hotUpdate, id)) {
/******/ 				moduleId = toModuleId(id);
/******/ 				var result;
/******/ 				if(hotUpdate[id]) {
/******/ 					result = getAffectedStuff(moduleId);
/******/ 				} else {
/******/ 					result = {
/******/ 						type: "disposed",
/******/ 						moduleId: id
/******/ 					};
/******/ 				}
/******/ 				var abortError = false;
/******/ 				var doApply = false;
/******/ 				var doDispose = false;
/******/ 				var chainInfo = "";
/******/ 				if(result.chain) {
/******/ 					chainInfo = "\nUpdate propagation: " + result.chain.join(" -> ");
/******/ 				}
/******/ 				switch(result.type) {
/******/ 					case "self-declined":
/******/ 						if(options.onDeclined)
/******/ 							options.onDeclined(result);
/******/ 						if(!options.ignoreDeclined)
/******/ 							abortError = new Error("Aborted because of self decline: " + result.moduleId + chainInfo);
/******/ 						break;
/******/ 					case "declined":
/******/ 						if(options.onDeclined)
/******/ 							options.onDeclined(result);
/******/ 						if(!options.ignoreDeclined)
/******/ 							abortError = new Error("Aborted because of declined dependency: " + result.moduleId + " in " + result.parentId + chainInfo);
/******/ 						break;
/******/ 					case "unaccepted":
/******/ 						if(options.onUnaccepted)
/******/ 							options.onUnaccepted(result);
/******/ 						if(!options.ignoreUnaccepted)
/******/ 							abortError = new Error("Aborted because " + moduleId + " is not accepted" + chainInfo);
/******/ 						break;
/******/ 					case "accepted":
/******/ 						if(options.onAccepted)
/******/ 							options.onAccepted(result);
/******/ 						doApply = true;
/******/ 						break;
/******/ 					case "disposed":
/******/ 						if(options.onDisposed)
/******/ 							options.onDisposed(result);
/******/ 						doDispose = true;
/******/ 						break;
/******/ 					default:
/******/ 						throw new Error("Unexception type " + result.type);
/******/ 				}
/******/ 				if(abortError) {
/******/ 					hotSetStatus("abort");
/******/ 					return Promise.reject(abortError);
/******/ 				}
/******/ 				if(doApply) {
/******/ 					appliedUpdate[moduleId] = hotUpdate[moduleId];
/******/ 					addAllToSet(outdatedModules, result.outdatedModules);
/******/ 					for(moduleId in result.outdatedDependencies) {
/******/ 						if(Object.prototype.hasOwnProperty.call(result.outdatedDependencies, moduleId)) {
/******/ 							if(!outdatedDependencies[moduleId])
/******/ 								outdatedDependencies[moduleId] = [];
/******/ 							addAllToSet(outdatedDependencies[moduleId], result.outdatedDependencies[moduleId]);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 				if(doDispose) {
/******/ 					addAllToSet(outdatedModules, [result.moduleId]);
/******/ 					appliedUpdate[moduleId] = warnUnexpectedRequire;
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 	
/******/ 		// Store self accepted outdated modules to require them later by the module system
/******/ 		var outdatedSelfAcceptedModules = [];
/******/ 		for(i = 0; i < outdatedModules.length; i++) {
/******/ 			moduleId = outdatedModules[i];
/******/ 			if(installedModules[moduleId] && installedModules[moduleId].hot._selfAccepted)
/******/ 				outdatedSelfAcceptedModules.push({
/******/ 					module: moduleId,
/******/ 					errorHandler: installedModules[moduleId].hot._selfAccepted
/******/ 				});
/******/ 		}
/******/ 	
/******/ 		// Now in "dispose" phase
/******/ 		hotSetStatus("dispose");
/******/ 		Object.keys(hotAvailableFilesMap).forEach(function(chunkId) {
/******/ 			if(hotAvailableFilesMap[chunkId] === false) {
/******/ 				hotDisposeChunk(chunkId);
/******/ 			}
/******/ 		});
/******/ 	
/******/ 		var idx;
/******/ 		var queue = outdatedModules.slice();
/******/ 		while(queue.length > 0) {
/******/ 			moduleId = queue.pop();
/******/ 			module = installedModules[moduleId];
/******/ 			if(!module) continue;
/******/ 	
/******/ 			var data = {};
/******/ 	
/******/ 			// Call dispose handlers
/******/ 			var disposeHandlers = module.hot._disposeHandlers;
/******/ 			for(j = 0; j < disposeHandlers.length; j++) {
/******/ 				cb = disposeHandlers[j];
/******/ 				cb(data);
/******/ 			}
/******/ 			hotCurrentModuleData[moduleId] = data;
/******/ 	
/******/ 			// disable module (this disables requires from this module)
/******/ 			module.hot.active = false;
/******/ 	
/******/ 			// remove module from cache
/******/ 			delete installedModules[moduleId];
/******/ 	
/******/ 			// when disposing there is no need to call dispose handler
/******/ 			delete outdatedDependencies[moduleId];
/******/ 	
/******/ 			// remove "parents" references from all children
/******/ 			for(j = 0; j < module.children.length; j++) {
/******/ 				var child = installedModules[module.children[j]];
/******/ 				if(!child) continue;
/******/ 				idx = child.parents.indexOf(moduleId);
/******/ 				if(idx >= 0) {
/******/ 					child.parents.splice(idx, 1);
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 	
/******/ 		// remove outdated dependency from module children
/******/ 		var dependency;
/******/ 		var moduleOutdatedDependencies;
/******/ 		for(moduleId in outdatedDependencies) {
/******/ 			if(Object.prototype.hasOwnProperty.call(outdatedDependencies, moduleId)) {
/******/ 				module = installedModules[moduleId];
/******/ 				if(module) {
/******/ 					moduleOutdatedDependencies = outdatedDependencies[moduleId];
/******/ 					for(j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 						dependency = moduleOutdatedDependencies[j];
/******/ 						idx = module.children.indexOf(dependency);
/******/ 						if(idx >= 0) module.children.splice(idx, 1);
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 	
/******/ 		// Not in "apply" phase
/******/ 		hotSetStatus("apply");
/******/ 	
/******/ 		hotCurrentHash = hotUpdateNewHash;
/******/ 	
/******/ 		// insert new code
/******/ 		for(moduleId in appliedUpdate) {
/******/ 			if(Object.prototype.hasOwnProperty.call(appliedUpdate, moduleId)) {
/******/ 				modules[moduleId] = appliedUpdate[moduleId];
/******/ 			}
/******/ 		}
/******/ 	
/******/ 		// call accept handlers
/******/ 		var error = null;
/******/ 		for(moduleId in outdatedDependencies) {
/******/ 			if(Object.prototype.hasOwnProperty.call(outdatedDependencies, moduleId)) {
/******/ 				module = installedModules[moduleId];
/******/ 				if(module) {
/******/ 					moduleOutdatedDependencies = outdatedDependencies[moduleId];
/******/ 					var callbacks = [];
/******/ 					for(i = 0; i < moduleOutdatedDependencies.length; i++) {
/******/ 						dependency = moduleOutdatedDependencies[i];
/******/ 						cb = module.hot._acceptedDependencies[dependency];
/******/ 						if(cb) {
/******/ 							if(callbacks.indexOf(cb) >= 0) continue;
/******/ 							callbacks.push(cb);
/******/ 						}
/******/ 					}
/******/ 					for(i = 0; i < callbacks.length; i++) {
/******/ 						cb = callbacks[i];
/******/ 						try {
/******/ 							cb(moduleOutdatedDependencies);
/******/ 						} catch(err) {
/******/ 							if(options.onErrored) {
/******/ 								options.onErrored({
/******/ 									type: "accept-errored",
/******/ 									moduleId: moduleId,
/******/ 									dependencyId: moduleOutdatedDependencies[i],
/******/ 									error: err
/******/ 								});
/******/ 							}
/******/ 							if(!options.ignoreErrored) {
/******/ 								if(!error)
/******/ 									error = err;
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 	
/******/ 		// Load self accepted modules
/******/ 		for(i = 0; i < outdatedSelfAcceptedModules.length; i++) {
/******/ 			var item = outdatedSelfAcceptedModules[i];
/******/ 			moduleId = item.module;
/******/ 			hotCurrentParents = [moduleId];
/******/ 			try {
/******/ 				__webpack_require__(moduleId);
/******/ 			} catch(err) {
/******/ 				if(typeof item.errorHandler === "function") {
/******/ 					try {
/******/ 						item.errorHandler(err);
/******/ 					} catch(err2) {
/******/ 						if(options.onErrored) {
/******/ 							options.onErrored({
/******/ 								type: "self-accept-error-handler-errored",
/******/ 								moduleId: moduleId,
/******/ 								error: err2,
/******/ 								orginalError: err, // TODO remove in webpack 4
/******/ 								originalError: err
/******/ 							});
/******/ 						}
/******/ 						if(!options.ignoreErrored) {
/******/ 							if(!error)
/******/ 								error = err2;
/******/ 						}
/******/ 						if(!error)
/******/ 							error = err;
/******/ 					}
/******/ 				} else {
/******/ 					if(options.onErrored) {
/******/ 						options.onErrored({
/******/ 							type: "self-accept-errored",
/******/ 							moduleId: moduleId,
/******/ 							error: err
/******/ 						});
/******/ 					}
/******/ 					if(!options.ignoreErrored) {
/******/ 						if(!error)
/******/ 							error = err;
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 	
/******/ 		// handle errors in accept handlers and self accepted module load
/******/ 		if(error) {
/******/ 			hotSetStatus("fail");
/******/ 			return Promise.reject(error);
/******/ 		}
/******/ 	
/******/ 		hotSetStatus("idle");
/******/ 		return new Promise(function(resolve) {
/******/ 			resolve(outdatedModules);
/******/ 		});
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {},
/******/ 			hot: hotCreateModule(moduleId),
/******/ 			parents: (hotCurrentParentsTemp = hotCurrentParents, hotCurrentParents = [], hotCurrentParentsTemp),
/******/ 			children: []
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, hotCreateRequire(moduleId));
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// __webpack_hash__
/******/ 	__webpack_require__.h = function() { return hotCurrentHash; };
/******/
/******/ 	// Load entry module and return exports
/******/ 	return hotCreateRequire(43)(__webpack_require__.s = 43);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (immutable) */ __webpack_exports__["debounce"] = debounce;
/* harmony export (immutable) */ __webpack_exports__["throttle"] = throttle;
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NOOP", function() { return NOOP; });
/* harmony export (immutable) */ __webpack_exports__["isBool"] = isBool;
/* harmony export (immutable) */ __webpack_exports__["isObj"] = isObj;
/* harmony export (immutable) */ __webpack_exports__["isNum"] = isNum;
/* harmony export (immutable) */ __webpack_exports__["isStr"] = isStr;
/* harmony export (immutable) */ __webpack_exports__["isFn"] = isFn;
/* harmony export (immutable) */ __webpack_exports__["isPlainObj"] = isPlainObj;
/* harmony export (immutable) */ __webpack_exports__["isArray"] = isArray;
/* harmony export (immutable) */ __webpack_exports__["merge"] = merge;
/* harmony export (immutable) */ __webpack_exports__["resolveVal"] = resolveVal;
/* harmony export (immutable) */ __webpack_exports__["resolveFn"] = resolveFn;
/* harmony export (immutable) */ __webpack_exports__["groupBy"] = groupBy;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__ajax__ = __webpack_require__(47);
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "ajaxSetup", function() { return __WEBPACK_IMPORTED_MODULE_0__ajax__["b"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "ajax", function() { return __WEBPACK_IMPORTED_MODULE_0__ajax__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__events__ = __webpack_require__(48);
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "createEventStrore", function() { return __WEBPACK_IMPORTED_MODULE_1__events__["b"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "attachEvent", function() { return __WEBPACK_IMPORTED_MODULE_1__events__["a"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "detachEvent", function() { return __WEBPACK_IMPORTED_MODULE_1__events__["d"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "detachAllEvents", function() { return __WEBPACK_IMPORTED_MODULE_1__events__["c"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "dispatchEvent", function() { return __WEBPACK_IMPORTED_MODULE_1__events__["e"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "dispatchHooks", function() { return __WEBPACK_IMPORTED_MODULE_1__events__["f"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__dom__ = __webpack_require__(49);
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "isIE", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["m"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "readConfig", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["u"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "htmlToElement", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["i"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "clearChildren", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["d"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "prependElement", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["s"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "replaceElement", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["x"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "wrapElement", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["C"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "isTouch", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["o"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "isMobile", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["n"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "getScrollTop", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["h"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "getScrollLeft", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["g"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "saveScrollPosition", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["z"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "restoreScrollPosition", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["y"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "preventBodyShift", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["t"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "inView", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["j"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "bringIntoView", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["c"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "scrollIntoView", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["A"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "get", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["f"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "find", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["e"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "traverse", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["B"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "isVisible", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["p"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "addClasses", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["b"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "remClasses", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["w"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "addClass", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["a"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "remClass", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["v"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "movClasses", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["r"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "loadDeferredStyles", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["q"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "init", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["k"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "inject", function() { return __WEBPACK_IMPORTED_MODULE_2__dom__["l"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__keys__ = __webpack_require__(50);
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "KEYS", function() { return __WEBPACK_IMPORTED_MODULE_3__keys__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__regexp__ = __webpack_require__(51);
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "escapeRegExp", function() { return __WEBPACK_IMPORTED_MODULE_4__regexp__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__serialize__ = __webpack_require__(38);
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "PARAMS", function() { return __WEBPACK_IMPORTED_MODULE_5__serialize__["a"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "serializeArray", function() { return __WEBPACK_IMPORTED_MODULE_5__serialize__["c"]; });
/* harmony namespace reexport (by provided) */ __webpack_require__.d(__webpack_exports__, "serialize", function() { return __WEBPACK_IMPORTED_MODULE_5__serialize__["b"]; });
// @ts-check







/**
 * Returns a function, that, as long as it continues to be invoked, will not
 * be triggered until wait has passed.
 */
function debounce(func, wait) {
  var timeout = void 0;
  return function () {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    var context = this;
    clearTimeout(timeout);
    timeout = setTimeout(function () {
      return func.apply(context, args);
    }, +wait);
  };
}

/**
 * Returns a function, that, as long as it continues to be invoked, will be
 * triggered triggered once per wait time.
 */
function throttle(func, wait) {
  var timeout = void 0;
  return function () {
    for (var _len2 = arguments.length, args = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
      args[_key2] = arguments[_key2];
    }

    var context = this;
    if (!timeout) {
      timeout = setTimeout(function () {
        func.apply(context, args);
        timeout = null;
      }, +wait);
    }
  };
}

/**
 * Returns an empty function that does nothing.
 */
var NOOP = function () {};

/**
 * Returns true if the passed argument is of type boolean, false otherwise.
 *
 * @param {any} arg The variable to check
 */
function isBool(arg) {
  return typeof arg === 'boolean';
}

/**
 * Returns true if the passed argument is of type object, false otherwise.
 *
 * @param {any} arg The variable to check
 */
function isObj(arg) {
  // important: typeof null yields 'object'
  return arg !== null && typeof arg === 'object';
}

/**
 * Returns true if the passed argument is of type number, false otherwise.
 *
 * @param {any} arg The variable to check
 */
function isNum(arg) {
  return typeof arg === 'number';
}

/**
 * Returns true if the passed argument is of type string, false otherwise.
 *
 * @param {any} arg The variable to check
 */
function isStr(arg) {
  return typeof arg === 'string';
}

/**
 * Returns true if the passed argument is of type function, false otherwise.
 *
 * @param {any} arg The variable to check
 */
function isFn(arg) {
  return typeof arg === 'function';
}

/**
 * Returns true if the passed argument is a plain javascript object.
 *
 * @param {any} arg The object to check
 */
function isPlainObj(arg) {
  var proto = void 0,
      Ctor = void 0;
  var ownProp = window.hasOwnProperty,
      ownPropToStr = ownProp.toString,
      toString = {}.toString;
  // Detect obvious negatives
  // Use toString instead of jQuery.type to catch host objects
  if (!arg || toString.call(arg) !== "[object Object]") {
    return false;
  }

  proto = Object.getPrototypeOf(arg);

  // Objects with no prototype (e.g., `Object.create( null )`) are plain
  if (!proto) {
    return true;
  }

  // Objects with prototype are plain iff they were constructed by a global Object function
  Ctor = ownProp.call(proto, "constructor") && proto.constructor;
  return typeof Ctor === "function" && ownPropToStr.call(Ctor) === ownPropToStr.call(Object);
}

/**
 * Returns true if the passed argument is an array.
 * @param {any} arg The array to check
 */
function isArray(arg) {
  return Array.isArray ? Array.isArray(arg) : arg instanceof Array;
}

/**
 * Merge the contents of two or more objects together into the first object.
 *
 * Pass true as first parameter to perform a deep merge
 */
function merge() {
  var options = void 0,
      name = void 0,
      src = void 0,
      copy = void 0,
      copyIsArray = void 0,
      clone = void 0,
      target = arguments[0],
      i = 1,
      length = arguments.length,
      deep = false,
      recurseArrays = true;

  // Handle a deep copy situation
  if (typeof target === "boolean") {
    recurseArrays = target;
    deep = true;

    // Skip the boolean and the target
    target = arguments[i] || {};
    i++;
  }

  // Handle case when target is a string or something (possible in deep copy)
  if (typeof target !== "object" && !isFn(target)) {
    target = {};
  }

  // // Extend B8 itself if only one argument is passed
  // if (i === length) {
  //   target = this;
  //   i--;
  // }

  for (; i < length; i++) {

    // Only deal with non-null/undefined values
    if ((options = arguments[i]) != null) {

      // Extend the base object
      for (name in options) {
        src = target[name];
        copy = options[name];

        // Prevent never-ending loop
        if (target === copy) {
          continue;
        }

        // Recurse if we're merging plain objects or arrays
        if (deep && copy && (isPlainObj(copy) || recurseArrays && (copyIsArray = Array.isArray(copy)))) {

          if (copyIsArray) {
            copyIsArray = false;
            clone = src && Array.isArray(src) ? src : [];
          } else {
            clone = src && isPlainObj(src) ? src : {};
          }

          // Never move original objects, clone them
          target[name] = merge(deep && recurseArrays, clone, copy);

          // Don't bring in undefined values
        } else if (copy !== undefined) {
          target[name] = copy;
        }
      }
    }
  }

  // Return the modified object
  return target;
}

/**
 * Resolves a value from a given scope based on the provided path.
 *
 * @param {any} scope The scope to resolve the value from.
 * @param {String} path The path leading to the value.
 * @param {Boolean} exact Defines whether to traverse the path or use it as is.
 */
function resolveVal(scope, path) {
  var exact = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

  if (exact) {
    return scope[path];
  } else {
    var parts = path.split('.'),
        index = 0;
    var result = scope[parts[index++]];
    while (result && index < parts.length) {
      result = result[parts[index++]];
    }
    return result;
  }
}
/**
 * Resolves a function from scope
 *
 * @param {any} arg The function to resolve.
 * @param {Function} fallback The fallback function to return in case it was not found.
 * @param {Object} scope  The scope to resolve the function from - defaults to window.
 * @param {Boolean} exact Defines whether to traverse the path or use it as is (in case of a string arg).
 */
function resolveFn(arg, fallback) {
  var scope = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : window;
  var exact = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;

  if (isFn(arg)) {
    return arg;
  } else if (isStr(arg)) {
    var result = resolveVal(scope, arg, exact);
    return isFn(result) ? result : resolveFn(result, fallback);
  }
  return fallback;
}

/**
 * Helper to group a dataset of records based on a given key.
 *
 * @param {Array} dataset The records array
 * @param {String} key The group by key
 */
function groupBy(dataset, key) {
  return dataset.reduce(function (result, record) {
    var groupKey = record[key] || '';(result[groupKey] = result[groupKey] || []).push(record);
    return result;
  }, {});
}

/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UIControl; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__control__ = __webpack_require__(33);
var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }





var bindTarget = function (element, type, attribute) {
  var instance = __WEBPACK_IMPORTED_MODULE_0__data_registry__["d" /* resolve */](type, element);
  if (!instance) {
    var config = __WEBPACK_IMPORTED_MODULE_1__utils_main__["readConfig"](element, attribute);
    new type(element, config);
  }
};

var UIControl = function (_Control) {
  _inherits(UIControl, _Control);

  _createClass(UIControl, null, [{
    key: '$init',
    value: function $init(target, type) {
      // see if target does match the selector
      var attribute = 'data-' + type.__TYPE__;
      var selector = '[' + attribute + ']';

      if (target && target.matches && target.matches(selector)) {
        bindTarget(target, type, attribute);
      }
      // find elements matching selector
      __WEBPACK_IMPORTED_MODULE_1__utils_main__["find"](selector, function (element) {
        bindTarget(element, type, attribute);
      }, target);
    }
    /**
     * Helper for initializing module helpers.
     *
     * @param {HTMLElement} container
     * @param {String} type
     * @param {Function} init
     * @param {Any} options
     *     query: CSS query to use instead of searching for data attribute. i.e. `.msg-close`
     *     tag: HTML tag to prefix the data attribute with. i.e. img[data-src]
     *     remove: whether to remove the data attribute after init or not.
     */

  }, {
    key: '$initHelper',
    value: function $initHelper(container, type, init) {
      var _ref = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {},
          _ref$query = _ref.query,
          query = _ref$query === undefined ? false : _ref$query,
          _ref$tag = _ref.tag,
          tag = _ref$tag === undefined ? false : _ref$tag,
          _ref$remove = _ref.remove,
          remove = _ref$remove === undefined ? true : _ref$remove;

      var attribute = 'data-' + type,
          selector = query || (tag || '') + '[' + attribute + ']',
          bound = attribute + '-b8';
      // loop over elements
      __WEBPACK_IMPORTED_MODULE_1__utils_main__["find"](selector, function (element) {
        if (!element.attr(bound)) {
          // read config
          var config = __WEBPACK_IMPORTED_MODULE_1__utils_main__["readConfig"](element, attribute);
          if (config) {
            //mark as bound to prevent re-initialization
            if (remove) {
              element.removeAttribute(attribute);
            }
            if (query || !remove) {
              //mark as bound to prevent re-initialization
              element.attr(bound, true);
            }
            init(element, config);
          }
        }
      }, container);
    }

    /**
     * Initializes a new Control instance
     */

  }]);

  function UIControl(element) {
    var config = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck(this, UIControl);

    var _this = _possibleConstructorReturn(this, (UIControl.__proto__ || Object.getPrototypeOf(UIControl)).call(this, config));

    Object.assign(_this._, {
      id: __WEBPACK_IMPORTED_MODULE_0__data_registry__["b" /* newID */](),
      el: element,
      dispatching: true
    });
    __WEBPACK_IMPORTED_MODULE_0__data_registry__["c" /* register */](_this);
    return _this;
  }

  /**
   * Gets the id of this instance.
   */


  _createClass(UIControl, [{
    key: 'dispose',


    /**
     * Disposes this UIControl
     */
    value: function dispose() {
      __WEBPACK_IMPORTED_MODULE_0__data_registry__["e" /* unregister */](this);
      _get(UIControl.prototype.__proto__ || Object.getPrototypeOf(UIControl.prototype), 'dispose', this).call(this);
    }
  }, {
    key: 'id',
    get: function () {
      return this._.id;
    }

    /**
     * Gets the associated HTMLElement.
     */

  }, {
    key: 'el',
    get: function () {
      return this._.el;
    }

    /**
     * Gets the instance configuration.
     */

  }, {
    key: 'config',
    get: function () {
      return this._.cfg;
    }

    /**
     * Gets if the element should dispatch hooks or events
     */

  }, {
    key: 'dispatching',
    get: function () {
      return !!this._.dispatching;
    }
    /**
     * Sets if the element should dispatch hooks or events
     */
    ,
    set: function (value) {
      this._.dispatching = value;
    }
  }]);

  return UIControl;
}(__WEBPACK_IMPORTED_MODULE_2__control__["a" /* Control */]);

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = SET__TYPE__;
/* unused harmony export GET__TYPE__ */
/* harmony export (immutable) */ __webpack_exports__["b"] = newID;
/* harmony export (immutable) */ __webpack_exports__["c"] = register;
/* harmony export (immutable) */ __webpack_exports__["e"] = unregister;
/* unused harmony export find */
/* harmony export (immutable) */ __webpack_exports__["d"] = resolve;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);

var _idCounter = 0;
var _registry = {};

/**
 * Grabs exports keys and assign them to exports
 * for later use with instances registry.
 * @param {Object} type The exported type.
 * @param {string} name The exported type name
 */
function SET__TYPE__(type, name) {
  type.__TYPE__ = name;
  // for (let key in moduleExports) {
  //   moduleExports[key].__TYPE__ = key.toLowerCase()
  // }
}

/**
 * Grabs exports keys and assign them to exports
 * for later use with instances registry.
 * @param {Object} instance The instance to get type from
  */
function GET__TYPE__(instance) {
  return instance.__TYPE__ || instance.constructor.__TYPE__ || 'unknown';
}

/**
 * Generate a new integer ID
 */
function newID() {
  return ++_idCounter;
}

/**
 * Register a control instance to be resolavable.
 *
 * @param {UIControl} instance The control to register.
 */
function register(instance) {
  // if no registry for this type, create one.
  var type = GET__TYPE__(instance);
  if (!_registry.hasOwnProperty(type)) {
    _registry[type] = {};
  }
  // check if already registered
  if (_registry[type].hasOwnProperty(instance.id)) {
    console.error('Instance with id \'' + id + '\' is already registered.');
  } else {
    // add to registery
    _registry[type][instance.id] = instance;
    // link to DOM
    instance.el.setAttribute('data-bayt-' + type, instance.id);
  }
}

/**
 * Unregisters the control instance.
 *
 * @param {UIControl} instance The control to unregister.
 */
function unregister(instance) {
  var type = GET__TYPE__(instance);
  if (_registry.hasOwnProperty(type) && _registry[type].hasOwnProperty(instance.id)) {
    _registry[type][instance.id].el.removeAttribute('data-bayt-' + type);
    delete _registry[type][instance.id];
  }
}

/**
 * Finds a given control instance by searching the type registery for the provided ID.
 *
 * @param {string} type The registry type
 * @param {number} id The instance id.
 */
function find(type, id) {
  return _registry[type] && _registry[type][id];
}

/**
 * Resolves the instance linked to the provided element.
 *
 * @param {Class | String} type The type of the instance to resolve.
 * @param {HTMLElement | String} element The element or selector of the element to resolve the instance on.
 */
function resolve(type, element) {
  if (Object(__WEBPACK_IMPORTED_MODULE_0__utils_main__["isFn"])(type)) {
    type = GET__TYPE__(type);
  }

  if (Object(__WEBPACK_IMPORTED_MODULE_0__utils_main__["isStr"])(element)) {
    element = Object(__WEBPACK_IMPORTED_MODULE_0__utils_main__["get"])(element);
  }

  var id = element && element.getAttribute('data-bayt-' + type);
  return id && _registry[type] && _registry[type][id];
}

/***/ }),
/* 3 */
/***/ (function(module, exports) {

var logLevel = "info";

function dummy() {}

function shouldLog(level) {
	var shouldLog = (logLevel === "info" && level === "info") ||
		(["info", "warning"].indexOf(logLevel) >= 0 && level === "warning") ||
		(["info", "warning", "error"].indexOf(logLevel) >= 0 && level === "error");
	return shouldLog;
}

function logGroup(logFn) {
	return function(level, msg) {
		if(shouldLog(level)) {
			logFn(msg);
		}
	};
}

module.exports = function(level, msg) {
	if(shouldLog(level)) {
		if(level === "info") {
			console.log(msg);
		} else if(level === "warning") {
			console.warn(msg);
		} else if(level === "error") {
			console.error(msg);
		}
	}
};

var group = console.group || dummy;
var groupCollapsed = console.groupCollapsed || dummy;
var groupEnd = console.groupEnd || dummy;

module.exports.group = logGroup(group);

module.exports.groupCollapsed = logGroup(groupCollapsed);

module.exports.groupEnd = logGroup(groupEnd);

module.exports.setLogLevel = function(level) {
	logLevel = level;
};


/***/ }),
/* 4 */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || Function("return this")() || (1,eval)("this");
} catch(e) {
	// This works if the window reference is available
	if(typeof window === "object")
		g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),
/* 5 */
/***/ (function(module, exports) {

var ENTITIES = [['Aacute', [193]], ['aacute', [225]], ['Abreve', [258]], ['abreve', [259]], ['ac', [8766]], ['acd', [8767]], ['acE', [8766, 819]], ['Acirc', [194]], ['acirc', [226]], ['acute', [180]], ['Acy', [1040]], ['acy', [1072]], ['AElig', [198]], ['aelig', [230]], ['af', [8289]], ['Afr', [120068]], ['afr', [120094]], ['Agrave', [192]], ['agrave', [224]], ['alefsym', [8501]], ['aleph', [8501]], ['Alpha', [913]], ['alpha', [945]], ['Amacr', [256]], ['amacr', [257]], ['amalg', [10815]], ['amp', [38]], ['AMP', [38]], ['andand', [10837]], ['And', [10835]], ['and', [8743]], ['andd', [10844]], ['andslope', [10840]], ['andv', [10842]], ['ang', [8736]], ['ange', [10660]], ['angle', [8736]], ['angmsdaa', [10664]], ['angmsdab', [10665]], ['angmsdac', [10666]], ['angmsdad', [10667]], ['angmsdae', [10668]], ['angmsdaf', [10669]], ['angmsdag', [10670]], ['angmsdah', [10671]], ['angmsd', [8737]], ['angrt', [8735]], ['angrtvb', [8894]], ['angrtvbd', [10653]], ['angsph', [8738]], ['angst', [197]], ['angzarr', [9084]], ['Aogon', [260]], ['aogon', [261]], ['Aopf', [120120]], ['aopf', [120146]], ['apacir', [10863]], ['ap', [8776]], ['apE', [10864]], ['ape', [8778]], ['apid', [8779]], ['apos', [39]], ['ApplyFunction', [8289]], ['approx', [8776]], ['approxeq', [8778]], ['Aring', [197]], ['aring', [229]], ['Ascr', [119964]], ['ascr', [119990]], ['Assign', [8788]], ['ast', [42]], ['asymp', [8776]], ['asympeq', [8781]], ['Atilde', [195]], ['atilde', [227]], ['Auml', [196]], ['auml', [228]], ['awconint', [8755]], ['awint', [10769]], ['backcong', [8780]], ['backepsilon', [1014]], ['backprime', [8245]], ['backsim', [8765]], ['backsimeq', [8909]], ['Backslash', [8726]], ['Barv', [10983]], ['barvee', [8893]], ['barwed', [8965]], ['Barwed', [8966]], ['barwedge', [8965]], ['bbrk', [9141]], ['bbrktbrk', [9142]], ['bcong', [8780]], ['Bcy', [1041]], ['bcy', [1073]], ['bdquo', [8222]], ['becaus', [8757]], ['because', [8757]], ['Because', [8757]], ['bemptyv', [10672]], ['bepsi', [1014]], ['bernou', [8492]], ['Bernoullis', [8492]], ['Beta', [914]], ['beta', [946]], ['beth', [8502]], ['between', [8812]], ['Bfr', [120069]], ['bfr', [120095]], ['bigcap', [8898]], ['bigcirc', [9711]], ['bigcup', [8899]], ['bigodot', [10752]], ['bigoplus', [10753]], ['bigotimes', [10754]], ['bigsqcup', [10758]], ['bigstar', [9733]], ['bigtriangledown', [9661]], ['bigtriangleup', [9651]], ['biguplus', [10756]], ['bigvee', [8897]], ['bigwedge', [8896]], ['bkarow', [10509]], ['blacklozenge', [10731]], ['blacksquare', [9642]], ['blacktriangle', [9652]], ['blacktriangledown', [9662]], ['blacktriangleleft', [9666]], ['blacktriangleright', [9656]], ['blank', [9251]], ['blk12', [9618]], ['blk14', [9617]], ['blk34', [9619]], ['block', [9608]], ['bne', [61, 8421]], ['bnequiv', [8801, 8421]], ['bNot', [10989]], ['bnot', [8976]], ['Bopf', [120121]], ['bopf', [120147]], ['bot', [8869]], ['bottom', [8869]], ['bowtie', [8904]], ['boxbox', [10697]], ['boxdl', [9488]], ['boxdL', [9557]], ['boxDl', [9558]], ['boxDL', [9559]], ['boxdr', [9484]], ['boxdR', [9554]], ['boxDr', [9555]], ['boxDR', [9556]], ['boxh', [9472]], ['boxH', [9552]], ['boxhd', [9516]], ['boxHd', [9572]], ['boxhD', [9573]], ['boxHD', [9574]], ['boxhu', [9524]], ['boxHu', [9575]], ['boxhU', [9576]], ['boxHU', [9577]], ['boxminus', [8863]], ['boxplus', [8862]], ['boxtimes', [8864]], ['boxul', [9496]], ['boxuL', [9563]], ['boxUl', [9564]], ['boxUL', [9565]], ['boxur', [9492]], ['boxuR', [9560]], ['boxUr', [9561]], ['boxUR', [9562]], ['boxv', [9474]], ['boxV', [9553]], ['boxvh', [9532]], ['boxvH', [9578]], ['boxVh', [9579]], ['boxVH', [9580]], ['boxvl', [9508]], ['boxvL', [9569]], ['boxVl', [9570]], ['boxVL', [9571]], ['boxvr', [9500]], ['boxvR', [9566]], ['boxVr', [9567]], ['boxVR', [9568]], ['bprime', [8245]], ['breve', [728]], ['Breve', [728]], ['brvbar', [166]], ['bscr', [119991]], ['Bscr', [8492]], ['bsemi', [8271]], ['bsim', [8765]], ['bsime', [8909]], ['bsolb', [10693]], ['bsol', [92]], ['bsolhsub', [10184]], ['bull', [8226]], ['bullet', [8226]], ['bump', [8782]], ['bumpE', [10926]], ['bumpe', [8783]], ['Bumpeq', [8782]], ['bumpeq', [8783]], ['Cacute', [262]], ['cacute', [263]], ['capand', [10820]], ['capbrcup', [10825]], ['capcap', [10827]], ['cap', [8745]], ['Cap', [8914]], ['capcup', [10823]], ['capdot', [10816]], ['CapitalDifferentialD', [8517]], ['caps', [8745, 65024]], ['caret', [8257]], ['caron', [711]], ['Cayleys', [8493]], ['ccaps', [10829]], ['Ccaron', [268]], ['ccaron', [269]], ['Ccedil', [199]], ['ccedil', [231]], ['Ccirc', [264]], ['ccirc', [265]], ['Cconint', [8752]], ['ccups', [10828]], ['ccupssm', [10832]], ['Cdot', [266]], ['cdot', [267]], ['cedil', [184]], ['Cedilla', [184]], ['cemptyv', [10674]], ['cent', [162]], ['centerdot', [183]], ['CenterDot', [183]], ['cfr', [120096]], ['Cfr', [8493]], ['CHcy', [1063]], ['chcy', [1095]], ['check', [10003]], ['checkmark', [10003]], ['Chi', [935]], ['chi', [967]], ['circ', [710]], ['circeq', [8791]], ['circlearrowleft', [8634]], ['circlearrowright', [8635]], ['circledast', [8859]], ['circledcirc', [8858]], ['circleddash', [8861]], ['CircleDot', [8857]], ['circledR', [174]], ['circledS', [9416]], ['CircleMinus', [8854]], ['CirclePlus', [8853]], ['CircleTimes', [8855]], ['cir', [9675]], ['cirE', [10691]], ['cire', [8791]], ['cirfnint', [10768]], ['cirmid', [10991]], ['cirscir', [10690]], ['ClockwiseContourIntegral', [8754]], ['clubs', [9827]], ['clubsuit', [9827]], ['colon', [58]], ['Colon', [8759]], ['Colone', [10868]], ['colone', [8788]], ['coloneq', [8788]], ['comma', [44]], ['commat', [64]], ['comp', [8705]], ['compfn', [8728]], ['complement', [8705]], ['complexes', [8450]], ['cong', [8773]], ['congdot', [10861]], ['Congruent', [8801]], ['conint', [8750]], ['Conint', [8751]], ['ContourIntegral', [8750]], ['copf', [120148]], ['Copf', [8450]], ['coprod', [8720]], ['Coproduct', [8720]], ['copy', [169]], ['COPY', [169]], ['copysr', [8471]], ['CounterClockwiseContourIntegral', [8755]], ['crarr', [8629]], ['cross', [10007]], ['Cross', [10799]], ['Cscr', [119966]], ['cscr', [119992]], ['csub', [10959]], ['csube', [10961]], ['csup', [10960]], ['csupe', [10962]], ['ctdot', [8943]], ['cudarrl', [10552]], ['cudarrr', [10549]], ['cuepr', [8926]], ['cuesc', [8927]], ['cularr', [8630]], ['cularrp', [10557]], ['cupbrcap', [10824]], ['cupcap', [10822]], ['CupCap', [8781]], ['cup', [8746]], ['Cup', [8915]], ['cupcup', [10826]], ['cupdot', [8845]], ['cupor', [10821]], ['cups', [8746, 65024]], ['curarr', [8631]], ['curarrm', [10556]], ['curlyeqprec', [8926]], ['curlyeqsucc', [8927]], ['curlyvee', [8910]], ['curlywedge', [8911]], ['curren', [164]], ['curvearrowleft', [8630]], ['curvearrowright', [8631]], ['cuvee', [8910]], ['cuwed', [8911]], ['cwconint', [8754]], ['cwint', [8753]], ['cylcty', [9005]], ['dagger', [8224]], ['Dagger', [8225]], ['daleth', [8504]], ['darr', [8595]], ['Darr', [8609]], ['dArr', [8659]], ['dash', [8208]], ['Dashv', [10980]], ['dashv', [8867]], ['dbkarow', [10511]], ['dblac', [733]], ['Dcaron', [270]], ['dcaron', [271]], ['Dcy', [1044]], ['dcy', [1076]], ['ddagger', [8225]], ['ddarr', [8650]], ['DD', [8517]], ['dd', [8518]], ['DDotrahd', [10513]], ['ddotseq', [10871]], ['deg', [176]], ['Del', [8711]], ['Delta', [916]], ['delta', [948]], ['demptyv', [10673]], ['dfisht', [10623]], ['Dfr', [120071]], ['dfr', [120097]], ['dHar', [10597]], ['dharl', [8643]], ['dharr', [8642]], ['DiacriticalAcute', [180]], ['DiacriticalDot', [729]], ['DiacriticalDoubleAcute', [733]], ['DiacriticalGrave', [96]], ['DiacriticalTilde', [732]], ['diam', [8900]], ['diamond', [8900]], ['Diamond', [8900]], ['diamondsuit', [9830]], ['diams', [9830]], ['die', [168]], ['DifferentialD', [8518]], ['digamma', [989]], ['disin', [8946]], ['div', [247]], ['divide', [247]], ['divideontimes', [8903]], ['divonx', [8903]], ['DJcy', [1026]], ['djcy', [1106]], ['dlcorn', [8990]], ['dlcrop', [8973]], ['dollar', [36]], ['Dopf', [120123]], ['dopf', [120149]], ['Dot', [168]], ['dot', [729]], ['DotDot', [8412]], ['doteq', [8784]], ['doteqdot', [8785]], ['DotEqual', [8784]], ['dotminus', [8760]], ['dotplus', [8724]], ['dotsquare', [8865]], ['doublebarwedge', [8966]], ['DoubleContourIntegral', [8751]], ['DoubleDot', [168]], ['DoubleDownArrow', [8659]], ['DoubleLeftArrow', [8656]], ['DoubleLeftRightArrow', [8660]], ['DoubleLeftTee', [10980]], ['DoubleLongLeftArrow', [10232]], ['DoubleLongLeftRightArrow', [10234]], ['DoubleLongRightArrow', [10233]], ['DoubleRightArrow', [8658]], ['DoubleRightTee', [8872]], ['DoubleUpArrow', [8657]], ['DoubleUpDownArrow', [8661]], ['DoubleVerticalBar', [8741]], ['DownArrowBar', [10515]], ['downarrow', [8595]], ['DownArrow', [8595]], ['Downarrow', [8659]], ['DownArrowUpArrow', [8693]], ['DownBreve', [785]], ['downdownarrows', [8650]], ['downharpoonleft', [8643]], ['downharpoonright', [8642]], ['DownLeftRightVector', [10576]], ['DownLeftTeeVector', [10590]], ['DownLeftVectorBar', [10582]], ['DownLeftVector', [8637]], ['DownRightTeeVector', [10591]], ['DownRightVectorBar', [10583]], ['DownRightVector', [8641]], ['DownTeeArrow', [8615]], ['DownTee', [8868]], ['drbkarow', [10512]], ['drcorn', [8991]], ['drcrop', [8972]], ['Dscr', [119967]], ['dscr', [119993]], ['DScy', [1029]], ['dscy', [1109]], ['dsol', [10742]], ['Dstrok', [272]], ['dstrok', [273]], ['dtdot', [8945]], ['dtri', [9663]], ['dtrif', [9662]], ['duarr', [8693]], ['duhar', [10607]], ['dwangle', [10662]], ['DZcy', [1039]], ['dzcy', [1119]], ['dzigrarr', [10239]], ['Eacute', [201]], ['eacute', [233]], ['easter', [10862]], ['Ecaron', [282]], ['ecaron', [283]], ['Ecirc', [202]], ['ecirc', [234]], ['ecir', [8790]], ['ecolon', [8789]], ['Ecy', [1069]], ['ecy', [1101]], ['eDDot', [10871]], ['Edot', [278]], ['edot', [279]], ['eDot', [8785]], ['ee', [8519]], ['efDot', [8786]], ['Efr', [120072]], ['efr', [120098]], ['eg', [10906]], ['Egrave', [200]], ['egrave', [232]], ['egs', [10902]], ['egsdot', [10904]], ['el', [10905]], ['Element', [8712]], ['elinters', [9191]], ['ell', [8467]], ['els', [10901]], ['elsdot', [10903]], ['Emacr', [274]], ['emacr', [275]], ['empty', [8709]], ['emptyset', [8709]], ['EmptySmallSquare', [9723]], ['emptyv', [8709]], ['EmptyVerySmallSquare', [9643]], ['emsp13', [8196]], ['emsp14', [8197]], ['emsp', [8195]], ['ENG', [330]], ['eng', [331]], ['ensp', [8194]], ['Eogon', [280]], ['eogon', [281]], ['Eopf', [120124]], ['eopf', [120150]], ['epar', [8917]], ['eparsl', [10723]], ['eplus', [10865]], ['epsi', [949]], ['Epsilon', [917]], ['epsilon', [949]], ['epsiv', [1013]], ['eqcirc', [8790]], ['eqcolon', [8789]], ['eqsim', [8770]], ['eqslantgtr', [10902]], ['eqslantless', [10901]], ['Equal', [10869]], ['equals', [61]], ['EqualTilde', [8770]], ['equest', [8799]], ['Equilibrium', [8652]], ['equiv', [8801]], ['equivDD', [10872]], ['eqvparsl', [10725]], ['erarr', [10609]], ['erDot', [8787]], ['escr', [8495]], ['Escr', [8496]], ['esdot', [8784]], ['Esim', [10867]], ['esim', [8770]], ['Eta', [919]], ['eta', [951]], ['ETH', [208]], ['eth', [240]], ['Euml', [203]], ['euml', [235]], ['euro', [8364]], ['excl', [33]], ['exist', [8707]], ['Exists', [8707]], ['expectation', [8496]], ['exponentiale', [8519]], ['ExponentialE', [8519]], ['fallingdotseq', [8786]], ['Fcy', [1060]], ['fcy', [1092]], ['female', [9792]], ['ffilig', [64259]], ['fflig', [64256]], ['ffllig', [64260]], ['Ffr', [120073]], ['ffr', [120099]], ['filig', [64257]], ['FilledSmallSquare', [9724]], ['FilledVerySmallSquare', [9642]], ['fjlig', [102, 106]], ['flat', [9837]], ['fllig', [64258]], ['fltns', [9649]], ['fnof', [402]], ['Fopf', [120125]], ['fopf', [120151]], ['forall', [8704]], ['ForAll', [8704]], ['fork', [8916]], ['forkv', [10969]], ['Fouriertrf', [8497]], ['fpartint', [10765]], ['frac12', [189]], ['frac13', [8531]], ['frac14', [188]], ['frac15', [8533]], ['frac16', [8537]], ['frac18', [8539]], ['frac23', [8532]], ['frac25', [8534]], ['frac34', [190]], ['frac35', [8535]], ['frac38', [8540]], ['frac45', [8536]], ['frac56', [8538]], ['frac58', [8541]], ['frac78', [8542]], ['frasl', [8260]], ['frown', [8994]], ['fscr', [119995]], ['Fscr', [8497]], ['gacute', [501]], ['Gamma', [915]], ['gamma', [947]], ['Gammad', [988]], ['gammad', [989]], ['gap', [10886]], ['Gbreve', [286]], ['gbreve', [287]], ['Gcedil', [290]], ['Gcirc', [284]], ['gcirc', [285]], ['Gcy', [1043]], ['gcy', [1075]], ['Gdot', [288]], ['gdot', [289]], ['ge', [8805]], ['gE', [8807]], ['gEl', [10892]], ['gel', [8923]], ['geq', [8805]], ['geqq', [8807]], ['geqslant', [10878]], ['gescc', [10921]], ['ges', [10878]], ['gesdot', [10880]], ['gesdoto', [10882]], ['gesdotol', [10884]], ['gesl', [8923, 65024]], ['gesles', [10900]], ['Gfr', [120074]], ['gfr', [120100]], ['gg', [8811]], ['Gg', [8921]], ['ggg', [8921]], ['gimel', [8503]], ['GJcy', [1027]], ['gjcy', [1107]], ['gla', [10917]], ['gl', [8823]], ['glE', [10898]], ['glj', [10916]], ['gnap', [10890]], ['gnapprox', [10890]], ['gne', [10888]], ['gnE', [8809]], ['gneq', [10888]], ['gneqq', [8809]], ['gnsim', [8935]], ['Gopf', [120126]], ['gopf', [120152]], ['grave', [96]], ['GreaterEqual', [8805]], ['GreaterEqualLess', [8923]], ['GreaterFullEqual', [8807]], ['GreaterGreater', [10914]], ['GreaterLess', [8823]], ['GreaterSlantEqual', [10878]], ['GreaterTilde', [8819]], ['Gscr', [119970]], ['gscr', [8458]], ['gsim', [8819]], ['gsime', [10894]], ['gsiml', [10896]], ['gtcc', [10919]], ['gtcir', [10874]], ['gt', [62]], ['GT', [62]], ['Gt', [8811]], ['gtdot', [8919]], ['gtlPar', [10645]], ['gtquest', [10876]], ['gtrapprox', [10886]], ['gtrarr', [10616]], ['gtrdot', [8919]], ['gtreqless', [8923]], ['gtreqqless', [10892]], ['gtrless', [8823]], ['gtrsim', [8819]], ['gvertneqq', [8809, 65024]], ['gvnE', [8809, 65024]], ['Hacek', [711]], ['hairsp', [8202]], ['half', [189]], ['hamilt', [8459]], ['HARDcy', [1066]], ['hardcy', [1098]], ['harrcir', [10568]], ['harr', [8596]], ['hArr', [8660]], ['harrw', [8621]], ['Hat', [94]], ['hbar', [8463]], ['Hcirc', [292]], ['hcirc', [293]], ['hearts', [9829]], ['heartsuit', [9829]], ['hellip', [8230]], ['hercon', [8889]], ['hfr', [120101]], ['Hfr', [8460]], ['HilbertSpace', [8459]], ['hksearow', [10533]], ['hkswarow', [10534]], ['hoarr', [8703]], ['homtht', [8763]], ['hookleftarrow', [8617]], ['hookrightarrow', [8618]], ['hopf', [120153]], ['Hopf', [8461]], ['horbar', [8213]], ['HorizontalLine', [9472]], ['hscr', [119997]], ['Hscr', [8459]], ['hslash', [8463]], ['Hstrok', [294]], ['hstrok', [295]], ['HumpDownHump', [8782]], ['HumpEqual', [8783]], ['hybull', [8259]], ['hyphen', [8208]], ['Iacute', [205]], ['iacute', [237]], ['ic', [8291]], ['Icirc', [206]], ['icirc', [238]], ['Icy', [1048]], ['icy', [1080]], ['Idot', [304]], ['IEcy', [1045]], ['iecy', [1077]], ['iexcl', [161]], ['iff', [8660]], ['ifr', [120102]], ['Ifr', [8465]], ['Igrave', [204]], ['igrave', [236]], ['ii', [8520]], ['iiiint', [10764]], ['iiint', [8749]], ['iinfin', [10716]], ['iiota', [8489]], ['IJlig', [306]], ['ijlig', [307]], ['Imacr', [298]], ['imacr', [299]], ['image', [8465]], ['ImaginaryI', [8520]], ['imagline', [8464]], ['imagpart', [8465]], ['imath', [305]], ['Im', [8465]], ['imof', [8887]], ['imped', [437]], ['Implies', [8658]], ['incare', [8453]], ['in', [8712]], ['infin', [8734]], ['infintie', [10717]], ['inodot', [305]], ['intcal', [8890]], ['int', [8747]], ['Int', [8748]], ['integers', [8484]], ['Integral', [8747]], ['intercal', [8890]], ['Intersection', [8898]], ['intlarhk', [10775]], ['intprod', [10812]], ['InvisibleComma', [8291]], ['InvisibleTimes', [8290]], ['IOcy', [1025]], ['iocy', [1105]], ['Iogon', [302]], ['iogon', [303]], ['Iopf', [120128]], ['iopf', [120154]], ['Iota', [921]], ['iota', [953]], ['iprod', [10812]], ['iquest', [191]], ['iscr', [119998]], ['Iscr', [8464]], ['isin', [8712]], ['isindot', [8949]], ['isinE', [8953]], ['isins', [8948]], ['isinsv', [8947]], ['isinv', [8712]], ['it', [8290]], ['Itilde', [296]], ['itilde', [297]], ['Iukcy', [1030]], ['iukcy', [1110]], ['Iuml', [207]], ['iuml', [239]], ['Jcirc', [308]], ['jcirc', [309]], ['Jcy', [1049]], ['jcy', [1081]], ['Jfr', [120077]], ['jfr', [120103]], ['jmath', [567]], ['Jopf', [120129]], ['jopf', [120155]], ['Jscr', [119973]], ['jscr', [119999]], ['Jsercy', [1032]], ['jsercy', [1112]], ['Jukcy', [1028]], ['jukcy', [1108]], ['Kappa', [922]], ['kappa', [954]], ['kappav', [1008]], ['Kcedil', [310]], ['kcedil', [311]], ['Kcy', [1050]], ['kcy', [1082]], ['Kfr', [120078]], ['kfr', [120104]], ['kgreen', [312]], ['KHcy', [1061]], ['khcy', [1093]], ['KJcy', [1036]], ['kjcy', [1116]], ['Kopf', [120130]], ['kopf', [120156]], ['Kscr', [119974]], ['kscr', [120000]], ['lAarr', [8666]], ['Lacute', [313]], ['lacute', [314]], ['laemptyv', [10676]], ['lagran', [8466]], ['Lambda', [923]], ['lambda', [955]], ['lang', [10216]], ['Lang', [10218]], ['langd', [10641]], ['langle', [10216]], ['lap', [10885]], ['Laplacetrf', [8466]], ['laquo', [171]], ['larrb', [8676]], ['larrbfs', [10527]], ['larr', [8592]], ['Larr', [8606]], ['lArr', [8656]], ['larrfs', [10525]], ['larrhk', [8617]], ['larrlp', [8619]], ['larrpl', [10553]], ['larrsim', [10611]], ['larrtl', [8610]], ['latail', [10521]], ['lAtail', [10523]], ['lat', [10923]], ['late', [10925]], ['lates', [10925, 65024]], ['lbarr', [10508]], ['lBarr', [10510]], ['lbbrk', [10098]], ['lbrace', [123]], ['lbrack', [91]], ['lbrke', [10635]], ['lbrksld', [10639]], ['lbrkslu', [10637]], ['Lcaron', [317]], ['lcaron', [318]], ['Lcedil', [315]], ['lcedil', [316]], ['lceil', [8968]], ['lcub', [123]], ['Lcy', [1051]], ['lcy', [1083]], ['ldca', [10550]], ['ldquo', [8220]], ['ldquor', [8222]], ['ldrdhar', [10599]], ['ldrushar', [10571]], ['ldsh', [8626]], ['le', [8804]], ['lE', [8806]], ['LeftAngleBracket', [10216]], ['LeftArrowBar', [8676]], ['leftarrow', [8592]], ['LeftArrow', [8592]], ['Leftarrow', [8656]], ['LeftArrowRightArrow', [8646]], ['leftarrowtail', [8610]], ['LeftCeiling', [8968]], ['LeftDoubleBracket', [10214]], ['LeftDownTeeVector', [10593]], ['LeftDownVectorBar', [10585]], ['LeftDownVector', [8643]], ['LeftFloor', [8970]], ['leftharpoondown', [8637]], ['leftharpoonup', [8636]], ['leftleftarrows', [8647]], ['leftrightarrow', [8596]], ['LeftRightArrow', [8596]], ['Leftrightarrow', [8660]], ['leftrightarrows', [8646]], ['leftrightharpoons', [8651]], ['leftrightsquigarrow', [8621]], ['LeftRightVector', [10574]], ['LeftTeeArrow', [8612]], ['LeftTee', [8867]], ['LeftTeeVector', [10586]], ['leftthreetimes', [8907]], ['LeftTriangleBar', [10703]], ['LeftTriangle', [8882]], ['LeftTriangleEqual', [8884]], ['LeftUpDownVector', [10577]], ['LeftUpTeeVector', [10592]], ['LeftUpVectorBar', [10584]], ['LeftUpVector', [8639]], ['LeftVectorBar', [10578]], ['LeftVector', [8636]], ['lEg', [10891]], ['leg', [8922]], ['leq', [8804]], ['leqq', [8806]], ['leqslant', [10877]], ['lescc', [10920]], ['les', [10877]], ['lesdot', [10879]], ['lesdoto', [10881]], ['lesdotor', [10883]], ['lesg', [8922, 65024]], ['lesges', [10899]], ['lessapprox', [10885]], ['lessdot', [8918]], ['lesseqgtr', [8922]], ['lesseqqgtr', [10891]], ['LessEqualGreater', [8922]], ['LessFullEqual', [8806]], ['LessGreater', [8822]], ['lessgtr', [8822]], ['LessLess', [10913]], ['lesssim', [8818]], ['LessSlantEqual', [10877]], ['LessTilde', [8818]], ['lfisht', [10620]], ['lfloor', [8970]], ['Lfr', [120079]], ['lfr', [120105]], ['lg', [8822]], ['lgE', [10897]], ['lHar', [10594]], ['lhard', [8637]], ['lharu', [8636]], ['lharul', [10602]], ['lhblk', [9604]], ['LJcy', [1033]], ['ljcy', [1113]], ['llarr', [8647]], ['ll', [8810]], ['Ll', [8920]], ['llcorner', [8990]], ['Lleftarrow', [8666]], ['llhard', [10603]], ['lltri', [9722]], ['Lmidot', [319]], ['lmidot', [320]], ['lmoustache', [9136]], ['lmoust', [9136]], ['lnap', [10889]], ['lnapprox', [10889]], ['lne', [10887]], ['lnE', [8808]], ['lneq', [10887]], ['lneqq', [8808]], ['lnsim', [8934]], ['loang', [10220]], ['loarr', [8701]], ['lobrk', [10214]], ['longleftarrow', [10229]], ['LongLeftArrow', [10229]], ['Longleftarrow', [10232]], ['longleftrightarrow', [10231]], ['LongLeftRightArrow', [10231]], ['Longleftrightarrow', [10234]], ['longmapsto', [10236]], ['longrightarrow', [10230]], ['LongRightArrow', [10230]], ['Longrightarrow', [10233]], ['looparrowleft', [8619]], ['looparrowright', [8620]], ['lopar', [10629]], ['Lopf', [120131]], ['lopf', [120157]], ['loplus', [10797]], ['lotimes', [10804]], ['lowast', [8727]], ['lowbar', [95]], ['LowerLeftArrow', [8601]], ['LowerRightArrow', [8600]], ['loz', [9674]], ['lozenge', [9674]], ['lozf', [10731]], ['lpar', [40]], ['lparlt', [10643]], ['lrarr', [8646]], ['lrcorner', [8991]], ['lrhar', [8651]], ['lrhard', [10605]], ['lrm', [8206]], ['lrtri', [8895]], ['lsaquo', [8249]], ['lscr', [120001]], ['Lscr', [8466]], ['lsh', [8624]], ['Lsh', [8624]], ['lsim', [8818]], ['lsime', [10893]], ['lsimg', [10895]], ['lsqb', [91]], ['lsquo', [8216]], ['lsquor', [8218]], ['Lstrok', [321]], ['lstrok', [322]], ['ltcc', [10918]], ['ltcir', [10873]], ['lt', [60]], ['LT', [60]], ['Lt', [8810]], ['ltdot', [8918]], ['lthree', [8907]], ['ltimes', [8905]], ['ltlarr', [10614]], ['ltquest', [10875]], ['ltri', [9667]], ['ltrie', [8884]], ['ltrif', [9666]], ['ltrPar', [10646]], ['lurdshar', [10570]], ['luruhar', [10598]], ['lvertneqq', [8808, 65024]], ['lvnE', [8808, 65024]], ['macr', [175]], ['male', [9794]], ['malt', [10016]], ['maltese', [10016]], ['Map', [10501]], ['map', [8614]], ['mapsto', [8614]], ['mapstodown', [8615]], ['mapstoleft', [8612]], ['mapstoup', [8613]], ['marker', [9646]], ['mcomma', [10793]], ['Mcy', [1052]], ['mcy', [1084]], ['mdash', [8212]], ['mDDot', [8762]], ['measuredangle', [8737]], ['MediumSpace', [8287]], ['Mellintrf', [8499]], ['Mfr', [120080]], ['mfr', [120106]], ['mho', [8487]], ['micro', [181]], ['midast', [42]], ['midcir', [10992]], ['mid', [8739]], ['middot', [183]], ['minusb', [8863]], ['minus', [8722]], ['minusd', [8760]], ['minusdu', [10794]], ['MinusPlus', [8723]], ['mlcp', [10971]], ['mldr', [8230]], ['mnplus', [8723]], ['models', [8871]], ['Mopf', [120132]], ['mopf', [120158]], ['mp', [8723]], ['mscr', [120002]], ['Mscr', [8499]], ['mstpos', [8766]], ['Mu', [924]], ['mu', [956]], ['multimap', [8888]], ['mumap', [8888]], ['nabla', [8711]], ['Nacute', [323]], ['nacute', [324]], ['nang', [8736, 8402]], ['nap', [8777]], ['napE', [10864, 824]], ['napid', [8779, 824]], ['napos', [329]], ['napprox', [8777]], ['natural', [9838]], ['naturals', [8469]], ['natur', [9838]], ['nbsp', [160]], ['nbump', [8782, 824]], ['nbumpe', [8783, 824]], ['ncap', [10819]], ['Ncaron', [327]], ['ncaron', [328]], ['Ncedil', [325]], ['ncedil', [326]], ['ncong', [8775]], ['ncongdot', [10861, 824]], ['ncup', [10818]], ['Ncy', [1053]], ['ncy', [1085]], ['ndash', [8211]], ['nearhk', [10532]], ['nearr', [8599]], ['neArr', [8663]], ['nearrow', [8599]], ['ne', [8800]], ['nedot', [8784, 824]], ['NegativeMediumSpace', [8203]], ['NegativeThickSpace', [8203]], ['NegativeThinSpace', [8203]], ['NegativeVeryThinSpace', [8203]], ['nequiv', [8802]], ['nesear', [10536]], ['nesim', [8770, 824]], ['NestedGreaterGreater', [8811]], ['NestedLessLess', [8810]], ['nexist', [8708]], ['nexists', [8708]], ['Nfr', [120081]], ['nfr', [120107]], ['ngE', [8807, 824]], ['nge', [8817]], ['ngeq', [8817]], ['ngeqq', [8807, 824]], ['ngeqslant', [10878, 824]], ['nges', [10878, 824]], ['nGg', [8921, 824]], ['ngsim', [8821]], ['nGt', [8811, 8402]], ['ngt', [8815]], ['ngtr', [8815]], ['nGtv', [8811, 824]], ['nharr', [8622]], ['nhArr', [8654]], ['nhpar', [10994]], ['ni', [8715]], ['nis', [8956]], ['nisd', [8954]], ['niv', [8715]], ['NJcy', [1034]], ['njcy', [1114]], ['nlarr', [8602]], ['nlArr', [8653]], ['nldr', [8229]], ['nlE', [8806, 824]], ['nle', [8816]], ['nleftarrow', [8602]], ['nLeftarrow', [8653]], ['nleftrightarrow', [8622]], ['nLeftrightarrow', [8654]], ['nleq', [8816]], ['nleqq', [8806, 824]], ['nleqslant', [10877, 824]], ['nles', [10877, 824]], ['nless', [8814]], ['nLl', [8920, 824]], ['nlsim', [8820]], ['nLt', [8810, 8402]], ['nlt', [8814]], ['nltri', [8938]], ['nltrie', [8940]], ['nLtv', [8810, 824]], ['nmid', [8740]], ['NoBreak', [8288]], ['NonBreakingSpace', [160]], ['nopf', [120159]], ['Nopf', [8469]], ['Not', [10988]], ['not', [172]], ['NotCongruent', [8802]], ['NotCupCap', [8813]], ['NotDoubleVerticalBar', [8742]], ['NotElement', [8713]], ['NotEqual', [8800]], ['NotEqualTilde', [8770, 824]], ['NotExists', [8708]], ['NotGreater', [8815]], ['NotGreaterEqual', [8817]], ['NotGreaterFullEqual', [8807, 824]], ['NotGreaterGreater', [8811, 824]], ['NotGreaterLess', [8825]], ['NotGreaterSlantEqual', [10878, 824]], ['NotGreaterTilde', [8821]], ['NotHumpDownHump', [8782, 824]], ['NotHumpEqual', [8783, 824]], ['notin', [8713]], ['notindot', [8949, 824]], ['notinE', [8953, 824]], ['notinva', [8713]], ['notinvb', [8951]], ['notinvc', [8950]], ['NotLeftTriangleBar', [10703, 824]], ['NotLeftTriangle', [8938]], ['NotLeftTriangleEqual', [8940]], ['NotLess', [8814]], ['NotLessEqual', [8816]], ['NotLessGreater', [8824]], ['NotLessLess', [8810, 824]], ['NotLessSlantEqual', [10877, 824]], ['NotLessTilde', [8820]], ['NotNestedGreaterGreater', [10914, 824]], ['NotNestedLessLess', [10913, 824]], ['notni', [8716]], ['notniva', [8716]], ['notnivb', [8958]], ['notnivc', [8957]], ['NotPrecedes', [8832]], ['NotPrecedesEqual', [10927, 824]], ['NotPrecedesSlantEqual', [8928]], ['NotReverseElement', [8716]], ['NotRightTriangleBar', [10704, 824]], ['NotRightTriangle', [8939]], ['NotRightTriangleEqual', [8941]], ['NotSquareSubset', [8847, 824]], ['NotSquareSubsetEqual', [8930]], ['NotSquareSuperset', [8848, 824]], ['NotSquareSupersetEqual', [8931]], ['NotSubset', [8834, 8402]], ['NotSubsetEqual', [8840]], ['NotSucceeds', [8833]], ['NotSucceedsEqual', [10928, 824]], ['NotSucceedsSlantEqual', [8929]], ['NotSucceedsTilde', [8831, 824]], ['NotSuperset', [8835, 8402]], ['NotSupersetEqual', [8841]], ['NotTilde', [8769]], ['NotTildeEqual', [8772]], ['NotTildeFullEqual', [8775]], ['NotTildeTilde', [8777]], ['NotVerticalBar', [8740]], ['nparallel', [8742]], ['npar', [8742]], ['nparsl', [11005, 8421]], ['npart', [8706, 824]], ['npolint', [10772]], ['npr', [8832]], ['nprcue', [8928]], ['nprec', [8832]], ['npreceq', [10927, 824]], ['npre', [10927, 824]], ['nrarrc', [10547, 824]], ['nrarr', [8603]], ['nrArr', [8655]], ['nrarrw', [8605, 824]], ['nrightarrow', [8603]], ['nRightarrow', [8655]], ['nrtri', [8939]], ['nrtrie', [8941]], ['nsc', [8833]], ['nsccue', [8929]], ['nsce', [10928, 824]], ['Nscr', [119977]], ['nscr', [120003]], ['nshortmid', [8740]], ['nshortparallel', [8742]], ['nsim', [8769]], ['nsime', [8772]], ['nsimeq', [8772]], ['nsmid', [8740]], ['nspar', [8742]], ['nsqsube', [8930]], ['nsqsupe', [8931]], ['nsub', [8836]], ['nsubE', [10949, 824]], ['nsube', [8840]], ['nsubset', [8834, 8402]], ['nsubseteq', [8840]], ['nsubseteqq', [10949, 824]], ['nsucc', [8833]], ['nsucceq', [10928, 824]], ['nsup', [8837]], ['nsupE', [10950, 824]], ['nsupe', [8841]], ['nsupset', [8835, 8402]], ['nsupseteq', [8841]], ['nsupseteqq', [10950, 824]], ['ntgl', [8825]], ['Ntilde', [209]], ['ntilde', [241]], ['ntlg', [8824]], ['ntriangleleft', [8938]], ['ntrianglelefteq', [8940]], ['ntriangleright', [8939]], ['ntrianglerighteq', [8941]], ['Nu', [925]], ['nu', [957]], ['num', [35]], ['numero', [8470]], ['numsp', [8199]], ['nvap', [8781, 8402]], ['nvdash', [8876]], ['nvDash', [8877]], ['nVdash', [8878]], ['nVDash', [8879]], ['nvge', [8805, 8402]], ['nvgt', [62, 8402]], ['nvHarr', [10500]], ['nvinfin', [10718]], ['nvlArr', [10498]], ['nvle', [8804, 8402]], ['nvlt', [60, 8402]], ['nvltrie', [8884, 8402]], ['nvrArr', [10499]], ['nvrtrie', [8885, 8402]], ['nvsim', [8764, 8402]], ['nwarhk', [10531]], ['nwarr', [8598]], ['nwArr', [8662]], ['nwarrow', [8598]], ['nwnear', [10535]], ['Oacute', [211]], ['oacute', [243]], ['oast', [8859]], ['Ocirc', [212]], ['ocirc', [244]], ['ocir', [8858]], ['Ocy', [1054]], ['ocy', [1086]], ['odash', [8861]], ['Odblac', [336]], ['odblac', [337]], ['odiv', [10808]], ['odot', [8857]], ['odsold', [10684]], ['OElig', [338]], ['oelig', [339]], ['ofcir', [10687]], ['Ofr', [120082]], ['ofr', [120108]], ['ogon', [731]], ['Ograve', [210]], ['ograve', [242]], ['ogt', [10689]], ['ohbar', [10677]], ['ohm', [937]], ['oint', [8750]], ['olarr', [8634]], ['olcir', [10686]], ['olcross', [10683]], ['oline', [8254]], ['olt', [10688]], ['Omacr', [332]], ['omacr', [333]], ['Omega', [937]], ['omega', [969]], ['Omicron', [927]], ['omicron', [959]], ['omid', [10678]], ['ominus', [8854]], ['Oopf', [120134]], ['oopf', [120160]], ['opar', [10679]], ['OpenCurlyDoubleQuote', [8220]], ['OpenCurlyQuote', [8216]], ['operp', [10681]], ['oplus', [8853]], ['orarr', [8635]], ['Or', [10836]], ['or', [8744]], ['ord', [10845]], ['order', [8500]], ['orderof', [8500]], ['ordf', [170]], ['ordm', [186]], ['origof', [8886]], ['oror', [10838]], ['orslope', [10839]], ['orv', [10843]], ['oS', [9416]], ['Oscr', [119978]], ['oscr', [8500]], ['Oslash', [216]], ['oslash', [248]], ['osol', [8856]], ['Otilde', [213]], ['otilde', [245]], ['otimesas', [10806]], ['Otimes', [10807]], ['otimes', [8855]], ['Ouml', [214]], ['ouml', [246]], ['ovbar', [9021]], ['OverBar', [8254]], ['OverBrace', [9182]], ['OverBracket', [9140]], ['OverParenthesis', [9180]], ['para', [182]], ['parallel', [8741]], ['par', [8741]], ['parsim', [10995]], ['parsl', [11005]], ['part', [8706]], ['PartialD', [8706]], ['Pcy', [1055]], ['pcy', [1087]], ['percnt', [37]], ['period', [46]], ['permil', [8240]], ['perp', [8869]], ['pertenk', [8241]], ['Pfr', [120083]], ['pfr', [120109]], ['Phi', [934]], ['phi', [966]], ['phiv', [981]], ['phmmat', [8499]], ['phone', [9742]], ['Pi', [928]], ['pi', [960]], ['pitchfork', [8916]], ['piv', [982]], ['planck', [8463]], ['planckh', [8462]], ['plankv', [8463]], ['plusacir', [10787]], ['plusb', [8862]], ['pluscir', [10786]], ['plus', [43]], ['plusdo', [8724]], ['plusdu', [10789]], ['pluse', [10866]], ['PlusMinus', [177]], ['plusmn', [177]], ['plussim', [10790]], ['plustwo', [10791]], ['pm', [177]], ['Poincareplane', [8460]], ['pointint', [10773]], ['popf', [120161]], ['Popf', [8473]], ['pound', [163]], ['prap', [10935]], ['Pr', [10939]], ['pr', [8826]], ['prcue', [8828]], ['precapprox', [10935]], ['prec', [8826]], ['preccurlyeq', [8828]], ['Precedes', [8826]], ['PrecedesEqual', [10927]], ['PrecedesSlantEqual', [8828]], ['PrecedesTilde', [8830]], ['preceq', [10927]], ['precnapprox', [10937]], ['precneqq', [10933]], ['precnsim', [8936]], ['pre', [10927]], ['prE', [10931]], ['precsim', [8830]], ['prime', [8242]], ['Prime', [8243]], ['primes', [8473]], ['prnap', [10937]], ['prnE', [10933]], ['prnsim', [8936]], ['prod', [8719]], ['Product', [8719]], ['profalar', [9006]], ['profline', [8978]], ['profsurf', [8979]], ['prop', [8733]], ['Proportional', [8733]], ['Proportion', [8759]], ['propto', [8733]], ['prsim', [8830]], ['prurel', [8880]], ['Pscr', [119979]], ['pscr', [120005]], ['Psi', [936]], ['psi', [968]], ['puncsp', [8200]], ['Qfr', [120084]], ['qfr', [120110]], ['qint', [10764]], ['qopf', [120162]], ['Qopf', [8474]], ['qprime', [8279]], ['Qscr', [119980]], ['qscr', [120006]], ['quaternions', [8461]], ['quatint', [10774]], ['quest', [63]], ['questeq', [8799]], ['quot', [34]], ['QUOT', [34]], ['rAarr', [8667]], ['race', [8765, 817]], ['Racute', [340]], ['racute', [341]], ['radic', [8730]], ['raemptyv', [10675]], ['rang', [10217]], ['Rang', [10219]], ['rangd', [10642]], ['range', [10661]], ['rangle', [10217]], ['raquo', [187]], ['rarrap', [10613]], ['rarrb', [8677]], ['rarrbfs', [10528]], ['rarrc', [10547]], ['rarr', [8594]], ['Rarr', [8608]], ['rArr', [8658]], ['rarrfs', [10526]], ['rarrhk', [8618]], ['rarrlp', [8620]], ['rarrpl', [10565]], ['rarrsim', [10612]], ['Rarrtl', [10518]], ['rarrtl', [8611]], ['rarrw', [8605]], ['ratail', [10522]], ['rAtail', [10524]], ['ratio', [8758]], ['rationals', [8474]], ['rbarr', [10509]], ['rBarr', [10511]], ['RBarr', [10512]], ['rbbrk', [10099]], ['rbrace', [125]], ['rbrack', [93]], ['rbrke', [10636]], ['rbrksld', [10638]], ['rbrkslu', [10640]], ['Rcaron', [344]], ['rcaron', [345]], ['Rcedil', [342]], ['rcedil', [343]], ['rceil', [8969]], ['rcub', [125]], ['Rcy', [1056]], ['rcy', [1088]], ['rdca', [10551]], ['rdldhar', [10601]], ['rdquo', [8221]], ['rdquor', [8221]], ['CloseCurlyDoubleQuote', [8221]], ['rdsh', [8627]], ['real', [8476]], ['realine', [8475]], ['realpart', [8476]], ['reals', [8477]], ['Re', [8476]], ['rect', [9645]], ['reg', [174]], ['REG', [174]], ['ReverseElement', [8715]], ['ReverseEquilibrium', [8651]], ['ReverseUpEquilibrium', [10607]], ['rfisht', [10621]], ['rfloor', [8971]], ['rfr', [120111]], ['Rfr', [8476]], ['rHar', [10596]], ['rhard', [8641]], ['rharu', [8640]], ['rharul', [10604]], ['Rho', [929]], ['rho', [961]], ['rhov', [1009]], ['RightAngleBracket', [10217]], ['RightArrowBar', [8677]], ['rightarrow', [8594]], ['RightArrow', [8594]], ['Rightarrow', [8658]], ['RightArrowLeftArrow', [8644]], ['rightarrowtail', [8611]], ['RightCeiling', [8969]], ['RightDoubleBracket', [10215]], ['RightDownTeeVector', [10589]], ['RightDownVectorBar', [10581]], ['RightDownVector', [8642]], ['RightFloor', [8971]], ['rightharpoondown', [8641]], ['rightharpoonup', [8640]], ['rightleftarrows', [8644]], ['rightleftharpoons', [8652]], ['rightrightarrows', [8649]], ['rightsquigarrow', [8605]], ['RightTeeArrow', [8614]], ['RightTee', [8866]], ['RightTeeVector', [10587]], ['rightthreetimes', [8908]], ['RightTriangleBar', [10704]], ['RightTriangle', [8883]], ['RightTriangleEqual', [8885]], ['RightUpDownVector', [10575]], ['RightUpTeeVector', [10588]], ['RightUpVectorBar', [10580]], ['RightUpVector', [8638]], ['RightVectorBar', [10579]], ['RightVector', [8640]], ['ring', [730]], ['risingdotseq', [8787]], ['rlarr', [8644]], ['rlhar', [8652]], ['rlm', [8207]], ['rmoustache', [9137]], ['rmoust', [9137]], ['rnmid', [10990]], ['roang', [10221]], ['roarr', [8702]], ['robrk', [10215]], ['ropar', [10630]], ['ropf', [120163]], ['Ropf', [8477]], ['roplus', [10798]], ['rotimes', [10805]], ['RoundImplies', [10608]], ['rpar', [41]], ['rpargt', [10644]], ['rppolint', [10770]], ['rrarr', [8649]], ['Rrightarrow', [8667]], ['rsaquo', [8250]], ['rscr', [120007]], ['Rscr', [8475]], ['rsh', [8625]], ['Rsh', [8625]], ['rsqb', [93]], ['rsquo', [8217]], ['rsquor', [8217]], ['CloseCurlyQuote', [8217]], ['rthree', [8908]], ['rtimes', [8906]], ['rtri', [9657]], ['rtrie', [8885]], ['rtrif', [9656]], ['rtriltri', [10702]], ['RuleDelayed', [10740]], ['ruluhar', [10600]], ['rx', [8478]], ['Sacute', [346]], ['sacute', [347]], ['sbquo', [8218]], ['scap', [10936]], ['Scaron', [352]], ['scaron', [353]], ['Sc', [10940]], ['sc', [8827]], ['sccue', [8829]], ['sce', [10928]], ['scE', [10932]], ['Scedil', [350]], ['scedil', [351]], ['Scirc', [348]], ['scirc', [349]], ['scnap', [10938]], ['scnE', [10934]], ['scnsim', [8937]], ['scpolint', [10771]], ['scsim', [8831]], ['Scy', [1057]], ['scy', [1089]], ['sdotb', [8865]], ['sdot', [8901]], ['sdote', [10854]], ['searhk', [10533]], ['searr', [8600]], ['seArr', [8664]], ['searrow', [8600]], ['sect', [167]], ['semi', [59]], ['seswar', [10537]], ['setminus', [8726]], ['setmn', [8726]], ['sext', [10038]], ['Sfr', [120086]], ['sfr', [120112]], ['sfrown', [8994]], ['sharp', [9839]], ['SHCHcy', [1065]], ['shchcy', [1097]], ['SHcy', [1064]], ['shcy', [1096]], ['ShortDownArrow', [8595]], ['ShortLeftArrow', [8592]], ['shortmid', [8739]], ['shortparallel', [8741]], ['ShortRightArrow', [8594]], ['ShortUpArrow', [8593]], ['shy', [173]], ['Sigma', [931]], ['sigma', [963]], ['sigmaf', [962]], ['sigmav', [962]], ['sim', [8764]], ['simdot', [10858]], ['sime', [8771]], ['simeq', [8771]], ['simg', [10910]], ['simgE', [10912]], ['siml', [10909]], ['simlE', [10911]], ['simne', [8774]], ['simplus', [10788]], ['simrarr', [10610]], ['slarr', [8592]], ['SmallCircle', [8728]], ['smallsetminus', [8726]], ['smashp', [10803]], ['smeparsl', [10724]], ['smid', [8739]], ['smile', [8995]], ['smt', [10922]], ['smte', [10924]], ['smtes', [10924, 65024]], ['SOFTcy', [1068]], ['softcy', [1100]], ['solbar', [9023]], ['solb', [10692]], ['sol', [47]], ['Sopf', [120138]], ['sopf', [120164]], ['spades', [9824]], ['spadesuit', [9824]], ['spar', [8741]], ['sqcap', [8851]], ['sqcaps', [8851, 65024]], ['sqcup', [8852]], ['sqcups', [8852, 65024]], ['Sqrt', [8730]], ['sqsub', [8847]], ['sqsube', [8849]], ['sqsubset', [8847]], ['sqsubseteq', [8849]], ['sqsup', [8848]], ['sqsupe', [8850]], ['sqsupset', [8848]], ['sqsupseteq', [8850]], ['square', [9633]], ['Square', [9633]], ['SquareIntersection', [8851]], ['SquareSubset', [8847]], ['SquareSubsetEqual', [8849]], ['SquareSuperset', [8848]], ['SquareSupersetEqual', [8850]], ['SquareUnion', [8852]], ['squarf', [9642]], ['squ', [9633]], ['squf', [9642]], ['srarr', [8594]], ['Sscr', [119982]], ['sscr', [120008]], ['ssetmn', [8726]], ['ssmile', [8995]], ['sstarf', [8902]], ['Star', [8902]], ['star', [9734]], ['starf', [9733]], ['straightepsilon', [1013]], ['straightphi', [981]], ['strns', [175]], ['sub', [8834]], ['Sub', [8912]], ['subdot', [10941]], ['subE', [10949]], ['sube', [8838]], ['subedot', [10947]], ['submult', [10945]], ['subnE', [10955]], ['subne', [8842]], ['subplus', [10943]], ['subrarr', [10617]], ['subset', [8834]], ['Subset', [8912]], ['subseteq', [8838]], ['subseteqq', [10949]], ['SubsetEqual', [8838]], ['subsetneq', [8842]], ['subsetneqq', [10955]], ['subsim', [10951]], ['subsub', [10965]], ['subsup', [10963]], ['succapprox', [10936]], ['succ', [8827]], ['succcurlyeq', [8829]], ['Succeeds', [8827]], ['SucceedsEqual', [10928]], ['SucceedsSlantEqual', [8829]], ['SucceedsTilde', [8831]], ['succeq', [10928]], ['succnapprox', [10938]], ['succneqq', [10934]], ['succnsim', [8937]], ['succsim', [8831]], ['SuchThat', [8715]], ['sum', [8721]], ['Sum', [8721]], ['sung', [9834]], ['sup1', [185]], ['sup2', [178]], ['sup3', [179]], ['sup', [8835]], ['Sup', [8913]], ['supdot', [10942]], ['supdsub', [10968]], ['supE', [10950]], ['supe', [8839]], ['supedot', [10948]], ['Superset', [8835]], ['SupersetEqual', [8839]], ['suphsol', [10185]], ['suphsub', [10967]], ['suplarr', [10619]], ['supmult', [10946]], ['supnE', [10956]], ['supne', [8843]], ['supplus', [10944]], ['supset', [8835]], ['Supset', [8913]], ['supseteq', [8839]], ['supseteqq', [10950]], ['supsetneq', [8843]], ['supsetneqq', [10956]], ['supsim', [10952]], ['supsub', [10964]], ['supsup', [10966]], ['swarhk', [10534]], ['swarr', [8601]], ['swArr', [8665]], ['swarrow', [8601]], ['swnwar', [10538]], ['szlig', [223]], ['Tab', [9]], ['target', [8982]], ['Tau', [932]], ['tau', [964]], ['tbrk', [9140]], ['Tcaron', [356]], ['tcaron', [357]], ['Tcedil', [354]], ['tcedil', [355]], ['Tcy', [1058]], ['tcy', [1090]], ['tdot', [8411]], ['telrec', [8981]], ['Tfr', [120087]], ['tfr', [120113]], ['there4', [8756]], ['therefore', [8756]], ['Therefore', [8756]], ['Theta', [920]], ['theta', [952]], ['thetasym', [977]], ['thetav', [977]], ['thickapprox', [8776]], ['thicksim', [8764]], ['ThickSpace', [8287, 8202]], ['ThinSpace', [8201]], ['thinsp', [8201]], ['thkap', [8776]], ['thksim', [8764]], ['THORN', [222]], ['thorn', [254]], ['tilde', [732]], ['Tilde', [8764]], ['TildeEqual', [8771]], ['TildeFullEqual', [8773]], ['TildeTilde', [8776]], ['timesbar', [10801]], ['timesb', [8864]], ['times', [215]], ['timesd', [10800]], ['tint', [8749]], ['toea', [10536]], ['topbot', [9014]], ['topcir', [10993]], ['top', [8868]], ['Topf', [120139]], ['topf', [120165]], ['topfork', [10970]], ['tosa', [10537]], ['tprime', [8244]], ['trade', [8482]], ['TRADE', [8482]], ['triangle', [9653]], ['triangledown', [9663]], ['triangleleft', [9667]], ['trianglelefteq', [8884]], ['triangleq', [8796]], ['triangleright', [9657]], ['trianglerighteq', [8885]], ['tridot', [9708]], ['trie', [8796]], ['triminus', [10810]], ['TripleDot', [8411]], ['triplus', [10809]], ['trisb', [10701]], ['tritime', [10811]], ['trpezium', [9186]], ['Tscr', [119983]], ['tscr', [120009]], ['TScy', [1062]], ['tscy', [1094]], ['TSHcy', [1035]], ['tshcy', [1115]], ['Tstrok', [358]], ['tstrok', [359]], ['twixt', [8812]], ['twoheadleftarrow', [8606]], ['twoheadrightarrow', [8608]], ['Uacute', [218]], ['uacute', [250]], ['uarr', [8593]], ['Uarr', [8607]], ['uArr', [8657]], ['Uarrocir', [10569]], ['Ubrcy', [1038]], ['ubrcy', [1118]], ['Ubreve', [364]], ['ubreve', [365]], ['Ucirc', [219]], ['ucirc', [251]], ['Ucy', [1059]], ['ucy', [1091]], ['udarr', [8645]], ['Udblac', [368]], ['udblac', [369]], ['udhar', [10606]], ['ufisht', [10622]], ['Ufr', [120088]], ['ufr', [120114]], ['Ugrave', [217]], ['ugrave', [249]], ['uHar', [10595]], ['uharl', [8639]], ['uharr', [8638]], ['uhblk', [9600]], ['ulcorn', [8988]], ['ulcorner', [8988]], ['ulcrop', [8975]], ['ultri', [9720]], ['Umacr', [362]], ['umacr', [363]], ['uml', [168]], ['UnderBar', [95]], ['UnderBrace', [9183]], ['UnderBracket', [9141]], ['UnderParenthesis', [9181]], ['Union', [8899]], ['UnionPlus', [8846]], ['Uogon', [370]], ['uogon', [371]], ['Uopf', [120140]], ['uopf', [120166]], ['UpArrowBar', [10514]], ['uparrow', [8593]], ['UpArrow', [8593]], ['Uparrow', [8657]], ['UpArrowDownArrow', [8645]], ['updownarrow', [8597]], ['UpDownArrow', [8597]], ['Updownarrow', [8661]], ['UpEquilibrium', [10606]], ['upharpoonleft', [8639]], ['upharpoonright', [8638]], ['uplus', [8846]], ['UpperLeftArrow', [8598]], ['UpperRightArrow', [8599]], ['upsi', [965]], ['Upsi', [978]], ['upsih', [978]], ['Upsilon', [933]], ['upsilon', [965]], ['UpTeeArrow', [8613]], ['UpTee', [8869]], ['upuparrows', [8648]], ['urcorn', [8989]], ['urcorner', [8989]], ['urcrop', [8974]], ['Uring', [366]], ['uring', [367]], ['urtri', [9721]], ['Uscr', [119984]], ['uscr', [120010]], ['utdot', [8944]], ['Utilde', [360]], ['utilde', [361]], ['utri', [9653]], ['utrif', [9652]], ['uuarr', [8648]], ['Uuml', [220]], ['uuml', [252]], ['uwangle', [10663]], ['vangrt', [10652]], ['varepsilon', [1013]], ['varkappa', [1008]], ['varnothing', [8709]], ['varphi', [981]], ['varpi', [982]], ['varpropto', [8733]], ['varr', [8597]], ['vArr', [8661]], ['varrho', [1009]], ['varsigma', [962]], ['varsubsetneq', [8842, 65024]], ['varsubsetneqq', [10955, 65024]], ['varsupsetneq', [8843, 65024]], ['varsupsetneqq', [10956, 65024]], ['vartheta', [977]], ['vartriangleleft', [8882]], ['vartriangleright', [8883]], ['vBar', [10984]], ['Vbar', [10987]], ['vBarv', [10985]], ['Vcy', [1042]], ['vcy', [1074]], ['vdash', [8866]], ['vDash', [8872]], ['Vdash', [8873]], ['VDash', [8875]], ['Vdashl', [10982]], ['veebar', [8891]], ['vee', [8744]], ['Vee', [8897]], ['veeeq', [8794]], ['vellip', [8942]], ['verbar', [124]], ['Verbar', [8214]], ['vert', [124]], ['Vert', [8214]], ['VerticalBar', [8739]], ['VerticalLine', [124]], ['VerticalSeparator', [10072]], ['VerticalTilde', [8768]], ['VeryThinSpace', [8202]], ['Vfr', [120089]], ['vfr', [120115]], ['vltri', [8882]], ['vnsub', [8834, 8402]], ['vnsup', [8835, 8402]], ['Vopf', [120141]], ['vopf', [120167]], ['vprop', [8733]], ['vrtri', [8883]], ['Vscr', [119985]], ['vscr', [120011]], ['vsubnE', [10955, 65024]], ['vsubne', [8842, 65024]], ['vsupnE', [10956, 65024]], ['vsupne', [8843, 65024]], ['Vvdash', [8874]], ['vzigzag', [10650]], ['Wcirc', [372]], ['wcirc', [373]], ['wedbar', [10847]], ['wedge', [8743]], ['Wedge', [8896]], ['wedgeq', [8793]], ['weierp', [8472]], ['Wfr', [120090]], ['wfr', [120116]], ['Wopf', [120142]], ['wopf', [120168]], ['wp', [8472]], ['wr', [8768]], ['wreath', [8768]], ['Wscr', [119986]], ['wscr', [120012]], ['xcap', [8898]], ['xcirc', [9711]], ['xcup', [8899]], ['xdtri', [9661]], ['Xfr', [120091]], ['xfr', [120117]], ['xharr', [10231]], ['xhArr', [10234]], ['Xi', [926]], ['xi', [958]], ['xlarr', [10229]], ['xlArr', [10232]], ['xmap', [10236]], ['xnis', [8955]], ['xodot', [10752]], ['Xopf', [120143]], ['xopf', [120169]], ['xoplus', [10753]], ['xotime', [10754]], ['xrarr', [10230]], ['xrArr', [10233]], ['Xscr', [119987]], ['xscr', [120013]], ['xsqcup', [10758]], ['xuplus', [10756]], ['xutri', [9651]], ['xvee', [8897]], ['xwedge', [8896]], ['Yacute', [221]], ['yacute', [253]], ['YAcy', [1071]], ['yacy', [1103]], ['Ycirc', [374]], ['ycirc', [375]], ['Ycy', [1067]], ['ycy', [1099]], ['yen', [165]], ['Yfr', [120092]], ['yfr', [120118]], ['YIcy', [1031]], ['yicy', [1111]], ['Yopf', [120144]], ['yopf', [120170]], ['Yscr', [119988]], ['yscr', [120014]], ['YUcy', [1070]], ['yucy', [1102]], ['yuml', [255]], ['Yuml', [376]], ['Zacute', [377]], ['zacute', [378]], ['Zcaron', [381]], ['zcaron', [382]], ['Zcy', [1047]], ['zcy', [1079]], ['Zdot', [379]], ['zdot', [380]], ['zeetrf', [8488]], ['ZeroWidthSpace', [8203]], ['Zeta', [918]], ['zeta', [950]], ['zfr', [120119]], ['Zfr', [8488]], ['ZHcy', [1046]], ['zhcy', [1078]], ['zigrarr', [8669]], ['zopf', [120171]], ['Zopf', [8484]], ['Zscr', [119989]], ['zscr', [120015]], ['zwj', [8205]], ['zwnj', [8204]]];

var alphaIndex = {};
var charIndex = {};

createIndexes(alphaIndex, charIndex);

/**
 * @constructor
 */
function Html5Entities() {}

/**
 * @param {String} str
 * @returns {String}
 */
Html5Entities.prototype.decode = function(str) {
    if (!str || !str.length) {
        return '';
    }
    return str.replace(/&(#?[\w\d]+);?/g, function(s, entity) {
        var chr;
        if (entity.charAt(0) === "#") {
            var code = entity.charAt(1) === 'x' ?
                parseInt(entity.substr(2).toLowerCase(), 16) :
                parseInt(entity.substr(1));

            if (!(isNaN(code) || code < -32768 || code > 65535)) {
                chr = String.fromCharCode(code);
            }
        } else {
            chr = alphaIndex[entity];
        }
        return chr || s;
    });
};

/**
 * @param {String} str
 * @returns {String}
 */
 Html5Entities.decode = function(str) {
    return new Html5Entities().decode(str);
 };

/**
 * @param {String} str
 * @returns {String}
 */
Html5Entities.prototype.encode = function(str) {
    if (!str || !str.length) {
        return '';
    }
    var strLength = str.length;
    var result = '';
    var i = 0;
    while (i < strLength) {
        var charInfo = charIndex[str.charCodeAt(i)];
        if (charInfo) {
            var alpha = charInfo[str.charCodeAt(i + 1)];
            if (alpha) {
                i++;
            } else {
                alpha = charInfo[''];
            }
            if (alpha) {
                result += "&" + alpha + ";";
                i++;
                continue;
            }
        }
        result += str.charAt(i);
        i++;
    }
    return result;
};

/**
 * @param {String} str
 * @returns {String}
 */
 Html5Entities.encode = function(str) {
    return new Html5Entities().encode(str);
 };

/**
 * @param {String} str
 * @returns {String}
 */
Html5Entities.prototype.encodeNonUTF = function(str) {
    if (!str || !str.length) {
        return '';
    }
    var strLength = str.length;
    var result = '';
    var i = 0;
    while (i < strLength) {
        var c = str.charCodeAt(i);
        var charInfo = charIndex[c];
        if (charInfo) {
            var alpha = charInfo[str.charCodeAt(i + 1)];
            if (alpha) {
                i++;
            } else {
                alpha = charInfo[''];
            }
            if (alpha) {
                result += "&" + alpha + ";";
                i++;
                continue;
            }
        }
        if (c < 32 || c > 126) {
            result += '&#' + c + ';';
        } else {
            result += str.charAt(i);
        }
        i++;
    }
    return result;
};

/**
 * @param {String} str
 * @returns {String}
 */
 Html5Entities.encodeNonUTF = function(str) {
    return new Html5Entities().encodeNonUTF(str);
 };

/**
 * @param {String} str
 * @returns {String}
 */
Html5Entities.prototype.encodeNonASCII = function(str) {
    if (!str || !str.length) {
        return '';
    }
    var strLength = str.length;
    var result = '';
    var i = 0;
    while (i < strLength) {
        var c = str.charCodeAt(i);
        if (c <= 255) {
            result += str[i++];
            continue;
        }
        result += '&#' + c + ';';
        i++
    }
    return result;
};

/**
 * @param {String} str
 * @returns {String}
 */
 Html5Entities.encodeNonASCII = function(str) {
    return new Html5Entities().encodeNonASCII(str);
 };

/**
 * @param {Object} alphaIndex Passed by reference.
 * @param {Object} charIndex Passed by reference.
 */
function createIndexes(alphaIndex, charIndex) {
    var i = ENTITIES.length;
    var _results = [];
    while (i--) {
        var e = ENTITIES[i];
        var alpha = e[0];
        var chars = e[1];
        var chr = chars[0];
        var addChar = (chr < 32 || chr > 126) || chr === 62 || chr === 60 || chr === 38 || chr === 34 || chr === 39;
        var charInfo;
        if (addChar) {
            charInfo = charIndex[chr] = charIndex[chr] || {};
        }
        if (chars[1]) {
            var chr2 = chars[1];
            alphaIndex[alpha] = String.fromCharCode(chr) + String.fromCharCode(chr2);
            _results.push(addChar && (charInfo[chr2] = alpha));
        } else {
            alphaIndex[alpha] = String.fromCharCode(chr);
            _results.push(addChar && (charInfo[''] = alpha));
        }
    }
}

module.exports = Html5Entities;


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

var EventEmitter = __webpack_require__(27);
module.exports = new EventEmitter();


/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return res; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__ar__ = __webpack_require__(59);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__en__ = __webpack_require__(60);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__fr__ = __webpack_require__(61);




var lang = document.documentElement.lang || 'en';
var res = { ar: __WEBPACK_IMPORTED_MODULE_0__ar__["a" /* strings */], en: __WEBPACK_IMPORTED_MODULE_1__en__["a" /* strings */], fr: __WEBPACK_IMPORTED_MODULE_2__fr__["a" /* strings */] }[lang];

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(__resourceQuery) {

/* global __resourceQuery WorkerGlobalScope self */
/* eslint prefer-destructuring: off */

var url = __webpack_require__(9);
var stripAnsi = __webpack_require__(16);
var log = __webpack_require__(18).getLogger('webpack-dev-server');
var socket = __webpack_require__(19);
var overlay = __webpack_require__(21);

function getCurrentScriptSource() {
  // `document.currentScript` is the most accurate way to find the current script,
  // but is not supported in all browsers.
  if (document.currentScript) {
    return document.currentScript.getAttribute('src');
  }
  // Fall back to getting all scripts in the document.
  var scriptElements = document.scripts || [];
  var currentScript = scriptElements[scriptElements.length - 1];
  if (currentScript) {
    return currentScript.getAttribute('src');
  }
  // Fail as there was no script to use.
  throw new Error('[WDS] Failed to get current script source.');
}

var urlParts = void 0;
var hotReload = true;
if (typeof window !== 'undefined') {
  var qs = window.location.search.toLowerCase();
  hotReload = qs.indexOf('hotreload=false') === -1;
}
if (true) {
  // If this bundle is inlined, use the resource query to get the correct url.
  urlParts = url.parse(__resourceQuery.substr(1));
} else {
  // Else, get the url from the <script> this file was called with.
  var scriptHost = getCurrentScriptSource();
  // eslint-disable-next-line no-useless-escape
  scriptHost = scriptHost.replace(/\/[^\/]+$/, '');
  urlParts = url.parse(scriptHost || '/', false, true);
}

if (!urlParts.port || urlParts.port === '0') {
  urlParts.port = self.location.port;
}

var _hot = false;
var initial = true;
var currentHash = '';
var useWarningOverlay = false;
var useErrorOverlay = false;
var useProgress = false;

var INFO = 'info';
var WARNING = 'warning';
var ERROR = 'error';
var NONE = 'none';

// Set the default log level
log.setDefaultLevel(INFO);

// Send messages to the outside, so plugins can consume it.
function sendMsg(type, data) {
  if (typeof self !== 'undefined' && (typeof WorkerGlobalScope === 'undefined' || !(self instanceof WorkerGlobalScope))) {
    self.postMessage({
      type: 'webpack' + type,
      data: data
    }, '*');
  }
}

// var onSocketMsg = {
//   hot: function hot() {
//     _hot = true;
//     log.info('[WDS] Hot Module Replacement enabled.');
//   },
//   invalid: function invalid() {
//     log.info('[WDS] App updated. Recompiling...');
//     // fixes #1042. overlay doesn't clear if errors are fixed but warnings remain.
//     if (useWarningOverlay || useErrorOverlay) overlay.clear();
//     sendMsg('Invalid');
//   },
//   hash: function hash(_hash) {
//     currentHash = _hash;
//   },

//   'still-ok': function stillOk() {
//     log.info('[WDS] Nothing changed.');
//     if (useWarningOverlay || useErrorOverlay) overlay.clear();
//     sendMsg('StillOk');
//   },
//   'log-level': function logLevel(level) {
//     var hotCtx = __webpack_require__(26);
//     if (hotCtx.keys().indexOf('./log') !== -1) {
//       hotCtx('./log').setLogLevel(level);
//     }
//     switch (level) {
//       case INFO:
//       case ERROR:
//         log.setLevel(level);
//         break;
//       case WARNING:
//         // loglevel's warning name is different from webpack's
//         log.setLevel('warn');
//         break;
//       case NONE:
//         log.disableAll();
//         break;
//       default:
//         log.error('[WDS] Unknown clientLogLevel \'' + level + '\'');
//     }
//   },
//   overlay: function overlay(value) {
//     if (typeof document !== 'undefined') {
//       if (typeof value === 'boolean') {
//         useWarningOverlay = false;
//         useErrorOverlay = value;
//       } else if (value) {
//         useWarningOverlay = value.warnings;
//         useErrorOverlay = value.errors;
//       }
//     }
//   },
//   progress: function progress(_progress) {
//     if (typeof document !== 'undefined') {
//       useProgress = _progress;
//     }
//   },

//   'progress-update': function progressUpdate(data) {
//     if (useProgress) log.info('[WDS] ' + data.percent + '% - ' + data.msg + '.');
//   },
//   ok: function ok() {
//     sendMsg('Ok');
//     if (useWarningOverlay || useErrorOverlay) overlay.clear();
//     if (initial) return initial = false; // eslint-disable-line no-return-assign
//     reloadApp();
//   },

//   'content-changed': function contentChanged() {
//     log.info('[WDS] Content base changed. Reloading...');
//     self.location.reload();
//   },
//   warnings: function warnings(_warnings) {
//     log.warn('[WDS] Warnings while compiling.');
//     var strippedWarnings = _warnings.map(function (warning) {
//       return stripAnsi(warning);
//     });
//     sendMsg('Warnings', strippedWarnings);
//     for (var i = 0; i < strippedWarnings.length; i++) {
//       log.warn(strippedWarnings[i]);
//     }
//     if (useWarningOverlay) overlay.showMessage(_warnings);

//     if (initial) return initial = false; // eslint-disable-line no-return-assign
//     reloadApp();
//   },
//   errors: function errors(_errors) {
//     log.error('[WDS] Errors while compiling. Reload prevented.');
//     var strippedErrors = _errors.map(function (error) {
//       return stripAnsi(error);
//     });
//     sendMsg('Errors', strippedErrors);
//     for (var i = 0; i < strippedErrors.length; i++) {
//       log.error(strippedErrors[i]);
//     }
//     if (useErrorOverlay) overlay.showMessage(_errors);
//     initial = false;
//   },
//   error: function error(_error) {
//     log.error(_error);
//   },
//   close: function close() {
//     log.error('[WDS] Disconnected!');
//     sendMsg('Close');
//   }
// };

// var hostname = urlParts.hostname;
// var protocol = urlParts.protocol;

// // check ipv4 and ipv6 `all hostname`
// if (hostname === '0.0.0.0' || hostname === '::') {
//   // why do we need this check?
//   // hostname n/a for file protocol (example, when using electron, ionic)
//   // see: https://github.com/webpack/webpack-dev-server/pull/384
//   // eslint-disable-next-line no-bitwise
//   if (self.location.hostname && !!~self.location.protocol.indexOf('http')) {
//     hostname = self.location.hostname;
//   }
// }

// `hostname` can be empty when the script path is relative. In that case, specifying
// a protocol would result in an invalid URL.
// When https is used in the app, secure websockets are always necessary
// because the browser doesn't accept non-secure websockets.
// if (hostname && (self.location.protocol === 'https:' || urlParts.hostname === '0.0.0.0')) {
//   protocol = self.location.protocol;
// }

// var socketUrl = url.format({
//   protocol: protocol,
//   auth: urlParts.auth,
//   hostname: hostname,
//   port: urlParts.port,
//   pathname: urlParts.path == null || urlParts.path === '/' ? '/sockjs-node' : urlParts.path
// });

// socket(socketUrl, onSocketMsg);

var isUnloading = false;
self.addEventListener('beforeunload', function () {
  isUnloading = true;
});

function reloadApp() {
  if (isUnloading || !hotReload) {
    return;
  }
  if (_hot) {
    log.info('[WDS] App hot update...');
    // eslint-disable-next-line global-require
    var hotEmitter = __webpack_require__(6);
    hotEmitter.emit('webpackHotUpdate', currentHash);
    if (typeof self !== 'undefined' && self.window) {
      // broadcast update to window
      self.postMessage('webpackHotUpdate' + currentHash, '*');
    }
  } else {
    var rootWindow = self;
    // use parent window for reload (in case we're in an iframe with no valid src)
    var intervalId = self.setInterval(function () {
      if (rootWindow.location.protocol !== 'about:') {
        // reload immediately if protocol is valid
        applyReload(rootWindow, intervalId);
      } else {
        rootWindow = rootWindow.parent;
        if (rootWindow.parent === rootWindow) {
          // if parent equals current window we've reached the root which would continue forever, so trigger a reload anyways
          applyReload(rootWindow, intervalId);
        }
      }
    });
  }

  function applyReload(rootWindow, intervalId) {
    clearInterval(intervalId);
    log.info('[WDS] App updated. Reloading...');
    rootWindow.location.reload();
  }
}
/* WEBPACK VAR INJECTION */}.call(exports, "?http://0.0.0.0:8181"))

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



var punycode = __webpack_require__(10);
var util = __webpack_require__(12);

exports.parse = urlParse;
exports.resolve = urlResolve;
exports.resolveObject = urlResolveObject;
exports.format = urlFormat;

exports.Url = Url;

function Url() {
  this.protocol = null;
  this.slashes = null;
  this.auth = null;
  this.host = null;
  this.port = null;
  this.hostname = null;
  this.hash = null;
  this.search = null;
  this.query = null;
  this.pathname = null;
  this.path = null;
  this.href = null;
}

// Reference: RFC 3986, RFC 1808, RFC 2396

// define these here so at least they only have to be
// compiled once on the first module load.
var protocolPattern = /^([a-z0-9.+-]+:)/i,
    portPattern = /:[0-9]*$/,

    // Special case for a simple path URL
    simplePathPattern = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,

    // RFC 2396: characters reserved for delimiting URLs.
    // We actually just auto-escape these.
    delims = ['<', '>', '"', '`', ' ', '\r', '\n', '\t'],

    // RFC 2396: characters not allowed for various reasons.
    unwise = ['{', '}', '|', '\\', '^', '`'].concat(delims),

    // Allowed by RFCs, but cause of XSS attacks.  Always escape these.
    autoEscape = ['\''].concat(unwise),
    // Characters that are never ever allowed in a hostname.
    // Note that any invalid chars are also handled, but these
    // are the ones that are *expected* to be seen, so we fast-path
    // them.
    nonHostChars = ['%', '/', '?', ';', '#'].concat(autoEscape),
    hostEndingChars = ['/', '?', '#'],
    hostnameMaxLen = 255,
    hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/,
    hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/,
    // protocols that can allow "unsafe" and "unwise" chars.
    unsafeProtocol = {
      'javascript': true,
      'javascript:': true
    },
    // protocols that never have a hostname.
    hostlessProtocol = {
      'javascript': true,
      'javascript:': true
    },
    // protocols that always contain a // bit.
    slashedProtocol = {
      'http': true,
      'https': true,
      'ftp': true,
      'gopher': true,
      'file': true,
      'http:': true,
      'https:': true,
      'ftp:': true,
      'gopher:': true,
      'file:': true
    },
    querystring = __webpack_require__(13);

function urlParse(url, parseQueryString, slashesDenoteHost) {
  if (url && util.isObject(url) && url instanceof Url) return url;

  var u = new Url;
  u.parse(url, parseQueryString, slashesDenoteHost);
  return u;
}

Url.prototype.parse = function(url, parseQueryString, slashesDenoteHost) {
  if (!util.isString(url)) {
    throw new TypeError("Parameter 'url' must be a string, not " + typeof url);
  }

  // Copy chrome, IE, opera backslash-handling behavior.
  // Back slashes before the query string get converted to forward slashes
  // See: https://code.google.com/p/chromium/issues/detail?id=25916
  var queryIndex = url.indexOf('?'),
      splitter =
          (queryIndex !== -1 && queryIndex < url.indexOf('#')) ? '?' : '#',
      uSplit = url.split(splitter),
      slashRegex = /\\/g;
  uSplit[0] = uSplit[0].replace(slashRegex, '/');
  url = uSplit.join(splitter);

  var rest = url;

  // trim before proceeding.
  // This is to support parse stuff like "  http://foo.com  \n"
  rest = rest.trim();

  if (!slashesDenoteHost && url.split('#').length === 1) {
    // Try fast path regexp
    var simplePath = simplePathPattern.exec(rest);
    if (simplePath) {
      this.path = rest;
      this.href = rest;
      this.pathname = simplePath[1];
      if (simplePath[2]) {
        this.search = simplePath[2];
        if (parseQueryString) {
          this.query = querystring.parse(this.search.substr(1));
        } else {
          this.query = this.search.substr(1);
        }
      } else if (parseQueryString) {
        this.search = '';
        this.query = {};
      }
      return this;
    }
  }

  var proto = protocolPattern.exec(rest);
  if (proto) {
    proto = proto[0];
    var lowerProto = proto.toLowerCase();
    this.protocol = lowerProto;
    rest = rest.substr(proto.length);
  }

  // figure out if it's got a host
  // user@server is *always* interpreted as a hostname, and url
  // resolution will treat //foo/bar as host=foo,path=bar because that's
  // how the browser resolves relative URLs.
  if (slashesDenoteHost || proto || rest.match(/^\/\/[^@\/]+@[^@\/]+/)) {
    var slashes = rest.substr(0, 2) === '//';
    if (slashes && !(proto && hostlessProtocol[proto])) {
      rest = rest.substr(2);
      this.slashes = true;
    }
  }

  if (!hostlessProtocol[proto] &&
      (slashes || (proto && !slashedProtocol[proto]))) {

    // there's a hostname.
    // the first instance of /, ?, ;, or # ends the host.
    //
    // If there is an @ in the hostname, then non-host chars *are* allowed
    // to the left of the last @ sign, unless some host-ending character
    // comes *before* the @-sign.
    // URLs are obnoxious.
    //
    // ex:
    // http://a@b@c/ => user:a@b host:c
    // http://a@b?@c => user:a host:c path:/?@c

    // v0.12 TODO(isaacs): This is not quite how Chrome does things.
    // Review our test case against browsers more comprehensively.

    // find the first instance of any hostEndingChars
    var hostEnd = -1;
    for (var i = 0; i < hostEndingChars.length; i++) {
      var hec = rest.indexOf(hostEndingChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
        hostEnd = hec;
    }

    // at this point, either we have an explicit point where the
    // auth portion cannot go past, or the last @ char is the decider.
    var auth, atSign;
    if (hostEnd === -1) {
      // atSign can be anywhere.
      atSign = rest.lastIndexOf('@');
    } else {
      // atSign must be in auth portion.
      // http://a@b/c@d => host:b auth:a path:/c@d
      atSign = rest.lastIndexOf('@', hostEnd);
    }

    // Now we have a portion which is definitely the auth.
    // Pull that off.
    if (atSign !== -1) {
      auth = rest.slice(0, atSign);
      rest = rest.slice(atSign + 1);
      this.auth = decodeURIComponent(auth);
    }

    // the host is the remaining to the left of the first non-host char
    hostEnd = -1;
    for (var i = 0; i < nonHostChars.length; i++) {
      var hec = rest.indexOf(nonHostChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
        hostEnd = hec;
    }
    // if we still have not hit it, then the entire thing is a host.
    if (hostEnd === -1)
      hostEnd = rest.length;

    this.host = rest.slice(0, hostEnd);
    rest = rest.slice(hostEnd);

    // pull out port.
    this.parseHost();

    // we've indicated that there is a hostname,
    // so even if it's empty, it has to be present.
    this.hostname = this.hostname || '';

    // if hostname begins with [ and ends with ]
    // assume that it's an IPv6 address.
    var ipv6Hostname = this.hostname[0] === '[' &&
        this.hostname[this.hostname.length - 1] === ']';

    // validate a little.
    if (!ipv6Hostname) {
      var hostparts = this.hostname.split(/\./);
      for (var i = 0, l = hostparts.length; i < l; i++) {
        var part = hostparts[i];
        if (!part) continue;
        if (!part.match(hostnamePartPattern)) {
          var newpart = '';
          for (var j = 0, k = part.length; j < k; j++) {
            if (part.charCodeAt(j) > 127) {
              // we replace non-ASCII char with a temporary placeholder
              // we need this to make sure size of hostname is not
              // broken by replacing non-ASCII by nothing
              newpart += 'x';
            } else {
              newpart += part[j];
            }
          }
          // we test again with ASCII char only
          if (!newpart.match(hostnamePartPattern)) {
            var validParts = hostparts.slice(0, i);
            var notHost = hostparts.slice(i + 1);
            var bit = part.match(hostnamePartStart);
            if (bit) {
              validParts.push(bit[1]);
              notHost.unshift(bit[2]);
            }
            if (notHost.length) {
              rest = '/' + notHost.join('.') + rest;
            }
            this.hostname = validParts.join('.');
            break;
          }
        }
      }
    }

    if (this.hostname.length > hostnameMaxLen) {
      this.hostname = '';
    } else {
      // hostnames are always lower case.
      this.hostname = this.hostname.toLowerCase();
    }

    if (!ipv6Hostname) {
      // IDNA Support: Returns a punycoded representation of "domain".
      // It only converts parts of the domain name that
      // have non-ASCII characters, i.e. it doesn't matter if
      // you call it with a domain that already is ASCII-only.
      this.hostname = punycode.toASCII(this.hostname);
    }

    var p = this.port ? ':' + this.port : '';
    var h = this.hostname || '';
    this.host = h + p;
    this.href += this.host;

    // strip [ and ] from the hostname
    // the host field still retains them, though
    if (ipv6Hostname) {
      this.hostname = this.hostname.substr(1, this.hostname.length - 2);
      if (rest[0] !== '/') {
        rest = '/' + rest;
      }
    }
  }

  // now rest is set to the post-host stuff.
  // chop off any delim chars.
  if (!unsafeProtocol[lowerProto]) {

    // First, make 100% sure that any "autoEscape" chars get
    // escaped, even if encodeURIComponent doesn't think they
    // need to be.
    for (var i = 0, l = autoEscape.length; i < l; i++) {
      var ae = autoEscape[i];
      if (rest.indexOf(ae) === -1)
        continue;
      var esc = encodeURIComponent(ae);
      if (esc === ae) {
        esc = escape(ae);
      }
      rest = rest.split(ae).join(esc);
    }
  }


  // chop off from the tail first.
  var hash = rest.indexOf('#');
  if (hash !== -1) {
    // got a fragment string.
    this.hash = rest.substr(hash);
    rest = rest.slice(0, hash);
  }
  var qm = rest.indexOf('?');
  if (qm !== -1) {
    this.search = rest.substr(qm);
    this.query = rest.substr(qm + 1);
    if (parseQueryString) {
      this.query = querystring.parse(this.query);
    }
    rest = rest.slice(0, qm);
  } else if (parseQueryString) {
    // no query string, but parseQueryString still requested
    this.search = '';
    this.query = {};
  }
  if (rest) this.pathname = rest;
  if (slashedProtocol[lowerProto] &&
      this.hostname && !this.pathname) {
    this.pathname = '/';
  }

  //to support http.request
  if (this.pathname || this.search) {
    var p = this.pathname || '';
    var s = this.search || '';
    this.path = p + s;
  }

  // finally, reconstruct the href based on what has been validated.
  this.href = this.format();
  return this;
};

// format a parsed object into a url string
function urlFormat(obj) {
  // ensure it's an object, and not a string url.
  // If it's an obj, this is a no-op.
  // this way, you can call url_format() on strings
  // to clean up potentially wonky urls.
  if (util.isString(obj)) obj = urlParse(obj);
  if (!(obj instanceof Url)) return Url.prototype.format.call(obj);
  return obj.format();
}

Url.prototype.format = function() {
  var auth = this.auth || '';
  if (auth) {
    auth = encodeURIComponent(auth);
    auth = auth.replace(/%3A/i, ':');
    auth += '@';
  }

  var protocol = this.protocol || '',
      pathname = this.pathname || '',
      hash = this.hash || '',
      host = false,
      query = '';

  if (this.host) {
    host = auth + this.host;
  } else if (this.hostname) {
    host = auth + (this.hostname.indexOf(':') === -1 ?
        this.hostname :
        '[' + this.hostname + ']');
    if (this.port) {
      host += ':' + this.port;
    }
  }

  if (this.query &&
      util.isObject(this.query) &&
      Object.keys(this.query).length) {
    query = querystring.stringify(this.query);
  }

  var search = this.search || (query && ('?' + query)) || '';

  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  // only the slashedProtocols get the //.  Not mailto:, xmpp:, etc.
  // unless they had them to begin with.
  if (this.slashes ||
      (!protocol || slashedProtocol[protocol]) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname.charAt(0) !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash.charAt(0) !== '#') hash = '#' + hash;
  if (search && search.charAt(0) !== '?') search = '?' + search;

  pathname = pathname.replace(/[?#]/g, function(match) {
    return encodeURIComponent(match);
  });
  search = search.replace('#', '%23');

  return protocol + host + pathname + search + hash;
};

function urlResolve(source, relative) {
  return urlParse(source, false, true).resolve(relative);
}

Url.prototype.resolve = function(relative) {
  return this.resolveObject(urlParse(relative, false, true)).format();
};

function urlResolveObject(source, relative) {
  if (!source) return relative;
  return urlParse(source, false, true).resolveObject(relative);
}

Url.prototype.resolveObject = function(relative) {
  if (util.isString(relative)) {
    var rel = new Url();
    rel.parse(relative, false, true);
    relative = rel;
  }

  var result = new Url();
  var tkeys = Object.keys(this);
  for (var tk = 0; tk < tkeys.length; tk++) {
    var tkey = tkeys[tk];
    result[tkey] = this[tkey];
  }

  // hash is always overridden, no matter what.
  // even href="" will remove it.
  result.hash = relative.hash;

  // if the relative url is empty, then there's nothing left to do here.
  if (relative.href === '') {
    result.href = result.format();
    return result;
  }

  // hrefs like //foo/bar always cut to the protocol.
  if (relative.slashes && !relative.protocol) {
    // take everything except the protocol from relative
    var rkeys = Object.keys(relative);
    for (var rk = 0; rk < rkeys.length; rk++) {
      var rkey = rkeys[rk];
      if (rkey !== 'protocol')
        result[rkey] = relative[rkey];
    }

    //urlParse appends trailing / to urls like http://www.example.com
    if (slashedProtocol[result.protocol] &&
        result.hostname && !result.pathname) {
      result.path = result.pathname = '/';
    }

    result.href = result.format();
    return result;
  }

  if (relative.protocol && relative.protocol !== result.protocol) {
    // if it's a known url protocol, then changing
    // the protocol does weird things
    // first, if it's not file:, then we MUST have a host,
    // and if there was a path
    // to begin with, then we MUST have a path.
    // if it is file:, then the host is dropped,
    // because that's known to be hostless.
    // anything else is assumed to be absolute.
    if (!slashedProtocol[relative.protocol]) {
      var keys = Object.keys(relative);
      for (var v = 0; v < keys.length; v++) {
        var k = keys[v];
        result[k] = relative[k];
      }
      result.href = result.format();
      return result;
    }

    result.protocol = relative.protocol;
    if (!relative.host && !hostlessProtocol[relative.protocol]) {
      var relPath = (relative.pathname || '').split('/');
      while (relPath.length && !(relative.host = relPath.shift()));
      if (!relative.host) relative.host = '';
      if (!relative.hostname) relative.hostname = '';
      if (relPath[0] !== '') relPath.unshift('');
      if (relPath.length < 2) relPath.unshift('');
      result.pathname = relPath.join('/');
    } else {
      result.pathname = relative.pathname;
    }
    result.search = relative.search;
    result.query = relative.query;
    result.host = relative.host || '';
    result.auth = relative.auth;
    result.hostname = relative.hostname || relative.host;
    result.port = relative.port;
    // to support http.request
    if (result.pathname || result.search) {
      var p = result.pathname || '';
      var s = result.search || '';
      result.path = p + s;
    }
    result.slashes = result.slashes || relative.slashes;
    result.href = result.format();
    return result;
  }

  var isSourceAbs = (result.pathname && result.pathname.charAt(0) === '/'),
      isRelAbs = (
          relative.host ||
          relative.pathname && relative.pathname.charAt(0) === '/'
      ),
      mustEndAbs = (isRelAbs || isSourceAbs ||
                    (result.host && relative.pathname)),
      removeAllDots = mustEndAbs,
      srcPath = result.pathname && result.pathname.split('/') || [],
      relPath = relative.pathname && relative.pathname.split('/') || [],
      psychotic = result.protocol && !slashedProtocol[result.protocol];

  // if the url is a non-slashed url, then relative
  // links like ../.. should be able
  // to crawl up to the hostname, as well.  This is strange.
  // result.protocol has already been set by now.
  // Later on, put the first path part into the host field.
  if (psychotic) {
    result.hostname = '';
    result.port = null;
    if (result.host) {
      if (srcPath[0] === '') srcPath[0] = result.host;
      else srcPath.unshift(result.host);
    }
    result.host = '';
    if (relative.protocol) {
      relative.hostname = null;
      relative.port = null;
      if (relative.host) {
        if (relPath[0] === '') relPath[0] = relative.host;
        else relPath.unshift(relative.host);
      }
      relative.host = null;
    }
    mustEndAbs = mustEndAbs && (relPath[0] === '' || srcPath[0] === '');
  }

  if (isRelAbs) {
    // it's absolute.
    result.host = (relative.host || relative.host === '') ?
                  relative.host : result.host;
    result.hostname = (relative.hostname || relative.hostname === '') ?
                      relative.hostname : result.hostname;
    result.search = relative.search;
    result.query = relative.query;
    srcPath = relPath;
    // fall through to the dot-handling below.
  } else if (relPath.length) {
    // it's relative
    // throw away the existing file, and take the new path instead.
    if (!srcPath) srcPath = [];
    srcPath.pop();
    srcPath = srcPath.concat(relPath);
    result.search = relative.search;
    result.query = relative.query;
  } else if (!util.isNullOrUndefined(relative.search)) {
    // just pull out the search.
    // like href='?foo'.
    // Put this after the other two cases because it simplifies the booleans
    if (psychotic) {
      result.hostname = result.host = srcPath.shift();
      //occationaly the auth can get stuck only in host
      //this especially happens in cases like
      //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
      var authInHost = result.host && result.host.indexOf('@') > 0 ?
                       result.host.split('@') : false;
      if (authInHost) {
        result.auth = authInHost.shift();
        result.host = result.hostname = authInHost.shift();
      }
    }
    result.search = relative.search;
    result.query = relative.query;
    //to support http.request
    if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
      result.path = (result.pathname ? result.pathname : '') +
                    (result.search ? result.search : '');
    }
    result.href = result.format();
    return result;
  }

  if (!srcPath.length) {
    // no path at all.  easy.
    // we've already handled the other stuff above.
    result.pathname = null;
    //to support http.request
    if (result.search) {
      result.path = '/' + result.search;
    } else {
      result.path = null;
    }
    result.href = result.format();
    return result;
  }

  // if a url ENDs in . or .., then it must get a trailing slash.
  // however, if it ends in anything else non-slashy,
  // then it must NOT get a trailing slash.
  var last = srcPath.slice(-1)[0];
  var hasTrailingSlash = (
      (result.host || relative.host || srcPath.length > 1) &&
      (last === '.' || last === '..') || last === '');

  // strip single dots, resolve double dots to parent dir
  // if the path tries to go above the root, `up` ends up > 0
  var up = 0;
  for (var i = srcPath.length; i >= 0; i--) {
    last = srcPath[i];
    if (last === '.') {
      srcPath.splice(i, 1);
    } else if (last === '..') {
      srcPath.splice(i, 1);
      up++;
    } else if (up) {
      srcPath.splice(i, 1);
      up--;
    }
  }

  // if the path is allowed to go above the root, restore leading ..s
  if (!mustEndAbs && !removeAllDots) {
    for (; up--; up) {
      srcPath.unshift('..');
    }
  }

  if (mustEndAbs && srcPath[0] !== '' &&
      (!srcPath[0] || srcPath[0].charAt(0) !== '/')) {
    srcPath.unshift('');
  }

  if (hasTrailingSlash && (srcPath.join('/').substr(-1) !== '/')) {
    srcPath.push('');
  }

  var isAbsolute = srcPath[0] === '' ||
      (srcPath[0] && srcPath[0].charAt(0) === '/');

  // put the host back
  if (psychotic) {
    result.hostname = result.host = isAbsolute ? '' :
                                    srcPath.length ? srcPath.shift() : '';
    //occationaly the auth can get stuck only in host
    //this especially happens in cases like
    //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
    var authInHost = result.host && result.host.indexOf('@') > 0 ?
                     result.host.split('@') : false;
    if (authInHost) {
      result.auth = authInHost.shift();
      result.host = result.hostname = authInHost.shift();
    }
  }

  mustEndAbs = mustEndAbs || (result.host && srcPath.length);

  if (mustEndAbs && !isAbsolute) {
    srcPath.unshift('');
  }

  if (!srcPath.length) {
    result.pathname = null;
    result.path = null;
  } else {
    result.pathname = srcPath.join('/');
  }

  //to support request.http
  if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
    result.path = (result.pathname ? result.pathname : '') +
                  (result.search ? result.search : '');
  }
  result.auth = relative.auth || result.auth;
  result.slashes = result.slashes || relative.slashes;
  result.href = result.format();
  return result;
};

Url.prototype.parseHost = function() {
  var host = this.host;
  var port = portPattern.exec(host);
  if (port) {
    port = port[0];
    if (port !== ':') {
      this.port = port.substr(1);
    }
    host = host.substr(0, host.length - port.length);
  }
  if (host) this.hostname = host;
};


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(module, global) {var __WEBPACK_AMD_DEFINE_RESULT__;/*! https://mths.be/punycode v1.4.1 by @mathias */
;(function(root) {

	/** Detect free variables */
	var freeExports = typeof exports == 'object' && exports &&
		!exports.nodeType && exports;
	var freeModule = typeof module == 'object' && module &&
		!module.nodeType && module;
	var freeGlobal = typeof global == 'object' && global;
	if (
		freeGlobal.global === freeGlobal ||
		freeGlobal.window === freeGlobal ||
		freeGlobal.self === freeGlobal
	) {
		root = freeGlobal;
	}

	/**
	 * The `punycode` object.
	 * @name punycode
	 * @type Object
	 */
	var punycode,

	/** Highest positive signed 32-bit float value */
	maxInt = 2147483647, // aka. 0x7FFFFFFF or 2^31-1

	/** Bootstring parameters */
	base = 36,
	tMin = 1,
	tMax = 26,
	skew = 38,
	damp = 700,
	initialBias = 72,
	initialN = 128, // 0x80
	delimiter = '-', // '\x2D'

	/** Regular expressions */
	regexPunycode = /^xn--/,
	regexNonASCII = /[^\x20-\x7E]/, // unprintable ASCII chars + non-ASCII chars
	regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g, // RFC 3490 separators

	/** Error messages */
	errors = {
		'overflow': 'Overflow: input needs wider integers to process',
		'not-basic': 'Illegal input >= 0x80 (not a basic code point)',
		'invalid-input': 'Invalid input'
	},

	/** Convenience shortcuts */
	baseMinusTMin = base - tMin,
	floor = Math.floor,
	stringFromCharCode = String.fromCharCode,

	/** Temporary variable */
	key;

	/*--------------------------------------------------------------------------*/

	/**
	 * A generic error utility function.
	 * @private
	 * @param {String} type The error type.
	 * @returns {Error} Throws a `RangeError` with the applicable error message.
	 */
	function error(type) {
		throw new RangeError(errors[type]);
	}

	/**
	 * A generic `Array#map` utility function.
	 * @private
	 * @param {Array} array The array to iterate over.
	 * @param {Function} callback The function that gets called for every array
	 * item.
	 * @returns {Array} A new array of values returned by the callback function.
	 */
	function map(array, fn) {
		var length = array.length;
		var result = [];
		while (length--) {
			result[length] = fn(array[length]);
		}
		return result;
	}

	/**
	 * A simple `Array#map`-like wrapper to work with domain name strings or email
	 * addresses.
	 * @private
	 * @param {String} domain The domain name or email address.
	 * @param {Function} callback The function that gets called for every
	 * character.
	 * @returns {Array} A new string of characters returned by the callback
	 * function.
	 */
	function mapDomain(string, fn) {
		var parts = string.split('@');
		var result = '';
		if (parts.length > 1) {
			// In email addresses, only the domain name should be punycoded. Leave
			// the local part (i.e. everything up to `@`) intact.
			result = parts[0] + '@';
			string = parts[1];
		}
		// Avoid `split(regex)` for IE8 compatibility. See #17.
		string = string.replace(regexSeparators, '\x2E');
		var labels = string.split('.');
		var encoded = map(labels, fn).join('.');
		return result + encoded;
	}

	/**
	 * Creates an array containing the numeric code points of each Unicode
	 * character in the string. While JavaScript uses UCS-2 internally,
	 * this function will convert a pair of surrogate halves (each of which
	 * UCS-2 exposes as separate characters) into a single code point,
	 * matching UTF-16.
	 * @see `punycode.ucs2.encode`
	 * @see <https://mathiasbynens.be/notes/javascript-encoding>
	 * @memberOf punycode.ucs2
	 * @name decode
	 * @param {String} string The Unicode input string (UCS-2).
	 * @returns {Array} The new array of code points.
	 */
	function ucs2decode(string) {
		var output = [],
		    counter = 0,
		    length = string.length,
		    value,
		    extra;
		while (counter < length) {
			value = string.charCodeAt(counter++);
			if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
				// high surrogate, and there is a next character
				extra = string.charCodeAt(counter++);
				if ((extra & 0xFC00) == 0xDC00) { // low surrogate
					output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
				} else {
					// unmatched surrogate; only append this code unit, in case the next
					// code unit is the high surrogate of a surrogate pair
					output.push(value);
					counter--;
				}
			} else {
				output.push(value);
			}
		}
		return output;
	}

	/**
	 * Creates a string based on an array of numeric code points.
	 * @see `punycode.ucs2.decode`
	 * @memberOf punycode.ucs2
	 * @name encode
	 * @param {Array} codePoints The array of numeric code points.
	 * @returns {String} The new Unicode string (UCS-2).
	 */
	function ucs2encode(array) {
		return map(array, function(value) {
			var output = '';
			if (value > 0xFFFF) {
				value -= 0x10000;
				output += stringFromCharCode(value >>> 10 & 0x3FF | 0xD800);
				value = 0xDC00 | value & 0x3FF;
			}
			output += stringFromCharCode(value);
			return output;
		}).join('');
	}

	/**
	 * Converts a basic code point into a digit/integer.
	 * @see `digitToBasic()`
	 * @private
	 * @param {Number} codePoint The basic numeric code point value.
	 * @returns {Number} The numeric value of a basic code point (for use in
	 * representing integers) in the range `0` to `base - 1`, or `base` if
	 * the code point does not represent a value.
	 */
	function basicToDigit(codePoint) {
		if (codePoint - 48 < 10) {
			return codePoint - 22;
		}
		if (codePoint - 65 < 26) {
			return codePoint - 65;
		}
		if (codePoint - 97 < 26) {
			return codePoint - 97;
		}
		return base;
	}

	/**
	 * Converts a digit/integer into a basic code point.
	 * @see `basicToDigit()`
	 * @private
	 * @param {Number} digit The numeric value of a basic code point.
	 * @returns {Number} The basic code point whose value (when used for
	 * representing integers) is `digit`, which needs to be in the range
	 * `0` to `base - 1`. If `flag` is non-zero, the uppercase form is
	 * used; else, the lowercase form is used. The behavior is undefined
	 * if `flag` is non-zero and `digit` has no uppercase form.
	 */
	function digitToBasic(digit, flag) {
		//  0..25 map to ASCII a..z or A..Z
		// 26..35 map to ASCII 0..9
		return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
	}

	/**
	 * Bias adaptation function as per section 3.4 of RFC 3492.
	 * https://tools.ietf.org/html/rfc3492#section-3.4
	 * @private
	 */
	function adapt(delta, numPoints, firstTime) {
		var k = 0;
		delta = firstTime ? floor(delta / damp) : delta >> 1;
		delta += floor(delta / numPoints);
		for (/* no initialization */; delta > baseMinusTMin * tMax >> 1; k += base) {
			delta = floor(delta / baseMinusTMin);
		}
		return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
	}

	/**
	 * Converts a Punycode string of ASCII-only symbols to a string of Unicode
	 * symbols.
	 * @memberOf punycode
	 * @param {String} input The Punycode string of ASCII-only symbols.
	 * @returns {String} The resulting string of Unicode symbols.
	 */
	function decode(input) {
		// Don't use UCS-2
		var output = [],
		    inputLength = input.length,
		    out,
		    i = 0,
		    n = initialN,
		    bias = initialBias,
		    basic,
		    j,
		    index,
		    oldi,
		    w,
		    k,
		    digit,
		    t,
		    /** Cached calculation results */
		    baseMinusT;

		// Handle the basic code points: let `basic` be the number of input code
		// points before the last delimiter, or `0` if there is none, then copy
		// the first basic code points to the output.

		basic = input.lastIndexOf(delimiter);
		if (basic < 0) {
			basic = 0;
		}

		for (j = 0; j < basic; ++j) {
			// if it's not a basic code point
			if (input.charCodeAt(j) >= 0x80) {
				error('not-basic');
			}
			output.push(input.charCodeAt(j));
		}

		// Main decoding loop: start just after the last delimiter if any basic code
		// points were copied; start at the beginning otherwise.

		for (index = basic > 0 ? basic + 1 : 0; index < inputLength; /* no final expression */) {

			// `index` is the index of the next character to be consumed.
			// Decode a generalized variable-length integer into `delta`,
			// which gets added to `i`. The overflow checking is easier
			// if we increase `i` as we go, then subtract off its starting
			// value at the end to obtain `delta`.
			for (oldi = i, w = 1, k = base; /* no condition */; k += base) {

				if (index >= inputLength) {
					error('invalid-input');
				}

				digit = basicToDigit(input.charCodeAt(index++));

				if (digit >= base || digit > floor((maxInt - i) / w)) {
					error('overflow');
				}

				i += digit * w;
				t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);

				if (digit < t) {
					break;
				}

				baseMinusT = base - t;
				if (w > floor(maxInt / baseMinusT)) {
					error('overflow');
				}

				w *= baseMinusT;

			}

			out = output.length + 1;
			bias = adapt(i - oldi, out, oldi == 0);

			// `i` was supposed to wrap around from `out` to `0`,
			// incrementing `n` each time, so we'll fix that now:
			if (floor(i / out) > maxInt - n) {
				error('overflow');
			}

			n += floor(i / out);
			i %= out;

			// Insert `n` at position `i` of the output
			output.splice(i++, 0, n);

		}

		return ucs2encode(output);
	}

	/**
	 * Converts a string of Unicode symbols (e.g. a domain name label) to a
	 * Punycode string of ASCII-only symbols.
	 * @memberOf punycode
	 * @param {String} input The string of Unicode symbols.
	 * @returns {String} The resulting Punycode string of ASCII-only symbols.
	 */
	function encode(input) {
		var n,
		    delta,
		    handledCPCount,
		    basicLength,
		    bias,
		    j,
		    m,
		    q,
		    k,
		    t,
		    currentValue,
		    output = [],
		    /** `inputLength` will hold the number of code points in `input`. */
		    inputLength,
		    /** Cached calculation results */
		    handledCPCountPlusOne,
		    baseMinusT,
		    qMinusT;

		// Convert the input in UCS-2 to Unicode
		input = ucs2decode(input);

		// Cache the length
		inputLength = input.length;

		// Initialize the state
		n = initialN;
		delta = 0;
		bias = initialBias;

		// Handle the basic code points
		for (j = 0; j < inputLength; ++j) {
			currentValue = input[j];
			if (currentValue < 0x80) {
				output.push(stringFromCharCode(currentValue));
			}
		}

		handledCPCount = basicLength = output.length;

		// `handledCPCount` is the number of code points that have been handled;
		// `basicLength` is the number of basic code points.

		// Finish the basic string - if it is not empty - with a delimiter
		if (basicLength) {
			output.push(delimiter);
		}

		// Main encoding loop:
		while (handledCPCount < inputLength) {

			// All non-basic code points < n have been handled already. Find the next
			// larger one:
			for (m = maxInt, j = 0; j < inputLength; ++j) {
				currentValue = input[j];
				if (currentValue >= n && currentValue < m) {
					m = currentValue;
				}
			}

			// Increase `delta` enough to advance the decoder's <n,i> state to <m,0>,
			// but guard against overflow
			handledCPCountPlusOne = handledCPCount + 1;
			if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
				error('overflow');
			}

			delta += (m - n) * handledCPCountPlusOne;
			n = m;

			for (j = 0; j < inputLength; ++j) {
				currentValue = input[j];

				if (currentValue < n && ++delta > maxInt) {
					error('overflow');
				}

				if (currentValue == n) {
					// Represent delta as a generalized variable-length integer
					for (q = delta, k = base; /* no condition */; k += base) {
						t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);
						if (q < t) {
							break;
						}
						qMinusT = q - t;
						baseMinusT = base - t;
						output.push(
							stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0))
						);
						q = floor(qMinusT / baseMinusT);
					}

					output.push(stringFromCharCode(digitToBasic(q, 0)));
					bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
					delta = 0;
					++handledCPCount;
				}
			}

			++delta;
			++n;

		}
		return output.join('');
	}

	/**
	 * Converts a Punycode string representing a domain name or an email address
	 * to Unicode. Only the Punycoded parts of the input will be converted, i.e.
	 * it doesn't matter if you call it on a string that has already been
	 * converted to Unicode.
	 * @memberOf punycode
	 * @param {String} input The Punycoded domain name or email address to
	 * convert to Unicode.
	 * @returns {String} The Unicode representation of the given Punycode
	 * string.
	 */
	function toUnicode(input) {
		return mapDomain(input, function(string) {
			return regexPunycode.test(string)
				? decode(string.slice(4).toLowerCase())
				: string;
		});
	}

	/**
	 * Converts a Unicode string representing a domain name or an email address to
	 * Punycode. Only the non-ASCII parts of the domain name will be converted,
	 * i.e. it doesn't matter if you call it with a domain that's already in
	 * ASCII.
	 * @memberOf punycode
	 * @param {String} input The domain name or email address to convert, as a
	 * Unicode string.
	 * @returns {String} The Punycode representation of the given domain name or
	 * email address.
	 */
	function toASCII(input) {
		return mapDomain(input, function(string) {
			return regexNonASCII.test(string)
				? 'xn--' + encode(string)
				: string;
		});
	}

	/*--------------------------------------------------------------------------*/

	/** Define the public API */
	punycode = {
		/**
		 * A string representing the current Punycode.js version number.
		 * @memberOf punycode
		 * @type String
		 */
		'version': '1.4.1',
		/**
		 * An object of methods to convert from JavaScript's internal character
		 * representation (UCS-2) to Unicode code points, and back.
		 * @see <https://mathiasbynens.be/notes/javascript-encoding>
		 * @memberOf punycode
		 * @type Object
		 */
		'ucs2': {
			'decode': ucs2decode,
			'encode': ucs2encode
		},
		'decode': decode,
		'encode': encode,
		'toASCII': toASCII,
		'toUnicode': toUnicode
	};

	/** Expose `punycode` */
	// Some AMD build optimizers, like r.js, check for specific condition patterns
	// like the following:
	if (
		true
	) {
		!(__WEBPACK_AMD_DEFINE_RESULT__ = (function() {
			return punycode;
		}).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else if (freeExports && freeModule) {
		if (module.exports == freeExports) {
			// in Node.js, io.js, or RingoJS v0.8.0+
			freeModule.exports = punycode;
		} else {
			// in Narwhal or RingoJS v0.7.0-
			for (key in punycode) {
				punycode.hasOwnProperty(key) && (freeExports[key] = punycode[key]);
			}
		}
	} else {
		// in Rhino or a web browser
		root.punycode = punycode;
	}

}(this));

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(11)(module), __webpack_require__(4)))

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = function(module) {
	if(!module.webpackPolyfill) {
		module.deprecate = function() {};
		module.paths = [];
		// module.parent = undefined by default
		if(!module.children) module.children = [];
		Object.defineProperty(module, "loaded", {
			enumerable: true,
			get: function() {
				return module.l;
			}
		});
		Object.defineProperty(module, "id", {
			enumerable: true,
			get: function() {
				return module.i;
			}
		});
		module.webpackPolyfill = 1;
	}
	return module;
};


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = {
  isString: function(arg) {
    return typeof(arg) === 'string';
  },
  isObject: function(arg) {
    return typeof(arg) === 'object' && arg !== null;
  },
  isNull: function(arg) {
    return arg === null;
  },
  isNullOrUndefined: function(arg) {
    return arg == null;
  }
};


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.decode = exports.parse = __webpack_require__(14);
exports.encode = exports.stringify = __webpack_require__(15);


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



// If obj.hasOwnProperty has been overridden, then calling
// obj.hasOwnProperty(prop) will break.
// See: https://github.com/joyent/node/issues/1707
function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}

module.exports = function(qs, sep, eq, options) {
  sep = sep || '&';
  eq = eq || '=';
  var obj = {};

  if (typeof qs !== 'string' || qs.length === 0) {
    return obj;
  }

  var regexp = /\+/g;
  qs = qs.split(sep);

  var maxKeys = 1000;
  if (options && typeof options.maxKeys === 'number') {
    maxKeys = options.maxKeys;
  }

  var len = qs.length;
  // maxKeys <= 0 means that we should not limit keys count
  if (maxKeys > 0 && len > maxKeys) {
    len = maxKeys;
  }

  for (var i = 0; i < len; ++i) {
    var x = qs[i].replace(regexp, '%20'),
        idx = x.indexOf(eq),
        kstr, vstr, k, v;

    if (idx >= 0) {
      kstr = x.substr(0, idx);
      vstr = x.substr(idx + 1);
    } else {
      kstr = x;
      vstr = '';
    }

    k = decodeURIComponent(kstr);
    v = decodeURIComponent(vstr);

    if (!hasOwnProperty(obj, k)) {
      obj[k] = v;
    } else if (isArray(obj[k])) {
      obj[k].push(v);
    } else {
      obj[k] = [obj[k], v];
    }
  }

  return obj;
};

var isArray = Array.isArray || function (xs) {
  return Object.prototype.toString.call(xs) === '[object Array]';
};


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



var stringifyPrimitive = function(v) {
  switch (typeof v) {
    case 'string':
      return v;

    case 'boolean':
      return v ? 'true' : 'false';

    case 'number':
      return isFinite(v) ? v : '';

    default:
      return '';
  }
};

module.exports = function(obj, sep, eq, name) {
  sep = sep || '&';
  eq = eq || '=';
  if (obj === null) {
    obj = undefined;
  }

  if (typeof obj === 'object') {
    return map(objectKeys(obj), function(k) {
      var ks = encodeURIComponent(stringifyPrimitive(k)) + eq;
      if (isArray(obj[k])) {
        return map(obj[k], function(v) {
          return ks + encodeURIComponent(stringifyPrimitive(v));
        }).join(sep);
      } else {
        return ks + encodeURIComponent(stringifyPrimitive(obj[k]));
      }
    }).join(sep);

  }

  if (!name) return '';
  return encodeURIComponent(stringifyPrimitive(name)) + eq +
         encodeURIComponent(stringifyPrimitive(obj));
};

var isArray = Array.isArray || function (xs) {
  return Object.prototype.toString.call(xs) === '[object Array]';
};

function map (xs, f) {
  if (xs.map) return xs.map(f);
  var res = [];
  for (var i = 0; i < xs.length; i++) {
    res.push(f(xs[i], i));
  }
  return res;
}

var objectKeys = Object.keys || function (obj) {
  var res = [];
  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) res.push(key);
  }
  return res;
};


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var ansiRegex = __webpack_require__(17)();

module.exports = function (str) {
	return typeof str === 'string' ? str.replace(ansiRegex, '') : str;
};


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = function () {
	return /[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-PRZcf-nqry=><]/g;
};


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;/*
* loglevel - https://github.com/pimterry/loglevel
*
* Copyright (c) 2013 Tim Perry
* Licensed under the MIT license.
*/
(function (root, definition) {
    "use strict";
    if (true) {
        !(__WEBPACK_AMD_DEFINE_FACTORY__ = (definition),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module)) :
				__WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
    } else if (typeof module === 'object' && module.exports) {
        module.exports = definition();
    } else {
        root.log = definition();
    }
}(this, function () {
    "use strict";

    // Slightly dubious tricks to cut down minimized file size
    var noop = function() {};
    var undefinedType = "undefined";

    var logMethods = [
        "trace",
        "debug",
        "info",
        "warn",
        "error"
    ];

    // Cross-browser bind equivalent that works at least back to IE6
    function bindMethod(obj, methodName) {
        var method = obj[methodName];
        if (typeof method.bind === 'function') {
            return method.bind(obj);
        } else {
            try {
                return Function.prototype.bind.call(method, obj);
            } catch (e) {
                // Missing bind shim or IE8 + Modernizr, fallback to wrapping
                return function() {
                    return Function.prototype.apply.apply(method, [obj, arguments]);
                };
            }
        }
    }

    // Build the best logging method possible for this env
    // Wherever possible we want to bind, not wrap, to preserve stack traces
    function realMethod(methodName) {
        if (methodName === 'debug') {
            methodName = 'log';
        }

        if (typeof console === undefinedType) {
            return false; // No method possible, for now - fixed later by enableLoggingWhenConsoleArrives
        } else if (console[methodName] !== undefined) {
            return bindMethod(console, methodName);
        } else if (console.log !== undefined) {
            return bindMethod(console, 'log');
        } else {
            return noop;
        }
    }

    // These private functions always need `this` to be set properly

    function replaceLoggingMethods(level, loggerName) {
        /*jshint validthis:true */
        for (var i = 0; i < logMethods.length; i++) {
            var methodName = logMethods[i];
            this[methodName] = (i < level) ?
                noop :
                this.methodFactory(methodName, level, loggerName);
        }

        // Define log.log as an alias for log.debug
        this.log = this.debug;
    }

    // In old IE versions, the console isn't present until you first open it.
    // We build realMethod() replacements here that regenerate logging methods
    function enableLoggingWhenConsoleArrives(methodName, level, loggerName) {
        return function () {
            if (typeof console !== undefinedType) {
                replaceLoggingMethods.call(this, level, loggerName);
                this[methodName].apply(this, arguments);
            }
        };
    }

    // By default, we use closely bound real methods wherever possible, and
    // otherwise we wait for a console to appear, and then try again.
    function defaultMethodFactory(methodName, level, loggerName) {
        /*jshint validthis:true */
        return realMethod(methodName) ||
               enableLoggingWhenConsoleArrives.apply(this, arguments);
    }

    function Logger(name, defaultLevel, factory) {
      var self = this;
      var currentLevel;
      var storageKey = "loglevel";
      if (name) {
        storageKey += ":" + name;
      }

      function persistLevelIfPossible(levelNum) {
          var levelName = (logMethods[levelNum] || 'silent').toUpperCase();

          if (typeof window === undefinedType) return;

          // Use localStorage if available
          try {
              window.localStorage[storageKey] = levelName;
              return;
          } catch (ignore) {}

          // Use session cookie as fallback
          try {
              window.document.cookie =
                encodeURIComponent(storageKey) + "=" + levelName + ";";
          } catch (ignore) {}
      }

      function getPersistedLevel() {
          var storedLevel;

          if (typeof window === undefinedType) return;

          try {
              storedLevel = window.localStorage[storageKey];
          } catch (ignore) {}

          // Fallback to cookies if local storage gives us nothing
          if (typeof storedLevel === undefinedType) {
              try {
                  var cookie = window.document.cookie;
                  var location = cookie.indexOf(
                      encodeURIComponent(storageKey) + "=");
                  if (location !== -1) {
                      storedLevel = /^([^;]+)/.exec(cookie.slice(location))[1];
                  }
              } catch (ignore) {}
          }

          // If the stored level is not valid, treat it as if nothing was stored.
          if (self.levels[storedLevel] === undefined) {
              storedLevel = undefined;
          }

          return storedLevel;
      }

      /*
       *
       * Public logger API - see https://github.com/pimterry/loglevel for details
       *
       */

      self.name = name;

      self.levels = { "TRACE": 0, "DEBUG": 1, "INFO": 2, "WARN": 3,
          "ERROR": 4, "SILENT": 5};

      self.methodFactory = factory || defaultMethodFactory;

      self.getLevel = function () {
          return currentLevel;
      };

      self.setLevel = function (level, persist) {
          if (typeof level === "string" && self.levels[level.toUpperCase()] !== undefined) {
              level = self.levels[level.toUpperCase()];
          }
          if (typeof level === "number" && level >= 0 && level <= self.levels.SILENT) {
              currentLevel = level;
              if (persist !== false) {  // defaults to true
                  persistLevelIfPossible(level);
              }
              replaceLoggingMethods.call(self, level, name);
              if (typeof console === undefinedType && level < self.levels.SILENT) {
                  return "No console available for logging";
              }
          } else {
              throw "log.setLevel() called with invalid level: " + level;
          }
      };

      self.setDefaultLevel = function (level) {
          if (!getPersistedLevel()) {
              self.setLevel(level, false);
          }
      };

      self.enableAll = function(persist) {
          self.setLevel(self.levels.TRACE, persist);
      };

      self.disableAll = function(persist) {
          self.setLevel(self.levels.SILENT, persist);
      };

      // Initialize with the right level
      var initialLevel = getPersistedLevel();
      if (initialLevel == null) {
          initialLevel = defaultLevel == null ? "WARN" : defaultLevel;
      }
      self.setLevel(initialLevel, false);
    }

    /*
     *
     * Top-level API
     *
     */

    var defaultLogger = new Logger();

    var _loggersByName = {};
    defaultLogger.getLogger = function getLogger(name) {
        if (typeof name !== "string" || name === "") {
          throw new TypeError("You must supply a name when creating a logger.");
        }

        var logger = _loggersByName[name];
        if (!logger) {
          logger = _loggersByName[name] = new Logger(
            name, defaultLogger.getLevel(), defaultLogger.methodFactory);
        }
        return logger;
    };

    // Grab the current global log variable in case of overwrite
    var _log = (typeof window !== undefinedType) ? window.log : undefined;
    defaultLogger.noConflict = function() {
        if (typeof window !== undefinedType &&
               window.log === defaultLogger) {
            window.log = _log;
        }

        return defaultLogger;
    };

    defaultLogger.getLoggers = function getLoggers() {
        return _loggersByName;
    };

    return defaultLogger;
}));


/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var SockJS = __webpack_require__(20);

var retries = 0;
var sock = null;

var socket = function initSocket(url, handlers) {
  sock = new SockJS(url);

  sock.onopen = function onopen() {
    retries = 0;
  };

  sock.onclose = function onclose() {
    if (retries === 0) {
      handlers.close();
    }

    // Try to reconnect.
    sock = null;

    // After 10 retries stop trying, to prevent logspam.
    if (retries <= 10) {
      // Exponentially increase timeout to reconnect.
      // Respectfully copied from the package `got`.
      // eslint-disable-next-line no-mixed-operators, no-restricted-properties
      var retryInMs = 1000 * Math.pow(2, retries) + Math.random() * 100;
      retries += 1;

      setTimeout(function () {
        socket(url, handlers);
      }, retryInMs);
    }
  };

  sock.onmessage = function onmessage(e) {
    // This assumes that all data sent via the websocket is JSON.
    var msg = JSON.parse(e.data);
    if (handlers[msg.type]) {
      handlers[msg.type](msg.data);
    }
  };
};

module.exports = socket;

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {var require;var require;/* sockjs-client v1.1.5 | http://sockjs.org | MIT license */
(function(f){if(true){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.SockJS = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return require(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
(function (global){
'use strict';

var transportList = require('./transport-list');

module.exports = require('./main')(transportList);

// TODO can't get rid of this until all servers do
if ('_sockjs_onload' in global) {
  setTimeout(global._sockjs_onload, 1);
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./main":14,"./transport-list":16}],2:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , Event = require('./event')
  ;

function CloseEvent() {
  Event.call(this);
  this.initEvent('close', false, false);
  this.wasClean = false;
  this.code = 0;
  this.reason = '';
}

inherits(CloseEvent, Event);

module.exports = CloseEvent;

},{"./event":4,"inherits":56}],3:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , EventTarget = require('./eventtarget')
  ;

function EventEmitter() {
  EventTarget.call(this);
}

inherits(EventEmitter, EventTarget);

EventEmitter.prototype.removeAllListeners = function(type) {
  if (type) {
    delete this._listeners[type];
  } else {
    this._listeners = {};
  }
};

EventEmitter.prototype.once = function(type, listener) {
  var self = this
    , fired = false;

  function g() {
    self.removeListener(type, g);

    if (!fired) {
      fired = true;
      listener.apply(this, arguments);
    }
  }

  this.on(type, g);
};

EventEmitter.prototype.emit = function() {
  var type = arguments[0];
  var listeners = this._listeners[type];
  if (!listeners) {
    return;
  }
  // equivalent of Array.prototype.slice.call(arguments, 1);
  var l = arguments.length;
  var args = new Array(l - 1);
  for (var ai = 1; ai < l; ai++) {
    args[ai - 1] = arguments[ai];
  }
  for (var i = 0; i < listeners.length; i++) {
    listeners[i].apply(this, args);
  }
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener = EventTarget.prototype.addEventListener;
EventEmitter.prototype.removeListener = EventTarget.prototype.removeEventListener;

module.exports.EventEmitter = EventEmitter;

},{"./eventtarget":5,"inherits":56}],4:[function(require,module,exports){
'use strict';

function Event(eventType) {
  this.type = eventType;
}

Event.prototype.initEvent = function(eventType, canBubble, cancelable) {
  this.type = eventType;
  this.bubbles = canBubble;
  this.cancelable = cancelable;
  this.timeStamp = +new Date();
  return this;
};

Event.prototype.stopPropagation = function() {};
Event.prototype.preventDefault = function() {};

Event.CAPTURING_PHASE = 1;
Event.AT_TARGET = 2;
Event.BUBBLING_PHASE = 3;

module.exports = Event;

},{}],5:[function(require,module,exports){
'use strict';

/* Simplified implementation of DOM2 EventTarget.
 *   http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-EventTarget
 */

function EventTarget() {
  this._listeners = {};
}

EventTarget.prototype.addEventListener = function(eventType, listener) {
  if (!(eventType in this._listeners)) {
    this._listeners[eventType] = [];
  }
  var arr = this._listeners[eventType];
  // #4
  if (arr.indexOf(listener) === -1) {
    // Make a copy so as not to interfere with a current dispatchEvent.
    arr = arr.concat([listener]);
  }
  this._listeners[eventType] = arr;
};

EventTarget.prototype.removeEventListener = function(eventType, listener) {
  var arr = this._listeners[eventType];
  if (!arr) {
    return;
  }
  var idx = arr.indexOf(listener);
  if (idx !== -1) {
    if (arr.length > 1) {
      // Make a copy so as not to interfere with a current dispatchEvent.
      this._listeners[eventType] = arr.slice(0, idx).concat(arr.slice(idx + 1));
    } else {
      delete this._listeners[eventType];
    }
    return;
  }
};

EventTarget.prototype.dispatchEvent = function() {
  var event = arguments[0];
  var t = event.type;
  // equivalent of Array.prototype.slice.call(arguments, 0);
  var args = arguments.length === 1 ? [event] : Array.apply(null, arguments);
  // TODO: This doesn't match the real behavior; per spec, onfoo get
  // their place in line from the /first/ time they're set from
  // non-null. Although WebKit bumps it to the end every time it's
  // set.
  if (this['on' + t]) {
    this['on' + t].apply(this, args);
  }
  if (t in this._listeners) {
    // Grab a reference to the listeners list. removeEventListener may alter the list.
    var listeners = this._listeners[t];
    for (var i = 0; i < listeners.length; i++) {
      listeners[i].apply(this, args);
    }
  }
};

module.exports = EventTarget;

},{}],6:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , Event = require('./event')
  ;

function TransportMessageEvent(data) {
  Event.call(this);
  this.initEvent('message', false, false);
  this.data = data;
}

inherits(TransportMessageEvent, Event);

module.exports = TransportMessageEvent;

},{"./event":4,"inherits":56}],7:[function(require,module,exports){
'use strict';

var JSON3 = require('json3')
  , iframeUtils = require('./utils/iframe')
  ;

function FacadeJS(transport) {
  this._transport = transport;
  transport.on('message', this._transportMessage.bind(this));
  transport.on('close', this._transportClose.bind(this));
}

FacadeJS.prototype._transportClose = function(code, reason) {
  iframeUtils.postMessage('c', JSON3.stringify([code, reason]));
};
FacadeJS.prototype._transportMessage = function(frame) {
  iframeUtils.postMessage('t', frame);
};
FacadeJS.prototype._send = function(data) {
  this._transport.send(data);
};
FacadeJS.prototype._close = function() {
  this._transport.close();
  this._transport.removeAllListeners();
};

module.exports = FacadeJS;

},{"./utils/iframe":47,"json3":57}],8:[function(require,module,exports){
(function (process){
'use strict';

var urlUtils = require('./utils/url')
  , eventUtils = require('./utils/event')
  , JSON3 = require('json3')
  , FacadeJS = require('./facade')
  , InfoIframeReceiver = require('./info-iframe-receiver')
  , iframeUtils = require('./utils/iframe')
  , loc = require('./location')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:iframe-bootstrap');
}

module.exports = function(SockJS, availableTransports) {
  var transportMap = {};
  availableTransports.forEach(function(at) {
    if (at.facadeTransport) {
      transportMap[at.facadeTransport.transportName] = at.facadeTransport;
    }
  });

  // hard-coded for the info iframe
  // TODO see if we can make this more dynamic
  transportMap[InfoIframeReceiver.transportName] = InfoIframeReceiver;
  var parentOrigin;

  /* eslint-disable camelcase */
  SockJS.bootstrap_iframe = function() {
    /* eslint-enable camelcase */
    var facade;
    iframeUtils.currentWindowId = loc.hash.slice(1);
    var onMessage = function(e) {
      if (e.source !== parent) {
        return;
      }
      if (typeof parentOrigin === 'undefined') {
        parentOrigin = e.origin;
      }
      if (e.origin !== parentOrigin) {
        return;
      }

      var iframeMessage;
      try {
        iframeMessage = JSON3.parse(e.data);
      } catch (ignored) {
        debug('bad json', e.data);
        return;
      }

      if (iframeMessage.windowId !== iframeUtils.currentWindowId) {
        return;
      }
      switch (iframeMessage.type) {
      case 's':
        var p;
        try {
          p = JSON3.parse(iframeMessage.data);
        } catch (ignored) {
          debug('bad json', iframeMessage.data);
          break;
        }
        var version = p[0];
        var transport = p[1];
        var transUrl = p[2];
        var baseUrl = p[3];
        debug(version, transport, transUrl, baseUrl);
        // change this to semver logic
        if (version !== SockJS.version) {
          throw new Error('Incompatible SockJS! Main site uses:' +
                    ' "' + version + '", the iframe:' +
                    ' "' + SockJS.version + '".');
        }

        if (!urlUtils.isOriginEqual(transUrl, loc.href) ||
            !urlUtils.isOriginEqual(baseUrl, loc.href)) {
          throw new Error('Can\'t connect to different domain from within an ' +
                    'iframe. (' + loc.href + ', ' + transUrl + ', ' + baseUrl + ')');
        }
        facade = new FacadeJS(new transportMap[transport](transUrl, baseUrl));
        break;
      case 'm':
        facade._send(iframeMessage.data);
        break;
      case 'c':
        if (facade) {
          facade._close();
        }
        facade = null;
        break;
      }
    };

    eventUtils.attachEvent('message', onMessage);

    // Start
    iframeUtils.postMessage('s');
  };
};

}).call(this,{ env: {} })

},{"./facade":7,"./info-iframe-receiver":10,"./location":13,"./utils/event":46,"./utils/iframe":47,"./utils/url":52,"debug":54,"json3":57}],9:[function(require,module,exports){
(function (process){
'use strict';

var EventEmitter = require('events').EventEmitter
  , inherits = require('inherits')
  , JSON3 = require('json3')
  , objectUtils = require('./utils/object')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:info-ajax');
}

function InfoAjax(url, AjaxObject) {
  EventEmitter.call(this);

  var self = this;
  var t0 = +new Date();
  this.xo = new AjaxObject('GET', url);

  this.xo.once('finish', function(status, text) {
    var info, rtt;
    if (status === 200) {
      rtt = (+new Date()) - t0;
      if (text) {
        try {
          info = JSON3.parse(text);
        } catch (e) {
          debug('bad json', text);
        }
      }

      if (!objectUtils.isObject(info)) {
        info = {};
      }
    }
    self.emit('finish', info, rtt);
    self.removeAllListeners();
  });
}

inherits(InfoAjax, EventEmitter);

InfoAjax.prototype.close = function() {
  this.removeAllListeners();
  this.xo.close();
};

module.exports = InfoAjax;

}).call(this,{ env: {} })

},{"./utils/object":49,"debug":54,"events":3,"inherits":56,"json3":57}],10:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , EventEmitter = require('events').EventEmitter
  , JSON3 = require('json3')
  , XHRLocalObject = require('./transport/sender/xhr-local')
  , InfoAjax = require('./info-ajax')
  ;

function InfoReceiverIframe(transUrl) {
  var self = this;
  EventEmitter.call(this);

  this.ir = new InfoAjax(transUrl, XHRLocalObject);
  this.ir.once('finish', function(info, rtt) {
    self.ir = null;
    self.emit('message', JSON3.stringify([info, rtt]));
  });
}

inherits(InfoReceiverIframe, EventEmitter);

InfoReceiverIframe.transportName = 'iframe-info-receiver';

InfoReceiverIframe.prototype.close = function() {
  if (this.ir) {
    this.ir.close();
    this.ir = null;
  }
  this.removeAllListeners();
};

module.exports = InfoReceiverIframe;

},{"./info-ajax":9,"./transport/sender/xhr-local":37,"events":3,"inherits":56,"json3":57}],11:[function(require,module,exports){
(function (process,global){
'use strict';

var EventEmitter = require('events').EventEmitter
  , inherits = require('inherits')
  , JSON3 = require('json3')
  , utils = require('./utils/event')
  , IframeTransport = require('./transport/iframe')
  , InfoReceiverIframe = require('./info-iframe-receiver')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:info-iframe');
}

function InfoIframe(baseUrl, url) {
  var self = this;
  EventEmitter.call(this);

  var go = function() {
    var ifr = self.ifr = new IframeTransport(InfoReceiverIframe.transportName, url, baseUrl);

    ifr.once('message', function(msg) {
      if (msg) {
        var d;
        try {
          d = JSON3.parse(msg);
        } catch (e) {
          debug('bad json', msg);
          self.emit('finish');
          self.close();
          return;
        }

        var info = d[0], rtt = d[1];
        self.emit('finish', info, rtt);
      }
      self.close();
    });

    ifr.once('close', function() {
      self.emit('finish');
      self.close();
    });
  };

  // TODO this seems the same as the 'needBody' from transports
  if (!global.document.body) {
    utils.attachEvent('load', go);
  } else {
    go();
  }
}

inherits(InfoIframe, EventEmitter);

InfoIframe.enabled = function() {
  return IframeTransport.enabled();
};

InfoIframe.prototype.close = function() {
  if (this.ifr) {
    this.ifr.close();
  }
  this.removeAllListeners();
  this.ifr = null;
};

module.exports = InfoIframe;

}).call(this,{ env: {} },typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./info-iframe-receiver":10,"./transport/iframe":22,"./utils/event":46,"debug":54,"events":3,"inherits":56,"json3":57}],12:[function(require,module,exports){
(function (process){
'use strict';

var EventEmitter = require('events').EventEmitter
  , inherits = require('inherits')
  , urlUtils = require('./utils/url')
  , XDR = require('./transport/sender/xdr')
  , XHRCors = require('./transport/sender/xhr-cors')
  , XHRLocal = require('./transport/sender/xhr-local')
  , XHRFake = require('./transport/sender/xhr-fake')
  , InfoIframe = require('./info-iframe')
  , InfoAjax = require('./info-ajax')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:info-receiver');
}

function InfoReceiver(baseUrl, urlInfo) {
  debug(baseUrl);
  var self = this;
  EventEmitter.call(this);

  setTimeout(function() {
    self.doXhr(baseUrl, urlInfo);
  }, 0);
}

inherits(InfoReceiver, EventEmitter);

// TODO this is currently ignoring the list of available transports and the whitelist

InfoReceiver._getReceiver = function(baseUrl, url, urlInfo) {
  // determine method of CORS support (if needed)
  if (urlInfo.sameOrigin) {
    return new InfoAjax(url, XHRLocal);
  }
  if (XHRCors.enabled) {
    return new InfoAjax(url, XHRCors);
  }
  if (XDR.enabled && urlInfo.sameScheme) {
    return new InfoAjax(url, XDR);
  }
  if (InfoIframe.enabled()) {
    return new InfoIframe(baseUrl, url);
  }
  return new InfoAjax(url, XHRFake);
};

InfoReceiver.prototype.doXhr = function(baseUrl, urlInfo) {
  var self = this
    , url = urlUtils.addPath(baseUrl, '/info')
    ;
  debug('doXhr', url);

  this.xo = InfoReceiver._getReceiver(baseUrl, url, urlInfo);

  this.timeoutRef = setTimeout(function() {
    debug('timeout');
    self._cleanup(false);
    self.emit('finish');
  }, InfoReceiver.timeout);

  this.xo.once('finish', function(info, rtt) {
    debug('finish', info, rtt);
    self._cleanup(true);
    self.emit('finish', info, rtt);
  });
};

InfoReceiver.prototype._cleanup = function(wasClean) {
  debug('_cleanup');
  clearTimeout(this.timeoutRef);
  this.timeoutRef = null;
  if (!wasClean && this.xo) {
    this.xo.close();
  }
  this.xo = null;
};

InfoReceiver.prototype.close = function() {
  debug('close');
  this.removeAllListeners();
  this._cleanup(false);
};

InfoReceiver.timeout = 8000;

module.exports = InfoReceiver;

}).call(this,{ env: {} })

},{"./info-ajax":9,"./info-iframe":11,"./transport/sender/xdr":34,"./transport/sender/xhr-cors":35,"./transport/sender/xhr-fake":36,"./transport/sender/xhr-local":37,"./utils/url":52,"debug":54,"events":3,"inherits":56}],13:[function(require,module,exports){
(function (global){
'use strict';

module.exports = global.location || {
  origin: 'http://localhost:80'
, protocol: 'http:'
, host: 'localhost'
, port: 80
, href: 'http://localhost/'
, hash: ''
};

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],14:[function(require,module,exports){
(function (process,global){
'use strict';

require('./shims');

var URL = require('url-parse')
  , inherits = require('inherits')
  , JSON3 = require('json3')
  , random = require('./utils/random')
  , escape = require('./utils/escape')
  , urlUtils = require('./utils/url')
  , eventUtils = require('./utils/event')
  , transport = require('./utils/transport')
  , objectUtils = require('./utils/object')
  , browser = require('./utils/browser')
  , log = require('./utils/log')
  , Event = require('./event/event')
  , EventTarget = require('./event/eventtarget')
  , loc = require('./location')
  , CloseEvent = require('./event/close')
  , TransportMessageEvent = require('./event/trans-message')
  , InfoReceiver = require('./info-receiver')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:main');
}

var transports;

// follow constructor steps defined at http://dev.w3.org/html5/websockets/#the-websocket-interface
function SockJS(url, protocols, options) {
  if (!(this instanceof SockJS)) {
    return new SockJS(url, protocols, options);
  }
  if (arguments.length < 1) {
    throw new TypeError("Failed to construct 'SockJS: 1 argument required, but only 0 present");
  }
  EventTarget.call(this);

  this.readyState = SockJS.CONNECTING;
  this.extensions = '';
  this.protocol = '';

  // non-standard extension
  options = options || {};
  if (options.protocols_whitelist) {
    log.warn("'protocols_whitelist' is DEPRECATED. Use 'transports' instead.");
  }
  this._transportsWhitelist = options.transports;
  this._transportOptions = options.transportOptions || {};

  var sessionId = options.sessionId || 8;
  if (typeof sessionId === 'function') {
    this._generateSessionId = sessionId;
  } else if (typeof sessionId === 'number') {
    this._generateSessionId = function() {
      return random.string(sessionId);
    };
  } else {
    throw new TypeError('If sessionId is used in the options, it needs to be a number or a function.');
  }

  this._server = options.server || random.numberString(1000);

  // Step 1 of WS spec - parse and validate the url. Issue #8
  var parsedUrl = new URL(url);
  if (!parsedUrl.host || !parsedUrl.protocol) {
    // throw new SyntaxError("The URL '" + url + "' is invalid");
  } else if (parsedUrl.hash) {
    // throw new SyntaxError('The URL must not contain a fragment');
  } else if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
    // throw new SyntaxError("The URL's scheme must be either 'http:' or 'https:'. '" + parsedUrl.protocol + "' is not allowed.");
  }

  var secure = parsedUrl.protocol === 'https:';
  // Step 2 - don't allow secure origin with an insecure protocol
  if (loc.protocol === 'https:' && !secure) {
    throw new Error('SecurityError: An insecure SockJS connection may not be initiated from a page loaded over HTTPS');
  }

  // Step 3 - check port access - no need here
  // Step 4 - parse protocols argument
  if (!protocols) {
    protocols = [];
  } else if (!Array.isArray(protocols)) {
    protocols = [protocols];
  }

  // Step 5 - check protocols argument
  var sortedProtocols = protocols.sort();
  sortedProtocols.forEach(function(proto, i) {
    if (!proto) {
      throw new SyntaxError("The protocols entry '" + proto + "' is invalid.");
    }
    if (i < (sortedProtocols.length - 1) && proto === sortedProtocols[i + 1]) {
      throw new SyntaxError("The protocols entry '" + proto + "' is duplicated.");
    }
  });

  // Step 6 - convert origin
  var o = urlUtils.getOrigin(loc.href);
  this._origin = o ? o.toLowerCase() : null;

  // remove the trailing slash
  parsedUrl.set('pathname', parsedUrl.pathname.replace(/\/+$/, ''));

  // store the sanitized url
  this.url = parsedUrl.href;
  debug('using url', this.url);

  // Step 7 - start connection in background
  // obtain server info
  // http://sockjs.github.io/sockjs-protocol/sockjs-protocol-0.3.3.html#section-26
  this._urlInfo = {
    nullOrigin: !browser.hasDomain()
  , sameOrigin: urlUtils.isOriginEqual(this.url, loc.href)
  , sameScheme: urlUtils.isSchemeEqual(this.url, loc.href)
  };

  this._ir = new InfoReceiver(this.url, this._urlInfo);
  this._ir.once('finish', this._receiveInfo.bind(this));
}

inherits(SockJS, EventTarget);

function userSetCode(code) {
  return code === 1000 || (code >= 3000 && code <= 4999);
}

SockJS.prototype.close = function(code, reason) {
  // Step 1
  if (code && !userSetCode(code)) {
    throw new Error('InvalidAccessError: Invalid code');
  }
  // Step 2.4 states the max is 123 bytes, but we are just checking length
  if (reason && reason.length > 123) {
    throw new SyntaxError('reason argument has an invalid length');
  }

  // Step 3.1
  if (this.readyState === SockJS.CLOSING || this.readyState === SockJS.CLOSED) {
    return;
  }

  // TODO look at docs to determine how to set this
  var wasClean = true;
  this._close(code || 1000, reason || 'Normal closure', wasClean);
};

SockJS.prototype.send = function(data) {
  // #13 - convert anything non-string to string
  // TODO this currently turns objects into [object Object]
  if (typeof data !== 'string') {
    data = '' + data;
  }
  if (this.readyState === SockJS.CONNECTING) {
    throw new Error('InvalidStateError: The connection has not been established yet');
  }
  if (this.readyState !== SockJS.OPEN) {
    return;
  }
  this._transport.send(escape.quote(data));
};

SockJS.version = require('./version');

SockJS.CONNECTING = 0;
SockJS.OPEN = 1;
SockJS.CLOSING = 2;
SockJS.CLOSED = 3;

SockJS.prototype._receiveInfo = function(info, rtt) {
  debug('_receiveInfo', rtt);
  this._ir = null;
  if (!info) {
    this._close(1002, 'Cannot connect to server');
    return;
  }

  // establish a round-trip timeout (RTO) based on the
  // round-trip time (RTT)
  this._rto = this.countRTO(rtt);
  // allow server to override url used for the actual transport
  this._transUrl = info.base_url ? info.base_url : this.url;
  info = objectUtils.extend(info, this._urlInfo);
  debug('info', info);
  // determine list of desired and supported transports
  var enabledTransports = transports.filterToEnabled(this._transportsWhitelist, info);
  this._transports = enabledTransports.main;
  debug(this._transports.length + ' enabled transports');

  this._connect();
};

SockJS.prototype._connect = function() {
  for (var Transport = this._transports.shift(); Transport; Transport = this._transports.shift()) {
    debug('attempt', Transport.transportName);
    if (Transport.needBody) {
      if (!global.document.body ||
          (typeof global.document.readyState !== 'undefined' &&
            global.document.readyState !== 'complete' &&
            global.document.readyState !== 'interactive')) {
        debug('waiting for body');
        this._transports.unshift(Transport);
        eventUtils.attachEvent('load', this._connect.bind(this));
        return;
      }
    }

    // calculate timeout based on RTO and round trips. Default to 5s
    var timeoutMs = (this._rto * Transport.roundTrips) || 5000;
    this._transportTimeoutId = setTimeout(this._transportTimeout.bind(this), timeoutMs);
    debug('using timeout', timeoutMs);

    var transportUrl = urlUtils.addPath(this._transUrl, '/' + this._server + '/' + this._generateSessionId());
    var options = this._transportOptions[Transport.transportName];
    debug('transport url', transportUrl);
    var transportObj = new Transport(transportUrl, this._transUrl, options);
    transportObj.on('message', this._transportMessage.bind(this));
    transportObj.once('close', this._transportClose.bind(this));
    transportObj.transportName = Transport.transportName;
    this._transport = transportObj;

    return;
  }
  this._close(2000, 'All transports failed', false);
};

SockJS.prototype._transportTimeout = function() {
  debug('_transportTimeout');
  if (this.readyState === SockJS.CONNECTING) {
    if (this._transport) {
      this._transport.close();
    }

    this._transportClose(2007, 'Transport timed out');
  }
};

SockJS.prototype._transportMessage = function(msg) {
  debug('_transportMessage', msg);
  var self = this
    , type = msg.slice(0, 1)
    , content = msg.slice(1)
    , payload
    ;

  // first check for messages that don't need a payload
  switch (type) {
    case 'o':
      this._open();
      return;
    case 'h':
      this.dispatchEvent(new Event('heartbeat'));
      debug('heartbeat', this.transport);
      return;
  }

  if (content) {
    try {
      payload = JSON3.parse(content);
    } catch (e) {
      debug('bad json', content);
    }
  }

  if (typeof payload === 'undefined') {
    debug('empty payload', content);
    return;
  }

  switch (type) {
    case 'a':
      if (Array.isArray(payload)) {
        payload.forEach(function(p) {
          debug('message', self.transport, p);
          self.dispatchEvent(new TransportMessageEvent(p));
        });
      }
      break;
    case 'm':
      debug('message', this.transport, payload);
      this.dispatchEvent(new TransportMessageEvent(payload));
      break;
    case 'c':
      if (Array.isArray(payload) && payload.length === 2) {
        this._close(payload[0], payload[1], true);
      }
      break;
  }
};

SockJS.prototype._transportClose = function(code, reason) {
  debug('_transportClose', this.transport, code, reason);
  if (this._transport) {
    this._transport.removeAllListeners();
    this._transport = null;
    this.transport = null;
  }

  if (!userSetCode(code) && code !== 2000 && this.readyState === SockJS.CONNECTING) {
    this._connect();
    return;
  }

  this._close(code, reason);
};

SockJS.prototype._open = function() {
  debug('_open', this._transport.transportName, this.readyState);
  if (this.readyState === SockJS.CONNECTING) {
    if (this._transportTimeoutId) {
      clearTimeout(this._transportTimeoutId);
      this._transportTimeoutId = null;
    }
    this.readyState = SockJS.OPEN;
    this.transport = this._transport.transportName;
    this.dispatchEvent(new Event('open'));
    debug('connected', this.transport);
  } else {
    // The server might have been restarted, and lost track of our
    // connection.
    this._close(1006, 'Server lost session');
  }
};

SockJS.prototype._close = function(code, reason, wasClean) {
  debug('_close', this.transport, code, reason, wasClean, this.readyState);
  var forceFail = false;

  if (this._ir) {
    forceFail = true;
    this._ir.close();
    this._ir = null;
  }
  if (this._transport) {
    this._transport.close();
    this._transport = null;
    this.transport = null;
  }

  if (this.readyState === SockJS.CLOSED) {
    throw new Error('InvalidStateError: SockJS has already been closed');
  }

  this.readyState = SockJS.CLOSING;
  setTimeout(function() {
    this.readyState = SockJS.CLOSED;

    if (forceFail) {
      this.dispatchEvent(new Event('error'));
    }

    var e = new CloseEvent('close');
    e.wasClean = wasClean || false;
    e.code = code || 1000;
    e.reason = reason;

    this.dispatchEvent(e);
    this.onmessage = this.onclose = this.onerror = null;
    debug('disconnected');
  }.bind(this), 0);
};

// See: http://www.erg.abdn.ac.uk/~gerrit/dccp/notes/ccid2/rto_estimator/
// and RFC 2988.
SockJS.prototype.countRTO = function(rtt) {
  // In a local environment, when using IE8/9 and the `jsonp-polling`
  // transport the time needed to establish a connection (the time that pass
  // from the opening of the transport to the call of `_dispatchOpen`) is
  // around 200msec (the lower bound used in the article above) and this
  // causes spurious timeouts. For this reason we calculate a value slightly
  // larger than that used in the article.
  if (rtt > 100) {
    return 4 * rtt; // rto > 400msec
  }
  return 300 + rtt; // 300msec < rto <= 400msec
};

module.exports = function(availableTransports) {
  transports = transport(availableTransports);
  require('./iframe-bootstrap')(SockJS, availableTransports);
  return SockJS;
};

}).call(this,{ env: {} },typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./event/close":2,"./event/event":4,"./event/eventtarget":5,"./event/trans-message":6,"./iframe-bootstrap":8,"./info-receiver":12,"./location":13,"./shims":15,"./utils/browser":44,"./utils/escape":45,"./utils/event":46,"./utils/log":48,"./utils/object":49,"./utils/random":50,"./utils/transport":51,"./utils/url":52,"./version":53,"debug":54,"inherits":56,"json3":57,"url-parse":61}],15:[function(require,module,exports){
/* eslint-disable */
/* jscs: disable */
'use strict';

// pulled specific shims from https://github.com/es-shims/es5-shim

var ArrayPrototype = Array.prototype;
var ObjectPrototype = Object.prototype;
var FunctionPrototype = Function.prototype;
var StringPrototype = String.prototype;
var array_slice = ArrayPrototype.slice;

var _toString = ObjectPrototype.toString;
var isFunction = function (val) {
    return ObjectPrototype.toString.call(val) === '[object Function]';
};
var isArray = function isArray(obj) {
    return _toString.call(obj) === '[object Array]';
};
var isString = function isString(obj) {
    return _toString.call(obj) === '[object String]';
};

var supportsDescriptors = Object.defineProperty && (function () {
    try {
        Object.defineProperty({}, 'x', {});
        return true;
    } catch (e) { /* this is ES3 */
        return false;
    }
}());

// Define configurable, writable and non-enumerable props
// if they don't exist.
var defineProperty;
if (supportsDescriptors) {
    defineProperty = function (object, name, method, forceAssign) {
        if (!forceAssign && (name in object)) { return; }
        Object.defineProperty(object, name, {
            configurable: true,
            enumerable: false,
            writable: true,
            value: method
        });
    };
} else {
    defineProperty = function (object, name, method, forceAssign) {
        if (!forceAssign && (name in object)) { return; }
        object[name] = method;
    };
}
var defineProperties = function (object, map, forceAssign) {
    for (var name in map) {
        if (ObjectPrototype.hasOwnProperty.call(map, name)) {
          defineProperty(object, name, map[name], forceAssign);
        }
    }
};

var toObject = function (o) {
    if (o == null) { // this matches both null and undefined
        throw new TypeError("can't convert " + o + ' to object');
    }
    return Object(o);
};

//
// Util
// ======
//

// ES5 9.4
// http://es5.github.com/#x9.4
// http://jsperf.com/to-integer

function toInteger(num) {
    var n = +num;
    if (n !== n) { // isNaN
        n = 0;
    } else if (n !== 0 && n !== (1 / 0) && n !== -(1 / 0)) {
        n = (n > 0 || -1) * Math.floor(Math.abs(n));
    }
    return n;
}

function ToUint32(x) {
    return x >>> 0;
}

//
// Function
// ========
//

// ES-5 15.3.4.5
// http://es5.github.com/#x15.3.4.5

function Empty() {}

defineProperties(FunctionPrototype, {
    bind: function bind(that) { // .length is 1
        // 1. Let Target be the this value.
        var target = this;
        // 2. If IsCallable(Target) is false, throw a TypeError exception.
        if (!isFunction(target)) {
            throw new TypeError('Function.prototype.bind called on incompatible ' + target);
        }
        // 3. Let A be a new (possibly empty) internal list of all of the
        //   argument values provided after thisArg (arg1, arg2 etc), in order.
        // XXX slicedArgs will stand in for "A" if used
        var args = array_slice.call(arguments, 1); // for normal call
        // 4. Let F be a new native ECMAScript object.
        // 11. Set the [[Prototype]] internal property of F to the standard
        //   built-in Function prototype object as specified in 15.3.3.1.
        // 12. Set the [[Call]] internal property of F as described in
        //   15.3.4.5.1.
        // 13. Set the [[Construct]] internal property of F as described in
        //   15.3.4.5.2.
        // 14. Set the [[HasInstance]] internal property of F as described in
        //   15.3.4.5.3.
        var binder = function () {

            if (this instanceof bound) {
                // 15.3.4.5.2 [[Construct]]
                // When the [[Construct]] internal method of a function object,
                // F that was created using the bind function is called with a
                // list of arguments ExtraArgs, the following steps are taken:
                // 1. Let target be the value of F's [[TargetFunction]]
                //   internal property.
                // 2. If target has no [[Construct]] internal method, a
                //   TypeError exception is thrown.
                // 3. Let boundArgs be the value of F's [[BoundArgs]] internal
                //   property.
                // 4. Let args be a new list containing the same values as the
                //   list boundArgs in the same order followed by the same
                //   values as the list ExtraArgs in the same order.
                // 5. Return the result of calling the [[Construct]] internal
                //   method of target providing args as the arguments.

                var result = target.apply(
                    this,
                    args.concat(array_slice.call(arguments))
                );
                if (Object(result) === result) {
                    return result;
                }
                return this;

            } else {
                // 15.3.4.5.1 [[Call]]
                // When the [[Call]] internal method of a function object, F,
                // which was created using the bind function is called with a
                // this value and a list of arguments ExtraArgs, the following
                // steps are taken:
                // 1. Let boundArgs be the value of F's [[BoundArgs]] internal
                //   property.
                // 2. Let boundThis be the value of F's [[BoundThis]] internal
                //   property.
                // 3. Let target be the value of F's [[TargetFunction]] internal
                //   property.
                // 4. Let args be a new list containing the same values as the
                //   list boundArgs in the same order followed by the same
                //   values as the list ExtraArgs in the same order.
                // 5. Return the result of calling the [[Call]] internal method
                //   of target providing boundThis as the this value and
                //   providing args as the arguments.

                // equiv: target.call(this, ...boundArgs, ...args)
                return target.apply(
                    that,
                    args.concat(array_slice.call(arguments))
                );

            }

        };

        // 15. If the [[Class]] internal property of Target is "Function", then
        //     a. Let L be the length property of Target minus the length of A.
        //     b. Set the length own property of F to either 0 or L, whichever is
        //       larger.
        // 16. Else set the length own property of F to 0.

        var boundLength = Math.max(0, target.length - args.length);

        // 17. Set the attributes of the length own property of F to the values
        //   specified in 15.3.5.1.
        var boundArgs = [];
        for (var i = 0; i < boundLength; i++) {
            boundArgs.push('$' + i);
        }

        // XXX Build a dynamic function with desired amount of arguments is the only
        // way to set the length property of a function.
        // In environments where Content Security Policies enabled (Chrome extensions,
        // for ex.) all use of eval or Function costructor throws an exception.
        // However in all of these environments Function.prototype.bind exists
        // and so this code will never be executed.
        var bound = Function('binder', 'return function (' + boundArgs.join(',') + '){ return binder.apply(this, arguments); }')(binder);

        if (target.prototype) {
            Empty.prototype = target.prototype;
            bound.prototype = new Empty();
            // Clean up dangling references.
            Empty.prototype = null;
        }

        // TODO
        // 18. Set the [[Extensible]] internal property of F to true.

        // TODO
        // 19. Let thrower be the [[ThrowTypeError]] function Object (13.2.3).
        // 20. Call the [[DefineOwnProperty]] internal method of F with
        //   arguments "caller", PropertyDescriptor {[[Get]]: thrower, [[Set]]:
        //   thrower, [[Enumerable]]: false, [[Configurable]]: false}, and
        //   false.
        // 21. Call the [[DefineOwnProperty]] internal method of F with
        //   arguments "arguments", PropertyDescriptor {[[Get]]: thrower,
        //   [[Set]]: thrower, [[Enumerable]]: false, [[Configurable]]: false},
        //   and false.

        // TODO
        // NOTE Function objects created using Function.prototype.bind do not
        // have a prototype property or the [[Code]], [[FormalParameters]], and
        // [[Scope]] internal properties.
        // XXX can't delete prototype in pure-js.

        // 22. Return F.
        return bound;
    }
});

//
// Array
// =====
//

// ES5 15.4.3.2
// http://es5.github.com/#x15.4.3.2
// https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/isArray
defineProperties(Array, { isArray: isArray });


var boxedString = Object('a');
var splitString = boxedString[0] !== 'a' || !(0 in boxedString);

var properlyBoxesContext = function properlyBoxed(method) {
    // Check node 0.6.21 bug where third parameter is not boxed
    var properlyBoxesNonStrict = true;
    var properlyBoxesStrict = true;
    if (method) {
        method.call('foo', function (_, __, context) {
            if (typeof context !== 'object') { properlyBoxesNonStrict = false; }
        });

        method.call([1], function () {
            'use strict';
            properlyBoxesStrict = typeof this === 'string';
        }, 'x');
    }
    return !!method && properlyBoxesNonStrict && properlyBoxesStrict;
};

defineProperties(ArrayPrototype, {
    forEach: function forEach(fun /*, thisp*/) {
        var object = toObject(this),
            self = splitString && isString(this) ? this.split('') : object,
            thisp = arguments[1],
            i = -1,
            length = self.length >>> 0;

        // If no callback function or if callback is not a callable function
        if (!isFunction(fun)) {
            throw new TypeError(); // TODO message
        }

        while (++i < length) {
            if (i in self) {
                // Invoke the callback function with call, passing arguments:
                // context, property value, property key, thisArg object
                // context
                fun.call(thisp, self[i], i, object);
            }
        }
    }
}, !properlyBoxesContext(ArrayPrototype.forEach));

// ES5 15.4.4.14
// http://es5.github.com/#x15.4.4.14
// https://developer.mozilla.org/en/JavaScript/Reference/Global_Objects/Array/indexOf
var hasFirefox2IndexOfBug = Array.prototype.indexOf && [0, 1].indexOf(1, 2) !== -1;
defineProperties(ArrayPrototype, {
    indexOf: function indexOf(sought /*, fromIndex */ ) {
        var self = splitString && isString(this) ? this.split('') : toObject(this),
            length = self.length >>> 0;

        if (!length) {
            return -1;
        }

        var i = 0;
        if (arguments.length > 1) {
            i = toInteger(arguments[1]);
        }

        // handle negative indices
        i = i >= 0 ? i : Math.max(0, length + i);
        for (; i < length; i++) {
            if (i in self && self[i] === sought) {
                return i;
            }
        }
        return -1;
    }
}, hasFirefox2IndexOfBug);

//
// String
// ======
//

// ES5 15.5.4.14
// http://es5.github.com/#x15.5.4.14

// [bugfix, IE lt 9, firefox 4, Konqueror, Opera, obscure browsers]
// Many browsers do not split properly with regular expressions or they
// do not perform the split correctly under obscure conditions.
// See http://blog.stevenlevithan.com/archives/cross-browser-split
// I've tested in many browsers and this seems to cover the deviant ones:
//    'ab'.split(/(?:ab)*/) should be ["", ""], not [""]
//    '.'.split(/(.?)(.?)/) should be ["", ".", "", ""], not ["", ""]
//    'tesst'.split(/(s)*/) should be ["t", undefined, "e", "s", "t"], not
//       [undefined, "t", undefined, "e", ...]
//    ''.split(/.?/) should be [], not [""]
//    '.'.split(/()()/) should be ["."], not ["", "", "."]

var string_split = StringPrototype.split;
if (
    'ab'.split(/(?:ab)*/).length !== 2 ||
    '.'.split(/(.?)(.?)/).length !== 4 ||
    'tesst'.split(/(s)*/)[1] === 't' ||
    'test'.split(/(?:)/, -1).length !== 4 ||
    ''.split(/.?/).length ||
    '.'.split(/()()/).length > 1
) {
    (function () {
        var compliantExecNpcg = /()??/.exec('')[1] === void 0; // NPCG: nonparticipating capturing group

        StringPrototype.split = function (separator, limit) {
            var string = this;
            if (separator === void 0 && limit === 0) {
                return [];
            }

            // If `separator` is not a regex, use native split
            if (_toString.call(separator) !== '[object RegExp]') {
                return string_split.call(this, separator, limit);
            }

            var output = [],
                flags = (separator.ignoreCase ? 'i' : '') +
                        (separator.multiline  ? 'm' : '') +
                        (separator.extended   ? 'x' : '') + // Proposed for ES6
                        (separator.sticky     ? 'y' : ''), // Firefox 3+
                lastLastIndex = 0,
                // Make `global` and avoid `lastIndex` issues by working with a copy
                separator2, match, lastIndex, lastLength;
            separator = new RegExp(separator.source, flags + 'g');
            string += ''; // Type-convert
            if (!compliantExecNpcg) {
                // Doesn't need flags gy, but they don't hurt
                separator2 = new RegExp('^' + separator.source + '$(?!\\s)', flags);
            }
            /* Values for `limit`, per the spec:
             * If undefined: 4294967295 // Math.pow(2, 32) - 1
             * If 0, Infinity, or NaN: 0
             * If positive number: limit = Math.floor(limit); if (limit > 4294967295) limit -= 4294967296;
             * If negative number: 4294967296 - Math.floor(Math.abs(limit))
             * If other: Type-convert, then use the above rules
             */
            limit = limit === void 0 ?
                -1 >>> 0 : // Math.pow(2, 32) - 1
                ToUint32(limit);
            while (match = separator.exec(string)) {
                // `separator.lastIndex` is not reliable cross-browser
                lastIndex = match.index + match[0].length;
                if (lastIndex > lastLastIndex) {
                    output.push(string.slice(lastLastIndex, match.index));
                    // Fix browsers whose `exec` methods don't consistently return `undefined` for
                    // nonparticipating capturing groups
                    if (!compliantExecNpcg && match.length > 1) {
                        match[0].replace(separator2, function () {
                            for (var i = 1; i < arguments.length - 2; i++) {
                                if (arguments[i] === void 0) {
                                    match[i] = void 0;
                                }
                            }
                        });
                    }
                    if (match.length > 1 && match.index < string.length) {
                        ArrayPrototype.push.apply(output, match.slice(1));
                    }
                    lastLength = match[0].length;
                    lastLastIndex = lastIndex;
                    if (output.length >= limit) {
                        break;
                    }
                }
                if (separator.lastIndex === match.index) {
                    separator.lastIndex++; // Avoid an infinite loop
                }
            }
            if (lastLastIndex === string.length) {
                if (lastLength || !separator.test('')) {
                    output.push('');
                }
            } else {
                output.push(string.slice(lastLastIndex));
            }
            return output.length > limit ? output.slice(0, limit) : output;
        };
    }());

// [bugfix, chrome]
// If separator is undefined, then the result array contains just one String,
// which is the this value (converted to a String). If limit is not undefined,
// then the output array is truncated so that it contains no more than limit
// elements.
// "0".split(undefined, 0) -> []
} else if ('0'.split(void 0, 0).length) {
    StringPrototype.split = function split(separator, limit) {
        if (separator === void 0 && limit === 0) { return []; }
        return string_split.call(this, separator, limit);
    };
}

// ECMA-262, 3rd B.2.3
// Not an ECMAScript standard, although ECMAScript 3rd Edition has a
// non-normative section suggesting uniform semantics and it should be
// normalized across all browsers
// [bugfix, IE lt 9] IE < 9 substr() with negative value not working in IE
var string_substr = StringPrototype.substr;
var hasNegativeSubstrBug = ''.substr && '0b'.substr(-1) !== 'b';
defineProperties(StringPrototype, {
    substr: function substr(start, length) {
        return string_substr.call(
            this,
            start < 0 ? ((start = this.length + start) < 0 ? 0 : start) : start,
            length
        );
    }
}, hasNegativeSubstrBug);

},{}],16:[function(require,module,exports){
'use strict';

module.exports = [
  // streaming transports
  require('./transport/websocket')
, require('./transport/xhr-streaming')
, require('./transport/xdr-streaming')
, require('./transport/eventsource')
, require('./transport/lib/iframe-wrap')(require('./transport/eventsource'))

  // polling transports
, require('./transport/htmlfile')
, require('./transport/lib/iframe-wrap')(require('./transport/htmlfile'))
, require('./transport/xhr-polling')
, require('./transport/xdr-polling')
, require('./transport/lib/iframe-wrap')(require('./transport/xhr-polling'))
, require('./transport/jsonp-polling')
];

},{"./transport/eventsource":20,"./transport/htmlfile":21,"./transport/jsonp-polling":23,"./transport/lib/iframe-wrap":26,"./transport/websocket":38,"./transport/xdr-polling":39,"./transport/xdr-streaming":40,"./transport/xhr-polling":41,"./transport/xhr-streaming":42}],17:[function(require,module,exports){
(function (process,global){
'use strict';

var EventEmitter = require('events').EventEmitter
  , inherits = require('inherits')
  , utils = require('../../utils/event')
  , urlUtils = require('../../utils/url')
  , XHR = global.XMLHttpRequest
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:browser:xhr');
}

function AbstractXHRObject(method, url, payload, opts) {
  debug(method, url);
  var self = this;
  EventEmitter.call(this);

  setTimeout(function () {
    self._start(method, url, payload, opts);
  }, 0);
}

inherits(AbstractXHRObject, EventEmitter);

AbstractXHRObject.prototype._start = function(method, url, payload, opts) {
  var self = this;

  try {
    this.xhr = new XHR();
  } catch (x) {
    // intentionally empty
  }

  if (!this.xhr) {
    debug('no xhr');
    this.emit('finish', 0, 'no xhr support');
    this._cleanup();
    return;
  }

  // several browsers cache POSTs
  url = urlUtils.addQuery(url, 't=' + (+new Date()));

  // Explorer tends to keep connection open, even after the
  // tab gets closed: http://bugs.jquery.com/ticket/5280
  this.unloadRef = utils.unloadAdd(function() {
    debug('unload cleanup');
    self._cleanup(true);
  });
  try {
    this.xhr.open(method, url, true);
    if (this.timeout && 'timeout' in this.xhr) {
      this.xhr.timeout = this.timeout;
      this.xhr.ontimeout = function() {
        debug('xhr timeout');
        self.emit('finish', 0, '');
        self._cleanup(false);
      };
    }
  } catch (e) {
    debug('exception', e);
    // IE raises an exception on wrong port.
    this.emit('finish', 0, '');
    this._cleanup(false);
    return;
  }

  if ((!opts || !opts.noCredentials) && AbstractXHRObject.supportsCORS) {
    debug('withCredentials');
    // Mozilla docs says https://developer.mozilla.org/en/XMLHttpRequest :
    // "This never affects same-site requests."

    this.xhr.withCredentials = true;
  }
  if (opts && opts.headers) {
    for (var key in opts.headers) {
      this.xhr.setRequestHeader(key, opts.headers[key]);
    }
  }

  this.xhr.onreadystatechange = function() {
    if (self.xhr) {
      var x = self.xhr;
      var text, status;
      debug('readyState', x.readyState);
      switch (x.readyState) {
      case 3:
        // IE doesn't like peeking into responseText or status
        // on Microsoft.XMLHTTP and readystate=3
        try {
          status = x.status;
          text = x.responseText;
        } catch (e) {
          // intentionally empty
        }
        debug('status', status);
        // IE returns 1223 for 204: http://bugs.jquery.com/ticket/1450
        if (status === 1223) {
          status = 204;
        }

        // IE does return readystate == 3 for 404 answers.
        if (status === 200 && text && text.length > 0) {
          debug('chunk');
          self.emit('chunk', status, text);
        }
        break;
      case 4:
        status = x.status;
        debug('status', status);
        // IE returns 1223 for 204: http://bugs.jquery.com/ticket/1450
        if (status === 1223) {
          status = 204;
        }
        // IE returns this for a bad port
        // http://msdn.microsoft.com/en-us/library/windows/desktop/aa383770(v=vs.85).aspx
        if (status === 12005 || status === 12029) {
          status = 0;
        }

        debug('finish', status, x.responseText);
        self.emit('finish', status, x.responseText);
        self._cleanup(false);
        break;
      }
    }
  };

  try {
    // self.xhr.send(payload);
  } catch (e) {
    self.emit('finish', 0, '');
    self._cleanup(false);
  }
};

AbstractXHRObject.prototype._cleanup = function(abort) {
  debug('cleanup');
  if (!this.xhr) {
    return;
  }
  this.removeAllListeners();
  utils.unloadDel(this.unloadRef);

  // IE needs this field to be a function
  this.xhr.onreadystatechange = function() {};
  if (this.xhr.ontimeout) {
    this.xhr.ontimeout = null;
  }

  if (abort) {
    try {
      this.xhr.abort();
    } catch (x) {
      // intentionally empty
    }
  }
  this.unloadRef = this.xhr = null;
};

AbstractXHRObject.prototype.close = function() {
  debug('close');
  this._cleanup(true);
};

AbstractXHRObject.enabled = !!XHR;
// override XMLHttpRequest for IE6/7
// obfuscate to avoid firewalls
var axo = ['Active'].concat('Object').join('X');
if (!AbstractXHRObject.enabled && (axo in global)) {
  debug('overriding xmlhttprequest');
  XHR = function() {
    try {
      return new global[axo]('Microsoft.XMLHTTP');
    } catch (e) {
      return null;
    }
  };
  AbstractXHRObject.enabled = !!new XHR();
}

var cors = false;
try {
  cors = 'withCredentials' in new XHR();
} catch (ignored) {
  // intentionally empty
}

AbstractXHRObject.supportsCORS = cors;

module.exports = AbstractXHRObject;

}).call(this,{ env: {} },typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../../utils/event":46,"../../utils/url":52,"debug":54,"events":3,"inherits":56}],18:[function(require,module,exports){
(function (global){
module.exports = global.EventSource;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],19:[function(require,module,exports){
(function (global){
'use strict';

var Driver = global.WebSocket || global.MozWebSocket;
if (Driver) {
	module.exports = function WebSocketBrowserDriver(url) {
		return new Driver(url);
	};
} else {
	module.exports = undefined;
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],20:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , AjaxBasedTransport = require('./lib/ajax-based')
  , EventSourceReceiver = require('./receiver/eventsource')
  , XHRCorsObject = require('./sender/xhr-cors')
  , EventSourceDriver = require('eventsource')
  ;

function EventSourceTransport(transUrl) {
  if (!EventSourceTransport.enabled()) {
    throw new Error('Transport created when disabled');
  }

  AjaxBasedTransport.call(this, transUrl, '/eventsource', EventSourceReceiver, XHRCorsObject);
}

inherits(EventSourceTransport, AjaxBasedTransport);

EventSourceTransport.enabled = function() {
  return !!EventSourceDriver;
};

EventSourceTransport.transportName = 'eventsource';
EventSourceTransport.roundTrips = 2;

module.exports = EventSourceTransport;

},{"./lib/ajax-based":24,"./receiver/eventsource":29,"./sender/xhr-cors":35,"eventsource":18,"inherits":56}],21:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , HtmlfileReceiver = require('./receiver/htmlfile')
  , XHRLocalObject = require('./sender/xhr-local')
  , AjaxBasedTransport = require('./lib/ajax-based')
  ;

function HtmlFileTransport(transUrl) {
  if (!HtmlfileReceiver.enabled) {
    throw new Error('Transport created when disabled');
  }
  AjaxBasedTransport.call(this, transUrl, '/htmlfile', HtmlfileReceiver, XHRLocalObject);
}

inherits(HtmlFileTransport, AjaxBasedTransport);

HtmlFileTransport.enabled = function(info) {
  return HtmlfileReceiver.enabled && info.sameOrigin;
};

HtmlFileTransport.transportName = 'htmlfile';
HtmlFileTransport.roundTrips = 2;

module.exports = HtmlFileTransport;

},{"./lib/ajax-based":24,"./receiver/htmlfile":30,"./sender/xhr-local":37,"inherits":56}],22:[function(require,module,exports){
(function (process){
'use strict';

// Few cool transports do work only for same-origin. In order to make
// them work cross-domain we shall use iframe, served from the
// remote domain. New browsers have capabilities to communicate with
// cross domain iframe using postMessage(). In IE it was implemented
// from IE 8+, but of course, IE got some details wrong:
//    http://msdn.microsoft.com/en-us/library/cc197015(v=VS.85).aspx
//    http://stevesouders.com/misc/test-postmessage.php

var inherits = require('inherits')
  , JSON3 = require('json3')
  , EventEmitter = require('events').EventEmitter
  , version = require('../version')
  , urlUtils = require('../utils/url')
  , iframeUtils = require('../utils/iframe')
  , eventUtils = require('../utils/event')
  , random = require('../utils/random')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:transport:iframe');
}

function IframeTransport(transport, transUrl, baseUrl) {
  if (!IframeTransport.enabled()) {
    throw new Error('Transport created when disabled');
  }
  EventEmitter.call(this);

  var self = this;
  this.origin = urlUtils.getOrigin(baseUrl);
  this.baseUrl = baseUrl;
  this.transUrl = transUrl;
  this.transport = transport;
  this.windowId = random.string(8);

  var iframeUrl = urlUtils.addPath(baseUrl, '/iframe.html') + '#' + this.windowId;
  debug(transport, transUrl, iframeUrl);

  this.iframeObj = iframeUtils.createIframe(iframeUrl, function(r) {
    debug('err callback');
    self.emit('close', 1006, 'Unable to load an iframe (' + r + ')');
    self.close();
  });

  this.onmessageCallback = this._message.bind(this);
  eventUtils.attachEvent('message', this.onmessageCallback);
}

inherits(IframeTransport, EventEmitter);

IframeTransport.prototype.close = function() {
  debug('close');
  this.removeAllListeners();
  if (this.iframeObj) {
    eventUtils.detachEvent('message', this.onmessageCallback);
    try {
      // When the iframe is not loaded, IE raises an exception
      // on 'contentWindow'.
      this.postMessage('c');
    } catch (x) {
      // intentionally empty
    }
    this.iframeObj.cleanup();
    this.iframeObj = null;
    this.onmessageCallback = this.iframeObj = null;
  }
};

IframeTransport.prototype._message = function(e) {
  debug('message', e.data);
  if (!urlUtils.isOriginEqual(e.origin, this.origin)) {
    debug('not same origin', e.origin, this.origin);
    return;
  }

  var iframeMessage;
  try {
    iframeMessage = JSON3.parse(e.data);
  } catch (ignored) {
    debug('bad json', e.data);
    return;
  }

  if (iframeMessage.windowId !== this.windowId) {
    debug('mismatched window id', iframeMessage.windowId, this.windowId);
    return;
  }

  switch (iframeMessage.type) {
  case 's':
    this.iframeObj.loaded();
    // window global dependency
    this.postMessage('s', JSON3.stringify([
      version
    , this.transport
    , this.transUrl
    , this.baseUrl
    ]));
    break;
  case 't':
    this.emit('message', iframeMessage.data);
    break;
  case 'c':
    var cdata;
    try {
      cdata = JSON3.parse(iframeMessage.data);
    } catch (ignored) {
      debug('bad json', iframeMessage.data);
      return;
    }
    this.emit('close', cdata[0], cdata[1]);
    this.close();
    break;
  }
};

IframeTransport.prototype.postMessage = function(type, data) {
  debug('postMessage', type, data);
  this.iframeObj.post(JSON3.stringify({
    windowId: this.windowId
  , type: type
  , data: data || ''
  }), this.origin);
};

IframeTransport.prototype.send = function(message) {
  debug('send', message);
  this.postMessage('m', message);
};

IframeTransport.enabled = function() {
  return iframeUtils.iframeEnabled;
};

IframeTransport.transportName = 'iframe';
IframeTransport.roundTrips = 2;

module.exports = IframeTransport;

}).call(this,{ env: {} })

},{"../utils/event":46,"../utils/iframe":47,"../utils/random":50,"../utils/url":52,"../version":53,"debug":54,"events":3,"inherits":56,"json3":57}],23:[function(require,module,exports){
(function (global){
'use strict';

// The simplest and most robust transport, using the well-know cross
// domain hack - JSONP. This transport is quite inefficient - one
// message could use up to one http request. But at least it works almost
// everywhere.
// Known limitations:
//   o you will get a spinning cursor
//   o for Konqueror a dumb timer is needed to detect errors

var inherits = require('inherits')
  , SenderReceiver = require('./lib/sender-receiver')
  , JsonpReceiver = require('./receiver/jsonp')
  , jsonpSender = require('./sender/jsonp')
  ;

function JsonPTransport(transUrl) {
  if (!JsonPTransport.enabled()) {
    throw new Error('Transport created when disabled');
  }
  SenderReceiver.call(this, transUrl, '/jsonp', jsonpSender, JsonpReceiver);
}

inherits(JsonPTransport, SenderReceiver);

JsonPTransport.enabled = function() {
  return !!global.document;
};

JsonPTransport.transportName = 'jsonp-polling';
JsonPTransport.roundTrips = 1;
JsonPTransport.needBody = true;

module.exports = JsonPTransport;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./lib/sender-receiver":28,"./receiver/jsonp":31,"./sender/jsonp":33,"inherits":56}],24:[function(require,module,exports){
(function (process){
'use strict';

var inherits = require('inherits')
  , urlUtils = require('../../utils/url')
  , SenderReceiver = require('./sender-receiver')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:ajax-based');
}

function createAjaxSender(AjaxObject) {
  return function(url, payload, callback) {
    debug('create ajax sender', url, payload);
    var opt = {};
    if (typeof payload === 'string') {
      opt.headers = {'Content-type': 'text/plain'};
    }
    var ajaxUrl = urlUtils.addPath(url, '/xhr_send');
    var xo = new AjaxObject('POST', ajaxUrl, payload, opt);
    xo.once('finish', function(status) {
      debug('finish', status);
      xo = null;

      if (status !== 200 && status !== 204) {
        return callback(new Error('http status ' + status));
      }
      callback();
    });
    return function() {
      debug('abort');
      xo.close();
      xo = null;

      var err = new Error('Aborted');
      err.code = 1000;
      callback(err);
    };
  };
}

function AjaxBasedTransport(transUrl, urlSuffix, Receiver, AjaxObject) {
  SenderReceiver.call(this, transUrl, urlSuffix, createAjaxSender(AjaxObject), Receiver, AjaxObject);
}

inherits(AjaxBasedTransport, SenderReceiver);

module.exports = AjaxBasedTransport;

}).call(this,{ env: {} })

},{"../../utils/url":52,"./sender-receiver":28,"debug":54,"inherits":56}],25:[function(require,module,exports){
(function (process){
'use strict';

var inherits = require('inherits')
  , EventEmitter = require('events').EventEmitter
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:buffered-sender');
}

function BufferedSender(url, sender) {
  debug(url);
  EventEmitter.call(this);
  this.sendBuffer = [];
  this.sender = sender;
  this.url = url;
}

inherits(BufferedSender, EventEmitter);

BufferedSender.prototype.send = function(message) {
  debug('send', message);
  this.sendBuffer.push(message);
  if (!this.sendStop) {
    this.sendSchedule();
  }
};

// For polling transports in a situation when in the message callback,
// new message is being send. If the sending connection was started
// before receiving one, it is possible to saturate the network and
// timeout due to the lack of receiving socket. To avoid that we delay
// sending messages by some small time, in order to let receiving
// connection be started beforehand. This is only a halfmeasure and
// does not fix the big problem, but it does make the tests go more
// stable on slow networks.
BufferedSender.prototype.sendScheduleWait = function() {
  debug('sendScheduleWait');
  var self = this;
  var tref;
  this.sendStop = function() {
    debug('sendStop');
    self.sendStop = null;
    clearTimeout(tref);
  };
  tref = setTimeout(function() {
    debug('timeout');
    self.sendStop = null;
    self.sendSchedule();
  }, 25);
};

BufferedSender.prototype.sendSchedule = function() {
  debug('sendSchedule', this.sendBuffer.length);
  var self = this;
  if (this.sendBuffer.length > 0) {
    var payload = '[' + this.sendBuffer.join(',') + ']';
    this.sendStop = this.sender(this.url, payload, function(err) {
      self.sendStop = null;
      if (err) {
        debug('error', err);
        self.emit('close', err.code || 1006, 'Sending error: ' + err);
        self.close();
      } else {
        self.sendScheduleWait();
      }
    });
    this.sendBuffer = [];
  }
};

BufferedSender.prototype._cleanup = function() {
  debug('_cleanup');
  this.removeAllListeners();
};

BufferedSender.prototype.close = function() {
  debug('close');
  this._cleanup();
  if (this.sendStop) {
    this.sendStop();
    this.sendStop = null;
  }
};

module.exports = BufferedSender;

}).call(this,{ env: {} })

},{"debug":54,"events":3,"inherits":56}],26:[function(require,module,exports){
(function (global){
'use strict';

var inherits = require('inherits')
  , IframeTransport = require('../iframe')
  , objectUtils = require('../../utils/object')
  ;

module.exports = function(transport) {

  function IframeWrapTransport(transUrl, baseUrl) {
    IframeTransport.call(this, transport.transportName, transUrl, baseUrl);
  }

  inherits(IframeWrapTransport, IframeTransport);

  IframeWrapTransport.enabled = function(url, info) {
    if (!global.document) {
      return false;
    }

    var iframeInfo = objectUtils.extend({}, info);
    iframeInfo.sameOrigin = true;
    return transport.enabled(iframeInfo) && IframeTransport.enabled();
  };

  IframeWrapTransport.transportName = 'iframe-' + transport.transportName;
  IframeWrapTransport.needBody = true;
  IframeWrapTransport.roundTrips = IframeTransport.roundTrips + transport.roundTrips - 1; // html, javascript (2) + transport - no CORS (1)

  IframeWrapTransport.facadeTransport = transport;

  return IframeWrapTransport;
};

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../../utils/object":49,"../iframe":22,"inherits":56}],27:[function(require,module,exports){
(function (process){
'use strict';

var inherits = require('inherits')
  , EventEmitter = require('events').EventEmitter
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:polling');
}

function Polling(Receiver, receiveUrl, AjaxObject) {
  debug(receiveUrl);
  EventEmitter.call(this);
  this.Receiver = Receiver;
  this.receiveUrl = receiveUrl;
  this.AjaxObject = AjaxObject;
  this._scheduleReceiver();
}

inherits(Polling, EventEmitter);

Polling.prototype._scheduleReceiver = function() {
  debug('_scheduleReceiver');
  var self = this;
  var poll = this.poll = new this.Receiver(this.receiveUrl, this.AjaxObject);

  poll.on('message', function(msg) {
    debug('message', msg);
    self.emit('message', msg);
  });

  poll.once('close', function(code, reason) {
    debug('close', code, reason, self.pollIsClosing);
    self.poll = poll = null;

    if (!self.pollIsClosing) {
      if (reason === 'network') {
        self._scheduleReceiver();
      } else {
        self.emit('close', code || 1006, reason);
        self.removeAllListeners();
      }
    }
  });
};

Polling.prototype.abort = function() {
  debug('abort');
  this.removeAllListeners();
  this.pollIsClosing = true;
  if (this.poll) {
    this.poll.abort();
  }
};

module.exports = Polling;

}).call(this,{ env: {} })

},{"debug":54,"events":3,"inherits":56}],28:[function(require,module,exports){
(function (process){
'use strict';

var inherits = require('inherits')
  , urlUtils = require('../../utils/url')
  , BufferedSender = require('./buffered-sender')
  , Polling = require('./polling')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:sender-receiver');
}

function SenderReceiver(transUrl, urlSuffix, senderFunc, Receiver, AjaxObject) {
  var pollUrl = urlUtils.addPath(transUrl, urlSuffix);
  debug(pollUrl);
  var self = this;
  BufferedSender.call(this, transUrl, senderFunc);

  this.poll = new Polling(Receiver, pollUrl, AjaxObject);
  this.poll.on('message', function(msg) {
    debug('poll message', msg);
    self.emit('message', msg);
  });
  this.poll.once('close', function(code, reason) {
    debug('poll close', code, reason);
    self.poll = null;
    self.emit('close', code, reason);
    self.close();
  });
}

inherits(SenderReceiver, BufferedSender);

SenderReceiver.prototype.close = function() {
  BufferedSender.prototype.close.call(this);
  debug('close');
  this.removeAllListeners();
  if (this.poll) {
    this.poll.abort();
    this.poll = null;
  }
};

module.exports = SenderReceiver;

}).call(this,{ env: {} })

},{"../../utils/url":52,"./buffered-sender":25,"./polling":27,"debug":54,"inherits":56}],29:[function(require,module,exports){
(function (process){
'use strict';

var inherits = require('inherits')
  , EventEmitter = require('events').EventEmitter
  , EventSourceDriver = require('eventsource')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:receiver:eventsource');
}

function EventSourceReceiver(url) {
  debug(url);
  EventEmitter.call(this);

  var self = this;
  var es = this.es = new EventSourceDriver(url);
  es.onmessage = function(e) {
    debug('message', e.data);
    self.emit('message', decodeURI(e.data));
  };
  es.onerror = function(e) {
    debug('error', es.readyState, e);
    // ES on reconnection has readyState = 0 or 1.
    // on network error it's CLOSED = 2
    var reason = (es.readyState !== 2 ? 'network' : 'permanent');
    self._cleanup();
    self._close(reason);
  };
}

inherits(EventSourceReceiver, EventEmitter);

EventSourceReceiver.prototype.abort = function() {
  debug('abort');
  this._cleanup();
  this._close('user');
};

EventSourceReceiver.prototype._cleanup = function() {
  debug('cleanup');
  var es = this.es;
  if (es) {
    es.onmessage = es.onerror = null;
    es.close();
    this.es = null;
  }
};

EventSourceReceiver.prototype._close = function(reason) {
  debug('close', reason);
  var self = this;
  // Safari and chrome < 15 crash if we close window before
  // waiting for ES cleanup. See:
  // https://code.google.com/p/chromium/issues/detail?id=89155
  setTimeout(function() {
    self.emit('close', null, reason);
    self.removeAllListeners();
  }, 200);
};

module.exports = EventSourceReceiver;

}).call(this,{ env: {} })

},{"debug":54,"events":3,"eventsource":18,"inherits":56}],30:[function(require,module,exports){
(function (process,global){
'use strict';

var inherits = require('inherits')
  , iframeUtils = require('../../utils/iframe')
  , urlUtils = require('../../utils/url')
  , EventEmitter = require('events').EventEmitter
  , random = require('../../utils/random')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:receiver:htmlfile');
}

function HtmlfileReceiver(url) {
  debug(url);
  EventEmitter.call(this);
  var self = this;
  iframeUtils.polluteGlobalNamespace();

  this.id = 'a' + random.string(6);
  url = urlUtils.addQuery(url, 'c=' + decodeURIComponent(iframeUtils.WPrefix + '.' + this.id));

  debug('using htmlfile', HtmlfileReceiver.htmlfileEnabled);
  var constructFunc = HtmlfileReceiver.htmlfileEnabled ?
      iframeUtils.createHtmlfile : iframeUtils.createIframe;

  global[iframeUtils.WPrefix][this.id] = {
    start: function() {
      debug('start');
      self.iframeObj.loaded();
    }
  , message: function(data) {
      debug('message', data);
      self.emit('message', data);
    }
  , stop: function() {
      debug('stop');
      self._cleanup();
      self._close('network');
    }
  };
  this.iframeObj = constructFunc(url, function() {
    debug('callback');
    self._cleanup();
    self._close('permanent');
  });
}

inherits(HtmlfileReceiver, EventEmitter);

HtmlfileReceiver.prototype.abort = function() {
  debug('abort');
  this._cleanup();
  this._close('user');
};

HtmlfileReceiver.prototype._cleanup = function() {
  debug('_cleanup');
  if (this.iframeObj) {
    this.iframeObj.cleanup();
    this.iframeObj = null;
  }
  delete global[iframeUtils.WPrefix][this.id];
};

HtmlfileReceiver.prototype._close = function(reason) {
  debug('_close', reason);
  this.emit('close', null, reason);
  this.removeAllListeners();
};

HtmlfileReceiver.htmlfileEnabled = false;

// obfuscate to avoid firewalls
var axo = ['Active'].concat('Object').join('X');
if (axo in global) {
  try {
    HtmlfileReceiver.htmlfileEnabled = !!new global[axo]('htmlfile');
  } catch (x) {
    // intentionally empty
  }
}

HtmlfileReceiver.enabled = HtmlfileReceiver.htmlfileEnabled || iframeUtils.iframeEnabled;

module.exports = HtmlfileReceiver;

}).call(this,{ env: {} },typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../../utils/iframe":47,"../../utils/random":50,"../../utils/url":52,"debug":54,"events":3,"inherits":56}],31:[function(require,module,exports){
(function (process,global){
'use strict';

var utils = require('../../utils/iframe')
  , random = require('../../utils/random')
  , browser = require('../../utils/browser')
  , urlUtils = require('../../utils/url')
  , inherits = require('inherits')
  , EventEmitter = require('events').EventEmitter
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:receiver:jsonp');
}

function JsonpReceiver(url) {
  debug(url);
  var self = this;
  EventEmitter.call(this);

  utils.polluteGlobalNamespace();

  this.id = 'a' + random.string(6);
  var urlWithId = urlUtils.addQuery(url, 'c=' + encodeURIComponent(utils.WPrefix + '.' + this.id));

  global[utils.WPrefix][this.id] = this._callback.bind(this);
  this._createScript(urlWithId);

  // Fallback mostly for Konqueror - stupid timer, 35 seconds shall be plenty.
  this.timeoutId = setTimeout(function() {
    debug('timeout');
    self._abort(new Error('JSONP script loaded abnormally (timeout)'));
  }, JsonpReceiver.timeout);
}

inherits(JsonpReceiver, EventEmitter);

JsonpReceiver.prototype.abort = function() {
  debug('abort');
  if (global[utils.WPrefix][this.id]) {
    var err = new Error('JSONP user aborted read');
    err.code = 1000;
    this._abort(err);
  }
};

JsonpReceiver.timeout = 35000;
JsonpReceiver.scriptErrorTimeout = 1000;

JsonpReceiver.prototype._callback = function(data) {
  debug('_callback', data);
  this._cleanup();

  if (this.aborting) {
    return;
  }

  if (data) {
    debug('message', data);
    this.emit('message', data);
  }
  this.emit('close', null, 'network');
  this.removeAllListeners();
};

JsonpReceiver.prototype._abort = function(err) {
  debug('_abort', err);
  this._cleanup();
  this.aborting = true;
  this.emit('close', err.code, err.message);
  this.removeAllListeners();
};

JsonpReceiver.prototype._cleanup = function() {
  debug('_cleanup');
  clearTimeout(this.timeoutId);
  if (this.script2) {
    this.script2.parentNode.removeChild(this.script2);
    this.script2 = null;
  }
  if (this.script) {
    var script = this.script;
    // Unfortunately, you can't really abort script loading of
    // the script.
    script.parentNode.removeChild(script);
    script.onreadystatechange = script.onerror =
        script.onload = script.onclick = null;
    this.script = null;
  }
  delete global[utils.WPrefix][this.id];
};

JsonpReceiver.prototype._scriptError = function() {
  debug('_scriptError');
  var self = this;
  if (this.errorTimer) {
    return;
  }

  this.errorTimer = setTimeout(function() {
    if (!self.loadedOkay) {
      self._abort(new Error('JSONP script loaded abnormally (onerror)'));
    }
  }, JsonpReceiver.scriptErrorTimeout);
};

JsonpReceiver.prototype._createScript = function(url) {
  debug('_createScript', url);
  var self = this;
  var script = this.script = global.document.createElement('script');
  var script2;  // Opera synchronous load trick.

  script.id = 'a' + random.string(8);
  script.src = url;
  script.type = 'text/javascript';
  script.charset = 'UTF-8';
  script.onerror = this._scriptError.bind(this);
  script.onload = function() {
    debug('onload');
    self._abort(new Error('JSONP script loaded abnormally (onload)'));
  };

  // IE9 fires 'error' event after onreadystatechange or before, in random order.
  // Use loadedOkay to determine if actually errored
  script.onreadystatechange = function() {
    debug('onreadystatechange', script.readyState);
    if (/loaded|closed/.test(script.readyState)) {
      if (script && script.htmlFor && script.onclick) {
        self.loadedOkay = true;
        try {
          // In IE, actually execute the script.
          script.onclick();
        } catch (x) {
          // intentionally empty
        }
      }
      if (script) {
        self._abort(new Error('JSONP script loaded abnormally (onreadystatechange)'));
      }
    }
  };
  // IE: event/htmlFor/onclick trick.
  // One can't rely on proper order for onreadystatechange. In order to
  // make sure, set a 'htmlFor' and 'event' properties, so that
  // script code will be installed as 'onclick' handler for the
  // script object. Later, onreadystatechange, manually execute this
  // code. FF and Chrome doesn't work with 'event' and 'htmlFor'
  // set. For reference see:
  //   http://jaubourg.net/2010/07/loading-script-as-onclick-handler-of.html
  // Also, read on that about script ordering:
  //   http://wiki.whatwg.org/wiki/Dynamic_Script_Execution_Order
  if (typeof script.async === 'undefined' && global.document.attachEvent) {
    // According to mozilla docs, in recent browsers script.async defaults
    // to 'true', so we may use it to detect a good browser:
    // https://developer.mozilla.org/en/HTML/Element/script
    if (!browser.isOpera()) {
      // Naively assume we're in IE
      try {
        script.htmlFor = script.id;
        script.event = 'onclick';
      } catch (x) {
        // intentionally empty
      }
      script.async = true;
    } else {
      // Opera, second sync script hack
      script2 = this.script2 = global.document.createElement('script');
      script2.text = "try{var a = document.getElementById('" + script.id + "'); if(a)a.onerror();}catch(x){};";
      script.async = script2.async = false;
    }
  }
  if (typeof script.async !== 'undefined') {
    script.async = true;
  }

  var head = global.document.getElementsByTagName('head')[0];
  head.insertBefore(script, head.firstChild);
  if (script2) {
    head.insertBefore(script2, head.firstChild);
  }
};

module.exports = JsonpReceiver;

}).call(this,{ env: {} },typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../../utils/browser":44,"../../utils/iframe":47,"../../utils/random":50,"../../utils/url":52,"debug":54,"events":3,"inherits":56}],32:[function(require,module,exports){
(function (process){
'use strict';

var inherits = require('inherits')
  , EventEmitter = require('events').EventEmitter
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:receiver:xhr');
}

function XhrReceiver(url, AjaxObject) {
  debug(url);
  EventEmitter.call(this);
  var self = this;

  this.bufferPosition = 0;

  this.xo = new AjaxObject('POST', url, null);
  this.xo.on('chunk', this._chunkHandler.bind(this));
  this.xo.once('finish', function(status, text) {
    debug('finish', status, text);
    self._chunkHandler(status, text);
    self.xo = null;
    var reason = status === 200 ? 'network' : 'permanent';
    debug('close', reason);
    self.emit('close', null, reason);
    self._cleanup();
  });
}

inherits(XhrReceiver, EventEmitter);

XhrReceiver.prototype._chunkHandler = function(status, text) {
  debug('_chunkHandler', status);
  if (status !== 200 || !text) {
    return;
  }

  for (var idx = -1; ; this.bufferPosition += idx + 1) {
    var buf = text.slice(this.bufferPosition);
    idx = buf.indexOf('\n');
    if (idx === -1) {
      break;
    }
    var msg = buf.slice(0, idx);
    if (msg) {
      debug('message', msg);
      this.emit('message', msg);
    }
  }
};

XhrReceiver.prototype._cleanup = function() {
  debug('_cleanup');
  this.removeAllListeners();
};

XhrReceiver.prototype.abort = function() {
  debug('abort');
  if (this.xo) {
    this.xo.close();
    debug('close');
    this.emit('close', null, 'user');
    this.xo = null;
  }
  this._cleanup();
};

module.exports = XhrReceiver;

}).call(this,{ env: {} })

},{"debug":54,"events":3,"inherits":56}],33:[function(require,module,exports){
(function (process,global){
'use strict';

var random = require('../../utils/random')
  , urlUtils = require('../../utils/url')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:sender:jsonp');
}

var form, area;

function createIframe(id) {
  debug('createIframe', id);
  try {
    // ie6 dynamic iframes with target="" support (thanks Chris Lambacher)
    return global.document.createElement('<iframe name="' + id + '">');
  } catch (x) {
    var iframe = global.document.createElement('iframe');
    iframe.name = id;
    return iframe;
  }
}

function createForm() {
  debug('createForm');
  form = global.document.createElement('form');
  form.style.display = 'none';
  form.style.position = 'absolute';
  form.method = 'POST';
  form.enctype = 'application/x-www-form-urlencoded';
  form.acceptCharset = 'UTF-8';

  area = global.document.createElement('textarea');
  area.name = 'd';
  form.appendChild(area);

  global.document.body.appendChild(form);
}

module.exports = function(url, payload, callback) {
  debug(url, payload);
  if (!form) {
    createForm();
  }
  var id = 'a' + random.string(8);
  form.target = id;
  form.action = urlUtils.addQuery(urlUtils.addPath(url, '/jsonp_send'), 'i=' + id);

  var iframe = createIframe(id);
  iframe.id = id;
  iframe.style.display = 'none';
  form.appendChild(iframe);

  try {
    area.value = payload;
  } catch (e) {
    // seriously broken browsers get here
  }
  form.submit();

  var completed = function(err) {
    debug('completed', id, err);
    if (!iframe.onerror) {
      return;
    }
    iframe.onreadystatechange = iframe.onerror = iframe.onload = null;
    // Opera mini doesn't like if we GC iframe
    // immediately, thus this timeout.
    setTimeout(function() {
      debug('cleaning up', id);
      iframe.parentNode.removeChild(iframe);
      iframe = null;
    }, 500);
    area.value = '';
    // It is not possible to detect if the iframe succeeded or
    // failed to submit our form.
    callback(err);
  };
  iframe.onerror = function() {
    debug('onerror', id);
    completed();
  };
  iframe.onload = function() {
    debug('onload', id);
    completed();
  };
  iframe.onreadystatechange = function(e) {
    debug('onreadystatechange', id, iframe.readyState, e);
    if (iframe.readyState === 'complete') {
      completed();
    }
  };
  return function() {
    debug('aborted', id);
    completed(new Error('Aborted'));
  };
};

}).call(this,{ env: {} },typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../../utils/random":50,"../../utils/url":52,"debug":54}],34:[function(require,module,exports){
(function (process,global){
'use strict';

var EventEmitter = require('events').EventEmitter
  , inherits = require('inherits')
  , eventUtils = require('../../utils/event')
  , browser = require('../../utils/browser')
  , urlUtils = require('../../utils/url')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:sender:xdr');
}

// References:
//   http://ajaxian.com/archives/100-line-ajax-wrapper
//   http://msdn.microsoft.com/en-us/library/cc288060(v=VS.85).aspx

function XDRObject(method, url, payload) {
  debug(method, url);
  var self = this;
  EventEmitter.call(this);

  setTimeout(function() {
    self._start(method, url, payload);
  }, 0);
}

inherits(XDRObject, EventEmitter);

XDRObject.prototype._start = function(method, url, payload) {
  debug('_start');
  var self = this;
  var xdr = new global.XDomainRequest();
  // IE caches even POSTs
  url = urlUtils.addQuery(url, 't=' + (+new Date()));

  xdr.onerror = function() {
    debug('onerror');
    self._error();
  };
  xdr.ontimeout = function() {
    debug('ontimeout');
    self._error();
  };
  xdr.onprogress = function() {
    debug('progress', xdr.responseText);
    self.emit('chunk', 200, xdr.responseText);
  };
  xdr.onload = function() {
    debug('load');
    self.emit('finish', 200, xdr.responseText);
    self._cleanup(false);
  };
  this.xdr = xdr;
  this.unloadRef = eventUtils.unloadAdd(function() {
    self._cleanup(true);
  });
  try {
    // Fails with AccessDenied if port number is bogus
    this.xdr.open(method, url);
    if (this.timeout) {
      this.xdr.timeout = this.timeout;
    }
    this.xdr.send(payload);
  } catch (x) {
    this._error();
  }
};

XDRObject.prototype._error = function() {
  this.emit('finish', 0, '');
  this._cleanup(false);
};

XDRObject.prototype._cleanup = function(abort) {
  debug('cleanup', abort);
  if (!this.xdr) {
    return;
  }
  this.removeAllListeners();
  eventUtils.unloadDel(this.unloadRef);

  this.xdr.ontimeout = this.xdr.onerror = this.xdr.onprogress = this.xdr.onload = null;
  if (abort) {
    try {
      this.xdr.abort();
    } catch (x) {
      // intentionally empty
    }
  }
  this.unloadRef = this.xdr = null;
};

XDRObject.prototype.close = function() {
  debug('close');
  this._cleanup(true);
};

// IE 8/9 if the request target uses the same scheme - #79
XDRObject.enabled = !!(global.XDomainRequest && browser.hasDomain());

module.exports = XDRObject;

}).call(this,{ env: {} },typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../../utils/browser":44,"../../utils/event":46,"../../utils/url":52,"debug":54,"events":3,"inherits":56}],35:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , XhrDriver = require('../driver/xhr')
  ;

function XHRCorsObject(method, url, payload, opts) {
  XhrDriver.call(this, method, url, payload, opts);
}

inherits(XHRCorsObject, XhrDriver);

XHRCorsObject.enabled = XhrDriver.enabled && XhrDriver.supportsCORS;

module.exports = XHRCorsObject;

},{"../driver/xhr":17,"inherits":56}],36:[function(require,module,exports){
'use strict';

var EventEmitter = require('events').EventEmitter
  , inherits = require('inherits')
  ;

function XHRFake(/* method, url, payload, opts */) {
  var self = this;
  EventEmitter.call(this);

  this.to = setTimeout(function() {
    self.emit('finish', 200, '{}');
  }, XHRFake.timeout);
}

inherits(XHRFake, EventEmitter);

XHRFake.prototype.close = function() {
  clearTimeout(this.to);
};

XHRFake.timeout = 2000;

module.exports = XHRFake;

},{"events":3,"inherits":56}],37:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , XhrDriver = require('../driver/xhr')
  ;

function XHRLocalObject(method, url, payload /*, opts */) {
  XhrDriver.call(this, method, url, payload, {
    noCredentials: true
  });
}

inherits(XHRLocalObject, XhrDriver);

XHRLocalObject.enabled = XhrDriver.enabled;

module.exports = XHRLocalObject;

},{"../driver/xhr":17,"inherits":56}],38:[function(require,module,exports){
(function (process){
'use strict';

var utils = require('../utils/event')
  , urlUtils = require('../utils/url')
  , inherits = require('inherits')
  , EventEmitter = require('events').EventEmitter
  , WebsocketDriver = require('./driver/websocket')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:websocket');
}

function WebSocketTransport(transUrl, ignore, options) {
  if (!WebSocketTransport.enabled()) {
    throw new Error('Transport created when disabled');
  }

  EventEmitter.call(this);
  debug('constructor', transUrl);

  var self = this;
  var url = urlUtils.addPath(transUrl, '/websocket');
  if (url.slice(0, 5) === 'https') {
    url = 'wss' + url.slice(5);
  } else {
    url = 'ws' + url.slice(4);
  }
  this.url = url;

  this.ws = new WebsocketDriver(this.url, [], options);
  this.ws.onmessage = function(e) {
    debug('message event', e.data);
    self.emit('message', e.data);
  };
  // Firefox has an interesting bug. If a websocket connection is
  // created after onunload, it stays alive even when user
  // navigates away from the page. In such situation let's lie -
  // let's not open the ws connection at all. See:
  // https://github.com/sockjs/sockjs-client/issues/28
  // https://bugzilla.mozilla.org/show_bug.cgi?id=696085
  this.unloadRef = utils.unloadAdd(function() {
    debug('unload');
    self.ws.close();
  });
  this.ws.onclose = function(e) {
    debug('close event', e.code, e.reason);
    self.emit('close', e.code, e.reason);
    self._cleanup();
  };
  this.ws.onerror = function(e) {
    debug('error event', e);
    self.emit('close', 1006, 'WebSocket connection broken');
    self._cleanup();
  };
}

inherits(WebSocketTransport, EventEmitter);

WebSocketTransport.prototype.send = function(data) {
  var msg = '[' + data + ']';
  debug('send', msg);
  this.ws.send(msg);
};

WebSocketTransport.prototype.close = function() {
  debug('close');
  var ws = this.ws;
  this._cleanup();
  if (ws) {
    ws.close();
  }
};

WebSocketTransport.prototype._cleanup = function() {
  debug('_cleanup');
  var ws = this.ws;
  if (ws) {
    ws.onmessage = ws.onclose = ws.onerror = null;
  }
  utils.unloadDel(this.unloadRef);
  this.unloadRef = this.ws = null;
  this.removeAllListeners();
};

WebSocketTransport.enabled = function() {
  debug('enabled');
  return !!WebsocketDriver;
};
WebSocketTransport.transportName = 'websocket';

// In theory, ws should require 1 round trip. But in chrome, this is
// not very stable over SSL. Most likely a ws connection requires a
// separate SSL connection, in which case 2 round trips are an
// absolute minumum.
WebSocketTransport.roundTrips = 2;

module.exports = WebSocketTransport;

}).call(this,{ env: {} })

},{"../utils/event":46,"../utils/url":52,"./driver/websocket":19,"debug":54,"events":3,"inherits":56}],39:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , AjaxBasedTransport = require('./lib/ajax-based')
  , XdrStreamingTransport = require('./xdr-streaming')
  , XhrReceiver = require('./receiver/xhr')
  , XDRObject = require('./sender/xdr')
  ;

function XdrPollingTransport(transUrl) {
  if (!XDRObject.enabled) {
    throw new Error('Transport created when disabled');
  }
  AjaxBasedTransport.call(this, transUrl, '/xhr', XhrReceiver, XDRObject);
}

inherits(XdrPollingTransport, AjaxBasedTransport);

XdrPollingTransport.enabled = XdrStreamingTransport.enabled;
XdrPollingTransport.transportName = 'xdr-polling';
XdrPollingTransport.roundTrips = 2; // preflight, ajax

module.exports = XdrPollingTransport;

},{"./lib/ajax-based":24,"./receiver/xhr":32,"./sender/xdr":34,"./xdr-streaming":40,"inherits":56}],40:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , AjaxBasedTransport = require('./lib/ajax-based')
  , XhrReceiver = require('./receiver/xhr')
  , XDRObject = require('./sender/xdr')
  ;

// According to:
//   http://stackoverflow.com/questions/1641507/detect-browser-support-for-cross-domain-xmlhttprequests
//   http://hacks.mozilla.org/2009/07/cross-site-xmlhttprequest-with-cors/

function XdrStreamingTransport(transUrl) {
  if (!XDRObject.enabled) {
    throw new Error('Transport created when disabled');
  }
  AjaxBasedTransport.call(this, transUrl, '/xhr_streaming', XhrReceiver, XDRObject);
}

inherits(XdrStreamingTransport, AjaxBasedTransport);

XdrStreamingTransport.enabled = function(info) {
  if (info.cookie_needed || info.nullOrigin) {
    return false;
  }
  return XDRObject.enabled && info.sameScheme;
};

XdrStreamingTransport.transportName = 'xdr-streaming';
XdrStreamingTransport.roundTrips = 2; // preflight, ajax

module.exports = XdrStreamingTransport;

},{"./lib/ajax-based":24,"./receiver/xhr":32,"./sender/xdr":34,"inherits":56}],41:[function(require,module,exports){
'use strict';

var inherits = require('inherits')
  , AjaxBasedTransport = require('./lib/ajax-based')
  , XhrReceiver = require('./receiver/xhr')
  , XHRCorsObject = require('./sender/xhr-cors')
  , XHRLocalObject = require('./sender/xhr-local')
  ;

function XhrPollingTransport(transUrl) {
  if (!XHRLocalObject.enabled && !XHRCorsObject.enabled) {
    throw new Error('Transport created when disabled');
  }
  AjaxBasedTransport.call(this, transUrl, '/xhr', XhrReceiver, XHRCorsObject);
}

inherits(XhrPollingTransport, AjaxBasedTransport);

XhrPollingTransport.enabled = function(info) {
  if (info.nullOrigin) {
    return false;
  }

  if (XHRLocalObject.enabled && info.sameOrigin) {
    return true;
  }
  return XHRCorsObject.enabled;
};

XhrPollingTransport.transportName = 'xhr-polling';
XhrPollingTransport.roundTrips = 2; // preflight, ajax

module.exports = XhrPollingTransport;

},{"./lib/ajax-based":24,"./receiver/xhr":32,"./sender/xhr-cors":35,"./sender/xhr-local":37,"inherits":56}],42:[function(require,module,exports){
(function (global){
'use strict';

var inherits = require('inherits')
  , AjaxBasedTransport = require('./lib/ajax-based')
  , XhrReceiver = require('./receiver/xhr')
  , XHRCorsObject = require('./sender/xhr-cors')
  , XHRLocalObject = require('./sender/xhr-local')
  , browser = require('../utils/browser')
  ;

function XhrStreamingTransport(transUrl) {
  if (!XHRLocalObject.enabled && !XHRCorsObject.enabled) {
    throw new Error('Transport created when disabled');
  }
  AjaxBasedTransport.call(this, transUrl, '/xhr_streaming', XhrReceiver, XHRCorsObject);
}

inherits(XhrStreamingTransport, AjaxBasedTransport);

XhrStreamingTransport.enabled = function(info) {
  if (info.nullOrigin) {
    return false;
  }
  // Opera doesn't support xhr-streaming #60
  // But it might be able to #92
  if (browser.isOpera()) {
    return false;
  }

  return XHRCorsObject.enabled;
};

XhrStreamingTransport.transportName = 'xhr-streaming';
XhrStreamingTransport.roundTrips = 2; // preflight, ajax

// Safari gets confused when a streaming ajax request is started
// before onload. This causes the load indicator to spin indefinetely.
// Only require body when used in a browser
XhrStreamingTransport.needBody = !!global.document;

module.exports = XhrStreamingTransport;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"../utils/browser":44,"./lib/ajax-based":24,"./receiver/xhr":32,"./sender/xhr-cors":35,"./sender/xhr-local":37,"inherits":56}],43:[function(require,module,exports){
(function (global){
'use strict';

if (global.crypto && global.crypto.getRandomValues) {
  module.exports.randomBytes = function(length) {
    var bytes = new Uint8Array(length);
    global.crypto.getRandomValues(bytes);
    return bytes;
  };
} else {
  module.exports.randomBytes = function(length) {
    var bytes = new Array(length);
    for (var i = 0; i < length; i++) {
      bytes[i] = Math.floor(Math.random() * 256);
    }
    return bytes;
  };
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],44:[function(require,module,exports){
(function (global){
'use strict';

module.exports = {
  isOpera: function() {
    return global.navigator &&
      /opera/i.test(global.navigator.userAgent);
  }

, isKonqueror: function() {
    return global.navigator &&
      /konqueror/i.test(global.navigator.userAgent);
  }

  // #187 wrap document.domain in try/catch because of WP8 from file:///
, hasDomain: function () {
    // non-browser client always has a domain
    if (!global.document) {
      return true;
    }

    try {
      return !!global.document.domain;
    } catch (e) {
      return false;
    }
  }
};

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],45:[function(require,module,exports){
'use strict';

var JSON3 = require('json3');

// Some extra characters that Chrome gets wrong, and substitutes with
// something else on the wire.
// eslint-disable-next-line no-control-regex
var extraEscapable = /[\x00-\x1f\ud800-\udfff\ufffe\uffff\u0300-\u0333\u033d-\u0346\u034a-\u034c\u0350-\u0352\u0357-\u0358\u035c-\u0362\u0374\u037e\u0387\u0591-\u05af\u05c4\u0610-\u0617\u0653-\u0654\u0657-\u065b\u065d-\u065e\u06df-\u06e2\u06eb-\u06ec\u0730\u0732-\u0733\u0735-\u0736\u073a\u073d\u073f-\u0741\u0743\u0745\u0747\u07eb-\u07f1\u0951\u0958-\u095f\u09dc-\u09dd\u09df\u0a33\u0a36\u0a59-\u0a5b\u0a5e\u0b5c-\u0b5d\u0e38-\u0e39\u0f43\u0f4d\u0f52\u0f57\u0f5c\u0f69\u0f72-\u0f76\u0f78\u0f80-\u0f83\u0f93\u0f9d\u0fa2\u0fa7\u0fac\u0fb9\u1939-\u193a\u1a17\u1b6b\u1cda-\u1cdb\u1dc0-\u1dcf\u1dfc\u1dfe\u1f71\u1f73\u1f75\u1f77\u1f79\u1f7b\u1f7d\u1fbb\u1fbe\u1fc9\u1fcb\u1fd3\u1fdb\u1fe3\u1feb\u1fee-\u1fef\u1ff9\u1ffb\u1ffd\u2000-\u2001\u20d0-\u20d1\u20d4-\u20d7\u20e7-\u20e9\u2126\u212a-\u212b\u2329-\u232a\u2adc\u302b-\u302c\uaab2-\uaab3\uf900-\ufa0d\ufa10\ufa12\ufa15-\ufa1e\ufa20\ufa22\ufa25-\ufa26\ufa2a-\ufa2d\ufa30-\ufa6d\ufa70-\ufad9\ufb1d\ufb1f\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufb4e\ufff0-\uffff]/g
  , extraLookup;

// This may be quite slow, so let's delay until user actually uses bad
// characters.
var unrollLookup = function(escapable) {
  var i;
  var unrolled = {};
  var c = [];
  for (i = 0; i < 65536; i++) {
    c.push( String.fromCharCode(i) );
  }
  escapable.lastIndex = 0;
  c.join('').replace(escapable, function(a) {
    unrolled[ a ] = '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
    return '';
  });
  escapable.lastIndex = 0;
  return unrolled;
};

// Quote string, also taking care of unicode characters that browsers
// often break. Especially, take care of unicode surrogates:
// http://en.wikipedia.org/wiki/Mapping_of_Unicode_characters#Surrogates
module.exports = {
  quote: function(string) {
    var quoted = JSON3.stringify(string);

    // In most cases this should be very fast and good enough.
    extraEscapable.lastIndex = 0;
    if (!extraEscapable.test(quoted)) {
      return quoted;
    }

    if (!extraLookup) {
      extraLookup = unrollLookup(extraEscapable);
    }

    return quoted.replace(extraEscapable, function(a) {
      return extraLookup[a];
    });
  }
};

},{"json3":57}],46:[function(require,module,exports){
(function (global){
'use strict';

var random = require('./random');

var onUnload = {}
  , afterUnload = false
    // detect google chrome packaged apps because they don't allow the 'unload' event
  , isChromePackagedApp = global.chrome && global.chrome.app && global.chrome.app.runtime
  ;

module.exports = {
  attachEvent: function(event, listener) {
    if (typeof global.addEventListener !== 'undefined') {
      global.addEventListener(event, listener, false);
    } else if (global.document && global.attachEvent) {
      // IE quirks.
      // According to: http://stevesouders.com/misc/test-postmessage.php
      // the message gets delivered only to 'document', not 'window'.
      global.document.attachEvent('on' + event, listener);
      // I get 'window' for ie8.
      global.attachEvent('on' + event, listener);
    }
  }

, detachEvent: function(event, listener) {
    if (typeof global.addEventListener !== 'undefined') {
      global.removeEventListener(event, listener, false);
    } else if (global.document && global.detachEvent) {
      global.document.detachEvent('on' + event, listener);
      global.detachEvent('on' + event, listener);
    }
  }

, unloadAdd: function(listener) {
    if (isChromePackagedApp) {
      return null;
    }

    var ref = random.string(8);
    onUnload[ref] = listener;
    if (afterUnload) {
      setTimeout(this.triggerUnloadCallbacks, 0);
    }
    return ref;
  }

, unloadDel: function(ref) {
    if (ref in onUnload) {
      delete onUnload[ref];
    }
  }

, triggerUnloadCallbacks: function() {
    for (var ref in onUnload) {
      onUnload[ref]();
      delete onUnload[ref];
    }
  }
};

var unloadTriggered = function() {
  if (afterUnload) {
    return;
  }
  afterUnload = true;
  module.exports.triggerUnloadCallbacks();
};

// 'unload' alone is not reliable in opera within an iframe, but we
// can't use `beforeunload` as IE fires it on javascript: links.
if (!isChromePackagedApp) {
  module.exports.attachEvent('unload', unloadTriggered);
}

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./random":50}],47:[function(require,module,exports){
(function (process,global){
'use strict';

var eventUtils = require('./event')
  , JSON3 = require('json3')
  , browser = require('./browser')
  ;

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:utils:iframe');
}

module.exports = {
  WPrefix: '_jp'
, currentWindowId: null

, polluteGlobalNamespace: function() {
    if (!(module.exports.WPrefix in global)) {
      global[module.exports.WPrefix] = {};
    }
  }

, postMessage: function(type, data) {
    if (global.parent !== global) {
      global.parent.postMessage(JSON3.stringify({
        windowId: module.exports.currentWindowId
      , type: type
      , data: data || ''
      }), '*');
    } else {
      debug('Cannot postMessage, no parent window.', type, data);
    }
  }

, createIframe: function(iframeUrl, errorCallback) {
    var iframe = global.document.createElement('iframe');
    var tref, unloadRef;
    var unattach = function() {
      debug('unattach');
      clearTimeout(tref);
      // Explorer had problems with that.
      try {
        iframe.onload = null;
      } catch (x) {
        // intentionally empty
      }
      iframe.onerror = null;
    };
    var cleanup = function() {
      debug('cleanup');
      if (iframe) {
        unattach();
        // This timeout makes chrome fire onbeforeunload event
        // within iframe. Without the timeout it goes straight to
        // onunload.
        setTimeout(function() {
          if (iframe) {
            iframe.parentNode.removeChild(iframe);
          }
          iframe = null;
        }, 0);
        eventUtils.unloadDel(unloadRef);
      }
    };
    var onerror = function(err) {
      debug('onerror', err);
      if (iframe) {
        cleanup();
        errorCallback(err);
      }
    };
    var post = function(msg, origin) {
      debug('post', msg, origin);
      setTimeout(function() {
        try {
          // When the iframe is not loaded, IE raises an exception
          // on 'contentWindow'.
          if (iframe && iframe.contentWindow) {
            iframe.contentWindow.postMessage(msg, origin);
          }
        } catch (x) {
          // intentionally empty
        }
      }, 0);
    };

    iframe.src = iframeUrl;
    iframe.style.display = 'none';
    iframe.style.position = 'absolute';
    iframe.onerror = function() {
      onerror('onerror');
    };
    iframe.onload = function() {
      debug('onload');
      // `onload` is triggered before scripts on the iframe are
      // executed. Give it few seconds to actually load stuff.
      clearTimeout(tref);
      tref = setTimeout(function() {
        onerror('onload timeout');
      }, 2000);
    };
    global.document.body.appendChild(iframe);
    tref = setTimeout(function() {
      onerror('timeout');
    }, 15000);
    unloadRef = eventUtils.unloadAdd(cleanup);
    return {
      post: post
    , cleanup: cleanup
    , loaded: unattach
    };
  }

/* eslint no-undef: "off", new-cap: "off" */
, createHtmlfile: function(iframeUrl, errorCallback) {
    var axo = ['Active'].concat('Object').join('X');
    var doc = new global[axo]('htmlfile');
    var tref, unloadRef;
    var iframe;
    var unattach = function() {
      clearTimeout(tref);
      iframe.onerror = null;
    };
    var cleanup = function() {
      if (doc) {
        unattach();
        eventUtils.unloadDel(unloadRef);
        iframe.parentNode.removeChild(iframe);
        iframe = doc = null;
        CollectGarbage();
      }
    };
    var onerror = function(r) {
      debug('onerror', r);
      if (doc) {
        cleanup();
        errorCallback(r);
      }
    };
    var post = function(msg, origin) {
      try {
        // When the iframe is not loaded, IE raises an exception
        // on 'contentWindow'.
        setTimeout(function() {
          if (iframe && iframe.contentWindow) {
              iframe.contentWindow.postMessage(msg, origin);
          }
        }, 0);
      } catch (x) {
        // intentionally empty
      }
    };

    doc.open();
    doc.write('<html><s' + 'cript>' +
              'document.domain="' + global.document.domain + '";' +
              '</s' + 'cript></html>');
    doc.close();
    doc.parentWindow[module.exports.WPrefix] = global[module.exports.WPrefix];
    var c = doc.createElement('div');
    doc.body.appendChild(c);
    iframe = doc.createElement('iframe');
    c.appendChild(iframe);
    iframe.src = iframeUrl;
    iframe.onerror = function() {
      onerror('onerror');
    };
    tref = setTimeout(function() {
      onerror('timeout');
    }, 15000);
    unloadRef = eventUtils.unloadAdd(cleanup);
    return {
      post: post
    , cleanup: cleanup
    , loaded: unattach
    };
  }
};

module.exports.iframeEnabled = false;
if (global.document) {
  // postMessage misbehaves in konqueror 4.6.5 - the messages are delivered with
  // huge delay, or not at all.
  module.exports.iframeEnabled = (typeof global.postMessage === 'function' ||
    typeof global.postMessage === 'object') && (!browser.isKonqueror());
}

}).call(this,{ env: {} },typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"./browser":44,"./event":46,"debug":54,"json3":57}],48:[function(require,module,exports){
(function (global){
'use strict';

var logObject = {};
['log', 'debug', 'warn'].forEach(function (level) {
  var levelExists;

  try {
    levelExists = global.console && global.console[level] && global.console[level].apply;
  } catch(e) {
    // do nothing
  }

  logObject[level] = levelExists ? function () {
    return global.console[level].apply(global.console, arguments);
  } : (level === 'log' ? function () {} : logObject.log);
});

module.exports = logObject;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],49:[function(require,module,exports){
'use strict';

module.exports = {
  isObject: function(obj) {
    var type = typeof obj;
    return type === 'function' || type === 'object' && !!obj;
  }

, extend: function(obj) {
    if (!this.isObject(obj)) {
      return obj;
    }
    var source, prop;
    for (var i = 1, length = arguments.length; i < length; i++) {
      source = arguments[i];
      for (prop in source) {
        if (Object.prototype.hasOwnProperty.call(source, prop)) {
          obj[prop] = source[prop];
        }
      }
    }
    return obj;
  }
};

},{}],50:[function(require,module,exports){
'use strict';

/* global crypto:true */
var crypto = require('crypto');

// This string has length 32, a power of 2, so the modulus doesn't introduce a
// bias.
var _randomStringChars = 'abcdefghijklmnopqrstuvwxyz012345';
module.exports = {
  string: function(length) {
    var max = _randomStringChars.length;
    var bytes = crypto.randomBytes(length);
    var ret = [];
    for (var i = 0; i < length; i++) {
      ret.push(_randomStringChars.substr(bytes[i] % max, 1));
    }
    return ret.join('');
  }

, number: function(max) {
    return Math.floor(Math.random() * max);
  }

, numberString: function(max) {
    var t = ('' + (max - 1)).length;
    var p = new Array(t + 1).join('0');
    return (p + this.number(max)).slice(-t);
  }
};

},{"crypto":43}],51:[function(require,module,exports){
(function (process){
'use strict';

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:utils:transport');
}

module.exports = function(availableTransports) {
  return {
    filterToEnabled: function(transportsWhitelist, info) {
      var transports = {
        main: []
      , facade: []
      };
      if (!transportsWhitelist) {
        transportsWhitelist = [];
      } else if (typeof transportsWhitelist === 'string') {
        transportsWhitelist = [transportsWhitelist];
      }

      availableTransports.forEach(function(trans) {
        if (!trans) {
          return;
        }

        if (trans.transportName === 'websocket' && info.websocket === false) {
          debug('disabled from server', 'websocket');
          return;
        }

        if (transportsWhitelist.length &&
            transportsWhitelist.indexOf(trans.transportName) === -1) {
          debug('not in whitelist', trans.transportName);
          return;
        }

        if (trans.enabled(info)) {
          debug('enabled', trans.transportName);
          transports.main.push(trans);
          if (trans.facadeTransport) {
            transports.facade.push(trans.facadeTransport);
          }
        } else {
          debug('disabled', trans.transportName);
        }
      });
      return transports;
    }
  };
};

}).call(this,{ env: {} })

},{"debug":54}],52:[function(require,module,exports){
(function (process){
'use strict';

var URL = require('url-parse');

var debug = function() {};
if (process.env.NODE_ENV !== 'production') {
  debug = require('debug')('sockjs-client:utils:url');
}

module.exports = {
  getOrigin: function(url) {
    if (!url) {
      return null;
    }

    var p = new URL(url);
    if (p.protocol === 'file:') {
      return null;
    }

    var port = p.port;
    if (!port) {
      port = (p.protocol === 'https:') ? '443' : '80';
    }

    return p.protocol + '//' + p.hostname + ':' + port;
  }

, isOriginEqual: function(a, b) {
    var res = this.getOrigin(a) === this.getOrigin(b);
    debug('same', a, b, res);
    return res;
  }

, isSchemeEqual: function(a, b) {
    return (a.split(':')[0] === b.split(':')[0]);
  }

, addPath: function (url, path) {
    var qs = url.split('?');
    return qs[0] + path + (qs[1] ? '?' + qs[1] : '');
  }

, addQuery: function (url, q) {
    return url + (url.indexOf('?') === -1 ? ('?' + q) : ('&' + q));
  }
};

}).call(this,{ env: {} })

},{"debug":54,"url-parse":61}],53:[function(require,module,exports){
module.exports = '1.1.5';

},{}],54:[function(require,module,exports){
(function (process){
/**
 * This is the web browser implementation of `debug()`.
 *
 * Expose `debug()` as the module.
 */

exports = module.exports = require('./debug');
exports.log = log;
exports.formatArgs = formatArgs;
exports.save = save;
exports.load = load;
exports.useColors = useColors;
exports.storage = 'undefined' != typeof chrome
               && 'undefined' != typeof chrome.storage
                  ? chrome.storage.local
                  : localstorage();

/**
 * Colors.
 */

exports.colors = [
  'lightseagreen',
  'forestgreen',
  'goldenrod',
  'dodgerblue',
  'darkorchid',
  'crimson'
];

/**
 * Currently only WebKit-based Web Inspectors, Firefox >= v31,
 * and the Firebug extension (any Firefox version) are known
 * to support "%c" CSS customizations.
 *
 * TODO: add a `localStorage` variable to explicitly enable/disable colors
 */

function useColors() {
  // NB: In an Electron preload script, document will be defined but not fully
  // initialized. Since we know we're in Chrome, we'll just detect this case
  // explicitly
  if (typeof window !== 'undefined' && window.process && window.process.type === 'renderer') {
    return true;
  }

  // is webkit? http://stackoverflow.com/a/16459606/376773
  // document is undefined in react-native: https://github.com/facebook/react-native/pull/1632
  return (typeof document !== 'undefined' && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance) ||
    // is firebug? http://stackoverflow.com/a/398120/376773
    (typeof window !== 'undefined' && window.console && (window.console.firebug || (window.console.exception && window.console.table))) ||
    // is firefox >= v31?
    // https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
    (typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31) ||
    // double check webkit in userAgent just in case we are in a worker
    (typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/));
}

/**
 * Map %j to `JSON.stringify()`, since no Web Inspectors do that by default.
 */

exports.formatters.j = function(v) {
  try {
    return JSON.stringify(v);
  } catch (err) {
    return '[UnexpectedJSONParseError]: ' + err.message;
  }
};


/**
 * Colorize log arguments if enabled.
 *
 * @api public
 */

function formatArgs(args) {
  var useColors = this.useColors;

  args[0] = (useColors ? '%c' : '')
    + this.namespace
    + (useColors ? ' %c' : ' ')
    + args[0]
    + (useColors ? '%c ' : ' ')
    + '+' + exports.humanize(this.diff);

  if (!useColors) return;

  var c = 'color: ' + this.color;
  args.splice(1, 0, c, 'color: inherit')

  // the final "%c" is somewhat tricky, because there could be other
  // arguments passed either before or after the %c, so we need to
  // figure out the correct index to insert the CSS into
  var index = 0;
  var lastC = 0;
  args[0].replace(/%[a-zA-Z%]/g, function(match) {
    if ('%%' === match) return;
    index++;
    if ('%c' === match) {
      // we only are interested in the *last* %c
      // (the user may have provided their own)
      lastC = index;
    }
  });

  args.splice(lastC, 0, c);
}

/**
 * Invokes `console.log()` when available.
 * No-op when `console.log` is not a "function".
 *
 * @api public
 */

function log() {
  // this hackery is required for IE8/9, where
  // the `console.log` function doesn't have 'apply'
  return 'object' === typeof console
    && console.log
    && Function.prototype.apply.call(console.log, console, arguments);
}

/**
 * Save `namespaces`.
 *
 * @param {String} namespaces
 * @api private
 */

function save(namespaces) {
  try {
    if (null == namespaces) {
      exports.storage.removeItem('debug');
    } else {
      exports.storage.debug = namespaces;
    }
  } catch(e) {}
}

/**
 * Load `namespaces`.
 *
 * @return {String} returns the previously persisted debug modes
 * @api private
 */

function load() {
  var r;
  try {
    r = exports.storage.debug;
  } catch(e) {}

  // If debug isn't set in LS, and we're in Electron, try to load $DEBUG
  if (!r && typeof process !== 'undefined' && 'env' in process) {
    r = process.env.DEBUG;
  }

  return r;
}

/**
 * Enable namespaces listed in `localStorage.debug` initially.
 */

exports.enable(load());

/**
 * Localstorage attempts to return the localstorage.
 *
 * This is necessary because safari throws
 * when a user disables cookies/localstorage
 * and you attempt to access it.
 *
 * @return {LocalStorage}
 * @api private
 */

function localstorage() {
  try {
    return window.localStorage;
  } catch (e) {}
}

}).call(this,{ env: {} })

},{"./debug":55}],55:[function(require,module,exports){

/**
 * This is the common logic for both the Node.js and web browser
 * implementations of `debug()`.
 *
 * Expose `debug()` as the module.
 */

exports = module.exports = createDebug.debug = createDebug['default'] = createDebug;
exports.coerce = coerce;
exports.disable = disable;
exports.enable = enable;
exports.enabled = enabled;
exports.humanize = require('ms');

/**
 * The currently active debug mode names, and names to skip.
 */

exports.names = [];
exports.skips = [];

/**
 * Map of special "%n" handling functions, for the debug "format" argument.
 *
 * Valid key names are a single, lower or upper-case letter, i.e. "n" and "N".
 */

exports.formatters = {};

/**
 * Previous log timestamp.
 */

var prevTime;

/**
 * Select a color.
 * @param {String} namespace
 * @return {Number}
 * @api private
 */

function selectColor(namespace) {
  var hash = 0, i;

  for (i in namespace) {
    hash  = ((hash << 5) - hash) + namespace.charCodeAt(i);
    hash |= 0; // Convert to 32bit integer
  }

  return exports.colors[Math.abs(hash) % exports.colors.length];
}

/**
 * Create a debugger with the given `namespace`.
 *
 * @param {String} namespace
 * @return {Function}
 * @api public
 */

function createDebug(namespace) {

  function debug() {
    // disabled?
    if (!debug.enabled) return;

    var self = debug;

    // set `diff` timestamp
    var curr = +new Date();
    var ms = curr - (prevTime || curr);
    self.diff = ms;
    self.prev = prevTime;
    self.curr = curr;
    prevTime = curr;

    // turn the `arguments` into a proper Array
    var args = new Array(arguments.length);
    for (var i = 0; i < args.length; i++) {
      args[i] = arguments[i];
    }

    args[0] = exports.coerce(args[0]);

    if ('string' !== typeof args[0]) {
      // anything else let's inspect with %O
      args.unshift('%O');
    }

    // apply any `formatters` transformations
    var index = 0;
    args[0] = args[0].replace(/%([a-zA-Z%])/g, function(match, format) {
      // if we encounter an escaped % then don't increase the array index
      if (match === '%%') return match;
      index++;
      var formatter = exports.formatters[format];
      if ('function' === typeof formatter) {
        var val = args[index];
        match = formatter.call(self, val);

        // now we need to remove `args[index]` since it's inlined in the `format`
        args.splice(index, 1);
        index--;
      }
      return match;
    });

    // apply env-specific formatting (colors, etc.)
    exports.formatArgs.call(self, args);

    var logFn = debug.log || exports.log || console.log.bind(console);
    logFn.apply(self, args);
  }

  debug.namespace = namespace;
  debug.enabled = exports.enabled(namespace);
  debug.useColors = exports.useColors();
  debug.color = selectColor(namespace);

  // env-specific initialization logic for debug instances
  if ('function' === typeof exports.init) {
    exports.init(debug);
  }

  return debug;
}

/**
 * Enables a debug mode by namespaces. This can include modes
 * separated by a colon and wildcards.
 *
 * @param {String} namespaces
 * @api public
 */

function enable(namespaces) {
  exports.save(namespaces);

  exports.names = [];
  exports.skips = [];

  var split = (typeof namespaces === 'string' ? namespaces : '').split(/[\s,]+/);
  var len = split.length;

  for (var i = 0; i < len; i++) {
    if (!split[i]) continue; // ignore empty strings
    namespaces = split[i].replace(/\*/g, '.*?');
    if (namespaces[0] === '-') {
      exports.skips.push(new RegExp('^' + namespaces.substr(1) + '$'));
    } else {
      exports.names.push(new RegExp('^' + namespaces + '$'));
    }
  }
}

/**
 * Disable debug output.
 *
 * @api public
 */

function disable() {
  exports.enable('');
}

/**
 * Returns true if the given mode name is enabled, false otherwise.
 *
 * @param {String} name
 * @return {Boolean}
 * @api public
 */

function enabled(name) {
  var i, len;
  for (i = 0, len = exports.skips.length; i < len; i++) {
    if (exports.skips[i].test(name)) {
      return false;
    }
  }
  for (i = 0, len = exports.names.length; i < len; i++) {
    if (exports.names[i].test(name)) {
      return true;
    }
  }
  return false;
}

/**
 * Coerce `val`.
 *
 * @param {Mixed} val
 * @return {Mixed}
 * @api private
 */

function coerce(val) {
  if (val instanceof Error) return val.stack || val.message;
  return val;
}

},{"ms":58}],56:[function(require,module,exports){
if (typeof Object.create === 'function') {
  // implementation from standard node.js 'util' module
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    ctor.prototype = Object.create(superCtor.prototype, {
      constructor: {
        value: ctor,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
  };
} else {
  // old school shim for old browsers
  module.exports = function inherits(ctor, superCtor) {
    ctor.super_ = superCtor
    var TempCtor = function () {}
    TempCtor.prototype = superCtor.prototype
    ctor.prototype = new TempCtor()
    ctor.prototype.constructor = ctor
  }
}

},{}],57:[function(require,module,exports){
(function (global){
/*! JSON v3.3.2 | http://bestiejs.github.io/json3 | Copyright 2012-2014, Kit Cambridge | http://kit.mit-license.org */
;(function () {
  // Detect the `define` function exposed by asynchronous module loaders. The
  // strict `define` check is necessary for compatibility with `r.js`.
  var isLoader = typeof define === "function" && define.amd;

  // A set of types used to distinguish objects from primitives.
  var objectTypes = {
    "function": true,
    "object": true
  };

  // Detect the `exports` object exposed by CommonJS implementations.
  var freeExports = objectTypes[typeof exports] && exports && !exports.nodeType && exports;

  // Use the `global` object exposed by Node (including Browserify via
  // `insert-module-globals`), Narwhal, and Ringo as the default context,
  // and the `window` object in browsers. Rhino exports a `global` function
  // instead.
  var root = objectTypes[typeof window] && window || this,
      freeGlobal = freeExports && objectTypes[typeof module] && module && !module.nodeType && typeof global == "object" && global;

  if (freeGlobal && (freeGlobal["global"] === freeGlobal || freeGlobal["window"] === freeGlobal || freeGlobal["self"] === freeGlobal)) {
    root = freeGlobal;
  }

  // Public: Initializes JSON 3 using the given `context` object, attaching the
  // `stringify` and `parse` functions to the specified `exports` object.
  function runInContext(context, exports) {
    context || (context = root["Object"]());
    exports || (exports = root["Object"]());

    // Native constructor aliases.
    var Number = context["Number"] || root["Number"],
        String = context["String"] || root["String"],
        Object = context["Object"] || root["Object"],
        Date = context["Date"] || root["Date"],
        SyntaxError = context["SyntaxError"] || root["SyntaxError"],
        TypeError = context["TypeError"] || root["TypeError"],
        Math = context["Math"] || root["Math"],
        nativeJSON = context["JSON"] || root["JSON"];

    // Delegate to the native `stringify` and `parse` implementations.
    if (typeof nativeJSON == "object" && nativeJSON) {
      exports.stringify = nativeJSON.stringify;
      exports.parse = nativeJSON.parse;
    }

    // Convenience aliases.
    var objectProto = Object.prototype,
        getClass = objectProto.toString,
        isProperty, forEach, undef;

    // Test the `Date#getUTC*` methods. Based on work by @Yaffle.
    var isExtended = new Date(-3509827334573292);
    try {
      // The `getUTCFullYear`, `Month`, and `Date` methods return nonsensical
      // results for certain dates in Opera >= 10.53.
      isExtended = isExtended.getUTCFullYear() == -109252 && isExtended.getUTCMonth() === 0 && isExtended.getUTCDate() === 1 &&
        // Safari < 2.0.2 stores the internal millisecond time value correctly,
        // but clips the values returned by the date methods to the range of
        // signed 32-bit integers ([-2 ** 31, 2 ** 31 - 1]).
        isExtended.getUTCHours() == 10 && isExtended.getUTCMinutes() == 37 && isExtended.getUTCSeconds() == 6 && isExtended.getUTCMilliseconds() == 708;
    } catch (exception) {}

    // Internal: Determines whether the native `JSON.stringify` and `parse`
    // implementations are spec-compliant. Based on work by Ken Snyder.
    function has(name) {
      if (has[name] !== undef) {
        // Return cached feature test result.
        return has[name];
      }
      var isSupported;
      if (name == "bug-string-char-index") {
        // IE <= 7 doesn't support accessing string characters using square
        // bracket notation. IE 8 only supports this for primitives.
        isSupported = "a"[0] != "a";
      } else if (name == "json") {
        // Indicates whether both `JSON.stringify` and `JSON.parse` are
        // supported.
        isSupported = has("json-stringify") && has("json-parse");
      } else {
        var value, serialized = '{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';
        // Test `JSON.stringify`.
        if (name == "json-stringify") {
          var stringify = exports.stringify, stringifySupported = typeof stringify == "function" && isExtended;
          if (stringifySupported) {
            // A test function object with a custom `toJSON` method.
            (value = function () {
              return 1;
            }).toJSON = value;
            try {
              stringifySupported =
                // Firefox 3.1b1 and b2 serialize string, number, and boolean
                // primitives as object literals.
                stringify(0) === "0" &&
                // FF 3.1b1, b2, and JSON 2 serialize wrapped primitives as object
                // literals.
                stringify(new Number()) === "0" &&
                stringify(new String()) == '""' &&
                // FF 3.1b1, 2 throw an error if the value is `null`, `undefined`, or
                // does not define a canonical JSON representation (this applies to
                // objects with `toJSON` properties as well, *unless* they are nested
                // within an object or array).
                stringify(getClass) === undef &&
                // IE 8 serializes `undefined` as `"undefined"`. Safari <= 5.1.7 and
                // FF 3.1b3 pass this test.
                stringify(undef) === undef &&
                // Safari <= 5.1.7 and FF 3.1b3 throw `Error`s and `TypeError`s,
                // respectively, if the value is omitted entirely.
                stringify() === undef &&
                // FF 3.1b1, 2 throw an error if the given value is not a number,
                // string, array, object, Boolean, or `null` literal. This applies to
                // objects with custom `toJSON` methods as well, unless they are nested
                // inside object or array literals. YUI 3.0.0b1 ignores custom `toJSON`
                // methods entirely.
                stringify(value) === "1" &&
                stringify([value]) == "[1]" &&
                // Prototype <= 1.6.1 serializes `[undefined]` as `"[]"` instead of
                // `"[null]"`.
                stringify([undef]) == "[null]" &&
                // YUI 3.0.0b1 fails to serialize `null` literals.
                stringify(null) == "null" &&
                // FF 3.1b1, 2 halts serialization if an array contains a function:
                // `[1, true, getClass, 1]` serializes as "[1,true,],". FF 3.1b3
                // elides non-JSON values from objects and arrays, unless they
                // define custom `toJSON` methods.
                stringify([undef, getClass, null]) == "[null,null,null]" &&
                // Simple serialization test. FF 3.1b1 uses Unicode escape sequences
                // where character escape codes are expected (e.g., `\b` => `\u0008`).
                stringify({ "a": [value, true, false, null, "\x00\b\n\f\r\t"] }) == serialized &&
                // FF 3.1b1 and b2 ignore the `filter` and `width` arguments.
                stringify(null, value) === "1" &&
                stringify([1, 2], null, 1) == "[\n 1,\n 2\n]" &&
                // JSON 2, Prototype <= 1.7, and older WebKit builds incorrectly
                // serialize extended years.
                stringify(new Date(-8.64e15)) == '"-271821-04-20T00:00:00.000Z"' &&
                // The milliseconds are optional in ES 5, but required in 5.1.
                stringify(new Date(8.64e15)) == '"+275760-09-13T00:00:00.000Z"' &&
                // Firefox <= 11.0 incorrectly serializes years prior to 0 as negative
                // four-digit years instead of six-digit years. Credits: @Yaffle.
                stringify(new Date(-621987552e5)) == '"-000001-01-01T00:00:00.000Z"' &&
                // Safari <= 5.1.5 and Opera >= 10.53 incorrectly serialize millisecond
                // values less than 1000. Credits: @Yaffle.
                stringify(new Date(-1)) == '"1969-12-31T23:59:59.999Z"';
            } catch (exception) {
              stringifySupported = false;
            }
          }
          isSupported = stringifySupported;
        }
        // Test `JSON.parse`.
        if (name == "json-parse") {
          var parse = exports.parse;
          if (typeof parse == "function") {
            try {
              // FF 3.1b1, b2 will throw an exception if a bare literal is provided.
              // Conforming implementations should also coerce the initial argument to
              // a string prior to parsing.
              if (parse("0") === 0 && !parse(false)) {
                // Simple parsing test.
                value = parse(serialized);
                var parseSupported = value["a"].length == 5 && value["a"][0] === 1;
                if (parseSupported) {
                  try {
                    // Safari <= 5.1.2 and FF 3.1b1 allow unescaped tabs in strings.
                    parseSupported = !parse('"\t"');
                  } catch (exception) {}
                  if (parseSupported) {
                    try {
                      // FF 4.0 and 4.0.1 allow leading `+` signs and leading
                      // decimal points. FF 4.0, 4.0.1, and IE 9-10 also allow
                      // certain octal literals.
                      parseSupported = parse("01") !== 1;
                    } catch (exception) {}
                  }
                  if (parseSupported) {
                    try {
                      // FF 4.0, 4.0.1, and Rhino 1.7R3-R4 allow trailing decimal
                      // points. These environments, along with FF 3.1b1 and 2,
                      // also allow trailing commas in JSON objects and arrays.
                      parseSupported = parse("1.") !== 1;
                    } catch (exception) {}
                  }
                }
              }
            } catch (exception) {
              parseSupported = false;
            }
          }
          isSupported = parseSupported;
        }
      }
      return has[name] = !!isSupported;
    }

    if (!has("json")) {
      // Common `[[Class]]` name aliases.
      var functionClass = "[object Function]",
          dateClass = "[object Date]",
          numberClass = "[object Number]",
          stringClass = "[object String]",
          arrayClass = "[object Array]",
          booleanClass = "[object Boolean]";

      // Detect incomplete support for accessing string characters by index.
      var charIndexBuggy = has("bug-string-char-index");

      // Define additional utility methods if the `Date` methods are buggy.
      if (!isExtended) {
        var floor = Math.floor;
        // A mapping between the months of the year and the number of days between
        // January 1st and the first of the respective month.
        var Months = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
        // Internal: Calculates the number of days between the Unix epoch and the
        // first day of the given month.
        var getDay = function (year, month) {
          return Months[month] + 365 * (year - 1970) + floor((year - 1969 + (month = +(month > 1))) / 4) - floor((year - 1901 + month) / 100) + floor((year - 1601 + month) / 400);
        };
      }

      // Internal: Determines if a property is a direct property of the given
      // object. Delegates to the native `Object#hasOwnProperty` method.
      if (!(isProperty = objectProto.hasOwnProperty)) {
        isProperty = function (property) {
          var members = {}, constructor;
          if ((members.__proto__ = null, members.__proto__ = {
            // The *proto* property cannot be set multiple times in recent
            // versions of Firefox and SeaMonkey.
            "toString": 1
          }, members).toString != getClass) {
            // Safari <= 2.0.3 doesn't implement `Object#hasOwnProperty`, but
            // supports the mutable *proto* property.
            isProperty = function (property) {
              // Capture and break the object's prototype chain (see section 8.6.2
              // of the ES 5.1 spec). The parenthesized expression prevents an
              // unsafe transformation by the Closure Compiler.
              var original = this.__proto__, result = property in (this.__proto__ = null, this);
              // Restore the original prototype chain.
              this.__proto__ = original;
              return result;
            };
          } else {
            // Capture a reference to the top-level `Object` constructor.
            constructor = members.constructor;
            // Use the `constructor` property to simulate `Object#hasOwnProperty` in
            // other environments.
            isProperty = function (property) {
              var parent = (this.constructor || constructor).prototype;
              return property in this && !(property in parent && this[property] === parent[property]);
            };
          }
          members = null;
          return isProperty.call(this, property);
        };
      }

      // Internal: Normalizes the `for...in` iteration algorithm across
      // environments. Each enumerated key is yielded to a `callback` function.
      forEach = function (object, callback) {
        var size = 0, Properties, members, property;

        // Tests for bugs in the current environment's `for...in` algorithm. The
        // `valueOf` property inherits the non-enumerable flag from
        // `Object.prototype` in older versions of IE, Netscape, and Mozilla.
        (Properties = function () {
          this.valueOf = 0;
        }).prototype.valueOf = 0;

        // Iterate over a new instance of the `Properties` class.
        members = new Properties();
        for (property in members) {
          // Ignore all properties inherited from `Object.prototype`.
          if (isProperty.call(members, property)) {
            size++;
          }
        }
        Properties = members = null;

        // Normalize the iteration algorithm.
        if (!size) {
          // A list of non-enumerable properties inherited from `Object.prototype`.
          members = ["valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor"];
          // IE <= 8, Mozilla 1.0, and Netscape 6.2 ignore shadowed non-enumerable
          // properties.
          forEach = function (object, callback) {
            var isFunction = getClass.call(object) == functionClass, property, length;
            var hasProperty = !isFunction && typeof object.constructor != "function" && objectTypes[typeof object.hasOwnProperty] && object.hasOwnProperty || isProperty;
            for (property in object) {
              // Gecko <= 1.0 enumerates the `prototype` property of functions under
              // certain conditions; IE does not.
              if (!(isFunction && property == "prototype") && hasProperty.call(object, property)) {
                callback(property);
              }
            }
            // Manually invoke the callback for each non-enumerable property.
            for (length = members.length; property = members[--length]; hasProperty.call(object, property) && callback(property));
          };
        } else if (size == 2) {
          // Safari <= 2.0.4 enumerates shadowed properties twice.
          forEach = function (object, callback) {
            // Create a set of iterated properties.
            var members = {}, isFunction = getClass.call(object) == functionClass, property;
            for (property in object) {
              // Store each property name to prevent double enumeration. The
              // `prototype` property of functions is not enumerated due to cross-
              // environment inconsistencies.
              if (!(isFunction && property == "prototype") && !isProperty.call(members, property) && (members[property] = 1) && isProperty.call(object, property)) {
                callback(property);
              }
            }
          };
        } else {
          // No bugs detected; use the standard `for...in` algorithm.
          forEach = function (object, callback) {
            var isFunction = getClass.call(object) == functionClass, property, isConstructor;
            for (property in object) {
              if (!(isFunction && property == "prototype") && isProperty.call(object, property) && !(isConstructor = property === "constructor")) {
                callback(property);
              }
            }
            // Manually invoke the callback for the `constructor` property due to
            // cross-environment inconsistencies.
            if (isConstructor || isProperty.call(object, (property = "constructor"))) {
              callback(property);
            }
          };
        }
        return forEach(object, callback);
      };

      // Public: Serializes a JavaScript `value` as a JSON string. The optional
      // `filter` argument may specify either a function that alters how object and
      // array members are serialized, or an array of strings and numbers that
      // indicates which properties should be serialized. The optional `width`
      // argument may be either a string or number that specifies the indentation
      // level of the output.
      if (!has("json-stringify")) {
        // Internal: A map of control characters and their escaped equivalents.
        var Escapes = {
          92: "\\\\",
          34: '\\"',
          8: "\\b",
          12: "\\f",
          10: "\\n",
          13: "\\r",
          9: "\\t"
        };

        // Internal: Converts `value` into a zero-padded string such that its
        // length is at least equal to `width`. The `width` must be <= 6.
        var leadingZeroes = "000000";
        var toPaddedString = function (width, value) {
          // The `|| 0` expression is necessary to work around a bug in
          // Opera <= 7.54u2 where `0 == -0`, but `String(-0) !== "0"`.
          return (leadingZeroes + (value || 0)).slice(-width);
        };

        // Internal: Double-quotes a string `value`, replacing all ASCII control
        // characters (characters with code unit values between 0 and 31) with
        // their escaped equivalents. This is an implementation of the
        // `Quote(value)` operation defined in ES 5.1 section 15.12.3.
        var unicodePrefix = "\\u00";
        var quote = function (value) {
          var result = '"', index = 0, length = value.length, useCharIndex = !charIndexBuggy || length > 10;
          var symbols = useCharIndex && (charIndexBuggy ? value.split("") : value);
          for (; index < length; index++) {
            var charCode = value.charCodeAt(index);
            // If the character is a control character, append its Unicode or
            // shorthand escape sequence; otherwise, append the character as-is.
            switch (charCode) {
              case 8: case 9: case 10: case 12: case 13: case 34: case 92:
                result += Escapes[charCode];
                break;
              default:
                if (charCode < 32) {
                  result += unicodePrefix + toPaddedString(2, charCode.toString(16));
                  break;
                }
                result += useCharIndex ? symbols[index] : value.charAt(index);
            }
          }
          return result + '"';
        };

        // Internal: Recursively serializes an object. Implements the
        // `Str(key, holder)`, `JO(value)`, and `JA(value)` operations.
        var serialize = function (property, object, callback, properties, whitespace, indentation, stack) {
          var value, className, year, month, date, time, hours, minutes, seconds, milliseconds, results, element, index, length, prefix, result;
          try {
            // Necessary for host object support.
            value = object[property];
          } catch (exception) {}
          if (typeof value == "object" && value) {
            className = getClass.call(value);
            if (className == dateClass && !isProperty.call(value, "toJSON")) {
              if (value > -1 / 0 && value < 1 / 0) {
                // Dates are serialized according to the `Date#toJSON` method
                // specified in ES 5.1 section 15.9.5.44. See section 15.9.1.15
                // for the ISO 8601 date time string format.
                if (getDay) {
                  // Manually compute the year, month, date, hours, minutes,
                  // seconds, and milliseconds if the `getUTC*` methods are
                  // buggy. Adapted from @Yaffle's `date-shim` project.
                  date = floor(value / 864e5);
                  for (year = floor(date / 365.2425) + 1970 - 1; getDay(year + 1, 0) <= date; year++);
                  for (month = floor((date - getDay(year, 0)) / 30.42); getDay(year, month + 1) <= date; month++);
                  date = 1 + date - getDay(year, month);
                  // The `time` value specifies the time within the day (see ES
                  // 5.1 section 15.9.1.2). The formula `(A % B + B) % B` is used
                  // to compute `A modulo B`, as the `%` operator does not
                  // correspond to the `modulo` operation for negative numbers.
                  time = (value % 864e5 + 864e5) % 864e5;
                  // The hours, minutes, seconds, and milliseconds are obtained by
                  // decomposing the time within the day. See section 15.9.1.10.
                  hours = floor(time / 36e5) % 24;
                  minutes = floor(time / 6e4) % 60;
                  seconds = floor(time / 1e3) % 60;
                  milliseconds = time % 1e3;
                } else {
                  year = value.getUTCFullYear();
                  month = value.getUTCMonth();
                  date = value.getUTCDate();
                  hours = value.getUTCHours();
                  minutes = value.getUTCMinutes();
                  seconds = value.getUTCSeconds();
                  milliseconds = value.getUTCMilliseconds();
                }
                // Serialize extended years correctly.
                value = (year <= 0 || year >= 1e4 ? (year < 0 ? "-" : "+") + toPaddedString(6, year < 0 ? -year : year) : toPaddedString(4, year)) +
                  "-" + toPaddedString(2, month + 1) + "-" + toPaddedString(2, date) +
                  // Months, dates, hours, minutes, and seconds should have two
                  // digits; milliseconds should have three.
                  "T" + toPaddedString(2, hours) + ":" + toPaddedString(2, minutes) + ":" + toPaddedString(2, seconds) +
                  // Milliseconds are optional in ES 5.0, but required in 5.1.
                  "." + toPaddedString(3, milliseconds) + "Z";
              } else {
                value = null;
              }
            } else if (typeof value.toJSON == "function" && ((className != numberClass && className != stringClass && className != arrayClass) || isProperty.call(value, "toJSON"))) {
              // Prototype <= 1.6.1 adds non-standard `toJSON` methods to the
              // `Number`, `String`, `Date`, and `Array` prototypes. JSON 3
              // ignores all `toJSON` methods on these objects unless they are
              // defined directly on an instance.
              value = value.toJSON(property);
            }
          }
          if (callback) {
            // If a replacement function was provided, call it to obtain the value
            // for serialization.
            value = callback.call(object, property, value);
          }
          if (value === null) {
            return "null";
          }
          className = getClass.call(value);
          if (className == booleanClass) {
            // Booleans are represented literally.
            return "" + value;
          } else if (className == numberClass) {
            // JSON numbers must be finite. `Infinity` and `NaN` are serialized as
            // `"null"`.
            return value > -1 / 0 && value < 1 / 0 ? "" + value : "null";
          } else if (className == stringClass) {
            // Strings are double-quoted and escaped.
            return quote("" + value);
          }
          // Recursively serialize objects and arrays.
          if (typeof value == "object") {
            // Check for cyclic structures. This is a linear search; performance
            // is inversely proportional to the number of unique nested objects.
            for (length = stack.length; length--;) {
              if (stack[length] === value) {
                // Cyclic structures cannot be serialized by `JSON.stringify`.
                throw TypeError();
              }
            }
            // Add the object to the stack of traversed objects.
            stack.push(value);
            results = [];
            // Save the current indentation level and indent one additional level.
            prefix = indentation;
            indentation += whitespace;
            if (className == arrayClass) {
              // Recursively serialize array elements.
              for (index = 0, length = value.length; index < length; index++) {
                element = serialize(index, value, callback, properties, whitespace, indentation, stack);
                results.push(element === undef ? "null" : element);
              }
              result = results.length ? (whitespace ? "[\n" + indentation + results.join(",\n" + indentation) + "\n" + prefix + "]" : ("[" + results.join(",") + "]")) : "[]";
            } else {
              // Recursively serialize object members. Members are selected from
              // either a user-specified list of property names, or the object
              // itself.
              forEach(properties || value, function (property) {
                var element = serialize(property, value, callback, properties, whitespace, indentation, stack);
                if (element !== undef) {
                  // According to ES 5.1 section 15.12.3: "If `gap` {whitespace}
                  // is not the empty string, let `member` {quote(property) + ":"}
                  // be the concatenation of `member` and the `space` character."
                  // The "`space` character" refers to the literal space
                  // character, not the `space` {width} argument provided to
                  // `JSON.stringify`.
                  results.push(quote(property) + ":" + (whitespace ? " " : "") + element);
                }
              });
              result = results.length ? (whitespace ? "{\n" + indentation + results.join(",\n" + indentation) + "\n" + prefix + "}" : ("{" + results.join(",") + "}")) : "{}";
            }
            // Remove the object from the traversed object stack.
            stack.pop();
            return result;
          }
        };

        // Public: `JSON.stringify`. See ES 5.1 section 15.12.3.
        exports.stringify = function (source, filter, width) {
          var whitespace, callback, properties, className;
          if (objectTypes[typeof filter] && filter) {
            if ((className = getClass.call(filter)) == functionClass) {
              callback = filter;
            } else if (className == arrayClass) {
              // Convert the property names array into a makeshift set.
              properties = {};
              for (var index = 0, length = filter.length, value; index < length; value = filter[index++], ((className = getClass.call(value)), className == stringClass || className == numberClass) && (properties[value] = 1));
            }
          }
          if (width) {
            if ((className = getClass.call(width)) == numberClass) {
              // Convert the `width` to an integer and create a string containing
              // `width` number of space characters.
              if ((width -= width % 1) > 0) {
                for (whitespace = "", width > 10 && (width = 10); whitespace.length < width; whitespace += " ");
              }
            } else if (className == stringClass) {
              whitespace = width.length <= 10 ? width : width.slice(0, 10);
            }
          }
          // Opera <= 7.54u2 discards the values associated with empty string keys
          // (`""`) only if they are used directly within an object member list
          // (e.g., `!("" in { "": 1})`).
          return serialize("", (value = {}, value[""] = source, value), callback, properties, whitespace, "", []);
        };
      }

      // Public: Parses a JSON source string.
      if (!has("json-parse")) {
        var fromCharCode = String.fromCharCode;

        // Internal: A map of escaped control characters and their unescaped
        // equivalents.
        var Unescapes = {
          92: "\\",
          34: '"',
          47: "/",
          98: "\b",
          116: "\t",
          110: "\n",
          102: "\f",
          114: "\r"
        };

        // Internal: Stores the parser state.
        var Index, Source;

        // Internal: Resets the parser state and throws a `SyntaxError`.
        var abort = function () {
          Index = Source = null;
          throw SyntaxError();
        };

        // Internal: Returns the next token, or `"$"` if the parser has reached
        // the end of the source string. A token may be a string, number, `null`
        // literal, or Boolean literal.
        var lex = function () {
          var source = Source, length = source.length, value, begin, position, isSigned, charCode;
          while (Index < length) {
            charCode = source.charCodeAt(Index);
            switch (charCode) {
              case 9: case 10: case 13: case 32:
                // Skip whitespace tokens, including tabs, carriage returns, line
                // feeds, and space characters.
                Index++;
                break;
              case 123: case 125: case 91: case 93: case 58: case 44:
                // Parse a punctuator token (`{`, `}`, `[`, `]`, `:`, or `,`) at
                // the current position.
                value = charIndexBuggy ? source.charAt(Index) : source[Index];
                Index++;
                return value;
              case 34:
                // `"` delimits a JSON string; advance to the next character and
                // begin parsing the string. String tokens are prefixed with the
                // sentinel `@` character to distinguish them from punctuators and
                // end-of-string tokens.
                for (value = "@", Index++; Index < length;) {
                  charCode = source.charCodeAt(Index);
                  if (charCode < 32) {
                    // Unescaped ASCII control characters (those with a code unit
                    // less than the space character) are not permitted.
                    abort();
                  } else if (charCode == 92) {
                    // A reverse solidus (`\`) marks the beginning of an escaped
                    // control character (including `"`, `\`, and `/`) or Unicode
                    // escape sequence.
                    charCode = source.charCodeAt(++Index);
                    switch (charCode) {
                      case 92: case 34: case 47: case 98: case 116: case 110: case 102: case 114:
                        // Revive escaped control characters.
                        value += Unescapes[charCode];
                        Index++;
                        break;
                      case 117:
                        // `\u` marks the beginning of a Unicode escape sequence.
                        // Advance to the first character and validate the
                        // four-digit code point.
                        begin = ++Index;
                        for (position = Index + 4; Index < position; Index++) {
                          charCode = source.charCodeAt(Index);
                          // A valid sequence comprises four hexdigits (case-
                          // insensitive) that form a single hexadecimal value.
                          if (!(charCode >= 48 && charCode <= 57 || charCode >= 97 && charCode <= 102 || charCode >= 65 && charCode <= 70)) {
                            // Invalid Unicode escape sequence.
                            abort();
                          }
                        }
                        // Revive the escaped character.
                        value += fromCharCode("0x" + source.slice(begin, Index));
                        break;
                      default:
                        // Invalid escape sequence.
                        abort();
                    }
                  } else {
                    if (charCode == 34) {
                      // An unescaped double-quote character marks the end of the
                      // string.
                      break;
                    }
                    charCode = source.charCodeAt(Index);
                    begin = Index;
                    // Optimize for the common case where a string is valid.
                    while (charCode >= 32 && charCode != 92 && charCode != 34) {
                      charCode = source.charCodeAt(++Index);
                    }
                    // Append the string as-is.
                    value += source.slice(begin, Index);
                  }
                }
                if (source.charCodeAt(Index) == 34) {
                  // Advance to the next character and return the revived string.
                  Index++;
                  return value;
                }
                // Unterminated string.
                abort();
              default:
                // Parse numbers and literals.
                begin = Index;
                // Advance past the negative sign, if one is specified.
                if (charCode == 45) {
                  isSigned = true;
                  charCode = source.charCodeAt(++Index);
                }
                // Parse an integer or floating-point value.
                if (charCode >= 48 && charCode <= 57) {
                  // Leading zeroes are interpreted as octal literals.
                  if (charCode == 48 && ((charCode = source.charCodeAt(Index + 1)), charCode >= 48 && charCode <= 57)) {
                    // Illegal octal literal.
                    abort();
                  }
                  isSigned = false;
                  // Parse the integer component.
                  for (; Index < length && ((charCode = source.charCodeAt(Index)), charCode >= 48 && charCode <= 57); Index++);
                  // Floats cannot contain a leading decimal point; however, this
                  // case is already accounted for by the parser.
                  if (source.charCodeAt(Index) == 46) {
                    position = ++Index;
                    // Parse the decimal component.
                    for (; position < length && ((charCode = source.charCodeAt(position)), charCode >= 48 && charCode <= 57); position++);
                    if (position == Index) {
                      // Illegal trailing decimal.
                      abort();
                    }
                    Index = position;
                  }
                  // Parse exponents. The `e` denoting the exponent is
                  // case-insensitive.
                  charCode = source.charCodeAt(Index);
                  if (charCode == 101 || charCode == 69) {
                    charCode = source.charCodeAt(++Index);
                    // Skip past the sign following the exponent, if one is
                    // specified.
                    if (charCode == 43 || charCode == 45) {
                      Index++;
                    }
                    // Parse the exponential component.
                    for (position = Index; position < length && ((charCode = source.charCodeAt(position)), charCode >= 48 && charCode <= 57); position++);
                    if (position == Index) {
                      // Illegal empty exponent.
                      abort();
                    }
                    Index = position;
                  }
                  // Coerce the parsed value to a JavaScript number.
                  return +source.slice(begin, Index);
                }
                // A negative sign may only precede numbers.
                if (isSigned) {
                  abort();
                }
                // `true`, `false`, and `null` literals.
                if (source.slice(Index, Index + 4) == "true") {
                  Index += 4;
                  return true;
                } else if (source.slice(Index, Index + 5) == "false") {
                  Index += 5;
                  return false;
                } else if (source.slice(Index, Index + 4) == "null") {
                  Index += 4;
                  return null;
                }
                // Unrecognized token.
                abort();
            }
          }
          // Return the sentinel `$` character if the parser has reached the end
          // of the source string.
          return "$";
        };

        // Internal: Parses a JSON `value` token.
        var get = function (value) {
          var results, hasMembers;
          if (value == "$") {
            // Unexpected end of input.
            abort();
          }
          if (typeof value == "string") {
            if ((charIndexBuggy ? value.charAt(0) : value[0]) == "@") {
              // Remove the sentinel `@` character.
              return value.slice(1);
            }
            // Parse object and array literals.
            if (value == "[") {
              // Parses a JSON array, returning a new JavaScript array.
              results = [];
              for (;; hasMembers || (hasMembers = true)) {
                value = lex();
                // A closing square bracket marks the end of the array literal.
                if (value == "]") {
                  break;
                }
                // If the array literal contains elements, the current token
                // should be a comma separating the previous element from the
                // next.
                if (hasMembers) {
                  if (value == ",") {
                    value = lex();
                    if (value == "]") {
                      // Unexpected trailing `,` in array literal.
                      abort();
                    }
                  } else {
                    // A `,` must separate each array element.
                    abort();
                  }
                }
                // Elisions and leading commas are not permitted.
                if (value == ",") {
                  abort();
                }
                results.push(get(value));
              }
              return results;
            } else if (value == "{") {
              // Parses a JSON object, returning a new JavaScript object.
              results = {};
              for (;; hasMembers || (hasMembers = true)) {
                value = lex();
                // A closing curly brace marks the end of the object literal.
                if (value == "}") {
                  break;
                }
                // If the object literal contains members, the current token
                // should be a comma separator.
                if (hasMembers) {
                  if (value == ",") {
                    value = lex();
                    if (value == "}") {
                      // Unexpected trailing `,` in object literal.
                      abort();
                    }
                  } else {
                    // A `,` must separate each object member.
                    abort();
                  }
                }
                // Leading commas are not permitted, object property names must be
                // double-quoted strings, and a `:` must separate each property
                // name and value.
                if (value == "," || typeof value != "string" || (charIndexBuggy ? value.charAt(0) : value[0]) != "@" || lex() != ":") {
                  abort();
                }
                results[value.slice(1)] = get(lex());
              }
              return results;
            }
            // Unexpected token encountered.
            abort();
          }
          return value;
        };

        // Internal: Updates a traversed object member.
        var update = function (source, property, callback) {
          var element = walk(source, property, callback);
          if (element === undef) {
            delete source[property];
          } else {
            source[property] = element;
          }
        };

        // Internal: Recursively traverses a parsed JSON object, invoking the
        // `callback` function for each value. This is an implementation of the
        // `Walk(holder, name)` operation defined in ES 5.1 section 15.12.2.
        var walk = function (source, property, callback) {
          var value = source[property], length;
          if (typeof value == "object" && value) {
            // `forEach` can't be used to traverse an array in Opera <= 8.54
            // because its `Object#hasOwnProperty` implementation returns `false`
            // for array indices (e.g., `![1, 2, 3].hasOwnProperty("0")`).
            if (getClass.call(value) == arrayClass) {
              for (length = value.length; length--;) {
                update(value, length, callback);
              }
            } else {
              forEach(value, function (property) {
                update(value, property, callback);
              });
            }
          }
          return callback.call(source, property, value);
        };

        // Public: `JSON.parse`. See ES 5.1 section 15.12.2.
        exports.parse = function (source, callback) {
          var result, value;
          Index = 0;
          Source = "" + source;
          result = get(lex());
          // If a JSON string contains multiple tokens, it is invalid.
          if (lex() != "$") {
            abort();
          }
          // Reset the parser state.
          Index = Source = null;
          return callback && getClass.call(callback) == functionClass ? walk((value = {}, value[""] = result, value), "", callback) : result;
        };
      }
    }

    exports["runInContext"] = runInContext;
    return exports;
  }

  if (freeExports && !isLoader) {
    // Export for CommonJS environments.
    runInContext(root, freeExports);
  } else {
    // Export for web browsers and JavaScript engines.
    var nativeJSON = root.JSON,
        previousJSON = root["JSON3"],
        isRestored = false;

    var JSON3 = runInContext(root, (root["JSON3"] = {
      // Public: Restores the original value of the global `JSON` object and
      // returns a reference to the `JSON3` object.
      "noConflict": function () {
        if (!isRestored) {
          isRestored = true;
          root.JSON = nativeJSON;
          root["JSON3"] = previousJSON;
          nativeJSON = previousJSON = null;
        }
        return JSON3;
      }
    }));

    root.JSON = {
      "parse": JSON3.parse,
      "stringify": JSON3.stringify
    };
  }

  // Export for asynchronous module loaders.
  if (isLoader) {
    define(function () {
      return JSON3;
    });
  }
}).call(this);

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{}],58:[function(require,module,exports){
/**
 * Helpers.
 */

var s = 1000;
var m = s * 60;
var h = m * 60;
var d = h * 24;
var y = d * 365.25;

/**
 * Parse or format the given `val`.
 *
 * Options:
 *
 *  - `long` verbose formatting [false]
 *
 * @param {String|Number} val
 * @param {Object} [options]
 * @throws {Error} throw an error if val is not a non-empty string or a number
 * @return {String|Number}
 * @api public
 */

module.exports = function(val, options) {
  options = options || {};
  var type = typeof val;
  if (type === 'string' && val.length > 0) {
    return parse(val);
  } else if (type === 'number' && isNaN(val) === false) {
    return options.long ? fmtLong(val) : fmtShort(val);
  }
  throw new Error(
    'val is not a non-empty string or a valid number. val=' +
      JSON.stringify(val)
  );
};

/**
 * Parse the given `str` and return milliseconds.
 *
 * @param {String} str
 * @return {Number}
 * @api private
 */

function parse(str) {
  str = String(str);
  if (str.length > 100) {
    return;
  }
  var match = /^((?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|years?|yrs?|y)?$/i.exec(
    str
  );
  if (!match) {
    return;
  }
  var n = parseFloat(match[1]);
  var type = (match[2] || 'ms').toLowerCase();
  switch (type) {
    case 'years':
    case 'year':
    case 'yrs':
    case 'yr':
    case 'y':
      return n * y;
    case 'days':
    case 'day':
    case 'd':
      return n * d;
    case 'hours':
    case 'hour':
    case 'hrs':
    case 'hr':
    case 'h':
      return n * h;
    case 'minutes':
    case 'minute':
    case 'mins':
    case 'min':
    case 'm':
      return n * m;
    case 'seconds':
    case 'second':
    case 'secs':
    case 'sec':
    case 's':
      return n * s;
    case 'milliseconds':
    case 'millisecond':
    case 'msecs':
    case 'msec':
    case 'ms':
      return n;
    default:
      return undefined;
  }
}

/**
 * Short format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function fmtShort(ms) {
  if (ms >= d) {
    return Math.round(ms / d) + 'd';
  }
  if (ms >= h) {
    return Math.round(ms / h) + 'h';
  }
  if (ms >= m) {
    return Math.round(ms / m) + 'm';
  }
  if (ms >= s) {
    return Math.round(ms / s) + 's';
  }
  return ms + 'ms';
}

/**
 * Long format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */

function fmtLong(ms) {
  return plural(ms, d, 'day') ||
    plural(ms, h, 'hour') ||
    plural(ms, m, 'minute') ||
    plural(ms, s, 'second') ||
    ms + ' ms';
}

/**
 * Pluralization helper.
 */

function plural(ms, n, name) {
  if (ms < n) {
    return;
  }
  if (ms < n * 1.5) {
    return Math.floor(ms / n) + ' ' + name;
  }
  return Math.ceil(ms / n) + ' ' + name + 's';
}

},{}],59:[function(require,module,exports){
'use strict';

var has = Object.prototype.hasOwnProperty;

/**
 * Decode a URI encoded string.
 *
 * @param {String} input The URI encoded string.
 * @returns {String} The decoded string.
 * @api private
 */
function decode(input) {
  return decodeURIComponent(input.replace(/\+/g, ' '));
}

/**
 * Simple query string parser.
 *
 * @param {String} query The query string that needs to be parsed.
 * @returns {Object}
 * @api public
 */
function querystring(query) {
  var parser = /([^=?&]+)=?([^&]*)/g
    , result = {}
    , part;

  while (part = parser.exec(query)) {
    var key = decode(part[1])
      , value = decode(part[2]);

    //
    // Prevent overriding of existing properties. This ensures that build-in
    // methods like `toString` or __proto__ are not overriden by malicious
    // querystrings.
    //
    if (key in result) continue;
    result[key] = value;
  }

  return result;
}

/**
 * Transform a query string to an object.
 *
 * @param {Object} obj Object that should be transformed.
 * @param {String} prefix Optional prefix.
 * @returns {String}
 * @api public
 */
function querystringify(obj, prefix) {
  prefix = prefix || '';

  var pairs = [];

  //
  // Optionally prefix with a '?' if needed
  //
  if ('string' !== typeof prefix) prefix = '?';

  for (var key in obj) {
    if (has.call(obj, key)) {
      pairs.push(encodeURIComponent(key) +'='+ encodeURIComponent(obj[key]));
    }
  }

  return pairs.length ? prefix + pairs.join('&') : '';
}

//
// Expose the module.
//
exports.stringify = querystringify;
exports.parse = querystring;

},{}],60:[function(require,module,exports){
'use strict';

/**
 * Check if we're required to add a port number.
 *
 * @see https://url.spec.whatwg.org/#default-port
 * @param {Number|String} port Port number we need to check
 * @param {String} protocol Protocol we need to check against.
 * @returns {Boolean} Is it a default port for the given protocol
 * @api private
 */
module.exports = function required(port, protocol) {
  protocol = protocol.split(':')[0];
  port = +port;

  if (!port) return false;

  switch (protocol) {
    case 'http':
    case 'ws':
    return port !== 80;

    case 'https':
    case 'wss':
    return port !== 443;

    case 'ftp':
    return port !== 21;

    case 'gopher':
    return port !== 70;

    case 'file':
    return false;
  }

  return port !== 0;
};

},{}],61:[function(require,module,exports){
(function (global){
'use strict';

var required = require('requires-port')
  , qs = require('querystringify')
  , protocolre = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\S\s]*)/i
  , slashes = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//;

/**
 * These are the parse rules for the URL parser, it informs the parser
 * about:
 *
 * 0. The char it Needs to parse, if it's a string it should be done using
 *    indexOf, RegExp using exec and NaN means set as current value.
 * 1. The property we should set when parsing this value.
 * 2. Indication if it's backwards or forward parsing, when set as number it's
 *    the value of extra chars that should be split off.
 * 3. Inherit from location if non existing in the parser.
 * 4. `toLowerCase` the resulting value.
 */
var rules = [
  ['#', 'hash'],                        // Extract from the back.
  ['?', 'query'],                       // Extract from the back.
  ['/', 'pathname'],                    // Extract from the back.
  ['@', 'auth', 1],                     // Extract from the front.
  [NaN, 'host', undefined, 1, 1],       // Set left over value.
  [/:(\d+)$/, 'port', undefined, 1],    // RegExp the back.
  [NaN, 'hostname', undefined, 1, 1]    // Set left over.
];

/**
 * These properties should not be copied or inherited from. This is only needed
 * for all non blob URL's as a blob URL does not include a hash, only the
 * origin.
 *
 * @type {Object}
 * @private
 */
var ignore = { hash: 1, query: 1 };

/**
 * The location object differs when your code is loaded through a normal page,
 * Worker or through a worker using a blob. And with the blobble begins the
 * trouble as the location object will contain the URL of the blob, not the
 * location of the page where our code is loaded in. The actual origin is
 * encoded in the `pathname` so we can thankfully generate a good "default"
 * location from it so we can generate proper relative URL's again.
 *
 * @param {Object|String} loc Optional default location object.
 * @returns {Object} lolcation object.
 * @api public
 */
function lolcation(loc) {
  loc = loc || global.location || {};

  var finaldestination = {}
    , type = typeof loc
    , key;

  if ('blob:' === loc.protocol) {
    finaldestination = new URL(unescape(loc.pathname), {});
  } else if ('string' === type) {
    finaldestination = new URL(loc, {});
    for (key in ignore) delete finaldestination[key];
  } else if ('object' === type) {
    for (key in loc) {
      if (key in ignore) continue;
      finaldestination[key] = loc[key];
    }

    if (finaldestination.slashes === undefined) {
      finaldestination.slashes = slashes.test(loc.href);
    }
  }

  return finaldestination;
}

/**
 * @typedef ProtocolExtract
 * @type Object
 * @property {String} protocol Protocol matched in the URL, in lowercase.
 * @property {Boolean} slashes `true` if protocol is followed by "//", else `false`.
 * @property {String} rest Rest of the URL that is not part of the protocol.
 */

/**
 * Extract protocol information from a URL with/without double slash ("//").
 *
 * @param {String} address URL we want to extract from.
 * @return {ProtocolExtract} Extracted information.
 * @api private
 */
function extractProtocol(address) {
  var match = protocolre.exec(address);

  return {
    protocol: match[1] ? match[1].toLowerCase() : '',
    slashes: !!match[2],
    rest: match[3]
  };
}

/**
 * Resolve a relative URL pathname against a base URL pathname.
 *
 * @param {String} relative Pathname of the relative URL.
 * @param {String} base Pathname of the base URL.
 * @return {String} Resolved pathname.
 * @api private
 */
function resolve(relative, base) {
  var path = (base || '/').split('/').slice(0, -1).concat(relative.split('/'))
    , i = path.length
    , last = path[i - 1]
    , unshift = false
    , up = 0;

  while (i--) {
    if (path[i] === '.') {
      path.splice(i, 1);
    } else if (path[i] === '..') {
      path.splice(i, 1);
      up++;
    } else if (up) {
      if (i === 0) unshift = true;
      path.splice(i, 1);
      up--;
    }
  }

  if (unshift) path.unshift('');
  if (last === '.' || last === '..') path.push('');

  return path.join('/');
}

/**
 * The actual URL instance. Instead of returning an object we've opted-in to
 * create an actual constructor as it's much more memory efficient and
 * faster and it pleases my OCD.
 *
 * @constructor
 * @param {String} address URL we want to parse.
 * @param {Object|String} location Location defaults for relative paths.
 * @param {Boolean|Function} parser Parser for the query string.
 * @api public
 */
function URL(address, location, parser) {
  if (!(this instanceof URL)) {
    return new URL(address, location, parser);
  }

  var relative, extracted, parse, instruction, index, key
    , instructions = rules.slice()
    , type = typeof location
    , url = this
    , i = 0;

  //
  // The following if statements allows this module two have compatibility with
  // 2 different API:
  //
  // 1. Node.js's `url.parse` api which accepts a URL, boolean as arguments
  //    where the boolean indicates that the query string should also be parsed.
  //
  // 2. The `URL` interface of the browser which accepts a URL, object as
  //    arguments. The supplied object will be used as default values / fall-back
  //    for relative paths.
  //
  if ('object' !== type && 'string' !== type) {
    parser = location;
    location = null;
  }

  if (parser && 'function' !== typeof parser) parser = qs.parse;

  location = lolcation(location);

  //
  // Extract protocol information before running the instructions.
  //
  extracted = extractProtocol(address || '');
  relative = !extracted.protocol && !extracted.slashes;
  url.slashes = extracted.slashes || relative && location.slashes;
  url.protocol = extracted.protocol || location.protocol || '';
  address = extracted.rest;

  //
  // When the authority component is absent the URL starts with a path
  // component.
  //
  if (!extracted.slashes) instructions[2] = [/(.*)/, 'pathname'];

  for (; i < instructions.length; i++) {
    instruction = instructions[i];
    parse = instruction[0];
    key = instruction[1];

    if (parse !== parse) {
      url[key] = address;
    } else if ('string' === typeof parse) {
      if (~(index = address.indexOf(parse))) {
        if ('number' === typeof instruction[2]) {
          url[key] = address.slice(0, index);
          address = address.slice(index + instruction[2]);
        } else {
          url[key] = address.slice(index);
          address = address.slice(0, index);
        }
      }
    } else if ((index = parse.exec(address))) {
      url[key] = index[1];
      address = address.slice(0, index.index);
    }

    url[key] = url[key] || (
      relative && instruction[3] ? location[key] || '' : ''
    );

    //
    // Hostname, host and protocol should be lowercased so they can be used to
    // create a proper `origin`.
    //
    if (instruction[4]) url[key] = url[key].toLowerCase();
  }

  //
  // Also parse the supplied query string in to an object. If we're supplied
  // with a custom parser as function use that instead of the default build-in
  // parser.
  //
  if (parser) url.query = parser(url.query);

  //
  // If the URL is relative, resolve the pathname against the base URL.
  //
  if (
      relative
    && location.slashes
    && url.pathname.charAt(0) !== '/'
    && (url.pathname !== '' || location.pathname !== '')
  ) {
    url.pathname = resolve(url.pathname, location.pathname);
  }

  //
  // We should not add port numbers if they are already the default port number
  // for a given protocol. As the host also contains the port number we're going
  // override it with the hostname which contains no port number.
  //
  if (!required(url.port, url.protocol)) {
    url.host = url.hostname;
    url.port = '';
  }

  //
  // Parse down the `auth` for the username and password.
  //
  url.username = url.password = '';
  if (url.auth) {
    instruction = url.auth.split(':');
    url.username = instruction[0] || '';
    url.password = instruction[1] || '';
  }

  url.origin = url.protocol && url.host && url.protocol !== 'file:'
    ? url.protocol +'//'+ url.host
    : 'null';

  //
  // The href is just the compiled result.
  //
  url.href = url.toString();
}

/**
 * This is convenience method for changing properties in the URL instance to
 * insure that they all propagate correctly.
 *
 * @param {String} part          Property we need to adjust.
 * @param {Mixed} value          The newly assigned value.
 * @param {Boolean|Function} fn  When setting the query, it will be the function
 *                               used to parse the query.
 *                               When setting the protocol, double slash will be
 *                               removed from the final url if it is true.
 * @returns {URL}
 * @api public
 */
function set(part, value, fn) {
  var url = this;

  switch (part) {
    case 'query':
      if ('string' === typeof value && value.length) {
        value = (fn || qs.parse)(value);
      }

      url[part] = value;
      break;

    case 'port':
      url[part] = value;

      if (!required(value, url.protocol)) {
        url.host = url.hostname;
        url[part] = '';
      } else if (value) {
        url.host = url.hostname +':'+ value;
      }

      break;

    case 'hostname':
      url[part] = value;

      if (url.port) value += ':'+ url.port;
      url.host = value;
      break;

    case 'host':
      url[part] = value;

      if (/:\d+$/.test(value)) {
        value = value.split(':');
        url.port = value.pop();
        url.hostname = value.join(':');
      } else {
        url.hostname = value;
        url.port = '';
      }

      break;

    case 'protocol':
      url.protocol = value.toLowerCase();
      url.slashes = !fn;
      break;

    case 'pathname':
    case 'hash':
      if (value) {
        var char = part === 'pathname' ? '/' : '#';
        url[part] = value.charAt(0) !== char ? char + value : value;
      } else {
        url[part] = value;
      }
      break;

    default:
      url[part] = value;
  }

  for (var i = 0; i < rules.length; i++) {
    var ins = rules[i];

    if (ins[4]) url[ins[1]] = url[ins[1]].toLowerCase();
  }

  url.origin = url.protocol && url.host && url.protocol !== 'file:'
    ? url.protocol +'//'+ url.host
    : 'null';

  url.href = url.toString();

  return url;
}

/**
 * Transform the properties back in to a valid and full URL string.
 *
 * @param {Function} stringify Optional query stringify function.
 * @returns {String}
 * @api public
 */
function toString(stringify) {
  if (!stringify || 'function' !== typeof stringify) stringify = qs.stringify;

  var query
    , url = this
    , protocol = url.protocol;

  if (protocol && protocol.charAt(protocol.length - 1) !== ':') protocol += ':';

  var result = protocol + (url.slashes ? '//' : '');

  if (url.username) {
    result += url.username;
    if (url.password) result += ':'+ url.password;
    result += '@';
  }

  result += url.host + url.pathname;

  query = 'object' === typeof url.query ? stringify(url.query) : url.query;
  if (query) result += '?' !== query.charAt(0) ? '?'+ query : query;

  if (url.hash) result += url.hash;

  return result;
}

URL.prototype = { set: set, toString: toString };

//
// Expose the URL parser and some additional properties that might be useful for
// others or testing.
//
URL.extractProtocol = extractProtocol;
URL.location = lolcation;
URL.qs = qs;

module.exports = URL;

}).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})

},{"querystringify":59,"requires-port":60}]},{},[1])(1)
});


//# sourceMappingURL=sockjs.js.map

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(4)))

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


// The error overlay is inspired (and mostly copied) from Create React App (https://github.com/facebookincubator/create-react-app)
// They, in turn, got inspired by webpack-hot-middleware (https://github.com/glenjamin/webpack-hot-middleware).

var ansiHTML = __webpack_require__(22);
var Entities = __webpack_require__(23).AllHtmlEntities;

var entities = new Entities();

var colors = {
  reset: ['transparent', 'transparent'],
  black: '181818',
  red: 'E36049',
  green: 'B3CB74',
  yellow: 'FFD080',
  blue: '7CAFC2',
  magenta: '7FACCA',
  cyan: 'C3C2EF',
  lightgrey: 'EBE7E3',
  darkgrey: '6D7891'
};
ansiHTML.setColors(colors);

function createOverlayIframe(onIframeLoad) {
  var iframe = document.createElement('iframe');
  iframe.id = 'webpack-dev-server-client-overlay';
  iframe.src = 'about:blank';
  iframe.style.position = 'fixed';
  iframe.style.left = 0;
  iframe.style.top = 0;
  iframe.style.right = 0;
  iframe.style.bottom = 0;
  iframe.style.width = '100vw';
  iframe.style.height = '100vh';
  iframe.style.border = 'none';
  iframe.style.zIndex = 9999999999;
  iframe.onload = onIframeLoad;
  return iframe;
}

function addOverlayDivTo(iframe) {
  var div = iframe.contentDocument.createElement('div');
  div.id = 'webpack-dev-server-client-overlay-div';
  div.style.position = 'fixed';
  div.style.boxSizing = 'border-box';
  div.style.left = 0;
  div.style.top = 0;
  div.style.right = 0;
  div.style.bottom = 0;
  div.style.width = '100vw';
  div.style.height = '100vh';
  div.style.backgroundColor = 'rgba(0, 0, 0, 0.85)';
  div.style.color = '#E8E8E8';
  div.style.fontFamily = 'Menlo, Consolas, monospace';
  div.style.fontSize = 'large';
  div.style.padding = '2rem';
  div.style.lineHeight = '1.2';
  div.style.whiteSpace = 'pre-wrap';
  div.style.overflow = 'auto';
  iframe.contentDocument.body.appendChild(div);
  return div;
}

var overlayIframe = null;
var overlayDiv = null;
var lastOnOverlayDivReady = null;

function ensureOverlayDivExists(onOverlayDivReady) {
  if (overlayDiv) {
    // Everything is ready, call the callback right away.
    onOverlayDivReady(overlayDiv);
    return;
  }

  // Creating an iframe may be asynchronous so we'll schedule the callback.
  // In case of multiple calls, last callback wins.
  lastOnOverlayDivReady = onOverlayDivReady;

  if (overlayIframe) {
    // We're already creating it.
    return;
  }

  // Create iframe and, when it is ready, a div inside it.
  overlayIframe = createOverlayIframe(function () {
    overlayDiv = addOverlayDivTo(overlayIframe);
    // Now we can talk!
    lastOnOverlayDivReady(overlayDiv);
  });

  // Zalgo alert: onIframeLoad() will be called either synchronously
  // or asynchronously depending on the browser.
  // We delay adding it so `overlayIframe` is set when `onIframeLoad` fires.
  document.body.appendChild(overlayIframe);
}

function showMessageOverlay(message) {
  ensureOverlayDivExists(function (div) {
    // Make it look similar to our terminal.
    div.innerHTML = '<span style="color: #' + colors.red + '">Failed to compile.</span><br><br>' + ansiHTML(entities.encode(message));
  });
}

function destroyErrorOverlay() {
  if (!overlayDiv) {
    // It is not there in the first place.
    return;
  }

  // Clean up and reset internal state.
  document.body.removeChild(overlayIframe);
  overlayDiv = null;
  overlayIframe = null;
  lastOnOverlayDivReady = null;
}

// Successful compilation.
exports.clear = function handleSuccess() {
  destroyErrorOverlay();
};

// Compilation with errors (e.g. syntax error or missing modules).
exports.showMessage = function handleMessage(messages) {
  showMessageOverlay(messages[0]);
};

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


module.exports = ansiHTML

// Reference to https://github.com/sindresorhus/ansi-regex
var _regANSI = /(?:(?:\u001b\[)|\u009b)(?:(?:[0-9]{1,3})?(?:(?:;[0-9]{0,3})*)?[A-M|f-m])|\u001b[A-M]/

var _defColors = {
  reset: ['fff', '000'], // [FOREGROUD_COLOR, BACKGROUND_COLOR]
  black: '000',
  red: 'ff0000',
  green: '209805',
  yellow: 'e8bf03',
  blue: '0000ff',
  magenta: 'ff00ff',
  cyan: '00ffee',
  lightgrey: 'f0f0f0',
  darkgrey: '888'
}
var _styles = {
  30: 'black',
  31: 'red',
  32: 'green',
  33: 'yellow',
  34: 'blue',
  35: 'magenta',
  36: 'cyan',
  37: 'lightgrey'
}
var _openTags = {
  '1': 'font-weight:bold', // bold
  '2': 'opacity:0.5', // dim
  '3': '<i>', // italic
  '4': '<u>', // underscore
  '8': 'display:none', // hidden
  '9': '<del>' // delete
}
var _closeTags = {
  '23': '</i>', // reset italic
  '24': '</u>', // reset underscore
  '29': '</del>' // reset delete
}

;[0, 21, 22, 27, 28, 39, 49].forEach(function (n) {
  _closeTags[n] = '</span>'
})

/**
 * Converts text with ANSI color codes to HTML markup.
 * @param {String} text
 * @returns {*}
 */
function ansiHTML (text) {
  // Returns the text if the string has no ANSI escape code.
  if (!_regANSI.test(text)) {
    return text
  }

  // Cache opened sequence.
  var ansiCodes = []
  // Replace with markup.
  var ret = text.replace(/\033\[(\d+)*m/g, function (match, seq) {
    var ot = _openTags[seq]
    if (ot) {
      // If current sequence has been opened, close it.
      if (!!~ansiCodes.indexOf(seq)) { // eslint-disable-line no-extra-boolean-cast
        ansiCodes.pop()
        return '</span>'
      }
      // Open tag.
      ansiCodes.push(seq)
      return ot[0] === '<' ? ot : '<span style="' + ot + ';">'
    }

    var ct = _closeTags[seq]
    if (ct) {
      // Pop sequence
      ansiCodes.pop()
      return ct
    }
    return ''
  })

  // Make sure tags are closed.
  var l = ansiCodes.length
  ;(l > 0) && (ret += Array(l + 1).join('</span>'))

  return ret
}

/**
 * Customize colors.
 * @param {Object} colors reference to _defColors
 */
ansiHTML.setColors = function (colors) {
  if (typeof colors !== 'object') {
    throw new Error('`colors` parameter must be an Object.')
  }

  var _finalColors = {}
  for (var key in _defColors) {
    var hex = colors.hasOwnProperty(key) ? colors[key] : null
    if (!hex) {
      _finalColors[key] = _defColors[key]
      continue
    }
    if ('reset' === key) {
      if (typeof hex === 'string') {
        hex = [hex]
      }
      if (!Array.isArray(hex) || hex.length === 0 || hex.some(function (h) {
        return typeof h !== 'string'
      })) {
        throw new Error('The value of `' + key + '` property must be an Array and each item could only be a hex string, e.g.: FF0000')
      }
      var defHexColor = _defColors[key]
      if (!hex[0]) {
        hex[0] = defHexColor[0]
      }
      if (hex.length === 1 || !hex[1]) {
        hex = [hex[0]]
        hex.push(defHexColor[1])
      }

      hex = hex.slice(0, 2)
    } else if (typeof hex !== 'string') {
      throw new Error('The value of `' + key + '` property must be a hex string, e.g.: FF0000')
    }
    _finalColors[key] = hex
  }
  _setTags(_finalColors)
}

/**
 * Reset colors.
 */
ansiHTML.reset = function () {
  _setTags(_defColors)
}

/**
 * Expose tags, including open and close.
 * @type {Object}
 */
ansiHTML.tags = {}

if (Object.defineProperty) {
  Object.defineProperty(ansiHTML.tags, 'open', {
    get: function () { return _openTags }
  })
  Object.defineProperty(ansiHTML.tags, 'close', {
    get: function () { return _closeTags }
  })
} else {
  ansiHTML.tags.open = _openTags
  ansiHTML.tags.close = _closeTags
}

function _setTags (colors) {
  // reset all
  _openTags['0'] = 'font-weight:normal;opacity:1;color:#' + colors.reset[0] + ';background:#' + colors.reset[1]
  // inverse
  _openTags['7'] = 'color:#' + colors.reset[1] + ';background:#' + colors.reset[0]
  // dark grey
  _openTags['90'] = 'color:#' + colors.darkgrey

  for (var code in _styles) {
    var color = _styles[code]
    var oriColor = colors[color] || '000'
    _openTags[code] = 'color:#' + oriColor
    code = parseInt(code)
    _openTags[(code + 10).toString()] = 'background:#' + oriColor
  }
}

ansiHTML.reset()


/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
  XmlEntities: __webpack_require__(24),
  Html4Entities: __webpack_require__(25),
  Html5Entities: __webpack_require__(5),
  AllHtmlEntities: __webpack_require__(5)
};


/***/ }),
/* 24 */
/***/ (function(module, exports) {

var ALPHA_INDEX = {
    '&lt': '<',
    '&gt': '>',
    '&quot': '"',
    '&apos': '\'',
    '&amp': '&',
    '&lt;': '<',
    '&gt;': '>',
    '&quot;': '"',
    '&apos;': '\'',
    '&amp;': '&'
};

var CHAR_INDEX = {
    60: 'lt',
    62: 'gt',
    34: 'quot',
    39: 'apos',
    38: 'amp'
};

var CHAR_S_INDEX = {
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    '\'': '&apos;',
    '&': '&amp;'
};

/**
 * @constructor
 */
function XmlEntities() {}

/**
 * @param {String} str
 * @returns {String}
 */
XmlEntities.prototype.encode = function(str) {
    if (!str || !str.length) {
        return '';
    }
    return str.replace(/<|>|"|'|&/g, function(s) {
        return CHAR_S_INDEX[s];
    });
};

/**
 * @param {String} str
 * @returns {String}
 */
 XmlEntities.encode = function(str) {
    return new XmlEntities().encode(str);
 };

/**
 * @param {String} str
 * @returns {String}
 */
XmlEntities.prototype.decode = function(str) {
    if (!str || !str.length) {
        return '';
    }
    return str.replace(/&#?[0-9a-zA-Z]+;?/g, function(s) {
        if (s.charAt(1) === '#') {
            var code = s.charAt(2).toLowerCase() === 'x' ?
                parseInt(s.substr(3), 16) :
                parseInt(s.substr(2));

            if (isNaN(code) || code < -32768 || code > 65535) {
                return '';
            }
            return String.fromCharCode(code);
        }
        return ALPHA_INDEX[s] || s;
    });
};

/**
 * @param {String} str
 * @returns {String}
 */
 XmlEntities.decode = function(str) {
    return new XmlEntities().decode(str);
 };

/**
 * @param {String} str
 * @returns {String}
 */
XmlEntities.prototype.encodeNonUTF = function(str) {
    if (!str || !str.length) {
        return '';
    }
    var strLength = str.length;
    var result = '';
    var i = 0;
    while (i < strLength) {
        var c = str.charCodeAt(i);
        var alpha = CHAR_INDEX[c];
        if (alpha) {
            result += "&" + alpha + ";";
            i++;
            continue;
        }
        if (c < 32 || c > 126) {
            result += '&#' + c + ';';
        } else {
            result += str.charAt(i);
        }
        i++;
    }
    return result;
};

/**
 * @param {String} str
 * @returns {String}
 */
 XmlEntities.encodeNonUTF = function(str) {
    return new XmlEntities().encodeNonUTF(str);
 };

/**
 * @param {String} str
 * @returns {String}
 */
XmlEntities.prototype.encodeNonASCII = function(str) {
    if (!str || !str.length) {
        return '';
    }
    var strLenght = str.length;
    var result = '';
    var i = 0;
    while (i < strLenght) {
        var c = str.charCodeAt(i);
        if (c <= 255) {
            result += str[i++];
            continue;
        }
        result += '&#' + c + ';';
        i++;
    }
    return result;
};

/**
 * @param {String} str
 * @returns {String}
 */
 XmlEntities.encodeNonASCII = function(str) {
    return new XmlEntities().encodeNonASCII(str);
 };

module.exports = XmlEntities;


/***/ }),
/* 25 */
/***/ (function(module, exports) {

var HTML_ALPHA = ['apos', 'nbsp', 'iexcl', 'cent', 'pound', 'curren', 'yen', 'brvbar', 'sect', 'uml', 'copy', 'ordf', 'laquo', 'not', 'shy', 'reg', 'macr', 'deg', 'plusmn', 'sup2', 'sup3', 'acute', 'micro', 'para', 'middot', 'cedil', 'sup1', 'ordm', 'raquo', 'frac14', 'frac12', 'frac34', 'iquest', 'Agrave', 'Aacute', 'Acirc', 'Atilde', 'Auml', 'Aring', 'Aelig', 'Ccedil', 'Egrave', 'Eacute', 'Ecirc', 'Euml', 'Igrave', 'Iacute', 'Icirc', 'Iuml', 'ETH', 'Ntilde', 'Ograve', 'Oacute', 'Ocirc', 'Otilde', 'Ouml', 'times', 'Oslash', 'Ugrave', 'Uacute', 'Ucirc', 'Uuml', 'Yacute', 'THORN', 'szlig', 'agrave', 'aacute', 'acirc', 'atilde', 'auml', 'aring', 'aelig', 'ccedil', 'egrave', 'eacute', 'ecirc', 'euml', 'igrave', 'iacute', 'icirc', 'iuml', 'eth', 'ntilde', 'ograve', 'oacute', 'ocirc', 'otilde', 'ouml', 'divide', 'oslash', 'ugrave', 'uacute', 'ucirc', 'uuml', 'yacute', 'thorn', 'yuml', 'quot', 'amp', 'lt', 'gt', 'OElig', 'oelig', 'Scaron', 'scaron', 'Yuml', 'circ', 'tilde', 'ensp', 'emsp', 'thinsp', 'zwnj', 'zwj', 'lrm', 'rlm', 'ndash', 'mdash', 'lsquo', 'rsquo', 'sbquo', 'ldquo', 'rdquo', 'bdquo', 'dagger', 'Dagger', 'permil', 'lsaquo', 'rsaquo', 'euro', 'fnof', 'Alpha', 'Beta', 'Gamma', 'Delta', 'Epsilon', 'Zeta', 'Eta', 'Theta', 'Iota', 'Kappa', 'Lambda', 'Mu', 'Nu', 'Xi', 'Omicron', 'Pi', 'Rho', 'Sigma', 'Tau', 'Upsilon', 'Phi', 'Chi', 'Psi', 'Omega', 'alpha', 'beta', 'gamma', 'delta', 'epsilon', 'zeta', 'eta', 'theta', 'iota', 'kappa', 'lambda', 'mu', 'nu', 'xi', 'omicron', 'pi', 'rho', 'sigmaf', 'sigma', 'tau', 'upsilon', 'phi', 'chi', 'psi', 'omega', 'thetasym', 'upsih', 'piv', 'bull', 'hellip', 'prime', 'Prime', 'oline', 'frasl', 'weierp', 'image', 'real', 'trade', 'alefsym', 'larr', 'uarr', 'rarr', 'darr', 'harr', 'crarr', 'lArr', 'uArr', 'rArr', 'dArr', 'hArr', 'forall', 'part', 'exist', 'empty', 'nabla', 'isin', 'notin', 'ni', 'prod', 'sum', 'minus', 'lowast', 'radic', 'prop', 'infin', 'ang', 'and', 'or', 'cap', 'cup', 'int', 'there4', 'sim', 'cong', 'asymp', 'ne', 'equiv', 'le', 'ge', 'sub', 'sup', 'nsub', 'sube', 'supe', 'oplus', 'otimes', 'perp', 'sdot', 'lceil', 'rceil', 'lfloor', 'rfloor', 'lang', 'rang', 'loz', 'spades', 'clubs', 'hearts', 'diams'];
var HTML_CODES = [39, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 34, 38, 60, 62, 338, 339, 352, 353, 376, 710, 732, 8194, 8195, 8201, 8204, 8205, 8206, 8207, 8211, 8212, 8216, 8217, 8218, 8220, 8221, 8222, 8224, 8225, 8240, 8249, 8250, 8364, 402, 913, 914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 931, 932, 933, 934, 935, 936, 937, 945, 946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966, 967, 968, 969, 977, 978, 982, 8226, 8230, 8242, 8243, 8254, 8260, 8472, 8465, 8476, 8482, 8501, 8592, 8593, 8594, 8595, 8596, 8629, 8656, 8657, 8658, 8659, 8660, 8704, 8706, 8707, 8709, 8711, 8712, 8713, 8715, 8719, 8721, 8722, 8727, 8730, 8733, 8734, 8736, 8743, 8744, 8745, 8746, 8747, 8756, 8764, 8773, 8776, 8800, 8801, 8804, 8805, 8834, 8835, 8836, 8838, 8839, 8853, 8855, 8869, 8901, 8968, 8969, 8970, 8971, 9001, 9002, 9674, 9824, 9827, 9829, 9830];

var alphaIndex = {};
var numIndex = {};

var i = 0;
var length = HTML_ALPHA.length;
while (i < length) {
    var a = HTML_ALPHA[i];
    var c = HTML_CODES[i];
    alphaIndex[a] = String.fromCharCode(c);
    numIndex[c] = a;
    i++;
}

/**
 * @constructor
 */
function Html4Entities() {}

/**
 * @param {String} str
 * @returns {String}
 */
Html4Entities.prototype.decode = function(str) {
    if (!str || !str.length) {
        return '';
    }
    return str.replace(/&(#?[\w\d]+);?/g, function(s, entity) {
        var chr;
        if (entity.charAt(0) === "#") {
            var code = entity.charAt(1).toLowerCase() === 'x' ?
                parseInt(entity.substr(2), 16) :
                parseInt(entity.substr(1));

            if (!(isNaN(code) || code < -32768 || code > 65535)) {
                chr = String.fromCharCode(code);
            }
        } else {
            chr = alphaIndex[entity];
        }
        return chr || s;
    });
};

/**
 * @param {String} str
 * @returns {String}
 */
Html4Entities.decode = function(str) {
    return new Html4Entities().decode(str);
};

/**
 * @param {String} str
 * @returns {String}
 */
Html4Entities.prototype.encode = function(str) {
    if (!str || !str.length) {
        return '';
    }
    var strLength = str.length;
    var result = '';
    var i = 0;
    while (i < strLength) {
        var alpha = numIndex[str.charCodeAt(i)];
        result += alpha ? "&" + alpha + ";" : str.charAt(i);
        i++;
    }
    return result;
};

/**
 * @param {String} str
 * @returns {String}
 */
Html4Entities.encode = function(str) {
    return new Html4Entities().encode(str);
};

/**
 * @param {String} str
 * @returns {String}
 */
Html4Entities.prototype.encodeNonUTF = function(str) {
    if (!str || !str.length) {
        return '';
    }
    var strLength = str.length;
    var result = '';
    var i = 0;
    while (i < strLength) {
        var cc = str.charCodeAt(i);
        var alpha = numIndex[cc];
        if (alpha) {
            result += "&" + alpha + ";";
        } else if (cc < 32 || cc > 126) {
            result += "&#" + cc + ";";
        } else {
            result += str.charAt(i);
        }
        i++;
    }
    return result;
};

/**
 * @param {String} str
 * @returns {String}
 */
Html4Entities.encodeNonUTF = function(str) {
    return new Html4Entities().encodeNonUTF(str);
};

/**
 * @param {String} str
 * @returns {String}
 */
Html4Entities.prototype.encodeNonASCII = function(str) {
    if (!str || !str.length) {
        return '';
    }
    var strLength = str.length;
    var result = '';
    var i = 0;
    while (i < strLength) {
        var c = str.charCodeAt(i);
        if (c <= 255) {
            result += str[i++];
            continue;
        }
        result += '&#' + c + ';';
        i++;
    }
    return result;
};

/**
 * @param {String} str
 * @returns {String}
 */
Html4Entities.encodeNonASCII = function(str) {
    return new Html4Entities().encodeNonASCII(str);
};

module.exports = Html4Entities;


/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./log": 3
};
function webpackContext(req) {
	return __webpack_require__(webpackContextResolve(req));
};
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) // check for number or string
		throw new Error("Cannot find module '" + req + "'.");
	return id;
};
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 26;

/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.



var R = typeof Reflect === 'object' ? Reflect : null
var ReflectApply = R && typeof R.apply === 'function'
  ? R.apply
  : function ReflectApply(target, receiver, args) {
    return Function.prototype.apply.call(target, receiver, args);
  }

var ReflectOwnKeys
if (R && typeof R.ownKeys === 'function') {
  ReflectOwnKeys = R.ownKeys
} else if (Object.getOwnPropertySymbols) {
  ReflectOwnKeys = function ReflectOwnKeys(target) {
    return Object.getOwnPropertyNames(target)
      .concat(Object.getOwnPropertySymbols(target));
  };
} else {
  ReflectOwnKeys = function ReflectOwnKeys(target) {
    return Object.getOwnPropertyNames(target);
  };
}

function ProcessEmitWarning(warning) {
  if (console && console.warn) console.warn(warning);
}

var NumberIsNaN = Number.isNaN || function NumberIsNaN(value) {
  return value !== value;
}

function EventEmitter() {
  EventEmitter.init.call(this);
}
module.exports = EventEmitter;

// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;

EventEmitter.prototype._events = undefined;
EventEmitter.prototype._eventsCount = 0;
EventEmitter.prototype._maxListeners = undefined;

// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
var defaultMaxListeners = 10;

Object.defineProperty(EventEmitter, 'defaultMaxListeners', {
  enumerable: true,
  get: function() {
    return defaultMaxListeners;
  },
  set: function(arg) {
    if (typeof arg !== 'number' || arg < 0 || NumberIsNaN(arg)) {
      throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + '.');
    }
    defaultMaxListeners = arg;
  }
});

EventEmitter.init = function() {

  if (this._events === undefined ||
      this._events === Object.getPrototypeOf(this)._events) {
    this._events = Object.create(null);
    this._eventsCount = 0;
  }

  this._maxListeners = this._maxListeners || undefined;
};

// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
  if (typeof n !== 'number' || n < 0 || NumberIsNaN(n)) {
    throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + '.');
  }
  this._maxListeners = n;
  return this;
};

function $getMaxListeners(that) {
  if (that._maxListeners === undefined)
    return EventEmitter.defaultMaxListeners;
  return that._maxListeners;
}

EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
  return $getMaxListeners(this);
};

EventEmitter.prototype.emit = function emit(type) {
  var args = [];
  for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
  var doError = (type === 'error');

  var events = this._events;
  if (events !== undefined)
    doError = (doError && events.error === undefined);
  else if (!doError)
    return false;

  // If there is no 'error' event listener then throw.
  if (doError) {
    var er;
    if (args.length > 0)
      er = args[0];
    if (er instanceof Error) {
      // Note: The comments on the `throw` lines are intentional, they show
      // up in Node's output if this results in an unhandled exception.
      throw er; // Unhandled 'error' event
    }
    // At least give some kind of context to the user
    var err = new Error('Unhandled error.' + (er ? ' (' + er.message + ')' : ''));
    err.context = er;
    throw err; // Unhandled 'error' event
  }

  var handler = events[type];

  if (handler === undefined)
    return false;

  if (typeof handler === 'function') {
    ReflectApply(handler, this, args);
  } else {
    var len = handler.length;
    var listeners = arrayClone(handler, len);
    for (var i = 0; i < len; ++i)
      ReflectApply(listeners[i], this, args);
  }

  return true;
};

function _addListener(target, type, listener, prepend) {
  var m;
  var events;
  var existing;

  if (typeof listener !== 'function') {
    throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
  }

  events = target._events;
  if (events === undefined) {
    events = target._events = Object.create(null);
    target._eventsCount = 0;
  } else {
    // To avoid recursion in the case that type === "newListener"! Before
    // adding it to the listeners, first emit "newListener".
    if (events.newListener !== undefined) {
      target.emit('newListener', type,
                  listener.listener ? listener.listener : listener);

      // Re-assign `events` because a newListener handler could have caused the
      // this._events to be assigned to a new object
      events = target._events;
    }
    existing = events[type];
  }

  if (existing === undefined) {
    // Optimize the case of one listener. Don't need the extra array object.
    existing = events[type] = listener;
    ++target._eventsCount;
  } else {
    if (typeof existing === 'function') {
      // Adding the second element, need to change to array.
      existing = events[type] =
        prepend ? [listener, existing] : [existing, listener];
      // If we've already got an array, just append.
    } else if (prepend) {
      existing.unshift(listener);
    } else {
      existing.push(listener);
    }

    // Check for listener leak
    m = $getMaxListeners(target);
    if (m > 0 && existing.length > m && !existing.warned) {
      existing.warned = true;
      // No error code for this since it is a Warning
      // eslint-disable-next-line no-restricted-syntax
      var w = new Error('Possible EventEmitter memory leak detected. ' +
                          existing.length + ' ' + String(type) + ' listeners ' +
                          'added. Use emitter.setMaxListeners() to ' +
                          'increase limit');
      w.name = 'MaxListenersExceededWarning';
      w.emitter = target;
      w.type = type;
      w.count = existing.length;
      ProcessEmitWarning(w);
    }
  }

  return target;
}

EventEmitter.prototype.addListener = function addListener(type, listener) {
  return _addListener(this, type, listener, false);
};

EventEmitter.prototype.on = EventEmitter.prototype.addListener;

EventEmitter.prototype.prependListener =
    function prependListener(type, listener) {
      return _addListener(this, type, listener, true);
    };

function onceWrapper() {
  var args = [];
  for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
  if (!this.fired) {
    this.target.removeListener(this.type, this.wrapFn);
    this.fired = true;
    ReflectApply(this.listener, this.target, args);
  }
}

function _onceWrap(target, type, listener) {
  var state = { fired: false, wrapFn: undefined, target: target, type: type, listener: listener };
  var wrapped = onceWrapper.bind(state);
  wrapped.listener = listener;
  state.wrapFn = wrapped;
  return wrapped;
}

EventEmitter.prototype.once = function once(type, listener) {
  if (typeof listener !== 'function') {
    throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
  }
  this.on(type, _onceWrap(this, type, listener));
  return this;
};

EventEmitter.prototype.prependOnceListener =
    function prependOnceListener(type, listener) {
      if (typeof listener !== 'function') {
        throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
      }
      this.prependListener(type, _onceWrap(this, type, listener));
      return this;
    };

// Emits a 'removeListener' event if and only if the listener was removed.
EventEmitter.prototype.removeListener =
    function removeListener(type, listener) {
      var list, events, position, i, originalListener;

      if (typeof listener !== 'function') {
        throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
      }

      events = this._events;
      if (events === undefined)
        return this;

      list = events[type];
      if (list === undefined)
        return this;

      if (list === listener || list.listener === listener) {
        if (--this._eventsCount === 0)
          this._events = Object.create(null);
        else {
          delete events[type];
          if (events.removeListener)
            this.emit('removeListener', type, list.listener || listener);
        }
      } else if (typeof list !== 'function') {
        position = -1;

        for (i = list.length - 1; i >= 0; i--) {
          if (list[i] === listener || list[i].listener === listener) {
            originalListener = list[i].listener;
            position = i;
            break;
          }
        }

        if (position < 0)
          return this;

        if (position === 0)
          list.shift();
        else {
          spliceOne(list, position);
        }

        if (list.length === 1)
          events[type] = list[0];

        if (events.removeListener !== undefined)
          this.emit('removeListener', type, originalListener || listener);
      }

      return this;
    };

EventEmitter.prototype.off = EventEmitter.prototype.removeListener;

EventEmitter.prototype.removeAllListeners =
    function removeAllListeners(type) {
      var listeners, events, i;

      events = this._events;
      if (events === undefined)
        return this;

      // not listening for removeListener, no need to emit
      if (events.removeListener === undefined) {
        if (arguments.length === 0) {
          this._events = Object.create(null);
          this._eventsCount = 0;
        } else if (events[type] !== undefined) {
          if (--this._eventsCount === 0)
            this._events = Object.create(null);
          else
            delete events[type];
        }
        return this;
      }

      // emit removeListener for all listeners on all events
      if (arguments.length === 0) {
        var keys = Object.keys(events);
        var key;
        for (i = 0; i < keys.length; ++i) {
          key = keys[i];
          if (key === 'removeListener') continue;
          this.removeAllListeners(key);
        }
        this.removeAllListeners('removeListener');
        this._events = Object.create(null);
        this._eventsCount = 0;
        return this;
      }

      listeners = events[type];

      if (typeof listeners === 'function') {
        this.removeListener(type, listeners);
      } else if (listeners !== undefined) {
        // LIFO order
        for (i = listeners.length - 1; i >= 0; i--) {
          this.removeListener(type, listeners[i]);
        }
      }

      return this;
    };

function _listeners(target, type, unwrap) {
  var events = target._events;

  if (events === undefined)
    return [];

  var evlistener = events[type];
  if (evlistener === undefined)
    return [];

  if (typeof evlistener === 'function')
    return unwrap ? [evlistener.listener || evlistener] : [evlistener];

  return unwrap ?
    unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
}

EventEmitter.prototype.listeners = function listeners(type) {
  return _listeners(this, type, true);
};

EventEmitter.prototype.rawListeners = function rawListeners(type) {
  return _listeners(this, type, false);
};

EventEmitter.listenerCount = function(emitter, type) {
  if (typeof emitter.listenerCount === 'function') {
    return emitter.listenerCount(type);
  } else {
    return listenerCount.call(emitter, type);
  }
};

EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(type) {
  var events = this._events;

  if (events !== undefined) {
    var evlistener = events[type];

    if (typeof evlistener === 'function') {
      return 1;
    } else if (evlistener !== undefined) {
      return evlistener.length;
    }
  }

  return 0;
}

EventEmitter.prototype.eventNames = function eventNames() {
  return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
};

function arrayClone(arr, n) {
  var copy = new Array(n);
  for (var i = 0; i < n; ++i)
    copy[i] = arr[i];
  return copy;
}

function spliceOne(list, index) {
  for (; index + 1 < list.length; index++)
    list[index] = list[index + 1];
  list.pop();
}

function unwrapListeners(arr) {
  var ret = new Array(arr.length);
  for (var i = 0; i < ret.length; ++i) {
    ret[i] = arr[i].listener || arr[i];
  }
  return ret;
}


/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
/*globals window __webpack_hash__ */
if(true) {
	var lastHash;
	var upToDate = function upToDate() {
		return lastHash.indexOf(__webpack_require__.h()) >= 0;
	};
	var log = __webpack_require__(3);
	var check = function check() {
		module.hot.check(true).then(function(updatedModules) {
			if(!updatedModules) {
				log("warning", "[HMR] Cannot find update. Need to do a full reload!");
				log("warning", "[HMR] (Probably because of restarting the webpack-dev-server)");
				window.location.reload();
				return;
			}

			if(!upToDate()) {
				check();
			}

			__webpack_require__(29)(updatedModules, updatedModules);

			if(upToDate()) {
				log("info", "[HMR] App is up to date.");
			}

		}).catch(function(err) {
			var status = module.hot.status();
			if(["abort", "fail"].indexOf(status) >= 0) {
				log("warning", "[HMR] Cannot apply update. Need to do a full reload!");
				log("warning", "[HMR] " + err.stack || err.message);
				window.location.reload();
			} else {
				log("warning", "[HMR] Update failed: " + err.stack || err.message);
			}
		});
	};
	var hotEmitter = __webpack_require__(6);
	hotEmitter.on("webpackHotUpdate", function(currentHash) {
		lastHash = currentHash;
		if(!upToDate() && module.hot.status() === "idle") {
			log("info", "[HMR] Checking for updates on the server...");
			check();
		}
	});
	log("info", "[HMR] Waiting for update signal from WDS...");
} else {
	throw new Error("[HMR] Hot Module Replacement is disabled.");
}


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
module.exports = function(updatedModules, renewedModules) {
	var unacceptedModules = updatedModules.filter(function(moduleId) {
		return renewedModules && renewedModules.indexOf(moduleId) < 0;
	});
	var log = __webpack_require__(3);

	if(unacceptedModules.length > 0) {
		log("warning", "[HMR] The following modules couldn't be hot updated: (They would need a full reload!)");
		unacceptedModules.forEach(function(moduleId) {
			log("warning", "[HMR]  - " + moduleId);
		});
	}

	if(!renewedModules || renewedModules.length === 0) {
		log("info", "[HMR] Nothing hot updated.");
	} else {
		log("info", "[HMR] Updated modules:");
		renewedModules.forEach(function(moduleId) {
			if(typeof moduleId === "string" && moduleId.indexOf("!") !== -1) {
				var parts = moduleId.split("!");
				log.groupCollapsed("info", "[HMR]  - " + parts.pop());
				log("info", "[HMR]  - " + moduleId);
				log.groupEnd("info");
			} else {
				log("info", "[HMR]  - " + moduleId);
			}
		});
		var numberIds = renewedModules.every(function(moduleId) {
			return typeof moduleId === "number";
		});
		if(numberIds)
			log("info", "[HMR] Consider using the NamedModulesPlugin for module names.");
	}
};


/***/ }),
/* 30 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "v", function() { return v; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lang", function() { return lang; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dir", function() { return dir; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rtl", function() { return rtl; });
/* harmony export (immutable) */ __webpack_exports__["ready"] = ready;
/* harmony export (immutable) */ __webpack_exports__["$bind"] = $bind;
/* harmony export (immutable) */ __webpack_exports__["CustomizeHighCharts"] = CustomizeHighCharts;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__framework_assets_cookies__ = __webpack_require__(44);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ui_styles__ = __webpack_require__(45);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ui_styles___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__ui_styles__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__polyfills__ = __webpack_require__(46);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__framework_ui_shared_popover_popover__ = __webpack_require__(34);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__framework_ui_shared_toggler_toggler__ = __webpack_require__(52);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__framework_ui_shared_snackbar_snackbar__ = __webpack_require__(53);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__framework_ui_shared_toggleSheet_toggleSheet__ = __webpack_require__(54);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__framework_ui_shared_scrollLock_scrollLock__ = __webpack_require__(37);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__framework_ui_input_searchable_searchable__ = __webpack_require__(56);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__framework_ui_nav_nav__ = __webpack_require__(62);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__framework_ui_tabs_tabs__ = __webpack_require__(64);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__framework_ui_gauge_gauge__ = __webpack_require__(65);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__framework_ui_slider_slider__ = __webpack_require__(66);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__framework_ui_spinner_loader__ = __webpack_require__(67);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__framework_ui_swiper_swiper__ = __webpack_require__(68);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__framework_ui_form_validate_form__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__framework_typography_type_trim__ = __webpack_require__(74);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__framework_ui_message_message__ = __webpack_require__(75);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__framework_ui_input_elements_file__ = __webpack_require__(76);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__framework_ui_image_image_remap__ = __webpack_require__(42);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_20__framework_ui_image_image_lazy__ = __webpack_require__(77);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_21__framework_ui_image_image_fit__ = __webpack_require__(78);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_22__framework_ui_shared_viewSize_viewSize__ = __webpack_require__(40);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_23__framework_ui_modal_dialogs_lightbox__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_24__framework_ui_form_clonable_field__ = __webpack_require__(86);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_25__framework_ui_shared_utils_serialize__ = __webpack_require__(38);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_27__framework_ui_shared_data_registry__ = __webpack_require__(2);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "resolve", function() { return __WEBPACK_IMPORTED_MODULE_27__framework_ui_shared_data_registry__["d"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "KEYS", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["KEYS"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_28__framework_ui_bubble_bubble__ = __webpack_require__(87);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Bubble", function() { return __WEBPACK_IMPORTED_MODULE_28__framework_ui_bubble_bubble__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_29__framework_ui_modal_modal__ = __webpack_require__(31);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Modal", function() { return __WEBPACK_IMPORTED_MODULE_29__framework_ui_modal_modal__["d"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Alert", function() { return __WEBPACK_IMPORTED_MODULE_29__framework_ui_modal_modal__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Confirm", function() { return __WEBPACK_IMPORTED_MODULE_29__framework_ui_modal_modal__["b"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Promo", function() { return __WEBPACK_IMPORTED_MODULE_29__framework_ui_modal_modal__["e"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "File", function() { return __WEBPACK_IMPORTED_MODULE_29__framework_ui_modal_modal__["c"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "ajax", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["ajax"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "ajaxSetup", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["ajaxSetup"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "init", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["init"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "merge", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["merge"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "get", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["get"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "find", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["find"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "escapeRegExp", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["escapeRegExp"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "isMobile", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["isMobile"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "isVisible", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["isVisible"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "addClass", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["addClass"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "addClasses", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["addClasses"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "remClass", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["remClass"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "remClasses", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["remClasses"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "resolveFn", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["resolveFn"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "NOOP", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["NOOP"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "inject", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["inject"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "readConfig", function() { return __WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["readConfig"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "serialize", function() { return __WEBPACK_IMPORTED_MODULE_25__framework_ui_shared_utils_serialize__["b"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "serializeArray", function() { return __WEBPACK_IMPORTED_MODULE_25__framework_ui_shared_utils_serialize__["c"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "push", function() { return __WEBPACK_IMPORTED_MODULE_5__framework_ui_shared_snackbar_snackbar__["b"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "attach", function() { return __WEBPACK_IMPORTED_MODULE_5__framework_ui_shared_snackbar_snackbar__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Popover", function() { return __WEBPACK_IMPORTED_MODULE_3__framework_ui_shared_popover_popover__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Nav", function() { return __WEBPACK_IMPORTED_MODULE_9__framework_ui_nav_nav__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Searchable", function() { return __WEBPACK_IMPORTED_MODULE_8__framework_ui_input_searchable_searchable__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Tabs", function() { return __WEBPACK_IMPORTED_MODULE_10__framework_ui_tabs_tabs__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Gauge", function() { return __WEBPACK_IMPORTED_MODULE_11__framework_ui_gauge_gauge__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "ValidateForm", function() { return __WEBPACK_IMPORTED_MODULE_15__framework_ui_form_validate_form__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "ToggleSheet", function() { return __WEBPACK_IMPORTED_MODULE_6__framework_ui_shared_toggleSheet_toggleSheet__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "ScrollLock", function() { return __WEBPACK_IMPORTED_MODULE_7__framework_ui_shared_scrollLock_scrollLock__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "Loader", function() { return __WEBPACK_IMPORTED_MODULE_13__framework_ui_spinner_loader__["a"]; });
var v = "1.59.0"; //webpack.DefinePlugin



window.Cookies = __WEBPACK_IMPORTED_MODULE_0__framework_assets_cookies__["a" /* api */];




































// Helpers
var lang = document.documentElement.lang,
    dir = document.dir || 'ltr',
    rtl = dir == 'rtl';
// In case we want these helper to be exposed as properties,
// but act as functions.

//
// Object.defineProperty(this, 'lang', {
//   set: NOOP,
//   get: function () { return document.documentElement.lang }
// })
// Object.defineProperty(this, 'dir', {
//   set: NOOP,
//   get: function () { return document.dir || 'ltr' }
// })
// Object.defineProperty(this, 'rtl', {
//   set: NOOP,
//   get: function () { return this.dir === 'rtl' }
// });
//

// Aliases
Document.prototype.qsa = Document.prototype.querySelectorAll;
Document.prototype.qs = Document.prototype.querySelector;
Element.prototype.qsa = Element.prototype.querySelectorAll;
Element.prototype.qs = Element.prototype.querySelector;

Element.prototype.attr = function (attr, val) {
  return arguments.length == 2 ? this.setAttribute.apply(this, arguments) : this.getAttribute.apply(this, arguments);
};

// Overrides
var FORM_PROTO_SUBMIT = HTMLFormElement.prototype.submit;
HTMLFormElement.prototype.submit = function () {
  var e = new CustomEvent('submit', { bubbles: true, cancelable: true }),
      _preventDefault = e.preventDefault,
      prevented = false;
  e.preventDefault = function () {
    _preventDefault.call(e);
    prevented = true;
  };
  this.dispatchEvent(e);
  if (!prevented) {
    FORM_PROTO_SUBMIT.call(this);
  }
};

// --------------------------------------------------------------+
// Bind all known JS components automatically upon document load.|
// --------------------------------------------------------------+
var readyHandlers = [];
function _ready() {

  requestAnimationFrame(function () {
    window.setTimeout(__WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["loadDeferredStyles"], 0);
  });

  //Bind all modules.
  $bind();
  //track popovers
  __WEBPACK_IMPORTED_MODULE_3__framework_ui_shared_popover_popover__["a" /* Popover */].$trackPopovers();
  //track nav panels
  __WEBPACK_IMPORTED_MODULE_9__framework_ui_nav_nav__["a" /* Nav */].$trackNavs();
  // call handlers
  var handler = null;
  while (handler = readyHandlers.pop()) {
    handler();
  }readyHandlers = null;
}
function _loaded() {
  document.removeEventListener('DOMContentLoaded', _loaded);
  window.removeEventListener('load', _loaded);
  _ready();
}
// check if document is already loaded
if (document.readyState === "complete") {
  window.setTimeout(_loaded);
} else {
  document.addEventListener("DOMContentLoaded", _loaded);
  window.addEventListener("load", _loaded);
}

/**
 * Offers a place to run JavaScript code as soon as the page's Document Object Model (DOM) becomes ready.
 */
function ready(callback) {
  if (readyHandlers) {
    readyHandlers.push(callback);
  } else {
    callback();
  }
}

/**
 *
 * @param {*} target
 */
function $bind() {
  var target = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : document;


  if (typeof target === 'string') {
    target = Object(__WEBPACK_IMPORTED_MODULE_26__framework_ui_shared_utils_main__["get"])(target);
  }

  //clone field
  //MUST BE FIRST: to clone elements before modules are initialized.
  Object(__WEBPACK_IMPORTED_MODULE_24__framework_ui_form_clonable_field__["a" /* $init */])(target);

  //trim text
  Object(__WEBPACK_IMPORTED_MODULE_16__framework_typography_type_trim__["a" /* $init */])(target);

  // msg close button
  Object(__WEBPACK_IMPORTED_MODULE_17__framework_ui_message_message__["a" /* $init */])(target);

  // file input state
  Object(__WEBPACK_IMPORTED_MODULE_18__framework_ui_input_elements_file__["a" /* $init */])(target);

  // image lazy load
  Object(__WEBPACK_IMPORTED_MODULE_20__framework_ui_image_image_lazy__["a" /* $init */])(target);

  // image map
  Object(__WEBPACK_IMPORTED_MODULE_19__framework_ui_image_image_remap__["a" /* $init */])(target);

  // image auto fit (ckeditor)
  Object(__WEBPACK_IMPORTED_MODULE_21__framework_ui_image_image_fit__["a" /* $init */])(target);

  // view size
  Object(__WEBPACK_IMPORTED_MODULE_22__framework_ui_shared_viewSize_viewSize__["a" /* $init */])(target);

  // lightbox
  Object(__WEBPACK_IMPORTED_MODULE_23__framework_ui_modal_dialogs_lightbox__["a" /* $init */])(target);

  //popovers
  __WEBPACK_IMPORTED_MODULE_3__framework_ui_shared_popover_popover__["a" /* Popover */].$init(target);

  //scrollLock
  __WEBPACK_IMPORTED_MODULE_7__framework_ui_shared_scrollLock_scrollLock__["a" /* ScrollLock */].$init(target);

  //togglers
  __WEBPACK_IMPORTED_MODULE_4__framework_ui_shared_toggler_toggler__["a" /* Toggler */].$init(target);

  //toggle sheets
  __WEBPACK_IMPORTED_MODULE_6__framework_ui_shared_toggleSheet_toggleSheet__["a" /* ToggleSheet */].$init(target);

  //nav
  __WEBPACK_IMPORTED_MODULE_9__framework_ui_nav_nav__["a" /* Nav */].$init(target);

  //searchable
  __WEBPACK_IMPORTED_MODULE_8__framework_ui_input_searchable_searchable__["a" /* Searchable */].$init(target);

  //tabs
  __WEBPACK_IMPORTED_MODULE_10__framework_ui_tabs_tabs__["a" /* Tabs */].$init(target);

  //gauge
  __WEBPACK_IMPORTED_MODULE_11__framework_ui_gauge_gauge__["a" /* Gauge */].$init(target);

  //slider
  __WEBPACK_IMPORTED_MODULE_12__framework_ui_slider_slider__["a" /* Slider */].$init(target);

  //loader
  __WEBPACK_IMPORTED_MODULE_13__framework_ui_spinner_loader__["a" /* Loader */].$init(target);

  //swiper
  __WEBPACK_IMPORTED_MODULE_14__framework_ui_swiper_swiper__["a" /* Swiper */].$init(target);

  //validate form
  __WEBPACK_IMPORTED_MODULE_15__framework_ui_form_validate_form__["a" /* ValidateForm */].$init(target);

  //MUST BE LAST: in case it references any initialized modules.
  Object(__WEBPACK_IMPORTED_MODULE_24__framework_ui_form_clonable_field__["b" /* $prePopulate */])();
}

var _drawPoints = null;
function CustomizeHighCharts(highcharts) {
  _drawPoints = _drawPoints || highcharts.Series.prototype.drawPoints;
  highcharts.Series.prototype.drawPoints = function () {
    if (!this.chart.userOptions.noPoints) {
      _drawPoints.call(this);
    }
  };
}

/***/ }),
/* 31 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return Modal; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__ui_scripts__ = __webpack_require__(30);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__ = __webpack_require__(80);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__dialogs_modal_alert__ = __webpack_require__(81);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_5__dialogs_modal_alert__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__dialogs_modal_confirm__ = __webpack_require__(82);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return __WEBPACK_IMPORTED_MODULE_6__dialogs_modal_confirm__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__dialogs_modal_promo__ = __webpack_require__(83);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return __WEBPACK_IMPORTED_MODULE_7__dialogs_modal_promo__["a"]; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__dialogs_modal_file__ = __webpack_require__(84);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return __WEBPACK_IMPORTED_MODULE_8__dialogs_modal_file__["a"]; });
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }







var _singleton = void 0;
var Modal = function (_UIControl) {
  _inherits(Modal, _UIControl);

  function Modal() {
    var _ret;

    var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
        _ref$buttons = _ref.buttons,
        buttons = _ref$buttons === undefined ? [] : _ref$buttons,
        _ref$focus = _ref.focus,
        focus = _ref$focus === undefined ? {} : _ref$focus,
        _ref$on = _ref.on,
        on = _ref$on === undefined ? {} : _ref$on,
        _ref$buttonsVertical = _ref.buttonsVertical,
        buttonsVertical = _ref$buttonsVertical === undefined ? false : _ref$buttonsVertical,
        _ref$closable = _ref.closable,
        closable = _ref$closable === undefined ? true : _ref$closable,
        _ref$closableByDimmer = _ref.closableByDimmer,
        closableByDimmer = _ref$closableByDimmer === undefined ? true : _ref$closableByDimmer,
        _ref$data = _ref.data,
        data = _ref$data === undefined ? {} : _ref$data;

    _classCallCheck(this, Modal);

    var config = { buttons: buttons, focus: focus, on: on, buttonsVertical: buttonsVertical, closable: closable, closableByDimmer: closableByDimmer, data: data };
    var element = __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["a" /* build */]();

    var _this = _possibleConstructorReturn(this, (Modal.__proto__ || Object.getPrototypeOf(Modal)).call(this, element, config));

    if (!_singleton) {
      _singleton = _this;
    } else {
      _singleton._.cfg = config;
    }
    __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["d" /* init */](_singleton);
    return _ret = _singleton, _possibleConstructorReturn(_this, _ret);
  }

  /**
   * Exposes Modal Singleton Instance.
   */


  _createClass(Modal, [{
    key: 'show',

    /**
     *
     * @param {Object} options Various options for preparing the modal contents
     *    {Boolean} bind  Whether to bind BaytUI modules - default is `false`.
     *    {Boolean} load  Whether to load external scripts - default is `false`.
     *    {Function} callback  A callback function to invoke when all is loaded and the dialog is about to be open.
     */
    value: function show() {
      var _this2 = this;

      var _ref2 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          _ref2$bind = _ref2.bind,
          bind = _ref2$bind === undefined ? false : _ref2$bind,
          _ref2$load = _ref2.load,
          load = _ref2$load === undefined ? false : _ref2$load,
          _ref2$callback = _ref2.callback,
          callback = _ref2$callback === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["NOOP"] : _ref2$callback;

      __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["init"](this.el, {
        bind: bind, load: load,
        before: function () {
          _this2.Waiting = true;
        }, after: function () {
          if (!__WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["resolveFn"](callback, __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["NOOP"]).call(_this2)) {
            _this2.Waiting = false;
          }
        }
      });

      __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["e" /* open */](this);
      return this;
    }
  }, {
    key: 'showGallery',
    value: function showGallery() {
      var images = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
      var currentUrl = arguments[1];

      __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["f" /* openGallery */](this, images, currentUrl);
      return this;
    }
  }, {
    key: 'hide',
    value: function hide() {
      __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["b" /* close */](this);
      __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["c" /* closeGallery */](this);
      return this;
    }
  }, {
    key: 'dispose',
    value: function dispose() {
      this.hide();
      _get(Modal.prototype.__proto__ || Object.getPrototypeOf(Modal.prototype), 'dispose', this).call(this);
    }
  }, {
    key: 'Banner',
    set: function (url) {
      var element = false;
      if (__WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["isStr"](url)) {
        element = __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["htmlToElement"]('<img src="' + url + '">');
      } else if (url instanceof HTMLElement) {
        element = url;
      }
      __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["h" /* updateElement */]('banner', element);
    }
  }, {
    key: 'Header',
    set: function (element) {
      if (__WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["isStr"](element)) {
        element = __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["htmlToElement"]('<div>' + element + '</div>');
      }
      __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["h" /* updateElement */]('head', element);
    }
  }, {
    key: 'Body',
    set: function (element) {
      if (__WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["isStr"](element)) {
        element = __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["htmlToElement"]('<div>' + element + '</div>');
      }
      __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["h" /* updateElement */]('body', element);
    }
  }, {
    key: 'Footer',
    set: function (element) {
      if (__WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["isStr"](element)) {
        element = __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["htmlToElement"]('<div>' + element + '</div>');
      }
      __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["h" /* updateElement */]('foot', element);
    }
  }, {
    key: 'Waiting',
    set: function (value) {
      __WEBPACK_IMPORTED_MODULE_3__dialogs_modal_core__["g" /* toggleLoading */](this, this._.w = value);
    },
    get: function () {
      return this._.w;
    }
  }], [{
    key: 'Current',
    get: function () {
      return _singleton || new Modal();
    }
  }]);

  return Modal;
}(__WEBPACK_IMPORTED_MODULE_4__shared_base_ui_control__["a" /* UIControl */]);






__WEBPACK_IMPORTED_MODULE_2__shared_data_registry__["a" /* SET__TYPE__ */](Modal, 'modal');

/***/ }),
/* 32 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ValidateForm; });
/* harmony export (immutable) */ __webpack_exports__["c"] = ValidatorTrim;
/* harmony export (immutable) */ __webpack_exports__["b"] = ValidatorGetValue;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__validators_validator_required__ = __webpack_require__(69);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__validators_validator_regex__ = __webpack_require__(41);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__validators_validator_range__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__validators_validator_compare__ = __webpack_require__(71);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__validators_validator_captcha__ = __webpack_require__(72);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__validate_form_redirect__ = __webpack_require__(73);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }












var VALDIATORS_LIST = {
  required: __WEBPACK_IMPORTED_MODULE_3__validators_validator_required__["a" /* required */],
  regex: __WEBPACK_IMPORTED_MODULE_4__validators_validator_regex__["b" /* regex */],
  range: __WEBPACK_IMPORTED_MODULE_5__validators_validator_range__["a" /* range */],
  compare: __WEBPACK_IMPORTED_MODULE_6__validators_validator_compare__["a" /* compare */],
  captcha: __WEBPACK_IMPORTED_MODULE_7__validators_validator_captcha__["a" /* captcha */]
  // validation status
};var STATUS_EMPTY = 0,
    STATUS_VALIDATED = 1,
    STATUS_PENDING_VALIDATION = 2,
    STATUS_VALIDATING = 3;

// validation trigger (flags)
var ON_SUBMIT = 1,
    ON_CHANGE = 2,
    ON_TYPE = 4;

var DEFAULTS = {
  param: 'ajax',
  url: undefined,
  delay: 200,
  trigger: ON_SUBMIT,
  hideMsgs: true,
  container: undefined,
  css: {
    success: undefined,
    error: 'has-error',
    validating: undefined
  },
  summary: undefined,
  timer: undefined,
  hooks: {
    before: undefined, // function (form, attribute) | boolean
    after: undefined, // function (form, attribute, data, hasError)
    attrBefore: undefined, // function (form) | boolean
    attrAfter: undefined // function (form, data, hasError) | boolean
  },
  allowEmpty: false,
  trim: true,
  focus: undefined,
  attrs: [],
  onerror: undefined,
  focusFirstError: true,
  focusOffset: 100
};

var WHEN_CHECKS = {
  //checks if val equals to any of the provided vals
  '=': function (val, vals) {
    return vals.find(function (v) {
      return v == val;
    }) !== undefined;
  },
  //checks if val contains any of the provided vals
  '*': function (val, vals) {
    return vals.find(function (v) {
      return val.indexOf(v) > -1;
    }) !== undefined;
  },
  //checks if val starts with any of the provided vals
  '^': function (val, vals) {
    return vals.find(function (v) {
      return val.startsWith(v);
    }) !== undefined;
  },
  //checks if val ends with any of the provided vals
  '$': function (val, vals) {
    return vals.find(function (v) {
      return val.endsWith(v);
    }) !== undefined;
  }
};

var ValidateForm = function (_UIControl) {
  _inherits(ValidateForm, _UIControl);

  _createClass(ValidateForm, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */].$init(target, ValidateForm);
    }
  }, {
    key: 'getValue',
    value: function getValue(element) {
      return ValidatorGetValue(element);
    }
  }]);

  function ValidateForm(element, config) {
    _classCallCheck(this, ValidateForm);

    var _this = _possibleConstructorReturn(this, (ValidateForm.__proto__ || Object.getPrototypeOf(ValidateForm)).call(this, element, __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["merge"](true, {}, DEFAULTS, config)));

    if (_this.config.url === undefined) {
      _this.config.url = _this.el.getAttribute('action');
    }
    //holds reference for the clicked submit button
    Object.assign(_this._, { button: null });
    extendAttributesConfig(_this.config);

    _this.config.submitting = false;

    init.bind(_this)();
    return _this;
  }

  _createClass(ValidateForm, [{
    key: 'isValid',
    get: function () {
      return this._.validated;
    }
  }]);

  return ValidateForm;
}(__WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */]);

__WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["a" /* SET__TYPE__ */](ValidateForm, 'validate-form');

function ValidatorTrim() {
  var s = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';

  var m = s.match(/^\s*(\S+(\s+\S+)*)\s*$/);
  return m == null ? "" : m[1];
}

function getTinyMCE(element) {
  if (element.tagName.toLowerCase() === 'textarea' && typeof tinymce !== 'undefined') return tinymce.editors[element.id];
}

function ValidatorGetValue(element) {
  var type = void 0,
      c = [];
  if (!element) {
    return undefined;
  }
  var editor = getTinyMCE(element);
  if (editor) {
    return editor.getContent({ format: 'text' });
  } else if (element.tagName.toLowerCase() === 'span') {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"](':checked', function (checked) {
      c.push(checked.value);
    }, element);
    return c.join(',');
  }
  type = element.type;
  if (type === 'checkbox' || type === 'radio') {
    return element.checked && element.value || undefined;
  } else {
    return element.value;
  }
}

function setFocus(form, config) {
  if (config.focus !== undefined && !window.location.hash) {
    var focus = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](config.focus, form);
    focus && focus.focus();
  }
}

function getInputContainer(attribute, form, inputID) {
  var selector = attribute.container || 'div';
  return __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + (inputID || attribute.inputID), form).closest(selector);
}

function getInputReplacement(attribute, form, inputID) {
  var suffix = attribute.rsuffix || '__r';
  return __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + (inputID || attribute.inputID) + suffix, form);
}

function clearClasses(elements, classes) {
  var cb = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function () {
    return true;
  };

  elements.forEach(function (el) {
    el && cb(el) && __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["remClasses"].apply(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__, [el].concat(_toConsumableArray(classes)));
  });
}
function updateInput(attribute, messages, form, config) {
  attribute.status = STATUS_EMPTY; // 1;
  var hasError = messages !== null && messages[attribute.id] instanceof Array && messages[attribute.id].length > 0,
      inputElement = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + attribute.inputID, form);
  if (inputElement) {
    var errorElement = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + attribute.errorID, form),
        containerElement = getInputContainer(attribute, form),
        replacementElement = getInputReplacement(attribute, form),
        editor = getTinyMCE(inputElement),
        _attribute$css = attribute.css,
        cssSuccess = _attribute$css.success,
        cssError = _attribute$css.error,
        cssValidating = _attribute$css.validating,
        related = attribute.related || [],
        relatedElements = [];

    //remove all validation classes from both element, container.
    clearClasses([inputElement, containerElement, replacementElement, editor && editor.getContainer()], [cssValidating, cssError, cssSuccess]);

    related.forEach(function (id) {
      var input = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + id),
          inputContainer = getInputContainer(attribute, form, id),
          inputReplacement = getInputReplacement(attribute, form, id);
      clearClasses([input, inputContainer, inputReplacement], [cssValidating, cssError, cssSuccess], function (e) {
        return relatedElements.push(e);
      });
    });

    if (hasError) {
      // add error classes
      errorElement && (errorElement.innerHTML = messages[attribute.id][0]);
      if (cssError) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"](cssError, containerElement, replacementElement, inputElement, editor && editor.getContainer());
        relatedElements.forEach(function (el) {
          return __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"](cssError, el);
        });
      }
    } else if (attribute.ajax || attribute.config) {
      //add success classes
      if (cssSuccess) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"](cssSuccess, containerElement, replacementElement, inputElement);
        relatedElements.forEach(function (el) {
          return __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"](cssSuccess, el);
        });
      }
    }
    if (errorElement && attribute.hide) {
      errorElement.style.display = hasError ? '' : 'none';
    }
    attribute.value = ValidatorGetValue(inputElement);
  }
  return hasError;
}

function updateSummary(form, messages, config) {
  var content = '';
  if (config.summary === undefined) {
    return;
  }
  if (messages) {
    var summaryAttributes = [];
    for (var i in config.attrs) {
      if (config.attrs[i].summary) {
        summaryAttributes.push(config.attrs[i].id);
      }
    }
    config.attrs.forEach(function (v, i) {
      if (summaryAttributes.indexOf(v.id) !== -1 && messages[v.id] instanceof Array) {
        messages[v.id].forEach(function (m, i) {
          content = content + '<li>' + m + '</li>';
        });
      }
    });
  }
  if (config.summary) {
    var summary = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](config.summary);
    if (summary) {
      var ul = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('ul', summary);
      ul && (ul.innerHTML = content);
      summary.style.display = content ? '' : 'none';
    }
  }
}

function validateForm(form, config, successCallback, errorCallback, submitButton) {
  var needAjaxValidation = false,
      messages = Object.create(null),
      firstError = false;

  config.attrs.forEach(function (attr, indx) {
    var value = void 0,
        msgs = [];
    if (!attr.disabled && attr.config !== undefined && attr.config.length && (config.submitting || attr.status === STATUS_PENDING_VALIDATION /*2*/ || attr.status === STATUS_VALIDATING /*3*/)) {
      //get value
      value = ValidatorGetValue(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + attr.inputID, form));
      //common validation logic
      var trimmed = attr.trim ? ValidatorTrim(value) : value;
      // [1] if empty and allowEmpty => VALID
      if (attr.allowEmpty && !trimmed.length) {
        return;
      }
      //do client validation
      attr.config.forEach(function (config) {

        // [2] If validator depends on another field AND checker returns false => VALID
        var _config$when = config.when;
        _config$when = _config$when === undefined ? {} : _config$when;
        var _config$when$id = _config$when.id,
            when_id = _config$when$id === undefined ? null : _config$when$id,
            _config$when$op = _config$when.op,
            when_op = _config$when$op === undefined ? '=' : _config$when$op,
            _config$when$vals = _config$when.vals,
            when_vals = _config$when$vals === undefined ? [] : _config$when$vals,
            _config$when$btn = _config$when.btn,
            btn = _config$when$btn === undefined ? false : _config$when$btn;

        // [3] If validator depends on a specific button AND button does not match => VALID

        if (btn && submitButton && btn != submitButton.value) return;

        if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](when_id)) {
          var when_value = ValidatorGetValue(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + when_id));
          // when check does matches
          if (!__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](when_op, function () {
            return __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](when_op, function () {
              return true;
            }).apply(config, arguments);
          }, WHEN_CHECKS).call(config, when_value, when_vals, attr)) {
            return;
          }
        }

        var fn = VALDIATORS_LIST[config.fn] || __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](config.fn);
        if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](fn)) {
          fn(trimmed, msgs, attr, config);
          if (msgs.length) {
            messages[attr.id] = msgs;
            if (!firstError) {
              firstError = attr.inputID;
            }
          }
        }
      });
    }
    if (attr.ajax && !msgs.length && (config.submitting || attr.status === STATUS_PENDING_VALIDATION /*2*/ || attr.status === STATUS_VALIDATING /*3*/)) {
      needAjaxValidation = true;
    }
  });

  if (!needAjaxValidation || config.submitting && !Object.keys(messages).length) {
    if (config.submitting) {
      successCallback(messages, firstError);
    } else {
      successCallback(messages, firstError);
    }
    return;
  }

  //var $button = $form.data('submitObject'),
  /* let extData = '&' + config.ajaxVar + '=' + form.getAttribute('id')
    if ($button && $button.length) {
      extData += '&' + $button.attr('name') + '=' + $button.attr('value');
    }
    */
  var data = new FormData(form);
  data.append(config.param, form.id);
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["ajax"]({
    url: config.url,
    type: form.getAttribute('method'),
    data: data,
    success: function (data) {
      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isObj"](data)) {
        config.attrs.forEach(function (attr, i) {
          if (!attr.ajax) {
            delete data[attr.id];
          }
        });
        successCallback(Object.assign({}, messages, data), firstError);
      } else {
        successCallback(messages, firstError);
      }
    },
    error: function () {
      if (errorCallback !== undefined) {
        errorCallback(firstError);
      }
    }
  });
}

function extendAttributesConfig(config) {
  config.attrs.forEach(function (attr, i) {
    var model = attr.model || config.model;

    attr = config.attrs[i] = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["merge"](true, {
      id: model + '_' + attr.name,
      inputID: model + '_' + attr.name,
      errorID: model + '_' + attr.name + '_em_',
      delay: config.delay,
      trigger: config.trigger,
      hide: config.hideMsgs,
      allowEmpty: config.allowEmpty,
      trim: config.trim,
      container: config.container,
      onerror: config.onerror,
      css: config.css,
      hooks: { before: config.attrBefore, after: config.attrAfter }
    }, attr);

    attr.value = ValidatorGetValue(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + attr.inputID));
  });
}

function init() {
  var _this2 = this;

  this._.button = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[type="submit"]', this.el);
  if (this.config.multiSubmit) __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[type="submit"]', function (btn) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this2, btn, 'click', function (e) {
      return _this2._.button = e.target;
    });
  }, this.el);

  var validate = function (attribute, forceValidate) {
    if (forceValidate) {
      attribute.status = STATUS_PENDING_VALIDATION; //2
    }

    _this2.config.attrs.forEach(function (attr) {
      if (attr.value !== ValidatorGetValue(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + attr.inputID))) {
        attr.status = STATUS_PENDING_VALIDATION; //2
        forceValidate = true;
      }
    });

    if (!forceValidate) {
      return;
    }

    if (_this2.config.timer !== undefined) {
      clearTimeout(_this2.config.timer);
    }

    _this2.config.timer = setTimeout(function () {
      if (_this2.config.submitting || !__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isVisible"](_this2.el)) {
        return;
      }
      var beforeValidateAttribute = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](attribute.hooks.before);
      if (beforeValidateAttribute === undefined || beforeValidateAttribute.call(_this2, _this2.el, attribute)) {
        _this2.config.attrs.forEach(function (attr) {
          if (attr.status === STATUS_PENDING_VALIDATION /*2*/) {
              attr.status = STATUS_VALIDATING; //3
              var containerElement = getInputContainer(attr, this.el);
              containerElement && attr.css.validating && containerElement.classList.add(attr.css.validating);
            }
        }, _this2); //each

        validateForm(_this2.el, _this2.config, function (msgs) {
          var hasError = false;
          _this2.config.attrs.forEach(function (attr, i) {
            if (attr.status === STATUS_PENDING_VALIDATION /*2*/ || attr.status === STATUS_VALIDATING /*3*/) {
                hasError = updateInput(attr, msgs, this.el) || hasError;
              }
          }, _this2);
          var afterValidateAttribute = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](attribute.hooks.after);
          afterValidateAttribute && afterValidateAttribute.call(_this2, _this2.el, attribute, msgs, hasError);
        }, _this2.config.onerror, _this2._.button);
      }
    }, attribute.delay);
  };

  //Hook events

  // per attriubte
  this.config.attrs.forEach(function (attr, i) {
    var inputElement = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + attr.inputID, this.el);
    if (inputElement) {
      if ((attr.trigger & ON_CHANGE) == ON_CHANGE) {
        //.validateOnChange
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, inputElement, 'change', function () {
          validate(attr, false);
        });
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, inputElement, 'blur', function () {
          if (attr.status !== STATUS_PENDING_VALIDATION /*2*/ && attr.status !== STATUS_VALIDATING /*3*/) {
              validate(attr, !attr.status);
            }
        });
      }
      if ((attr.trigger & ON_TYPE) == ON_TYPE) {
        //.validateOnType
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, inputElement, 'keyup', function () {
          if (attr.value !== ValidatorGetValue(inputElement)) {
            validate(attr, false);
          }
        });
      }
    } //inputElement
  }, this);

  // per form
  if ((this.config.trigger & ON_SUBMIT) == ON_SUBMIT) {
    //.validateOnSubmit
    this._.validated = false;
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this.el, 'submit', function (e) {
      if (_this2._.validated) {
        _this2._.validated = false;
        return e.returnValue = true;
      }
      if (_this2.config.timer !== undefined) {
        clearTimeout(_this2.config.timer);
      }
      _this2.config.submitting = true;
      var beforeValidate = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](_this2.config.hooks.before);
      if (beforeValidate === undefined || beforeValidate.call(_this2, _this2.el)) {
        validateForm(_this2.el, _this2.config, function (msgs, firstError) {
          var hasError = false;
          _this2.config.attrs.forEach(function (attr, i) {
            hasError = updateInput(attr, msgs, _this2.el, _this2.config) || hasError;
          });
          updateSummary(_this2.el, msgs, _this2.config);
          //focus first error
          if (_this2.config.focusFirstError && firstError) {
            var errorInput = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + firstError);
            if (errorInput) {
              var editor = getTinyMCE(errorInput);
              if (editor) {
                editor.focus();
              } else if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isVisible"](errorInput)) {
                errorInput.focus && errorInput.focus();
              } else {
                //find first visible element
                while (errorInput && !__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isVisible"](errorInput)) {
                  errorInput = errorInput.parentElement;
                }
                errorInput && errorInput.scrollIntoView();
              }
              //ensure nav offset is handled
              if (errorInput) {
                var offset = _this2.config.focusOffset;
                if (isNaN(offset)) {
                  offset = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](offset, function () {
                    return 0;
                  }).call(_this2);
                }
                window.scrollTo(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["getScrollLeft"](), __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["getScrollTop"]() - (!isNaN(offset) ? offset : 0));
              }
            }
          }
          var afterValidate = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](_this2.config.hooks.after);
          if (afterValidate === undefined || afterValidate.call(_this2, _this2.el, msgs, hasError)) {
            if (!hasError) {
              _this2._.validated = true;
              // when a form has a button named 'submit', it will override the `submit()` method
              // this is a workaround to submit the form.

              // The below causes the submit button not to be included in the post
              // Do not use it.

              //HTMLFormElement.prototype.submit.call(this.el)
              if (_this2.config.redirect) {
                _this2._.validated = false;
                var url = Object(__WEBPACK_IMPORTED_MODULE_8__validate_form_redirect__["a" /* transform */])(_this2.config.redirect);
                if (url !== false) {
                  location.href = url;
                }
              } else {
                // delay so that the form can be submitted without problem
                setTimeout(function () {
                  //let btn = Utils.get('[type="submit"]', this.el)
                  if (_this2._.button) {
                    _this2._.button.click();
                  } else {
                    _this2.el.submit();
                  }
                }, 200);
              }

              // Old code from existing yii validation.

              // var $button = $form.data('submitObject') || $form.find(':submit:first');
              // // TODO: if the submission is caused by "change" event, it will not work
              // if ($button.length) {
              //   $button.click();
              // } else {  // no submit button in the form
              //   $form.submit();
              // }
              return;
            }
          }
          _this2.config.submitting = false;
        }, _this2.config.onerror, _this2._.button);
      } else {
        _this2.config.submitting = false;
      }
      e.preventDefault();
      return e.returnValue = false;
    });
  }

  // In case of reseting the form we need to reset error messages
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this.el, 'reset', function () {
    /*
     * because we bind directly to a form reset event, not to a reset button (that could or could not exist),
     * when this function is executed form elements values have not been reset yet,
     * because of that we use the setTimeout
     */
    setTimeout(function () {
      _this2.config.attrs.forEach(function (attr, i) {
        attr.status = STATUS_EMPTY /*0*/;
        var errorElement = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + attr.errorID, _this2.el),
            containerElement = getInputContainer(attr, _this2.el);

        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["remClasses"](containerElement, attr.css.validating, attr.css.error, attr.css.success);

        if (errorElement) {
          errorElement.innerHTML = '';
          errorElement.style.display = 'none';
        }
        /*
         * without the setTimeout() we would get here the current entered value before the reset instead of the reseted value
         */
        attr.value = ValidatorGetValue(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + attr.inputID, _this2.el));
      });
      /*
       * If the form is submited (non ajax) with errors, labels and input gets the class 'error'
       */
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('.has-error', function (element) {
        element.classList.remove(_this2.config.css.error);
      }, _this2.el);
      // $form.find('label, :input').each(function () {
      //   $(this).removeClass(settings.errorCss);
      // });
      if (_this2.config.summary) {
        var summary = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](_this2.config.summary);
        if (summary) {
          var ul = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('ul', summary);
          if (ul) {
            ul.innerHTML = '';
          }
          summary.style.display = 'none';
        }
      }
      //.. set to initial focus on reset
      setFocus(_this2.el, _this2.config);
    }, 1);
  });

  /*
   * set to initial focus
   */
  setFocus(this.el, this.config);
}

/***/ }),
/* 33 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Control; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }



var Control = function () {
  /**
   * Initializes a new Control instance
   */
  function Control() {
    var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    _classCallCheck(this, Control);

    this._ = {
      cfg: config,
      ev: __WEBPACK_IMPORTED_MODULE_0__utils_main__["createEventStrore"]()
    };
  }

  /**
   * Gets the events store
   */


  _createClass(Control, [{
    key: 'dispose',


    /**
     * Disposes this Control
     */
    value: function dispose() {
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["detachAllEvents"](this);
    }
  }, {
    key: '_events',
    get: function () {
      return this._.ev;
    }

    /**
     * Gets the type name of this instance
     */

  }, {
    key: '_type',
    get: function () {
      console.log('inside _type', this._.type, this.constructor.__TYPE__);
      return this.constructor.__TYPE__;
      //return this._.type
    }
  }]);

  return Control;
}();

/***/ }),
/* 34 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Popover; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__blurfix_blurfix__ = __webpack_require__(39);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__capture_capture__ = __webpack_require__(36);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__base_ui_control__ = __webpack_require__(1);
var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }







var TYPE = 'popover',
    BOUND = 'bound',
    ATTR_CLOSE = 'data-popover-close',
    DEFAULTS = {
  trigger: 'hover',
  relocate: false,
  transition: true
},
    openPopovers = [];
var toggleCache = null;
function toggle(target) {
  if (toggleCache && !toggleCache.owner.contains(target) && !toggleCache.el.contains(target)) {
    toggleCache.close();
    return true;
  }
  return false;
}

function bindClose() {
  var _this = this;

  __WEBPACK_IMPORTED_MODULE_0__utils_main__["find"]('[' + ATTR_CLOSE + ']', function (close) {
    var isBound = close.attr(ATTR_CLOSE);
    if (isBound != BOUND) {
      close.attr(ATTR_CLOSE, BOUND);
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](_this, close, 'click', function (e) {
        e.preventDefault();
        _this.close();
      });
    }
  }, this.el);
}
function unbindClose() {
  __WEBPACK_IMPORTED_MODULE_0__utils_main__["find"]('[' + ATTR_CLOSE + ']', function (close) {
    var isBound = close.attr(ATTR_CLOSE);
    if (isBound == BOUND) {
      close.attr(ATTR_CLOSE, '');
    }
  }, this.el);
}

function bind() {
  var _this2 = this;

  if (!this._.bound && (this._.bound = true)) {
    this._.owner = this.el.closest('.popover-owner');

    //
    //  copy instance id from element to owner
    //  without this multiple instances of popover will be created
    //
    var attr = 'data-bayt-' + TYPE;
    this._.owner.attr(attr, this.el.attr(attr));
    this.el.removeAttribute(attr);

    if (this.config.placement) {
      this.placement = this.config.placement;
    }

    var clickHandler = function (e) {
      if (e.target === _this2.owner || _this2.owner.contains(e.target) && !_this2.el.contains(e.target)) {
        //(e.target).parentElement === this.owner || (e.target).parentElement.parentElement === this.owner) {
        e.preventDefault();
        e.stopPropagation();
        if (e.type == 'mouseenter') {
          _this2.open();
        } else if (e.type == 'mouseleave') {
          _this2.close();
        } else {
          !_this2.active ? _this2.open() : _this2.close();
        }
      }
    };

    if (this.config.trigger === 'click') {
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.owner, 'click', clickHandler);
    } else if (this.config.trigger !== 'none') {
      //hover
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.owner, 'mouseenter', function (e) {
        if (!__WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]()) clickHandler(e);
      });
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.owner, 'mouseleave', function (e) {
        if (!__WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]()) clickHandler(e);
      });
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.owner, 'click', function (e) {
        // console.log('is-mobile', Utils.isMobile())
        if (__WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]()) clickHandler(e);
      });
    }

    bindClose.call(this);
  }
}

function unbind() {
  var attr = 'data-bayt-' + TYPE;
  this.el.attr(attr, this._.owner.attr(attr));
  this._.owner.removeAttribute(attr);

  __WEBPACK_IMPORTED_MODULE_0__utils_main__["detachAllEvents"](this);
  unbindClose.call(this);
  this._.bound = false;
}

var Popover = function (_MixinCapture) {
  _inherits(Popover, _MixinCapture);

  _createClass(Popover, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_4__base_ui_control__["a" /* UIControl */].$init(target, Popover);
    }
  }, {
    key: '$trackPopovers',
    value: function $trackPopovers() {

      window.addEventListener('resize', function () {
        if (openPopovers.length && __WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]() != openPopovers.isMobile) {
          openPopovers.locked = true;
          while (openPopovers.length) {
            openPopovers.pop().close(true);
          }
          openPopovers.locked = false;
        }
      });

      document.addEventListener('touchstart', function (e) {
        if (toggle(e.target)) {
          toggleCache = null;
        }
      });

      document.addEventListener('click', function (e) {
        if (toggle(e.target)) toggleCache = null;
      });

      document.addEventListener('b8._popover.open', function (e) {
        var control = e.detail && e.detail.control;
        if (control) {
          if (!control.owner.parentElement.closest('.popover-owner') && !(__WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]() && control.inline)) {
            toggle(e.target);
            toggleCache = control;
          }

          if (!openPopovers.length) {
            openPopovers.isMobile = __WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]();
          }
          openPopovers.push(control);
        }
      });

      document.addEventListener('b8._popover.close', function (e) {
        if (!openPopovers.locked) {
          var control = e.detail && e.detail.control;
          if (control) {
            var i = openPopovers.indexOf(control);
            if (i > -1) {
              openPopovers.splice(i, 1)[0];
            }
          }
        }
      });
    }
  }, {
    key: '$closeOthers',
    value: function $closeOthers(instance) {
      var t = instance.owner.closest('.popover');
      if (t) {
        [].forEach.call(t.qsa('.popover-owner'), function (popover) {
          var child = __WEBPACK_IMPORTED_MODULE_1__data_registry__["d" /* resolve */](Popover, popover);
          if (child !== instance) {
            child.active && child.close();
          }
        }, this);
      }
    }
  }, {
    key: '$closeSub',
    value: function $closeSub(instance) {
      var t = instance.owner;
      if (t) {
        [].forEach.call(t.qsa('.popover-owner'), function (popover) {
          var child = __WEBPACK_IMPORTED_MODULE_1__data_registry__["d" /* resolve */](Popover, popover);
          child && child.close(true);
        }, this);
      }
    }
  }]);

  function Popover(element, config) {
    _classCallCheck(this, Popover);

    var _this3 = _possibleConstructorReturn(this, (Popover.__proto__ || Object.getPrototypeOf(Popover)).call(this, element.qs('.popover'), Object.assign({}, DEFAULTS, config)));

    Object.assign(_this3._, {
      bound: false,
      bf: new __WEBPACK_IMPORTED_MODULE_2__blurfix_blurfix__["a" /* BlurFix */]()
    });
    bind.call(_this3);
    return _this3;
  }

  _createClass(Popover, [{
    key: 'open',
    value: function open() {
      var _this4 = this;

      if (this._.bound) {
        Popover.$closeOthers(this);

        if (!this.active) {
          var on = this.config.on,
              one = this.config.one;

          __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchHooks"]('beforeopen', this);

          //WORKAROUND FOR FF
          //- DESKTOP BROWSERS (MOBILE SIZE)
          //- NAV POPOVER ELEMENT IS DISPALYED AT THE WRONG POSITION
          //BEGIN ===>
          // Utils.detachEvent(this, this.el, 'transitionend', { suppress: true })
          // Utils.attachEvent(this, this.el, 'transitionend', (e) => {
          //   console.log('transition ended.')
          //   let display = this.el.style.display;
          //   this.el.style.display = 'none'
          //   let reflow = this.el.offsetWidth * this.el.offsetHeight
          //   this.el.style.display = display
          //   Utils.detachEvent(this, this.el, 'transitionend')
          // })
          //END <===
          if (this.config.transition !== false) {
            this.el.classList.add('has-transition');
          }
          var firingElement = this.el;
          var reflow = this.el.offsetWidth * this.el.offsetHeight || 1;
          if (reflow) {
            if (__WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]() && !this.inline && !!this.config.relocate) {
              //[1] grab parent modal before replacing the element.
              var parentModal = this.el.closest('.modal');

              __WEBPACK_IMPORTED_MODULE_0__utils_main__["replaceElement"](this.el, this.ph);
              document.body.appendChild(this.el);
              //[2] copy z-index from modal and apply to the sub popover on mobile this will cause the popover to show above the modal.
              if (parentModal) {
                this.el.style.zIndex = getComputedStyle(parentModal).zIndex;
              }
              firingElement = this.ph;
              setTimeout(function () {
                _this4.el.classList.add('is-active');
              }, 0);
            }
            this.owner.classList.add('is-active');
          }
          if (!this.inline) {
            this._.bf.attach(this.el);
            this.capture(function () {
              _this4.close();
            });
          }
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchEvent"]('popover.open', this, null, firingElement);

          __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchHooks"]('afteropen', this);
        }
        //new TapTrap().start(this.el)
      }
    }
  }, {
    key: 'close',
    value: function close(selfOnly) {
      if (this._.bound) {
        !selfOnly && Popover.$closeSub(this);
        if (this.active) {
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchHooks"]('beforeclose', this);
          this.owner.classList.remove('is-active');
          this.el.classList.remove('has-transition');
          this._.bf.detach(this.el);

          // text nodes such as comments has no parentElement in IE, thus use parentNode.
          this.ph.parentNode && __WEBPACK_IMPORTED_MODULE_0__utils_main__["replaceElement"](this.ph, this.el);
          this.el.classList.remove('is-active');
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchEvent"]('popover.close', this);
          this.uncapture();
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchHooks"]('afterclose', this);
        }
        //new TapTrap().end(this.el)
      }
    }
  }, {
    key: 'dispose',
    value: function dispose() {
      _get(Popover.prototype.__proto__ || Object.getPrototypeOf(Popover.prototype), 'dispose', this).call(this);
      this._.bf.detach(this.el);
      unbind.call(this);
    }
  }, {
    key: 'active',
    get: function () {
      return this._.bound && this.owner.classList.contains('is-active');
    }
  }, {
    key: 'ph',
    get: function () {
      return this._.ph = this._.ph || document.createComment('ph');
    }
  }, {
    key: 'owner',
    get: function () {
      return this._.owner;
    }
  }, {
    key: 'inline',
    get: function () {
      return this._.bound && this.el.classList.contains('is-inline');
    }
  }, {
    key: 'placement',
    get: function () {
      return this.el.getAttribute('data-placement');
    },
    set: function (p) {
      this.el.setAttribute('data-placement', p);
    }
  }]);

  return Popover;
}(Object(__WEBPACK_IMPORTED_MODULE_3__capture_capture__["a" /* MixinCapture */])(__WEBPACK_IMPORTED_MODULE_4__base_ui_control__["a" /* UIControl */]));

__WEBPACK_IMPORTED_MODULE_1__data_registry__["a" /* SET__TYPE__ */](Popover, TYPE);

/***/ }),
/* 35 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ResizeFire; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__base_control__ = __webpack_require__(33);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils_main__ = __webpack_require__(0);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }




var _template = '<div style="height:0!important"></div>';

/**
 * Helper to prevent text blur in chrome.
 *
 * The resize handler will be called:
 *  [1] upon element resize, arguments (the resize event).
 *  [2] upon attachment, with no arguments.
 *  [3] upon deattachment, arguments (false).
 *
 */
var ResizeFire = function (_Control) {
  _inherits(ResizeFire, _Control);

  function ResizeFire() {
    _classCallCheck(this, ResizeFire);

    var _this = _possibleConstructorReturn(this, (ResizeFire.__proto__ || Object.getPrototypeOf(ResizeFire)).call(this));

    _this.attached = false;
    _this._fix = __WEBPACK_IMPORTED_MODULE_1__utils_main__["htmlToElement"](_template);
    _this._obj;
    _this._resizeHandler;
    return _this;
  }

  _createClass(ResizeFire, [{
    key: 'attach',
    value: function attach(element) {
      var _this2 = this;

      var handler = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : function () {
        return void 0;
      };
      var container = arguments[2];

      if (!this.attached && (this.attached = true)) {
        this._resizeHandler = handler;
        var doAttach = function () {
          if (_this2._obj && _this2._obj.contentDocument) {
            //object loaded, detach the handler
            __WEBPACK_IMPORTED_MODULE_1__utils_main__["detachEvent"](_this2, _this2._obj, 'load', { suppress: true });
            //attach resize listner
            _this2._obj.contentDocument.defaultView.addEventListener('resize', function (e) {
              _this2._resizeHandler(e); //[1]
            });
          }
        };

        // add to element
        container ? container.appendChild(this._fix) : element.appendChild(this._fix);

        // create the resize listener window
        if (!this._obj) {
          this._obj = document.createElement('object');
          this._obj.tabIndex = -1;
          this._obj.setAttribute('style', "left: 0px; top: 0px; width: 100%; height: 100%; overflow: hidden; display: block; position: absolute; z-index: -1; pointer-events: none;opacity:0;");
          __WEBPACK_IMPORTED_MODULE_1__utils_main__["attachEvent"](this, this._obj, 'load', doAttach);
          this._obj.type = 'text/html';
          if (__WEBPACK_IMPORTED_MODULE_1__utils_main__["isIE"]()) this._fix.appendChild(this._obj);
          // set the data after attaching the dom to trigger load event
          this._obj.data = 'about:blank';
          if (!__WEBPACK_IMPORTED_MODULE_1__utils_main__["isIE"]()) this._fix.appendChild(this._obj);
        } else if (!this._obj.contentDocument) {
          __WEBPACK_IMPORTED_MODULE_1__utils_main__["attachEvent"](this, this._obj, 'load', doAttach);
        } else {
          // when remove from DOM, event listener is no longer attached
          // re-attach
          doAttach();
        }
        // call once
        this._resizeHandler(); //[2]
      }
    }
  }, {
    key: 'detach',
    value: function detach(element) {
      if (this.attached) {
        __WEBPACK_IMPORTED_MODULE_1__utils_main__["detachAllEvents"](this);
        this._resizeHandler(false); //[3]
        element.removeChild(this._fix);
        element = null;
        this.attached = false;
      }
    }
  }]);

  return ResizeFire;
}(__WEBPACK_IMPORTED_MODULE_0__base_control__["a" /* Control */]);

/***/ }),
/* 36 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MixinCapture; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }



var noop = function () {
  return void 0;
};
var MixinCapture = function (superclass) {
  var config = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return function (_superclass) {
    _inherits(_class, _superclass);

    function _class() {
      _classCallCheck(this, _class);

      var _this = _possibleConstructorReturn(this, (_class.__proto__ || Object.getPrototypeOf(_class)).apply(this, arguments));

      Object.assign(_this._, {
        capture: {
          active: false,
          callback: noop,
          check: function () {
            return true;
          },
          target: undefined,
          //default capture on mobile only.
          className: config.mode === '*' ? 'js-capture' : config.mode === 'd' ? 'js-capture-d' : 'js-capture-m'
        }
      });
      return _this;
    }

    _createClass(_class, [{
      key: 'capture',
      value: function capture(callback, check) {
        var _this2 = this;

        if (!this._.capture.active) {
          this._.capture.active = true;
          var target = this._.capture.target = this.el.closest('[data-capture]') || document.body;
          var count = parseInt(target.getAttribute('data-capture-count')) || 0;
          target.classList.add(this._.capture.className);
          target.setAttribute('data-capture-count', ++count);
          this._.capture.callback = callback || noop;
          if (__WEBPACK_IMPORTED_MODULE_0__utils_main__["isFn"](check)) {
            this._.capture.check = check;
          }
          var hanlder = function (e) {
            if (e.target === target && _this2._.capture.check(e)) {
              e.preventDefault();
              _this2.uncapture(true);
            }
          };
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, target, 'touchstart', hanlder);
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, target, 'click', hanlder);
        }
      }
    }, {
      key: 'uncapture',
      value: function uncapture(doCallback) {
        if (this._.capture.active) {
          this._.capture.active = false;
          var target = this._.capture.target;
          var count = parseInt(target.getAttribute('data-capture-count')) || 0;
          if (--count == 0) {
            target.classList.remove(this._.capture.className);
          }
          target.setAttribute('data-capture-count', count);
          doCallback && this._.capture.callback();
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["detachEvent"](this, target, 'touchstart', { suppress: true });
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["detachEvent"](this, target, 'click', { suppress: true });
        }
      }
    }]);

    return _class;
  }(superclass);
};

/***/ }),
/* 37 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return WHEEL_EVENT_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ScrollLock; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__base_ui_control__ = __webpack_require__(1);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }





var DEFAULTS = {
  strict: false,
  strictFn: function (element) {
    return element.scrollHeight > this.clientHeightFn(element);
  },
  clientHeightFn: function (element) {
    var pseudoBefore = parseInt(getComputedStyle(element, ':before').height),
        pseudoAfter = parseInt(getComputedStyle(element, ':after').height);
    return Math.max(pseudoBefore || 0, pseudoAfter || 0, element.clientHeight);
  },
  selector: false,
  touch: __WEBPACK_IMPORTED_MODULE_0__utils_main__["isTouch"](),
  keyboard: false,
  unblock: undefined
},
    WHEEL_EVENT_NAME = 'onwheel' in document.createElement('div') ? 'wheel' : // Modern browsers support "wheel"
document.onmousewheel !== undefined ? 'mousewheel' : // Webkit and IE support at least "mousewheel"
'DOMMouseScroll' // let's assume that remaining browsers are older Firefox,


,
    UNBLOCK_HANDLER = function (e) {
  e.unblockTarget = e.delegateTarget;
},
    TOUCH_HANDLER = function (instance, e) {
  instance._.startClientY = e.touches[0].clientY;
},
    PROCESS_SCROLL_EVENT = function (instance, event, element, startClientY) {
  var scrollTop = element.scrollTop,
      scrollHeight = element.scrollHeight,
      clientHeight = instance.config.clientHeightFn(element),
      delta = event.wheelDelta || -1 * event.detail || -1 * event.deltaY,
      deltaY = 0;
  if (event.type === 'wheel') {
    var ratio = element.offsetHeight / window.innerHeight;
    deltaY = event.deltaY * ratio;
  } else if (instance.config.touch && event.type === 'touchmove') {
    delta = event.changedTouches[0].clientY - startClientY;
  }
  var top, prevent;
  prevent = (top = delta > 0 && scrollTop + deltaY <= 0) || delta < 0 && scrollTop + deltaY >= scrollHeight - clientHeight;
  return { prevent: prevent, top: top, scrollTop: scrollTop, deltaY: deltaY };
},
    PROCESS_KEYBOARD_EVENT = function (event, $element) {
  var scrollTop = element.scrollTop,
      result = { top: false, bottom: false };
  result.top = scrollTop === 0 && (event.keyCode === __WEBPACK_IMPORTED_MODULE_0__utils_main__["KEYS"].PAGEUP || event.keyCode === __WEBPACK_IMPORTED_MODULE_0__utils_main__["KEYS"].HOME || event.keyCode === __WEBPACK_IMPORTED_MODULE_0__utils_main__["KEYS"].UP);
  if (!result.top) {
    var scrollHeight = element.scrollHeight,
        clientHeight = element.clientHeight;
    result.bottom = scrollHeight === scrollTop + clientHeight && (event.keyCode === __WEBPACK_IMPORTED_MODULE_0__utils_main__["KEYS"].SPACE || event.keyCode === __WEBPACK_IMPORTED_MODULE_0__utils_main__["KEYS"].PAGEDOWN || event.keyCode === __WEBPACK_IMPORTED_MODULE_0__utils_main__["KEYS"].END || event.keyCode === __WEBPACK_IMPORTED_MODULE_0__utils_main__["KEYS"].DOWN);
  }
  return result;
},
    HANDLER = function (instance, event, target) {
  // allow zooming
  if (instance.enabled && !event.ctrlKey) {
    var _element = event.currentTarget || target;
    if (instance.config.strict !== true || instance.config.strictFn(_element)) {
      // Support for nested scrollable blocks (see https://github.com/MohammadYounes/jquery-scrollLock/issues/4)
      event.stopPropagation();
      var result = PROCESS_SCROLL_EVENT(instance, event, _element, instance._.startClientY);
      if (event.unblockTarget) result.prevent &= PROCESS_SCROLL_EVENT(instance, event, event.unblockTarget, instance._.startClientY).prevent;
      if (result.prevent) {
        event.preventDefault();
        if (result.deltaY && instance.config.strictFn(_element)) {
          _element.scrollTop = result.scrollTop + result.deltaY;
        }
        var key = result.top ? 'top' : 'bottom';
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchEvent"]('scrollLock.' + key, instance, { edge: key });
      }
    }
  }
},
    KEYBOARD_HANDLER = function (instance, event) {
  var element = event.currentTarget,
      scrollTop = element.scrollTop,
      result = PROCESS_KEYBOARD_EVENT(event, element);
  if (event.unblockTarget) {
    var result2 = PROCESS_KEYBOARD_EVENT(event, event.unblockTarget);
    result.top &= result2.top;
    result.bottom &= result2.bottom;
  }
  if (result.top) {
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchEvent"]('scrollLock.top', instance, { edge: 'top' });
    return false;
  } else if (result.bottom) {
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchEvent"]('scrollLock.bottom', instance, { edge: 'bottom' });
    return false;
  }
};


/**
 * Helper to prevent scrolling outside container.
 *
 */
var ScrollLock = function (_UIControl) {
  _inherits(ScrollLock, _UIControl);

  _createClass(ScrollLock, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_2__base_ui_control__["a" /* UIControl */].$init(target, ScrollLock);
    }
  }]);

  function ScrollLock(element) {
    var config = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck(this, ScrollLock);

    var _this = _possibleConstructorReturn(this, (ScrollLock.__proto__ || Object.getPrototypeOf(ScrollLock)).call(this, element, Object.assign({}, DEFAULTS, config)));

    Object.assign(_this._, {
      enabled: true,
      startClientY: 0
    });
    _this.lock();
    return _this;
  }

  _createClass(ScrollLock, [{
    key: 'lock',
    value: function lock() {
      var _this2 = this;

      if (this.config.unblock) {
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.el, WHEEL_EVENT_NAME, UNBLOCK_HANDLER, { selector: this.config.unblock });
      }
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.el, WHEEL_EVENT_NAME, function (e) {
        HANDLER(_this2, e);
      });

      if (this.config.touch) {
        if (this.config.unblock) {
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.el, 'touchmove', UNBLOCK_HANDLER, { selector: this.config.unblock });
        }

        __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.el, 'touchstart', function (e) {
          TOUCH_HANDLER(_this2, e);
        });
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.el, 'touchmove', function (e) {
          HANDLER(_this2, e);
        });
      }
      if (this.config.keyboard) {
        element.setAttribute('tabindex', this.config.keyboard.tabindex || 0);
        if (this.config.unblock) {
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.el, 'keydown', UNBLOCK_HANDLER, { selector: this.config.unblock });
        }
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, this.el, 'keydown', function (e) {
          KEYBOARD_HANDLER(_this2, e);
        });
      }
    }
  }, {
    key: 'unlock',
    value: function unlock() {
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["detachAllEvents"](this);
    }
  }, {
    key: 'enabled',
    get: function () {
      return this._.enabled;
    },
    set: function (value) {
      this._.enabled = !!value;
    }
  }]);

  return ScrollLock;
}(__WEBPACK_IMPORTED_MODULE_2__base_ui_control__["a" /* UIControl */]);
__WEBPACK_IMPORTED_MODULE_1__data_registry__["a" /* SET__TYPE__ */](ScrollLock, 'scrolllock');

/***/ }),
/* 38 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PARAMS; });
/* harmony export (immutable) */ __webpack_exports__["c"] = serializeArray;
/* harmony export (immutable) */ __webpack_exports__["b"] = serialize;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__main__ = __webpack_require__(0);


var NON_SERIALIZABLE_TYPES = ['file', 'reset', 'submit', 'button'];
/**
 * Encodes key/value into a URL parameter
 *
 * @param {String} key The param key.
 * @param {Any} value The param value.
 */
var PARAMS_ENCODE = function (key, value) {
  return encodeURIComponent(key) + "=" + encodeURIComponent(value);
};

/**
 * Encodes an object into a URL paramter
 *
 * @param {Object} obj  The object to encode
 * @param {Boolean} pair  Defines if obj is name/value pair or a plain object.
 * @param {Function} encode The function to handle parameter encoding.
 */
var PARAMS = function (obj) {
  var pair = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var encode = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : PARAMS_ENCODE;

  return pair ? encode(obj.name, obj.value) : Object.keys(obj).map(function (key) {
    return encode(key, obj[key]);
  });
};

/**
 * Creates a JavaScript array of objects, each with a name/value keys.
 *
 *    {name: ..., value: ...}
 *
 * @param {HTMLElement | String} container The HTML element to serialize or its selector.
 */
function serializeArray(container) {
  if (__WEBPACK_IMPORTED_MODULE_0__main__["isStr"](container)) {
    container = __WEBPACK_IMPORTED_MODULE_0__main__["get"](container);
  }
  var result = [];
  container && __WEBPACK_IMPORTED_MODULE_0__main__["find"]('input, select, textarea', function (field) {
    if (field.name && !field.disabled && NON_SERIALIZABLE_TYPES.indexOf(field.type) < 0) {
      if (field.type == 'select-one' && !field.options[field.selectedIndex].value) {
        //do nothing
      } else if (field.type == 'select-multiple') {
        l = field.options.length;
        for (j = 0; j < l; j++) {
          if (field.options[j].selected) result[result.length] = { name: field.name, value: field.options[j].value };
        }
      } else if (field.checked || field.type != 'checkbox' && field.type != 'radio') {
        result[result.length] = { name: field.name, value: field.value };
      }
    }
  }, container);
  return result;
}

/**
 * Creates a text string in standard URL-encoded notation. It accepts a variety of input types:
 *
 *  1. Plain Object, all keys will be serialized. {a:1, b:2} ==> a=1&b=2
 *  2. Array, expected to have a collection of name/value pairs. [{name:'a', value:1}, {name:'b', value:2}] ==> a=1&b=2
 *  3. HTMLFormElement
 *  4. String, expected to be a valid CSS selector.
 *
 *
 * @param {Any} input
 */
function serialize(input) {
  var result = void 0;
  if (__WEBPACK_IMPORTED_MODULE_0__main__["isPlainObj"](input)) {
    result = PARAMS(input);
  } else if (__WEBPACK_IMPORTED_MODULE_0__main__["isArray"](input)) {
    result = input.map(function (item) {
      return PARAMS(item, true);
    });
  } else if (input instanceof HTMLFormElement || __WEBPACK_IMPORTED_MODULE_0__main__["isStr"](input)) {
    result = serializeArray(input).map(function (item) {
      return PARAMS(item, true);
    });
  }
  return result ? result.join('&').replace(/%20/g, '+') : '';
}

/***/ }),
/* 39 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BlurFix; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__base_control__ = __webpack_require__(33);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__resizeFire_resizeFire__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__utils_main__ = __webpack_require__(0);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }





var _regexMatrix = /(?!matrix(3d))?\([^\(\)]+\)/ig,
    _regexReplace = /\-?(\d*?\.\d+|\d+)/g,
    _subPixels = [25, 50, 75],


/**
 * Helper to get `top` and `left` sub-pixel value from transform
 *
 * @param {CSSStyleDeclaration} style The computed style
 */
_getTransformTopLeft = function (style) {
  var top = 0,
      left = 0;
  style.transform.replace(_regexMatrix, function (transform) {
    var i = 0;
    return transform.replace(_regexReplace, function (num) {
      // 5, 13: X
      // 6, 14: Y
      if (++i === 5 || i === 13) {
        left = Math.abs(parseFloat(num) % 1);
      } else if (i === 6 || i === 14) {
        top = Math.abs(parseFloat(num) % 1);
      }
    });
  });
  return { top: top, left: left };
},


/**
 * A debounced helper to add the closest sub-pixel fix to the element
 */
_subPixelHandler = __WEBPACK_IMPORTED_MODULE_2__utils_main__["debounce"](function (element, style) {
  var transform = _getTransformTopLeft(style);
  var top = transform.top;
  if (top) {
    var subPixel = top * 100;
    element.classList.add('on-subpixel-' + _subPixels.reduce(function (prev, curr) {
      return Math.abs(curr - subPixel) < Math.abs(prev - subPixel) ? curr : prev;
    }));
  }
}, 250),


/**
 * Clears the sub-pixel classes from the element
 *
 * @param {HTMLElement} element The element to clear sub-pixel classes from.
 */
_clearSubPixl = function (element) {
  for (var i = 0; i < _subPixels.length; i++) {
    element.classList.remove('on-subpixel-' + _subPixels[i]);
  }
};

/**
 * Helper to prevent text blur in chrome.
 *
 */
var BlurFix = function (_ResizeFire) {
  _inherits(BlurFix, _ResizeFire);

  function BlurFix() {
    _classCallCheck(this, BlurFix);

    return _possibleConstructorReturn(this, (BlurFix.__proto__ || Object.getPrototypeOf(BlurFix)).apply(this, arguments));
  }

  _createClass(BlurFix, [{
    key: 'attach',
    value: function attach(element) {
      var style = getComputedStyle(element);
      _get(BlurFix.prototype.__proto__ || Object.getPrototypeOf(BlurFix.prototype), 'attach', this).call(this, element, function (e) {
        // clear when detached or on response to a resize event.
        // when triggered by resize event => e is an event.
        // when triggered by detach => e is false.
        if (arguments.length) {
          _clearSubPixl(element);
        }
        // handle when attached or on response to a resize event.
        // when triggered for the first time, no arguments are passed.
        if (e !== false) {
          _subPixelHandler(element, style);
        }
      });
    }
  }]);

  return BlurFix;
}(__WEBPACK_IMPORTED_MODULE_1__resizeFire_resizeFire__["a" /* ResizeFire */]);

/***/ }),
/* 40 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = $init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__base_ui_control__ = __webpack_require__(1);


var WIDTH = 'width',
    HEIGHT = 'height';

function updateSize(element, prop, attr, fn) {
  for (var k in attr) {
    var key = (k ? k + '-' : '') + prop;

    element.style[key] = __WEBPACK_IMPORTED_MODULE_0__utils_main__["isFn"](fn) ? fn(attr[k]) : '';
  }
}

/**
 * Helper module to prevent half pixel when setting style relative to view size.
 *
 * @param {*} element
 * @param {*} config
 */
function viewSize(element, config) {
  function handler() {
    var v = __WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]() ? ['m', 'd'] : ['d', 'm'],
        de = document.documentElement;
    // loop throguh width/height actions
    // clear opposite view
    // set current view
    [//p: style property  //fn: value function
    { p: HEIGHT, fn: function (v) {
        return Math.floor(v * de.clientHeight) + 'px';
      } }, { p: WIDTH, fn: function (v) {
        return Math.floor(v * de.clientWidth) + 'px';
      } }].forEach(function (action) {
      updateSize(element, action.p, __WEBPACK_IMPORTED_MODULE_0__utils_main__["resolveVal"](config, v[1] + '.' + action.p));
      updateSize(element, action.p, __WEBPACK_IMPORTED_MODULE_0__utils_main__["resolveVal"](config, v[0] + '.' + action.p), action.fn);
    });
  }
  var debounced = __WEBPACK_IMPORTED_MODULE_0__utils_main__["debounce"](handler, 10);
  window.addEventListener('resize', debounced);
  //invoke once
  debounced();
}

/**
* Module helper to make prevent half pixel with VW/VH units.
*
* @param {HTMLElement} container The element to search in (optional).
*/
function $init(container) {
  __WEBPACK_IMPORTED_MODULE_1__base_ui_control__["a" /* UIControl */].$initHelper(container, 'viewsize', viewSize);
}

/***/ }),
/* 41 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export DEFAULTS */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PATTERNS; });
/* harmony export (immutable) */ __webpack_exports__["b"] = regex;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);


var DEFAULTS = {
  expr: undefined, // pattern or pattern name
  not: false, // negate the condition
  msg: undefined // msg to use when invalid
};

var PATTERNS = {
  email: /^[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/,
  emailNamed: /^[^@]*<[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?>$/,
  url: /^(http(s?)):\/\/(([A-Z0-9][A-Z0-9_-]*)(\.[A-Z0-9][A-Z0-9_-]*)+)/i,
  integer: /^\s*[+-]?\d+\s*$/,
  float: /^\s*[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?\s*$/
};

function regex(value, messages, attribute, config) {
  !config._ && __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["merge"](config, __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["merge"](true, {}, DEFAULTS, config, { _: true }));

  //check against regex
  var expr = config.expr;
  if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](expr)) {
    expr = PATTERNS[expr] || expr; // or use the passed expression
  } else if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isPlainObj"](expr)) {
    expr = new RegExp(expr.pattern, expr.flags);
  }

  var rx = new RegExp(expr);
  var valid = config.not ? !rx.test(value) : rx.test(value);
  if (!valid) {
    messages.push(config.msg);
  }
}

/***/ }),
/* 42 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = getNaturalDimensions;
/* harmony export (immutable) */ __webpack_exports__["a"] = $init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_resizeFire_resizeFire__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__ = __webpack_require__(1);




var ATTR_DATA_W = 'data-width',
    ATTR_DATA_H = 'data-height',
    ATTR_C = 'coords';

function getNaturalDimensions(url, cb) {
  var surrogate = Object(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"])('<img style="visiblity:hidden;" />');
  surrogate.addEventListener('error', function () {
    cb(0, 0);
  });
  surrogate.addEventListener('load', function () {
    // [1-2] IE10 does not compute the width/height of the image unless added to document
    document.body.appendChild(surrogate); //[1]
    var width = surrogate.width,
        height = surrogate.height;
    document.body.removeChild(surrogate); //[2]
    cb(width, height);
  });
  surrogate.src = url;
}

function remap(image, config) {
  var usemap = image.attr('usemap');
  if (usemap != null) {
    getNaturalDimensions(image.src, function (nWidth, nHeight) {

      var mapName = usemap.substr(1),
          resizeFire = new __WEBPACK_IMPORTED_MODULE_1__shared_resizeFire_resizeFire__["a" /* ResizeFire */](),
          map = Object(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"])('map[name="' + mapName + '"]');

      image.attr(ATTR_DATA_W, nWidth);
      image.attr(ATTR_DATA_H, nHeight);

      function resizeHandler(e) {
        var lastWidth = +image.attr(ATTR_DATA_W),
            lastHeight = +image.attr(ATTR_DATA_H),
            width = image.width,
            height = image.height;

        Object(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"])('area', function (area) {
          var coords = area.attr(ATTR_C).split(',');
          for (var i = 0; i < coords.length; ++i) {
            if (i % 2 === 0) coords[i] = +coords[i] * (width / lastWidth);else coords[i] = +coords[i] * (height / lastHeight);
          }
          area.attr(ATTR_C, coords.toString());
        }, map);
        image.attr(ATTR_DATA_W, width);
        image.attr(ATTR_DATA_H, height);
      }

      var debounced = Object(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["debounce"])(resizeHandler, 500);
      resizeFire.attach(image, debounced, map);
      debounced();
    });
  }
}

/**
* Module helper to make image maps responsive
*
* @param {HTMLElement} container The element to search in (optional).
*/
function $init(container) {
  __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */].$initHelper(container, 'remap', remap);
}

/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(8);
__webpack_require__(28);
module.exports = __webpack_require__(30);


/***/ }),
/* 44 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return api; });
/*
 * JavaScript Cookie v2.2.0
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */

function api(key, value, attributes) {
  var result;

  // Write
  if (arguments.length > 1) {
    attributes = Object.assign({
      path: '/'
    }, api.defaults, attributes);

    if (typeof attributes.expires === 'number') {
      var expires = new Date();
      expires.setMilliseconds(expires.getMilliseconds() + attributes.expires * 864e+5);
      attributes.expires = expires;
    }

    // We're using "expires" because "max-age" is not supported by IE
    attributes.expires = attributes.expires ? attributes.expires.toUTCString() : '';

    try {
      result = JSON.stringify(value);
      if (/^[\{\[]/.test(result)) {
        value = result;
      }
    } catch (e) {}

    //if (!converter.write) {
    value = encodeURIComponent(String(value)).replace(/%(23|24|26|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent);
    // } else {
    //   value = converter.write(value, key);
    // }

    key = encodeURIComponent(String(key));
    key = key.replace(/%(23|24|26|5E|60|7C)/g, decodeURIComponent);
    key = key.replace(/[\(\)]/g, escape);

    var stringifiedAttributes = '';

    for (var attributeName in attributes) {
      if (!attributes[attributeName]) {
        continue;
      }
      stringifiedAttributes += '; ' + attributeName;
      if (attributes[attributeName] === true) {
        continue;
      }
      stringifiedAttributes += '=' + attributes[attributeName];
    }
    return document.cookie = key + '=' + value + stringifiedAttributes;
  }

  // Read

  if (!key) {
    result = {};
  }

  // To prevent the for loop in the first place assign an empty array
  // in case there are no cookies at all. Also prevents odd result when
  // calling "get()"
  var cookies = document.cookie ? document.cookie.split('; ') : [];
  var rdecode = /(%[0-9A-Z]{2})+/gi;
  var i = 0;

  for (; i < cookies.length; i++) {
    var parts = cookies[i].split('=');
    var cookie = parts.slice(1).join('=');

    if (!this.json && cookie.charAt(0) === '"') {
      cookie = cookie.slice(1, -1);
    }

    try {
      var name = parts[0].replace(rdecode, decodeURIComponent);
      cookie = //converter.read ? converter.read(cookie, name) : converter(cookie, name) ||
      cookie.replace(rdecode, decodeURIComponent);

      if (this.json) {
        try {
          cookie = JSON.parse(cookie);
        } catch (e) {}
      }

      if (key === name) {
        result = cookie;
        break;
      }

      if (!key) {
        result[name] = cookie;
      }
    } catch (e) {}
  }

  return result;
}

api.set = api;
api.get = function (key) {
  return api.call(api, key);
};
api.getJSON = function () {
  return api.apply({
    json: true
  }, [].slice.call(arguments));
};
api.defaults = {};

api.remove = function (key, attributes) {
  api(key, '', Object.assign(attributes || {}, {
    expires: -1
  }));
};



/***/ }),
/* 45 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 46 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__framework_ui_shared_utils_main__ = __webpack_require__(0);

//export * from './ui-scripts'
//require('core-js/fn/array/find-index');
//require('core-js/es6/promise')
//require('core-js/es6/symbol')
// require('es6-promise').polyfill();
// require('whatwg-fetch')

/// CUSTOM EVENT POLYFILL FOR IE
//SCRIPT1047: In strict mode, function declarations cannot be nested inside a statement or block. They may only appear at the top level or directly inside a function body.
if (!Object(__WEBPACK_IMPORTED_MODULE_0__framework_ui_shared_utils_main__["isFn"])(window.CustomEvent)) {
  window.CustomEvent = function (event, params) {
    params = params || { bubbles: false, cancelable: false, detail: undefined };
    var evt = document.createEvent('CustomEvent');
    evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
    return evt;
  };
  CustomEvent.prototype = window.Event.prototype;
}

/// CLOSEST POLYFILL
if (window.Element && !Element.prototype.closest) {
  Element.prototype.closest = function (s) {
    var matches = (this.document || this.ownerDocument).qsa(s),
        i,
        el = this;
    do {
      i = matches.length;
      while (--i >= 0 && matches.item(i) !== el) {};
    } while (i < 0 && (el = el.parentElement));
    return el;
  };
}

/// MATCHES POLYFILL
if (!Element.prototype.matches) {
  Element.prototype.matches = Element.prototype.matchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector || Element.prototype.webkitMatchesSelector || function (s) {
    var matches = (this.document || this.ownerDocument).qsa(s),
        i = matches.length;
    while (--i >= 0 && matches.item(i) !== this) {}
    return i > -1;
  };
}

/// object.assign POLYFILL
if (!Object(__WEBPACK_IMPORTED_MODULE_0__framework_ui_shared_utils_main__["isFn"])(Object.assign)) {
  // Must be writable: true, enumerable: false, configurable: true
  Object.defineProperty(Object, "assign", {
    value: function assign(target, varArgs) {
      // .length of function is 2
      'use strict';

      if (target == null) {
        // TypeError if undefined or null
        throw new TypeError('Cannot convert undefined or null to object');
      }

      var to = Object(target);

      for (var index = 1; index < arguments.length; index++) {
        var nextSource = arguments[index];

        if (nextSource != null) {
          // Skip over if undefined or null
          for (var nextKey in nextSource) {
            // Avoid bugs when hasOwnProperty is shadowed
            if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
              to[nextKey] = nextSource[nextKey];
            }
          }
        }
      }
      return to;
    },
    writable: true,
    configurable: true
  });
}

/// array.find POLYFILL
if (!Array.prototype.find) {
  Object.defineProperty(Array.prototype, 'find', {
    value: function (predicate) {
      // 1. Let O be ? ToObject(this value).
      if (this == null) {
        throw new TypeError('"this" is null or not defined');
      }

      var o = Object(this);

      // 2. Let len be ? ToLength(? Get(O, "length")).
      var len = o.length >>> 0;

      // 3. If IsCallable(predicate) is false, throw a TypeError exception.
      if (!Object(__WEBPACK_IMPORTED_MODULE_0__framework_ui_shared_utils_main__["isFn"])(predicate)) {
        throw new TypeError('predicate must be a function');
      }

      // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
      var thisArg = arguments[1];

      // 5. Let k be 0.
      var k = 0;

      // 6. Repeat, while k < len
      while (k < len) {
        // a. Let Pk be ! ToString(k).
        // b. Let kValue be ? Get(O, Pk).
        // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
        // d. If testResult is true, return kValue.
        var kValue = o[k];
        if (predicate.call(thisArg, kValue, k, o)) {
          return kValue;
        }
        // e. Increase k by 1.
        k++;
      }

      // 7. Return undefined.
      return undefined;
    }
  });
}

/// array.findIndex POLYFILL
if (!Array.prototype.findIndex) {
  Object.defineProperty(Array.prototype, 'findIndex', {
    value: function (predicate) {
      // 1. Let O be ? ToObject(this value).
      if (this == null) {
        throw new TypeError('"this" is null or not defined');
      }

      var o = Object(this);

      // 2. Let len be ? ToLength(? Get(O, "length")).
      var len = o.length >>> 0;

      // 3. If IsCallable(predicate) is false, throw a TypeError exception.
      if (!Object(__WEBPACK_IMPORTED_MODULE_0__framework_ui_shared_utils_main__["isFn"])(predicate)) {
        throw new TypeError('predicate must be a function');
      }

      // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
      var thisArg = arguments[1];

      // 5. Let k be 0.
      var k = 0;

      // 6. Repeat, while k < len
      while (k < len) {
        // a. Let Pk be ! ToString(k).
        // b. Let kValue be ? Get(O, Pk).
        // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
        // d. If testResult is true, return k.
        var kValue = o[k];
        if (predicate.call(thisArg, kValue, k, o)) {
          return k;
        }
        // e. Increase k by 1.
        k++;
      }

      // 7. Return -1.
      return -1;
    }
  });
}

/***/ }),
/* 47 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = ajaxSetup;
/* harmony export (immutable) */ __webpack_exports__["a"] = ajax;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__main__ = __webpack_require__(0);


var NOOP = function () {},
    X_REQUESTED_WITH = 'X-Requested-With',
    DEFAULTS = {
  context: null,
  url: '.',
  method: 'GET',
  username: undefined,
  password: undefined,
  xhrFields: {},
  headers: {},
  crossDomain: false,
  cache: true,
  data: null,
  processData: true,
  done: NOOP,
  success: NOOP,
  error: NOOP,
  beforeSend: NOOP
},
    PROCESS = function (request, response, xhr) {
  if (request.processData) {
    var type = xhr.getResponseHeader('content-type');
    if (type.match(/^ap.+\/json/)) {
      try {
        response.body = JSON.parse(response.body);
      } catch (e) {}
    }
  }
},
    DONE = function (request, response, xhr) {
  request.done.call(request.context, xhr);
},
    SUCCESS = function (request, response, xhr) {
  PROCESS(request, response, xhr);
  request.success.call(request.context, response.body, xhr);
  DONE(request, response, xhr);
},
    ERROR = function (request, response, xhr) {
  request.error.call(request.context, xhr, response.reason);
  DONE(request, response, xhr);
},
    CALLBACK = function (reason, request, response, xhr) {
  return function () {
    if (!reason && xhr.status >= 200 && xhr.status < 300 || xhr.status === 304) {
      SUCCESS(request, response = {
        url: 'responseURL' in xhr ? xhr.responseURL : xhr.getResponseHeader('X-Request-URL'),
        body: 'response' in xhr ? xhr.response : xhr.responseText
      }, xhr);
    } else {
      ERROR(request, response = { reason: reason || 'error' }, xhr);
    }
  };
},
    STATES = ['success', 'error', 'done'],
    PROCESS_FORM_DATA = function (data, defaultData) {
  var processedData = void 0;
  if (data instanceof FormData) {
    processedData = data;
  } else {
    processedData = new FormData();
    if (Object(__WEBPACK_IMPORTED_MODULE_0__main__["isPlainObj"])(data)) {
      Object(__WEBPACK_IMPORTED_MODULE_0__main__["PARAMS"])(data, false, function (key, value) {
        return processedData.append(key, value);
      });
    } else if (Object(__WEBPACK_IMPORTED_MODULE_0__main__["isArray"])(data)) {
      //serialized array
      data.map(function (item) {
        return Object(__WEBPACK_IMPORTED_MODULE_0__main__["PARAMS"])(item, true, function (key, value) {
          return processedData.append(key, value);
        });
      });
    } else if (data instanceof HTMLFormElement) {
      processedData = new FormData(data);
    } else if (Object(__WEBPACK_IMPORTED_MODULE_0__main__["isStr"])(data)) {
      processedData = new FormData(Object(__WEBPACK_IMPORTED_MODULE_0__main__["get"])(data));
    }
  }
  ////merge default data with request data
  if (Object(__WEBPACK_IMPORTED_MODULE_0__main__["isPlainObj"])(defaultData)) {
    Object(__WEBPACK_IMPORTED_MODULE_0__main__["PARAMS"])(defaultData, false, function (key, value) {
      return processedData.append(key, value);
    });
  }
  return processedData;
},
    DEFAULT_KEY = '',
    DEFAULTS_MAP = { _defaultKey: {}
  /**
   * Helper for setting up default ajax parameters including additional data.
   *
   * @param {String} url The default request Url.
   * @param {Object} options The request options.
   * @param {Boolean} strict When `true`, options will be applied to matching request method only.
   */
};function ajaxSetup(url, options) {
  var strict = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

  var key = strict ? options.method || DEFAULT_KEY : DEFAULT_KEY,
      defaults = DEFAULTS_MAP[key] = DEFAULTS_MAP[key] || {};

  defaults.url = url;
  defaults.options = options;
  defaults.data = defaults.options.data;
  //clear data from default options to avoid appending duplicate keys.
  defaults.options.data = {};
}

/**
 * Helper for performing AJAX requests.
 *
 * @param {String} url The request url
 * @param {Object} options The request options
 */
function ajax() {
  var url = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : DEFAULTS_MAP[DEFAULT_KEY].url;
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var key = options.method || DEFAULT_KEY,
      defaults = DEFAULTS_MAP[key] || DEFAULTS_MAP[DEFAULT_KEY] || {},
      defaultOptions = defaults.options,
      defaultData = defaults.data;

  var xhr = new XMLHttpRequest(),
      request = Object(__WEBPACK_IMPORTED_MODULE_0__main__["merge"])(true, {}, DEFAULTS, defaultOptions, options),
      response = null,
      result = {};

  //build result object
  STATES.forEach(function (key) {
    result[key] = function (cb) {
      request[key] = cb;
      if (response) {
        [key.toUpperCase()](request, response, xhr);
      }
      return result;
    };
  }, this);

  xhr.onload = CALLBACK(null, request, response, xhr);
  xhr.onerror = CALLBACK('error', request, response, xhr);
  xhr.ontimeout = CALLBACK('timeout', request, response, xhr);

  // set the url
  request.url = request.cache ? url : '' + url + (url.indexOf('?') > -1 ? '&' : '?') + '_=' + Math.floor(Math.random() * Date.now());

  if (request.method === 'GET') {
    //merge default data with request data
    var qsparams = Object(__WEBPACK_IMPORTED_MODULE_0__main__["serialize"])(Object(__WEBPACK_IMPORTED_MODULE_0__main__["merge"])({}, defaultData, request.data));
    if (qsparams) {
      request.url += (request.url.indexOf('?') > -1 ? '&' : '?') + qsparams;
    }
    // clear request data as they have been already handled.
    request.data = null;
  }

  xhr.open(request.method, request.url, true, request.username, request.password);

  // custom fields
  if (request.xhrFields) {
    for (var _key in request.xhrFields) {
      xhr[_key] = request.xhrFields[_key];
    }
  }

  // Override mime type if needed
  if (request.mimeType && xhr.overrideMimeType) {
    xhr.overrideMimeType(request.mimeType);
  }

  //set headers
  if (!request.crossDomain && !(X_REQUESTED_WITH in request.headers)) {
    request.headers[X_REQUESTED_WITH] = "XMLHttpRequest";
  }
  for (var _key2 in request.headers) {
    xhr.setRequestHeader(_key2, request.headers[_key2]);
  }

  // Process formData
  if (request.data) {
    request.data = PROCESS_FORM_DATA(request.data, defaultData);
  }

  request.beforeSend(xhr);
  xhr.send(request.data);
  return result;
}

/***/ }),
/* 48 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = createEventStrore;
/* harmony export (immutable) */ __webpack_exports__["a"] = attachEvent;
/* harmony export (immutable) */ __webpack_exports__["d"] = detachEvent;
/* harmony export (immutable) */ __webpack_exports__["c"] = detachAllEvents;
/* harmony export (immutable) */ __webpack_exports__["e"] = dispatchEvent;
/* harmony export (immutable) */ __webpack_exports__["f"] = dispatchHooks;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__main__ = __webpack_require__(0);
//@ts-check


/**
 * Test to check if passive event listeners are supported.
 */
var IsPassiveSupported = false;
try {
  var options = Object.defineProperty({}, 'passive', {
    get: function () {
      IsPassiveSupported = true;
    }
  });
  window.addEventListener('test', options, options);
  window.removeEventListener('test', options, options);
} catch (e) {}

/**
 * Create an event store
 */
function createEventStrore() {
  return {
    handleEvent: function (event) {
      var tuples = this[event.type];
      for (var x = 0; x < tuples.length; x++) {
        var tuple = tuples[x];
        // tuple [element, handler, once, selector]
        var current = event.target,
            element = tuple[0],
            handler = tuple[1],
            once = tuple[2],
            selector = tuple[3],
            matched = selector === undefined;
        // Find delegate handlers
        if (selector && current.nodeType && !(event.type === 'click' && event.button >= 1)) {
          for (; current !== element; current = current.parentNode || element) {
            if (current.nodeType === 1 && !(event.type === 'click' && current.disabled === true) && current.matches(selector)) {
              matched = true;
              event.delegateTarget = current;
              break;
            }
          }
        }
        // invoke the handler
        if (matched && element === event.currentTarget) {
          // detach if once
          if (once) {
            detachEvent(this, element, handler);
          }
          handler.call(this, event);

          // WARNING: CHANGE REQUIRES FULL TEST
          // Returning True or False has no effect in vanilla event listeners.

          // <div id="div">
          //   <button id="btnNone"> Click me </button>
          //   <button id="btnTrue"> Click me True </button>
          //   <button id="btnFalse"> Click me False </button>
          // </div>
          //
          // div.addEventListener('click', function(e){
          //   console.log('div', e)
          // })
          //
          // btnNone.addEventListener('click', function(e){
          //   console.log('btn', e)
          // })
          //
          // btnTrue.addEventListener('click', function(e){
          //   console.log('btn true', e)
          //   return true
          // })
          //
          // btnFalse.addEventListener('click', function(e){
          //   console.log('btn false', e)
          //   return false
          // })

          // prevent/stop propagation if false is returned
          // if (handler.call(this, event) === false) {
          //   event.preventDefault()
          //   event.stopPropagation()
          // }
        }
      }
    }
  };
}
/**
 * Adds an event listener
 *
 * @param {any} context  The context which holds the events store `context._events`.
 * @param {HTMLElement} element The EventTarget to register the listenr on.
 * @param {string} type The event type to listen for.
 * @param {function} handler  The function to handle the event.
 * @param {boolean} useCapture  Specifices if the event to be dispatched to the registered listener before being dispatched to any EventTarget beneath it in the DOM tree.
 * @param {boolean} once  Specifices if the event must detach itself after first invocation.
 * @param {boolean} passive A Boolean which, if true, indicates that the function specified by listener will never call preventDefault().
 */
function attachEvent(context, element, type, handler) {
  var _ref = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {},
      _ref$useCapture = _ref.useCapture,
      useCapture = _ref$useCapture === undefined ? false : _ref$useCapture,
      _ref$once = _ref.once,
      once = _ref$once === undefined ? false : _ref$once,
      _ref$selector = _ref.selector,
      selector = _ref$selector === undefined ? undefined : _ref$selector,
      _ref$passive = _ref.passive,
      passive = _ref$passive === undefined ? false : _ref$passive;

  var events = context._events;
  var tuples = events[type] = events[type] || [];
  // tuple [element, handler, once, selector]
  var tuple = tuples.find(function (t) {
    return t[0] === element && t[3] === selector;
  });
  if (tuple !== undefined) console.error('Element already has ' + type + ' event attached to it.');
  tuples.push([element, handler, once, selector]);
  element.addEventListener(type, events, IsPassiveSupported ? { capture: useCapture, passive: passive } : useCapture);
}
/**
 * Removes an event listener
 *
 * @param {any} context  The context which holds the events store `context._events`.
 * @param {HTMLElement} element The EventTarget to unregister the listenr from.
 * @param {string} type The event type to remove.
 * @param {boolean} suppress When true no error is logged to the console.
 *
 */
function detachEvent(context, element, type) {
  var _ref2 = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {},
      _ref2$suppress = _ref2.suppress,
      suppress = _ref2$suppress === undefined ? false : _ref2$suppress,
      _ref2$selector = _ref2.selector,
      selector = _ref2$selector === undefined ? undefined : _ref2$selector;

  var tuples = context._events[type] || [];
  var index = tuples.findIndex(function (t) {
    return t[0] === element && t[3] === selector;
  });
  if (index !== -1) {
    var tuple = tuples[index];
    tuples.splice(index, 1);
    tuple[0].removeEventListener(type, context._events);
  } else if (!suppress) {
    console.error('Event ' + type + ' is not attached to element.');
  }
}
/**
 * Removes all event listeners
 *
 * @param {any} context  The context which holds the events store `context._events`.
 */
function detachAllEvents(context) {
  var events = context._events;
  for (var key in events) {
    if (key === 'handleEvent') continue;
    //for (let tuple of events[key]) {
    for (var k in events[key]) {
      var tuple = events[key][k];
      tuple[0].removeEventListener(key, events);
    }
    events[key].length = 0;
  }
}

/**
 * Dispatches a custom event
 *
 * @param {string}  type  The event type.
 * @param {UIControl} control The control that dispatched the event.
 * @param {any} data Any custom data to be sent along with the event.
 */
function dispatchEvent(type, control) {
  var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
  var firingElement = arguments[3];

  // do nothing if dispatching is turned off
  if (!control.dispatching) return;

  // fire custom event
  var args = { bubbles: true, detail: { control: control, data: data } };

  firingElement = firingElement || control.el;
  //privat event for internal use.
  var e = new CustomEvent('b8._' + type, args);
  firingElement.dispatchEvent(e);

  //public event for external use.
  e = new CustomEvent('b8.' + type, args);
  firingElement.dispatchEvent(e);
}

/**
 * Dispatches a custom hook attached to the config.
 *
 * This will resolve the hook type from `config.on` and invoke it.
 * If the key has `.one` event modifier suffix it will be invoked only once and then removed from the hooks
 *
 * For example: To subscribe to the `activate` hook once, you register with `activate.one` key.
 *
 * @param {string}  type  The event type.
 * @param {UIControl} control The control that dispatched the event.
 * @param {any} data Any custom data to be sent along with the event.
 */
function dispatchHooks(type, control) {
  var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;

  // do nothing if dispatching is turned off
  if (!control.dispatching) return;

  // fire custom event
  var args = { control: control, data: data, type: type };
  var _control$config$on = control.config.on,
      on = _control$config$on === undefined ? {} : _control$config$on;

  //invoke always

  Object(__WEBPACK_IMPORTED_MODULE_1__main__["resolveFn"])(type, __WEBPACK_IMPORTED_MODULE_1__main__["NOOP"], on).call(this, args);

  //invoke once
  var onceType = type + '.one';
  if (onceType in on) {
    Object(__WEBPACK_IMPORTED_MODULE_1__main__["resolveFn"])(onceType, __WEBPACK_IMPORTED_MODULE_1__main__["NOOP"], on, true).call(this, args);
    delete on[onceType];
  }
}

/***/ }),
/* 49 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["m"] = isIE;
/* harmony export (immutable) */ __webpack_exports__["u"] = readConfig;
/* harmony export (immutable) */ __webpack_exports__["i"] = htmlToElement;
/* harmony export (immutable) */ __webpack_exports__["d"] = clearChildren;
/* harmony export (immutable) */ __webpack_exports__["s"] = prependElement;
/* harmony export (immutable) */ __webpack_exports__["x"] = replaceElement;
/* harmony export (immutable) */ __webpack_exports__["C"] = wrapElement;
/* harmony export (immutable) */ __webpack_exports__["o"] = isTouch;
/* harmony export (immutable) */ __webpack_exports__["n"] = isMobile;
/* harmony export (immutable) */ __webpack_exports__["h"] = getScrollTop;
/* harmony export (immutable) */ __webpack_exports__["g"] = getScrollLeft;
/* harmony export (immutable) */ __webpack_exports__["z"] = saveScrollPosition;
/* harmony export (immutable) */ __webpack_exports__["y"] = restoreScrollPosition;
/* harmony export (immutable) */ __webpack_exports__["t"] = preventBodyShift;
/* harmony export (immutable) */ __webpack_exports__["j"] = inView;
/* harmony export (immutable) */ __webpack_exports__["c"] = bringIntoView;
/* harmony export (immutable) */ __webpack_exports__["A"] = scrollIntoView;
/* harmony export (immutable) */ __webpack_exports__["f"] = get;
/* harmony export (immutable) */ __webpack_exports__["e"] = find;
/* harmony export (immutable) */ __webpack_exports__["B"] = traverse;
/* harmony export (immutable) */ __webpack_exports__["p"] = isVisible;
/* harmony export (immutable) */ __webpack_exports__["b"] = addClasses;
/* harmony export (immutable) */ __webpack_exports__["w"] = remClasses;
/* harmony export (immutable) */ __webpack_exports__["a"] = addClass;
/* harmony export (immutable) */ __webpack_exports__["v"] = remClass;
/* harmony export (immutable) */ __webpack_exports__["r"] = movClasses;
/* harmony export (immutable) */ __webpack_exports__["q"] = loadDeferredStyles;
/* harmony export (immutable) */ __webpack_exports__["k"] = init;
/* harmony export (immutable) */ __webpack_exports__["l"] = inject;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ui_scripts__ = __webpack_require__(30);
// @ts-check


/**
 * Returns true if agent is Internet Explorer
 */
function isIE() {
  return 'ActiveXObject' in window || navigator.appVersion.match(/Edge\/\d+/);
}

/**
 * Helper: Reads the config from an element data attribute.
 *
 * @param {HTMLElement} element The element to read attribute from
 * @param {String} attribute The name of the attribute
 */
function readConfig(element, attribute) {
  var config = void 0,
      data = element.getAttribute(attribute);
  // see if this is a json, parse it
  if (/^\s*\{/.test(data)) {
    config = JSON.parse(data);
  } else if (data && data.length) {
    // if not, try evaluating it
    config = Object(__WEBPACK_IMPORTED_MODULE_0__main__["resolveVal"])(window, data);
    //if a function, invoke it to get the config.
    if (Object(__WEBPACK_IMPORTED_MODULE_0__main__["isFn"])(config)) {
      config = config();
    } else if (config === undefined && Object(__WEBPACK_IMPORTED_MODULE_0__main__["isStr"])(data)) {
      // as is with attribute returned as key (converted from kebak-case to camelCase)
      var key = attribute.replace(/(^data-)|(-)([a-z]{1})/g, function (m, c1, c2, c3) {
        return c3 ? c3.toUpperCase() : '';
      });
      // uglifyjs does not like `config = {[key]:data}` !!
      config = {};
      config[key] = data;
    }
  } else {
    // default is no config.
    config = {};
  }
  return config;
}

var tempEl = null;
/**
 * Convert HTML string to HTMLElement
 */
function htmlToElement(html) {
  tempEl = tempEl || document.createElement('div');
  tempEl.innerHTML = html;
  var element = tempEl.firstElementChild;
  tempEl.removeChild(element);
  return element;
}

// export function htmlToElements(html) {
//   tempEl = tempEl || document.createElement('div')
//   tempEl.innerHTML = html
//   let elements = tempEl.childNodes
//   clearChildren(tempEl)
//   return elements
// }

/**
 * Clears a given element children
 * @param {HTMLElement} element  The element to clear
 */
function clearChildren(element) {
  while (element.lastChild) {
    element.removeChild(element.lastChild);
  }
}

/**
 * Insert the given element at the start of parent
 *
 * @param {HTMLElement} newElement  The element to insert
 * @param {HTMLElement} parentElement  The parent element
 */
function prependElement(newElement, parentElement) {
  parentElement.insertBefore(newElement, parentElement.firstElementChild);
}

/**
 * Replaces a given element with another.
 *
 * @param {HTMLElement} element  The element to replace.
 * @param {HTMLElement} newElement  The new element to replace with.
 */
function replaceElement(element, newElement) {
  element.parentNode.replaceChild(newElement, element);
}

/**
 * Wraps the element inside a given wrapper
 *
 * @param {HTMLElement} element  The element to wrap
 * @param {HTMLElement} wrapper  The new wrapper element
 */
function wrapElement(element, wrapper) {
  element.parentElement.insertBefore(wrapper, element);
  wrapper.appendChild(element);
}

/**
 * Check if the current device has touch support
 */
function isTouch() {
  return 'ontouchstart' in window;
}

var fakeElement = null;
/**
 * Check if the current screen size is mobile
 */
function isMobile() {
  if (!fakeElement) {
    fakeElement = document.createElement('i');
    fakeElement.classList.add('d');
    document.body.appendChild(fakeElement);
  }
  return getComputedStyle(fakeElement).display === 'none';
  //return document.documentElement.offsetWidth <= 1024
}

/**
 * Get the view scroll top position
 */
function getScrollTop() {
  return document.documentElement.scrollTop || document.body.scrollTop;
}
/**
 * Get the view scroll left position
 */
function getScrollLeft() {
  return document.documentElement.scrollLeft || document.body.scrollLeft;
}

var scrollX = void 0,
    scrollY = void 0;
/**
 * Saves the current scroll position
 */
function saveScrollPosition() {
  scrollX = getScrollLeft();
  scrollY = getScrollTop();
}
/**
 * Restores the last saved position
 */
function restoreScrollPosition() {
  window.scrollTo(scrollX, scrollY);
}

var topScroll = void 0,
    top = void 0;
/**
 * Prevents body shifting when showing a model
 * Requires body to have position fixed with overflow-y scroll
 *
 */
function preventBodyShift(add) {

  if (document.documentElement.scrollHeight > document.documentElement.clientHeight) {
    if (add) {
      topScroll = scrollY;
      top = document.body.style.top;
      document.body.classList.add('js-is-fixed');
      document.body.style.top = -scrollY + 'px';
    } else {
      scrollY = topScroll;
      document.body.style.top = top;
      document.body.classList.remove('js-is-fixed');
      restoreScrollPosition();
    }
    return true;
  }
  return false;
}

/**
 * Checks if the given target is in visible area of a scrollable view.
 *
 *  Will be in view when both target top & bottom are within view top & bottom.
 *
 *                             +--+  <-- Target Top
 *                         --> |  |
 *                        /    +--+  <-- Target Bottom
 *                       /
 *                      /      +--+
 *                     /-----> |  |   +-------------------+  <--- View Top
 *                    /        +--+   |                  ||
 *                   /                |                  ||
 *                  /          +--+   |                  ||
 *        Targets  |---------> |  |   |       VIEW       ||
 *                  \          +--+   |                  ||
 *                   \                |                  ||
 *                    \        +--+   |                  ||
 *                     \-----> |  |   +-------------------+   <--- View Bottom
 *                      \      +--+
 *                       \
 *                        \    +--+
 *                         --> |  |
 *                             +--+
 *
 */
function inView(target, view) {

  var targetTop = target.offsetTop;
  var targetBottom = target.offsetTop + target.offsetHeight;
  var viewTop = view.scrollTop;
  var viewBottom = view.scrollTop + view.offsetHeight;

  return targetTop >= viewTop && targetTop <= viewBottom && targetBottom >= viewTop && targetBottom <= viewBottom;
}

/**
 * Conditionally scrolls the view so target is inside the visible area.
 *
 * @param {HTMLElement} target The target to bring into view.
 * @param {HTMLElement} view The view to scroll.
 * @param {boolean} upwards indicates if the operation is due to moving up or down.
 */
function bringIntoView(target, view) {
  var upwards = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

  if (!inView(target, view)) {
    view.scrollTop = upwards ? target.offsetTop : target.offsetTop + target.offsetHeight - view.offsetHeight;
  }
}

/**
 * Scrolls the window to the current element.
 */
function scrollIntoView(element) {
  var rect = element.getBoundingClientRect();
  window.scrollTo(rect.left, rect.top);
}

/**
 * Returns the first Element that matches the specified selector
 *
 * @param {String} selector The element selector.
 * @param {Document | HTMLElement} container The element to search in (optional).
 */
function get(selector) {
  var container = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : document;

  return container.qs(selector);
}

/**
 * Returns a non-live NodeList of all elements descended from the element on which it is invoked that matches the specified group of CSS selectors.
 * (The base element itself is not included, even if it matches.)
 *
 * @param {String} selector The elements selector.
 * @param {Function} iterator The function to invoke once for each of the selected elements (optional).
 * @param {Document | HTMLElement} container The element to search in (optional).
 */
function find(selector, iterator) {
  var container = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : document;

  if (Object(__WEBPACK_IMPORTED_MODULE_0__main__["isFn"])(iterator)) {
    return [].forEach.call(container.qsa(selector), function (el, idx) {
      iterator(el, idx);
    });
  } else {
    return container.qsa(selector);
  }
}

/**
 * Traverses a given path from a starting node till predicate is satisified.
 *
 * @param {HTMLElement} element The starting element to begin traversing.
 * @param {string} path The name of the traversing direction function.
 * @param {Function} predicate Called for every element found. Traversing stops once it returns true.
 * @param {HTMLElement} fallback A default element to return in case traversing didn't yield any element.
 * @param {Boolean} excludeSelf When false, initial element will be checked against predicate.
 */
function traverse(element, path, predicate, fallback) {
  var excludeSelf = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : true;

  var t = (excludeSelf ? element && element[path] : element) || fallback;
  while (t && !predicate(t)) {
    t = t[path];
  }
  return t || fallback;
}
/**
 * Returns true if the element is visible.
 *
 * @param {HTMLElement} element
 */
function isVisible(element) {
  return !!(element.offsetParent || element.offsetWidth || element.offsetHeight || element.getClientRects().length);
}

/**
 * Private helper to add/remove class from element with IE Polyfill for SVG elements
 *
 * @param {HTMLElement} element The element to add/remove class to/from.
 * @param {Boolean} add Whether to add or remove the class.
 * @param {String} className The name of the class to add/remove.
 */
function _addRemoveClass(element, add, className) {
  if (element) {
    if (element.classList) {
      element.classList[add ? 'add' : 'remove'](className);
    } else if ('baseVal' in element.className) {
      //IE does not support classList on SVG elements.
      var classes = element.className.baseVal.split(' ');
      var index = classes.indexOf(className);
      if (add) {
        // add if not exists
        index < 0 && classes.push(className);
      } else {
        //remove if exists
        index > -1 && classes.splice(index, 1);
      }
      element.className.baseVal = classes.join(' ');
    }
  }
}

/**
 * Private Helper: Adds or Removes a list of classes to/from element.
 *
 * @param {HTMLElement} element The element to add/remove classes to/from
 * @param {Boolean} add Whether to add or remove the classes.
 * @param {Array} classes The list of classes to add/remove
 */
function addRemClasses(element, add) {
  for (var _len = arguments.length, classes = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
    classes[_key - 2] = arguments[_key];
  }

  classes.forEach(function (className) {
    _addRemoveClass(element, add, className);
  });
}

/**
 * Helper: Adds a list of classes to element.
 *
 * @param {HTMLElement} element The element to add classes to
 * @param {Array} classes The list of classes to add
 */
function addClasses(element) {
  for (var _len2 = arguments.length, classes = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
    classes[_key2 - 1] = arguments[_key2];
  }

  addRemClasses.apply(undefined, [element, true].concat(classes));
}

/**
 * Helper: Removes a list of classes from element.
 *
 * @param {HTMLElement} element The element to remove classes from
 * @param {Array<String>} classes The list of classes to remove
 */

function remClasses(element) {
  for (var _len3 = arguments.length, classes = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
    classes[_key3 - 1] = arguments[_key3];
  }

  addRemClasses.apply(undefined, [element, false].concat(classes));
}

/**
 * Private Helper: Adds or Removes a class to/from a list of elements.
 *
 * @param {String} className The class name to add/remove from elements
 * @param {Boolean} add Whether to add or remove the class.
 * @param {Array<HTMLElement>} elements The list of elements to add to or remove the class from.
 */
function addRemClass(className) {
  var add = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

  for (var _len4 = arguments.length, elements = Array(_len4 > 2 ? _len4 - 2 : 0), _key4 = 2; _key4 < _len4; _key4++) {
    elements[_key4 - 2] = arguments[_key4];
  }

  elements.forEach(function (element) {
    _addRemoveClass(element, add, className);
  });
}

/**
 * Helper: Adds a class to a list of elements.
 *
 * @param {String} className The class name to add to elements
 * @param {Array<HTMLElement>} elements The list of elements to add the class to.
 */
function addClass(className) {
  for (var _len5 = arguments.length, elements = Array(_len5 > 1 ? _len5 - 1 : 0), _key5 = 1; _key5 < _len5; _key5++) {
    elements[_key5 - 1] = arguments[_key5];
  }

  addRemClass.apply(undefined, [className, true].concat(elements));
}

/**
 * Helper: Removes a class from a list of elements.
 *
 * @param {String} className The class name to remove from elements
 * @param {Array<HTMLElement>} elements The list of elements to remove the class from.
 */
function remClass(className) {
  for (var _len6 = arguments.length, elements = Array(_len6 > 1 ? _len6 - 1 : 0), _key6 = 1; _key6 < _len6; _key6++) {
    elements[_key6 - 1] = arguments[_key6];
  }

  addRemClass.apply(undefined, [className, false].concat(elements));
}

/**
 * Helper to move a list classes from one element to another.
 *
 * @param {HTMLElement} from The element to remove classes from.
 * @param {Boolean} skipCheck Whether to check if the classs exists on from element.
 * @param {HTMLElement} to  The element to add classes to.
 * @param {Array<String>} classes The class or classes to move from one element to another.
 */
function movClasses(from, to, skipCheck) {
  for (var _len7 = arguments.length, classes = Array(_len7 > 3 ? _len7 - 3 : 0), _key7 = 3; _key7 < _len7; _key7++) {
    classes[_key7 - 3] = arguments[_key7];
  }

  classes.forEach(function (className) {
    if (skipCheck || from && from.classList.contains(className)) {
      from && remClass(className, from);
      to && addClass(className, to);
    }
  });
}

/**
 * Helper: Load deferred styles
 */
function loadDeferredStyles() {
  find('[data-deferred-styles]', function (addStylesNode) {
    var replacement = document.createElement("div");
    replacement.innerHTML = addStylesNode.textContent;
    document.body.appendChild(replacement);
    addStylesNode.parentElement.removeChild(addStylesNode);
  });
}

/**
 * Initializes a given element by loading scripts and binding modules.
 *
 * @param {HTMLElement | String} element The HTML element to prepare.
 * @param {Object} options The various options for preparing the element.
 *    {Boolean} bind  Whether to bind BaytUI modules - default is `false`.
 *    {Boolean} load  Whether to load external scripts - default is `false`.
 *    {Function} before  A callback function to invoke before starting to load or bind action.
 *    {Function} after   A callback function to invoke when all is loaded and bound.
 */
function init(element) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
      _ref$bind = _ref.bind,
      bind = _ref$bind === undefined ? false : _ref$bind,
      _ref$load = _ref.load,
      load = _ref$load === undefined ? false : _ref$load,
      _ref$before = _ref.before,
      before = _ref$before === undefined ? __WEBPACK_IMPORTED_MODULE_0__main__["NOOP"] : _ref$before,
      _ref$after = _ref.after,
      after = _ref$after === undefined ? __WEBPACK_IMPORTED_MODULE_0__main__["NOOP"] : _ref$after;

  if (Object(__WEBPACK_IMPORTED_MODULE_0__main__["isStr"])(element)) {
    element = get(element);
  }

  var wait = 0;
  before(); //this.Waiting = true
  if (load) {
    find('script', function (node) {
      var script = document.createElement("script");
      if (!node.src) {
        // inline script
        script.text = node.innerText;
        // eval once
        document.head.appendChild(script).parentNode.removeChild(script);
      } else {
        // linked script
        script.src = node.src;
        script.onload = script.onerror = function () {
          wait--;
        };
        document.head.appendChild(script); // add to document
        // increment wait count
        wait++;
      }
    }, element);
  }
  var interval = setInterval(function () {
    if (!wait) {
      clearInterval(interval);
      if (bind) {
        Object(__WEBPACK_IMPORTED_MODULE_1__ui_scripts__["$bind"])(element);
      }
      after(); //this.Waiting = false
    }
  }, 100);
}

/**
 * Private Helper to trigger callbacks once injection is complete.
 *
 * @param {Array} callbacks Array of registered callbacks waiting for the script injection to be complete.
 */

var INJECT_CALLBACK_STORE = {};
/**
 * Private Helper: registers the callback into it's corresponding store, returns `false` if the store is locked.
 *
 * @param {String} id The store identifier.
 * @param {Function} callback The callback to register
 */
function registerInjectCallback(id, callback) {
  var store = INJECT_CALLBACK_STORE[id] = INJECT_CALLBACK_STORE[id] || [];
  if (store.locked) {
    return false;
  }
  store.push(callback);
  return true;
}

/**
 * Private Helper: Executes all registered callbacks of a given callback store.
 *
 * @param {String} id The store identifier to invoke all of its registered callbacks.
 */
function injectComplete(id) {
  INJECT_CALLBACK_STORE[id].locked = true;
  var store = INJECT_CALLBACK_STORE[id],
      callback = void 0;
  while (callback = store.pop()) {
    callback.call();
  }
}

/**
 * Inject an external script into the page.
 *
 * @param {String} id The unique id of the script
 * @param {String} url The script url
 * @param {Function} callback The function to call once the script is loaded or errored.
 */
function inject(id, url) {
  var callback = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : __WEBPACK_IMPORTED_MODULE_0__main__["NOOP"];

  var d = document,
      s = 'script';
  var script = d.getElementById(id),
      firstScript = d.getElementsByTagName(s)[0];
  var locked = !registerInjectCallback(id, callback);
  if (!script) {
    script = d.createElement(s);
    script.id = id;
    script.src = url;
    //add marker to know if the script already exists or loaded or else injectComplete will never be called.
    script.attr('data-b8', true);
    script.onload = script.onerror = function () {
      injectComplete.call(this, id);
      script.removeAttribute('data-b8');
    };
    firstScript.parentNode.insertBefore(script, firstScript);
  } else if (!script.attr('data-b8')) {
    //script already exists or loaded
    callback();
  } else if (locked) {
    // when script is already added and the callback store is locked
    // don't wait and just invoke the callback
    callback();
  }
}

/***/ }),
/* 50 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return KEYS; });
/**
 * Common Key Codes
 */
var KEYS = {
  ENTER: 13,
  ESC: 27,
  F1: 112,
  F12: 123,
  LEFT: 37,
  UP: 38,
  RIGHT: 39,
  DOWN: 40,
  TAB: 9,
  SPACE: 32,
  PAGEUP: 33,
  PAGEDOWN: 34,
  END: 35,
  HOME: 36
};

/***/ }),
/* 51 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = escapeRegExp;
var REGEX_ESCAPE = /[.*+?^${}()|[\]\\]/g;
/**
 * Escapes input to be treated as a literal string within a regular expression.
 *
 * @param {input} string The string to escape
 */
function escapeRegExp(input) {
  return input.replace(REGEX_ESCAPE, '\\$&');
}

/***/ }),
/* 52 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Toggler; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__base_ui_control__ = __webpack_require__(1);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }





var Toggler = function (_UIControl) {
  _inherits(Toggler, _UIControl);

  _createClass(Toggler, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_2__base_ui_control__["a" /* UIControl */].$init(target, Toggler);
    }
  }]);

  function Toggler(element, config) {
    _classCallCheck(this, Toggler);

    if (__WEBPACK_IMPORTED_MODULE_0__utils_main__["isStr"](config)) {
      config = { target: config };
    }

    var _this = _possibleConstructorReturn(this, (Toggler.__proto__ || Object.getPrototypeOf(Toggler)).call(this, element, config));

    Object.assign(_this._.cfg, {});

    if (!_this.config.target) {
      _this.config.target = _this.el.hash;
    }

    if (_this.config.target && (_this._.target = __WEBPACK_IMPORTED_MODULE_0__utils_main__["get"](_this.config.target))) {
      var toggle = function (e) {
        e.preventDefault();
        _this.toggle();
      };
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](_this, element, 'click', toggle);

      if (_this.config.alt) {
        var alt = __WEBPACK_IMPORTED_MODULE_0__utils_main__["get"](_this.config.alt, _this.target);
        if (alt) {
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](_this, alt, 'click', toggle);
        }
      }
      //initially active.
      _this.activate();
    }
    return _this;
  }

  _createClass(Toggler, [{
    key: 'activate',
    value: function activate() {
      this.el.classList.add('toggler-active');
      this.el.classList.remove('toggler-inactive');
      this.target.style.display = 'none';
    }
  }, {
    key: 'deactivate',
    value: function deactivate() {
      this.el.classList.remove('toggler-active');
      this.el.classList.add('toggler-inactive');
      this.target.style.display = '';
    }
  }, {
    key: 'toggle',
    value: function toggle() {
      if (this.el.classList.contains('toggler-active')) {
        this.deactivate();
      } else {
        this.activate();
      }
    }
  }, {
    key: 'target',
    get: function () {
      return this._.target;
    }
  }]);

  return Toggler;
}(__WEBPACK_IMPORTED_MODULE_2__base_ui_control__["a" /* UIControl */]);

__WEBPACK_IMPORTED_MODULE_1__data_registry__["a" /* SET__TYPE__ */](Toggler, 'toggler');

/***/ }),
/* 53 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = push;
/* harmony export (immutable) */ __webpack_exports__["a"] = attach;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);


var TIMER = void 0;
var QUEUE = [],
    TIMEOUT = 500,
    // should be greater than transition duration
DEFAULTS = {
  duration: 5,
  position: {
    d: 'bc',
    m: 'b'
  },
  closable: true,
  element: undefined
},
    ATTR_CLOSE = 'data-attach-close',
    ATTR_POSITION = 'data-position',
    CLS_IS_OUTER = 'is-outer',
    CLS_IS_INNER = 'is-inner',
    _htmlFn = function (content, closable) {
  return '\n    ' + (closable ? '<a href="javascript:void(0)" ' + ATTR_CLOSE + ' class="b-close is-mute t-xsmall is-attached is-inner p20" ' + ATTR_POSITION + '="rc"></a>' : '') + '\n    ' + content + '\n  ';
},
    _templateFn = function (html, position, classes) {
  return '<div class="snackbar ' + classes + ' has-transition is-attached has-radius to-screen is-outer" ' + ATTR_POSITION + '-d="' + position.d + '" ' + ATTR_POSITION + '-m="' + position.m + '"> ' + html + ' </div>';
};

/**
 *  API for pushing messages or attaching elements to the screen.
*/
function push() {
  var msg = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  var config = arguments[1];

  QUEUE.push(__WEBPACK_IMPORTED_MODULE_0__utils_main__["merge"](true, {}, DEFAULTS, config, { msg: msg }));
  next();
}
function attach() {
  var html = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
  var config = arguments[1];

  return show(__WEBPACK_IMPORTED_MODULE_0__utils_main__["merge"](true, {}, DEFAULTS, config, { html: html }), true);
}

/**
 * Shows next snack if there is no visible one at the moment
 */
function next() {
  if (!QUEUE.locked && (QUEUE.locked = true)) {
    var config = QUEUE.shift();
    if (config) {
      show(config);
    } else {
      QUEUE.locked = false;
    }
  }
}

/**
 * Creates and displays a snack or attachable element.
 *
 * @param {Object} config The snack of attachable configuration
 * @param {Boolean} attach When true, the provided HTML will be attached as is.
 */
function show(config) {
  var attach = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;


  if (!config.el) {
    var html = void 0,
        classes = '',
        position = config.position;
    if (__WEBPACK_IMPORTED_MODULE_0__utils_main__["isStr"](position)) {
      position = {
        d: position,
        m: position
      };
    }
    if (attach) {
      html = config.html;
    } else {
      html = _htmlFn(config.msg, config.closable);
      classes = 'is-default';
    }
    // Build the snack
    // TODO: Create one snack and re-use it
    config.el = __WEBPACK_IMPORTED_MODULE_0__utils_main__["htmlToElement"](_templateFn(html, position, classes));
  }

  var attachTimer = void 0,
      showSnack = function () {
    return show(config, attach);
  },
      hideSnack = function () {
    hide(config.el, attach, attach ? attachTimer : TIMER);
    return showSnack;
  };

  // do nothing if already attached.
  if (config.el.parentElement) {
    return hideSnack;
  }

  if (attach) {
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["prependElement"](config.el, document.body);
  } else {
    document.body.appendChild(config.el);
  }

  // find all elements marked to close the snack
  __WEBPACK_IMPORTED_MODULE_0__utils_main__["find"]('[' + ATTR_CLOSE + ']', function (close) {
    close.addEventListener('click', function (e) {
      e.preventDefault();
      hideSnack();
    });
  }, config.el);

  if (config.el.offsetWidth) {
    // reflow
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["remClass"](CLS_IS_OUTER, config.el);
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["addClass"](CLS_IS_INNER, config.el);
  }
  if (config.duration) {
    var timeOut = setTimeout(function () {
      hideSnack();
    }, config.duration * 1000);
    if (attach) {
      attachTimer = timeOut;
    } else {
      TIMER = timeOut;
    }
  }
  return hideSnack;
}

/**
 * Hides and remove a snack of attachable element.
 *
 * @param {*} snack
 * @param {*} attach
 */
function hide(snack, attach, timer) {
  // clear the timer to prevent multiple calls to hide
  clearTimeout(timer);
  // no parent, already removed
  if (snack.parentElement) {
    var fallbackTimer = void 0,
        end = function () {
      clearTimeout(fallbackTimer);
      // remove the lister
      snack.removeEventListener('transitionend', end);
      remove(snack, attach);
    };
    snack.addEventListener('transitionend', end);
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["remClass"](CLS_IS_INNER, snack);
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["addClass"](CLS_IS_OUTER, snack);
    fallbackTimer = setTimeout(end, TIMEOUT);
  }
}

/**
 * Removes a snack or attachable element, then invokes next()
 *
 * @param {HTMLElement} snack The snack to remove
 * @param {Boolean} attach Flag indicating if this was attachable or a snack.
 */
function remove(snack, attach) {
  snack.parentElement && document.body.removeChild(snack);
  if (!attach) {
    QUEUE.locked = false;
    next();
  }
}

/***/ }),
/* 54 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ToggleSheet; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__mixins_tab_lock__ = __webpack_require__(55);
var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/*WARNING: TEMP CODE AHEAD*/





var DEFAULTS = {},
    CSS_HAS_TRANSITION = 'has-transition',
    CSS_IS_ACTIVE = 'is-active',
    CSS_NO_OVERFLOW = 'no-overflow',
    CSS_IS_ALL = 'is-all';

function _init() {
  var _this = this;

  if (this.config.activator) {
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["find"](this.config.activator, function (activator) {
      __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](_this, activator, 'click', function (e) {
        e.preventDefault();
        _this.open();
      });
    });
  }

  __WEBPACK_IMPORTED_MODULE_0__utils_main__["find"]('[data-close-sheet]', function (close) {
    _this._.refs.close = _this._.refs.close || close;
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](_this, close, 'click', function (e) {
      _this.close();
    });
  }, this.el);

  // Utils.find('[data-dispose-sheet]', (dispose) => {
  //   Utils.attachEvent(this, dispose, 'click', (e) => {
  //     this.dispose()
  //   })
  // }, this.el)

  __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, window, 'resize', function () {
    if (!_this.el.classList.contains(CSS_IS_ALL) && _this._.isMobile != __WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]()) {
      _this.close();
    }
  });

  /*HANDLING FORM SUBMIT IF EXIST*/
  __WEBPACK_IMPORTED_MODULE_0__utils_main__["find"]('[data-click]', function (clickElement) {
    __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](_this, clickElement, 'click', function (e) {
      document.qs(clickElement.attr('data-click')).click();
    });
  }, this.el);
}

function _setFocs() {
  var f = __WEBPACK_IMPORTED_MODULE_0__utils_main__["get"]('[data-sheet-focus-' + (__WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]() ? 'm' : 'd') + ']', this.el);
  f && f.focus && f.focus();
}

var ToggleSheet = function (_mixTabLock) {
  _inherits(ToggleSheet, _mixTabLock);

  _createClass(ToggleSheet, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_2__base_ui_control__["a" /* UIControl */].$init(target, ToggleSheet);
    }
  }]);

  function ToggleSheet(element) {
    var config = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck(this, ToggleSheet);

    config = Object.assign({}, DEFAULTS, 'toggleSheet' in config ? { activator: config.toggleSheet } : config);

    var _this2 = _possibleConstructorReturn(this, (ToggleSheet.__proto__ || Object.getPrototypeOf(ToggleSheet)).call(this, element, config));

    Object.assign(_this2._, {
      isMobile: undefined,
      refs: {
        close: undefined
      }
    });
    _init.call(_this2);
    return _this2;
  }

  _createClass(ToggleSheet, [{
    key: 'open',
    value: function open() {
      if (!this.isOpen) {
        this._.isMobile = __WEBPACK_IMPORTED_MODULE_0__utils_main__["isMobile"]();
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchHooks"]('beforeopen', this);
        this.lock();
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["addClass"](CSS_NO_OVERFLOW, document.body);
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["addClasses"](this.el, CSS_HAS_TRANSITION, CSS_IS_ACTIVE);
        _setFocs.call(this);
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchHooks"]('afteropen', this);
      }
    }
  }, {
    key: 'close',
    value: function close() {
      if (this.isOpen) {
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchHooks"]('beforeclose', this);
        this.unlock();
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["remClass"](CSS_NO_OVERFLOW, document.body);
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["remClasses"](this.el, CSS_IS_ACTIVE, CSS_HAS_TRANSITION);
        __WEBPACK_IMPORTED_MODULE_0__utils_main__["dispatchHooks"]('afterclose', this);
      }
    }
  }, {
    key: 'dispose',
    value: function dispose() {
      this.close();
      _get(ToggleSheet.prototype.__proto__ || Object.getPrototypeOf(ToggleSheet.prototype), 'dispose', this).call(this);
    }
  }, {
    key: 'isOpen',
    get: function () {
      return this.el.classList.contains(CSS_IS_ACTIVE);
    }
  }]);

  return ToggleSheet;
}(Object(__WEBPACK_IMPORTED_MODULE_3__mixins_tab_lock__["a" /* mixTabLock */])(__WEBPACK_IMPORTED_MODULE_2__base_ui_control__["a" /* UIControl */]));

__WEBPACK_IMPORTED_MODULE_1__data_registry__["a" /* SET__TYPE__ */](ToggleSheet, 'toggle-sheet');

/***/ }),
/* 55 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return mixTabLock; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_main__ = __webpack_require__(0);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }



var mixTabLock = function (superclass) {
  return function (_superclass) {
    _inherits(_class, _superclass);

    function _class() {
      _classCallCheck(this, _class);

      var _this = _possibleConstructorReturn(this, (_class.__proto__ || Object.getPrototypeOf(_class)).apply(this, arguments));

      if (!__WEBPACK_IMPORTED_MODULE_0__utils_main__["isObj"](_this._mixins)) _this._mixins = {};

      Object.assign(_this._mixins, {
        tabLock: {
          resets: [],
          active: false,
          tabIndex: null
        }
      });
      return _this;
    }

    _createClass(_class, [{
      key: 'lock',
      value: function lock() {

        var resets = this._mixins.tabLock.resets;
        if (!resets.length) {
          resets.push(document.createElement('button'));
          resets[0].className = 'js-tabtrap';

          resets.push(document.createElement('button'));
          resets[1].className = 'js-tabtrap';

          this.el.insertBefore(resets[0], this.el.firstElementChild);
          this.el.appendChild(resets[1]);
        }

        if (!this._mixins.tabLock.active && (this._mixins.tabLock.active = true)) {

          resets[0].focus();

          __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, resets[0], 'keydown', function (e) {
            if (e.shiftKey === true && e.key === "Tab") resets[1].focus();
          });

          __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, resets[1], 'keydown', function (e) {
            if (e.shiftKey === false && e.key === "Tab") resets[0].focus();
          });

          if (!this._mixins.tabLock.tabIndex) this._mixins.tabLock.tabIndex = document.body.getAttribute('tabindex');

          document.body.attr('tabindex', '0');

          __WEBPACK_IMPORTED_MODULE_0__utils_main__["attachEvent"](this, document.body, 'focus', function (e) {
            //console.log('focusing...', e)
            resets[0].focus();
          });
        }
      }
    }, {
      key: 'unlock',
      value: function unlock() {
        var _this2 = this;

        if (this._mixins.tabLock.active) {
          var resets = this._mixins.tabLock.resets;
          resets.forEach(function (reset) {
            __WEBPACK_IMPORTED_MODULE_0__utils_main__["detachEvent"](_this2, reset, 'keydown');
          });
          __WEBPACK_IMPORTED_MODULE_0__utils_main__["detachEvent"](this, document.body, 'focus');
          if (!this._mixins.tabLock.tabIndex) document.body.removeAttribute('tabindex');else document.body.attr('tabindex', this._mixins.tabLock.tabIndex);

          this._mixins.tabLock.active = false;
        }
      }
    }]);

    return _class;
  }(superclass);
};

/***/ }),
/* 56 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Searchable; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__searchable_core__ = __webpack_require__(57);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_popover_popover__ = __webpack_require__(34);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_i18n_res__ = __webpack_require__(7);
var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }








var Searchable = function (_UIControl) {
  _inherits(Searchable, _UIControl);

  _createClass(Searchable, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_3__shared_base_ui_control__["a" /* UIControl */].$init(target, Searchable);
    }
  }]);

  function Searchable(element, config) {
    _classCallCheck(this, Searchable);

    var _this = _possibleConstructorReturn(this, (Searchable.__proto__ || Object.getPrototypeOf(Searchable)).call(this, element, Object.assign({
      view: {
        title: __WEBPACK_IMPORTED_MODULE_5__shared_i18n_res__["a" /* res */].search,
        empty: __WEBPACK_IMPORTED_MODULE_5__shared_i18n_res__["a" /* res */].noMatch,
        placeholder: '',
        highlight: true
      }, data: {
        search: '^',
        dependsOn: ''
      },
      optional: false,
      delayDispatch: false
    }, config)));
    //Object.assign is one level.


    Object.assign(_this._, {
      refs: {
        input: undefined, // holds the readonly textbox for select.
        suggest: undefined, //a clone of the textbox used for typeahead hint.
        spinner: undefined, // used to indicate waiting while fetching data.
        popover: undefined, // holds the popover instance used to show results.
        focus: undefined, //holds the element to focus when viewed on mobile.
        search: undefined, //hold the results search box.
        options: undefined, //holds the options list
        clear: undefined, //holds the clear option
        postbackOption: undefined // holds the postback option
      },
      cache: [],
      cached: false,
      select: element.tagName === 'SELECT',
      refillOptions: function (data) {}
    });

    //SELECT with no fetch, then use own options.
    if (_this._.select) {

      // check if first option will act as a placeholder.
      var firstOpt = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('option', _this.el);
      _this.el.setAttribute('placeholder', firstOpt && firstOpt.disabled && !firstOpt.getAttribute('value') ? firstOpt.textContent : _this.config.view.placeholder || '');
      _this.el.setAttribute('autocomplete', 'nope');
      // see if selection is to be taken from data attribute.
      var checkSelected = _this.el.getAttribute('data-value') === null;

      var _this$config$data = _this.config.data;
      _this$config$data = _this$config$data === undefined ? {} : _this$config$data;
      var _this$config$data$tex = _this$config$data.text,
          textKey = _this$config$data$tex === undefined ? 'text' : _this$config$data$tex,
          _this$config$data$val = _this$config$data.value,
          valueKey = _this$config$data$val === undefined ? 'value' : _this$config$data$val,
          _this$config$data$gro = _this$config$data.group,
          groupKey = _this$config$data$gro === undefined ? '' : _this$config$data$gro;

      if (!_this.config.data.fetch) {
        _this.config.data.static = true;
        var selectElement = _this.el,
            selectOptions = [],
            importOption = function (opt, group) {
          // set selection using selected option
          if (!opt.disabled) {
            if (checkSelected && opt.selected) {
              selectElement.setAttribute('data-value', opt.value);
              checkSelected = false;
            }
            var record = {};
            record[textKey] = opt.text;
            record[valueKey] = opt.value;
            if (groupKey) record[groupKey] = group;
            selectOptions.push(record);
          }
        };
        _this.config.data.fetch = function (value, callback) {
          !selectOptions.length && [].forEach.call(selectElement.children, function (opt) {
            if (opt.tagName == 'OPTGROUP') [].forEach.call(opt.children, function (o) {
              return importOption(o, opt.label);
            });else importOption(opt);
          }, this);
          return callback(selectOptions, value);
        };
      }
      if (_this.config.data.static) {
        _this._.refillOptions = function (data) {
          var value = _this.el.value;
          //only in case of static source clear select and fill the options
          __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["clearChildren"](_this._.el);
          //append placeholder item
          _this._.el.appendChild(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<option value="" selected>' + _this.el.attr('placeholder') + '</option>'));
          data.forEach(function (record) {
            this._.el.appendChild(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<option value="' + __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveVal"](record, valueKey) + '">' + __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveVal"](record, textKey) + '</option>'));
          }, _this);
          _this.el.value = value;
        };
      }
    }
    _this.dispatching = !_this.config.delayDispatch;
    __WEBPACK_IMPORTED_MODULE_2__searchable_core__["a" /* create */].call(_this, function () {
      var _this$config$on = _this.config.on;
      _this$config$on = _this$config$on === undefined ? {} : _this$config$on;
      var onReady = _this$config$on.ready;

      var readyFn = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](onReady);
      if (readyFn) {
        readyFn.call(_this);
      }
      _this.dispatching = true;
    });
    return _this;
  }

  _createClass(Searchable, [{
    key: 'refetchCache',
    value: function refetchCache() {
      __WEBPACK_IMPORTED_MODULE_2__searchable_core__["c" /* refetchCache */].call(this);
    }
  }, {
    key: 'clear',
    value: function clear() {
      this.value = "";
    }
  }, {
    key: 'dispose',
    value: function dispose() {
      _get(Searchable.prototype.__proto__ || Object.getPrototypeOf(Searchable.prototype), 'dispose', this).call(this);
      __WEBPACK_IMPORTED_MODULE_2__searchable_core__["b" /* destroy */].call(this);
    }
  }, {
    key: 'is',
    get: function () {
      return {
        select: this._.select,
        searchahead: this.config.data.search === '^',
        typeahead: !this._.select && this.config.data.search === '^',
        searchable: !this._.select || this.config.data.search !== false
      };
    }
  }, {
    key: 'value',
    set: function (value) {
      var selection = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-value="' + value + '"]', this._.refs.options) || this._.refs.options.qs('li');
      __WEBPACK_IMPORTED_MODULE_2__searchable_core__["d" /* setValue */].call(this, selection);
    }
  }, {
    key: 'input',
    get: function () {
      return this._.input;
    }
  }, {
    key: 'popover',
    get: function () {
      return this._.popover;
    }
  }, {
    key: 'cache',
    get: function () {
      return this._.cache;
    }
  }]);

  return Searchable;
}(__WEBPACK_IMPORTED_MODULE_3__shared_base_ui_control__["a" /* UIControl */]);

__WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["a" /* SET__TYPE__ */](Searchable, 'searchable');

/***/ }),
/* 57 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export filterData */
/* unused harmony export createSearchExpression */
/* harmony export (immutable) */ __webpack_exports__["d"] = setValue;
/* harmony export (immutable) */ __webpack_exports__["a"] = create;
/* harmony export (immutable) */ __webpack_exports__["c"] = refetchCache;
/* harmony export (immutable) */ __webpack_exports__["b"] = destroy;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__searchable_options__ = __webpack_require__(58);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_i18n_res__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_popover_popover__ = __webpack_require__(34);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_scrollLock_scrollLock__ = __webpack_require__(37);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__shared_viewSize_viewSize__ = __webpack_require__(40);







var ATTR_DATA_TEXT = 'data-text',
    ATTR_DATA_VALUE = 'data-value',
    ATTR_PLACEHOLDER = 'placeholder',
    ATTR_DATA_POPOVER = 'data-popover',
    ATT_DATA_EMPTY = 'data-empty',
    CLS_IS_ACTIVE = 'is-active',
    CLS_SEARCHABLE = 'searchable',
    CLS_POPOVER_OWNER = 'popover-owner',
    CLS_IS_SELECTED = 'is-selected',
    CSS_IS_ACTIVE = '.' + CLS_IS_ACTIVE,
    CSS_SEARCHABLE = '.' + CLS_SEARCHABLE,
    CSS_SELECT = '.select',
    FN_TRAVERSE_PREDICATE = function (node) {
  return node.matches('[' + ATTR_DATA_TEXT + ']');
};

var _spinnerTemplateFn = function () {
  return '\n<i class="loader d" style="opacity: 0;" data-loader></i>\n';
};
var getName = function (name) {
  var template = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '$1__v';

  var regex = new RegExp('(' + __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["escapeRegExp"](name) + ')');
  return name.replace(regex, template);
};

var _selectReplacementTemplateFn = function (id, name, classes, placeholder) {
  return '\n<input type="text" ' + (id ? 'id=' + id + '__r' : '') + ' ' + (name ? 'name=' + name : '') + ' class="' + classes + '" placeholder="' + placeholder + '" data-input readonly>\n';
};
var _searchBoxTemplateFn = function () {
  var select = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
  return '\n<div class="list-menu-title ' + (!select ? 'm' : '') + '">\n  <div class="has-icon">\n    <input type="search" class="input is-small u-expanded" placeholder="' + __WEBPACK_IMPORTED_MODULE_3__shared_i18n_res__["a" /* res */].search + ' ..." data-search>\n    <span class="icon is-search"></span>\n  </div>\n</div>';
};

var _popoverTemplateFn = function (title, placeholder, emptyPlaceholder) {
  var placement = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'bl';
  var searchable = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;
  var select = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : false;
  var fitted = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : false;
  var bidi = arguments.length > 7 && arguments[7] !== undefined ? arguments[7] : false;
  return '\n<div class="popover is-full ' + (fitted ? 'is-fit' : 'is-wide') + '" data-placement="' + placement + '" tabindex="0" data-scrolllock=\'{"unblock":".list-menu-group"}\'>\n  <div class="list-menu is-autosize">\n    <div class="list-menu-title m">\n      <a data-popover-close data-focus href="#" class="b-close is-large t-mute u-abs m"></a>\n      <h6 class="t-center-m m0">' + title + '</h6>\n    </div>\n    ' + (searchable ? _searchBoxTemplateFn(select) : '') + '\n    <div class="list-menu-group no-minsize" data-viewsize=\'{"d":{"height":{ "max":0.5 }}}\'>\n      <ul class="options is-autosize ' + (bidi ? 'has-bidi' : '') + '" data-empty="' + emptyPlaceholder + '"></ul>\n    </div>\n  </div>\n</div>';
};

/**
 *  Filters the provided dataset according to search term.
 *
 * @param {string} term The search term.
 * @param {array} dataset The dataset to filter
 * @param {object} config The searchable instance configuration
 * @param {RegExp} expression The filtering regular expression.
 */
var filterData = function (term, dataset, config, expression) {
  return dataset.filter(function (v) {
    return v[config.data.text || 'text'].match(expression) != null;
  });
};

/**
 * Creates a RegExp to search for a specific search term.
 *
 * @param {string} term The search term.
 * @param {boolean} beginsWith When true, searches the beginning of input.
 *
 * @return {RegExp} a new RegExp capturing the escaped search term.
 */
function createSearchExpression(term, beginsWith) {
  return new RegExp((beginsWith ? '^' : '') + '(' + __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["escapeRegExp"](term) + ')', 'ig');
}

/**
 * Handles different keyboard events (MUST be bound to the instance).
 *
 *
 * @param {Event} e The keyboard event object.
 */
function keydownHandler(e) {
  if (e.keyCode == __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ESC) {
    // clear the suggestion and close the popover.
    if (this.is.typeahead) {
      this._.refs.suggest.attr(ATTR_PLACEHOLDER, '');
    }
    //only if popover is open prevent default
    if (this.popover.active) {
      e.preventDefault();
      e.stopPropagation();
      this.popover.close();
      this.is.select && !__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]() && this._.refs.input.focus();
    }
  } else if (e.keyCode == __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].TAB) {
    if (this.is.typeahead) {
      // if typeahead
      var suggestion = this._.refs.suggest.attr(ATTR_PLACEHOLDER) || '';
      if (suggestion.length) {
        e.preventDefault();
        // set the value to the suggestion and close the popover
        this.el.value = suggestion;
        this._.refs.suggest.attr(ATTR_PLACEHOLDER, '');
      }
    } else if (this.is.select && this.popover.active) {
      // auto select active item when tabbing out.
      var active = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](CSS_IS_ACTIVE, this._.refs.options);
      if (active) {
        setValue.call(this, active);
      }
    }
    this.popover.close();
  } else if (e.keyCode == __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].DOWN) {

    // find active option
    var target = void 0,
        _active = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](CSS_IS_ACTIVE, this._.refs.options);

    // prevents cycling options
    // if (active === this._.refs.options.lastElementChild) {
    //   e.preventDefault()
    //   return
    // }

    // if found, deactivate it and get next sibling or the first item
    var firstChild = this._.refs.options.firstElementChild,
        startFrom = firstChild;
    if (_active) {
      _active.classList.remove(CLS_IS_ACTIVE);
      startFrom = _active;
    }
    target = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["traverse"](startFrom, 'nextElementSibling', FN_TRAVERSE_PREDICATE, firstChild, !!_active);

    // if there is a target
    if (target) {
      e.preventDefault();
      // activate it and use its value
      target.classList.add(CLS_IS_ACTIVE);
      if (this.is.typeahead) {
        this._.refs.suggest.attr(ATTR_PLACEHOLDER, '');
      }
      setValue.call(this, target);
      // if open
      if (this.popover.active) {
        // scroll the list so the item is visible in view.
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["bringIntoView"](target, this._.refs.options.parentElement);
      }
    }
  } else if (e.keyCode == __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].UP) {

    // find active option
    var _target = void 0,
        _active2 = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](CSS_IS_ACTIVE, this._.refs.options);

    // prevents cycling options
    // if (active === this._.refs.options.firstElementChild) {
    //   e.preventDefault()
    //   return
    // }

    // if found
    var lastChild = this._.refs.options.lastElementChild,
        _startFrom = lastChild;
    if (_active2) {
      // deactivate it and get previous sibling or the last item
      _active2.classList.remove(CLS_IS_ACTIVE);
      _startFrom = _active2;
    }
    _target = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["traverse"](_startFrom, 'previousElementSibling', FN_TRAVERSE_PREDICATE, lastChild, !!_active2);
    // if there is a target
    if (_target) {
      e.preventDefault();
      // activate it and use its value
      _target.classList.add(CLS_IS_ACTIVE);
      if (this.is.typeahead) {
        this._.refs.suggest.attr(ATTR_PLACEHOLDER, '');
      }
      setValue.call(this, _target);

      // if open
      if (this.popover.active) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["bringIntoView"](_target, this._.refs.options.parentElement, true);
      }
    }
  } else if (e.keyCode === __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].SPACE) {
    if (e.target.readOnly) {
      e.preventDefault();
      this.popover.open();
      if (this.is.searchable) {
        this._.refs.search.focus();
      }
    }
  } else if (e.keyCode === __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ENTER) {
    //prevent form submission when enter used by searchable
    if (this.popover.active) {
      e.preventDefault();
    }
  }
}

/**
 * Handles ENTER in keyup event to prevent collision with modals. (MUST be bound to the instance).
 *
 * @param {Event} e The keyboard event object.
 */
function keyupHandler(e) {
  if (e.keyCode == __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ENTER) {
    // find active option
    var active = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](CSS_IS_ACTIVE, this._.refs.options);
    // if found
    if (active) {
      e.preventDefault();
      e.stopPropagation();
      // use its value and close the popover
      setValue.call(this, active, true);
      if (this.is.typeahead) {
        this._.refs.suggest.attr(ATTR_PLACEHOLDER, '');
      }
      this.popover.close();
    } else if (this.is.typeahead) {
      // if not found and there is a suggestion
      var suggestion = this._.refs.suggest.attr(ATTR_PLACEHOLDER);
      if (suggestion.length) {
        e.preventDefault();
        // use it and close the popover
        this.el.value = suggestion;
        this._.refs.suggest.attr(ATTR_PLACEHOLDER, '');
        this.popover.close();
      }
    }
  }
}

/**
 * Handls rendering data feteched from data source (MUST be bound to the instance).
 *
 * @param {array} dataset The search results..
 * @param {HTMLElement} element The element that triggered the fetch operation
 * @param {string} value The orginal search value
 * @param {function} cb The function to call once fetching and rendering is complete.
 * @param {boolean} silent A flag indicating this was a silent call (in case of caching data)
 */
function renderHanlder(dataset, element, originalValue, cb) {
  var _this = this;

  var silent = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;

  if (!silent) {
    // hide the loader when suggestions are populated.
    this._.refs.spinner && (this._.refs.spinner.style.opacity = 0);
    // do nothing if the element lost focus or the original value does not match
    if (element.value != originalValue || element != document.activeElement && element != this._.refs.search) {
      return;
    }
  }

  // clear all items.
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["clearChildren"](this._.refs.options);
  // if we have data.
  if (dataset.length) {
    this._.refs.options.scrollTop = 0;
    var expression = createSearchExpression(originalValue, this.is.searchahead);
    // if typeahead mode, set the hint to match the input case
    if (!silent && this.is.typeahead && !__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
      // grab the text of the first item
      var firstText = dataset[0][this.config.data.text];
      // replace the placeholder with the result text to match the case
      this._.refs.suggest.attr(ATTR_PLACEHOLDER, firstText.replace(expression, originalValue));
    }

    var groupBy = this.config.data.group,
        groups = null;
    if (groupBy) {
      groups = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["groupBy"](dataset, groupBy);
    }

    var docfrag = __WEBPACK_IMPORTED_MODULE_2__searchable_options__["a" /* renderItems */](function (renderItem, renderGroup) {
      if (groups != null) {
        Object.keys(groups).forEach(function (key) {
          var dataGroup = groups[key];
          renderGroup(key);
          for (var index = 0; index < dataGroup.length; index++) {
            renderItem(dataGroup[index]);
          }
        });
      } else {
        for (var index = 0; index < dataset.length; index++) {
          renderItem(dataset[index]);
        }
      }
    }, this.config, expression);
    // append all elements at once and reflow
    this._.refs.options.style.overflow = 'hidden';
    this._.refs.options.appendChild(docfrag);
    // prepend clear option
    if (this.is.select && this.config.optional && !originalValue) {
      if (!this._.refs.clear) {
        // create the option only once.
        // item click is handled by options click handler
        this._.refs.clear = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<li disabled data-text="" data-value="">' + (this.el.attr(ATTR_PLACEHOLDER) || '') + '</li>');
      }
      // add to the begining of the list.
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["prependElement"](this._.refs.clear, this._.refs.options);
    }

    //grab the first item and activate it.
    if (this.popover.active) {
      var firstItem = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["traverse"](this._.refs.options.firstElementChild, 'nextElementSibling', function (t) {
        return t.matches('[data-text]');
      }, null, false); // Utils.get('li', this._.refs.options)
      if (firstItem) {
        firstItem.classList.add(CLS_IS_ACTIVE);
      }
    }
    this._.refs.options.style.overflow = '';
  } else if (!this.is.select) {
    var value = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]() ? this._.refs.search.value : this._.refs.input.value;
    if (!this._.refs.dynamic) {
      // create the option only once.
      this._.refs.dynamic = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<li data-text="' + value + '">' + value + '</li>');
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this._.refs.dynamic, 'click', function (e) {
        e.preventDefault();
        setValue.call(_this, _this._.refs.dynamic, true);
        _this.popover.close();
        //should be removed on close when source is not static
        _this._.refs.dynamic.parentElement && _this._.refs.options.removeChild(_this._.refs.dynamic);
      });
    }
    this._.refs.dynamic.attr(ATTR_DATA_TEXT, this._.refs.dynamic.textContent = value);
    // add to the begining of the list if not already added
    !this._.refs.dynamic.parentElement && __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["prependElement"](this._.refs.dynamic, this._.refs.options);
  }
  cb(dataset);
}

/**
 * Handls fetching data from async data source (MUST be bound to the instance).
 *
 * @param {string} value The value to search for.
 * @param {HTMLElement} element The element triggering the fetch operation
 * @param {function} cb The function to call once fetching and rendering is complete.
 */
function fetchHandler(value, element) {
  var _this2 = this;

  var cb = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function () {
    return void 0;
  };
  var silent = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;


  // if no fetch function, do nothin
  var fetchFn = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](this.config.data.fetch);
  if (!__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](fetchFn)) {
    return;
  }
  if (this.config.data.static === true) {
    var fetchFromCache = function (term, silent) {
      // if no filter function supplied, use a default.
      var filterFn = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](_this2.config.data.filter, filterData);
      var expression = createSearchExpression(term, _this2.config.data.search === '^');
      renderHanlder.call(_this2, filterFn(term, _this2._.cache, _this2.config, expression), element, value, cb, silent);
    };
    if (!this._.cached) {
      //pass null for first time to get all data
      fetchFn.call(this, null, function (data, originalValue) {
        //cache data
        _this2._.cache = data;
        //mark as cached
        _this2._.cached = true;

        //only in case of static source
        //clear select and fill the options
        _this2._.refillOptions(data);
        //refill from cache
        fetchFromCache(value, true);
      }, this.config);
    } else {
      fetchFromCache(value);
    }
  } else {
    // do fetch
    fetchFn.call(this, value, function (data, value) {
      renderHanlder.call(_this2, data, element, value, cb, silent);
    }, this.config);
  }
}

/**
 * Sets the selected value
 *
 * @param {HTMLElement} selection The selected LI option
 * @param {Boolean} refocus Indicates if orginal input should be refocused - defaults to false
 */
function setValue(selection) {
  var refocus = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;

  //grab format function or use default.
  var formatFn = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](this.config.data.format, function (selected, input) {
    return selected && selected.attr(ATTR_DATA_TEXT);
  });
  //set the formatted value
  this._.refs.input.value = formatFn(selection, this._.refs.input);
  //set select value too & refocus input.
  if (this.is.select) {
    // add option to hold the select value to be posted back to server.
    if (!this.config.data.static && selection) {
      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-value="' + selection.attr(ATTR_DATA_VALUE) + '"]', this._.refs.options)) {
        //option exists
        var postbackOption = this._.refs.postbackOption;
        if (!postbackOption) {
          postbackOption = document.createElement('option');
          postbackOption.attr('data-searchable-pb', true);
        }
        this.el.appendChild(postbackOption);
        postbackOption.text = selection.attr(ATTR_DATA_TEXT);
        postbackOption.value = selection.attr(ATTR_DATA_VALUE);
        this._.refs.postbackOption = postbackOption;
      }
    }
    this.el.value = selection && selection.attr(ATTR_DATA_VALUE);
    var selected = { text: selection && selection.attr(ATTR_DATA_TEXT), value: this.el.value

      //fire change event only if new value is different from an old set value.
    };if ('ov' in this._ && this._.ov != this.el.value) {
      var args = Object.assign({ oldValue: this._.ov }, selected);
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["dispatchHooks"]('change', this, args);
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["dispatchEvent"]('searchable.change', this, args);
    }
    this._.ov = this.el.value;

    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["dispatchHooks"]('select', this, selected);
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["dispatchEvent"]('searchable.select', this, selected);
    //refocus
    refocus && !__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]() && this._.refs.input.focus();
  }
}

/**
 * Creates required DOM and binds events for searchable (MUST be bound to the instance).
 */
function create() {
  var _this3 = this;

  var cb = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["NOOP"];


  // wrap inside searchable container
  var wrapper = this.el.closest(this.is.select ? CSS_SELECT : CSS_SEARCHABLE);
  if (!wrapper) {
    wrapper = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<div></div>');
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["wrapElement"](this.el, wrapper);
  }
  wrapper.classList.add(CLS_SEARCHABLE);
  wrapper.classList.add(CLS_POPOVER_OWNER);

  //move input-pack classes to the wrapper div
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["movClasses"](this.el, wrapper, false, 'in-pack', 'is-double', 'is-triple');

  wrapper.attr(ATTR_DATA_POPOVER, JSON.stringify({ trigger: 'none', transition: false, relocate: true }));

  var placeholder = this.el.attr(ATTR_PLACEHOLDER);
  var _config$view = this.config.view;
  _config$view = _config$view === undefined ? {} : _config$view;
  var _config$view$empty = _config$view.empty,
      dataEmpty = _config$view$empty === undefined ? __WEBPACK_IMPORTED_MODULE_3__shared_i18n_res__["a" /* res */].noMatch : _config$view$empty;

  // create the popover

  this._.refs.popover = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](_popoverTemplateFn(this.config.view.title || placeholder, placeholder, this.is.select ? dataEmpty : this.config.view.placeholder, this.config.view.placement, this.is.searchable, this.is.select, this.config.view.fitted, this.config.view.bidi));
  this._.refs.focus = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-focus]', this._.refs.popover);
  this._.refs.search = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-search]', this._.refs.popover);
  this._.refs.options = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('.options', this._.refs.popover);

  wrapper.appendChild(this._.refs.popover);

  if (this.is.select) {
    //use select to hold the value
    //this._.refs.value = this.el
    //add select replace
    this.el.attr('style', 'display:none !important');
    var input = this._.refs.input = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](_selectReplacementTemplateFn(this.el.id, getName(this.el.name, this.config.view.name), this.el.className, placeholder));
    wrapper.insertBefore(input, this.el);
  } else {
    this._.refs.input = this.el;
    //add spinner
    this._.refs.spinner = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](_spinnerTemplateFn());
    wrapper.appendChild(this._.refs.spinner);
    //add typeahead field
    if (this.is.typeahead) {
      var suggest = this._.refs.suggest = this.el.cloneNode();
      suggest.value = "";
      suggest.removeAttribute('id');
      suggest.removeAttribute('name');
      suggest.removeAttribute('data-searchable');
      suggest.attr('tabindex', '-1');
      suggest.attr(ATTR_PLACEHOLDER, '');
      suggest.classList.add('is-suggest');
      wrapper.insertBefore(suggest, this.el);
    }
  }

  __WEBPACK_IMPORTED_MODULE_4__shared_popover_popover__["a" /* Popover */].$init(wrapper);
  __WEBPACK_IMPORTED_MODULE_5__shared_scrollLock_scrollLock__["a" /* ScrollLock */].$init(this._.refs.popover);
  Object(__WEBPACK_IMPORTED_MODULE_6__shared_viewSize_viewSize__["a" /* $init */])(wrapper);
  //resolve once
  this._.popover = __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["d" /* resolve */](__WEBPACK_IMPORTED_MODULE_4__shared_popover_popover__["a" /* Popover */], wrapper);
  this._.scrollLock = __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["d" /* resolve */](__WEBPACK_IMPORTED_MODULE_5__shared_scrollLock_scrollLock__["a" /* ScrollLock */], this._.refs.popover);
  var invokeCallback = true,
      debouncedFetchFn = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["debounce"](fetchHandler.bind(this), +this.config.data.delay);
  // static sources are filled once, then filtered.
  if (this.is.select && this.config.data.static) {
    invokeCallback = false;
    debouncedFetchFn('', this.el, function () {
      var autoSelect = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](_this3.config.data.selected, function () {
        return _this3.el.attr(ATTR_DATA_VALUE) || _this3.el.value;
      });
      var value = autoSelect.call(_this3);
      if (value) {
        _this3.value = value;
      }
      cb(_this3);
    });
  }

  if (this.config.data.dependsOn) {
    var parent = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](this.config.data.dependsOn);
    if (parent) {
      var value = this.el.value || this.el.attr(ATTR_DATA_VALUE);
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, parent, 'b8._searchable.select', function (e) {
        var selectedItem = e.detail.data;
        renderHanlder.call(_this3, [], _this3.el, "", function () {}, true);
        debouncedFetchFn(selectedItem, _this3.el, function () {
          _this3.value = value;
          value = "";
        }, true);
      });
    }
  }

  // bind events
  if (this.is.searchable) {
    //[1 of 4] Fixes IE firing input event on focus/blur unlike other browsers
    var lastValue = null;

    //[2 of 4] Fixes IE firing input event on focus/blur unlike other browsers
    if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isIE"]()) {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this._.refs.search, 'focusin', function (e) {
        lastValue = _this3._.refs.search.value;
      });
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this._.refs.search, 'focusout', function (e) {
        lastValue = _this3._.refs.search.value;
      });
    }
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this._.refs.search, 'input', function (e) {
      //[3 of 4] Fixes IE firing input event on focus/blur unline other browsers
      if (lastValue === _this3._.refs.search.value) {
        return;
      }
      var value = e.currentTarget.value;
      debouncedFetchFn(value, e.currentTarget, function () {
        var _config$view2 = _this3.config.view;
        _config$view2 = _config$view2 === undefined ? {} : _config$view2;
        var _config$view2$empty = _config$view2.empty,
            dataEmpty = _config$view2$empty === undefined ? __WEBPACK_IMPORTED_MODULE_3__shared_i18n_res__["a" /* res */].noMatch : _config$view2$empty;

        _this3._.refs.options.attr(ATT_DATA_EMPTY, !value.length ? _this3.config.view.placeholder : dataEmpty);
      });

      //[4 of 4] Fixes IE firing input event on focus/blur unline other browsers
      lastValue = null;
    });
  }
  if (!this.is.select) {
    //[1 of 4] Fixes IE firing input event on focus/blur unline other browsers
    var _lastValue = null;
    //[2 of 4] Fixes IE firing input event on focus/blur unline other browsers
    if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isIE"]()) {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this.el, 'focusin', function (e) {
        _lastValue = _this3.el.value;
      });
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this.el, 'focusout', function (e) {
        _lastValue = _this3.el.value;
      });
    }

    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this.el, 'input', function (e) {
      //[3 of 4] Fixes IE firing input event on focus/blur unline other browsers
      if (_lastValue === _this3.el.value) {
        return;
      }
      var value = e.currentTarget.value;
      if (_this3.is.typeahead) {
        // if there is a suggestion, match its case to the input
        var suggestion = _this3._.refs.suggest.attr(ATTR_PLACEHOLDER) || '';
        var expression = createSearchExpression(value, _this3.is.searchahead);
        if (value.length === 0 || !suggestion.match(expression)) {
          _this3._.refs.suggest.attr(ATTR_PLACEHOLDER, '');
        } else {
          _this3._.refs.suggest.attr(ATTR_PLACEHOLDER, suggestion.replace(expression, value));
        }
      }
      _this3._.refs.options.attr(ATT_DATA_EMPTY, !value.length ? _this3.config.view.placeholder : _this3.config.view.empty);
      if (value.length) {
        debouncedFetchFn(value, e.currentTarget, function () {
          if (!__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
            if (_this3._.refs.options.children.length) {
              _this3.popover.open();
            } else {
              _this3.popover.close();
            }
          }
        });
      } else if (!__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
        _this3.popover.close();
      }
      //[4 of 4] Fixes IE firing input event on focus/blur unline other browsers
      _lastValue = null;
    });
  }
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this._.refs.input, 'focus', function (e) {
    if (_this3.is.typeahead) {
      _this3._.refs.suggest.classList.add('has-focus');
    }
  });
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this._.refs.input, 'blur', function (e) {
    if (_this3.is.typeahead) {
      _this3._.refs.suggest.classList.remove('has-focus');
    }
  });

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this._.refs.input, 'click', function (e) {
    if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["saveScrollPosition"]();
      _this3.popover.open();
    } else if (_this3.is.select) {
      _this3.popover.active ? _this3.popover.close(true) : _this3.popover.open();
    }
  });

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, wrapper, 'b8._popover.open', function (e) {
    //helper to set current selection
    var updateSelection = function () {
      var selection = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('.is-selected', _this3._.refs.options);
      if (selection) {
        selection.classList.remove(CLS_IS_SELECTED);
      }
      // see if there is a value and select it
      selection = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-value="' + _this3.el.value + '"]', _this3._.refs.options);
      // if there is a selection
      if (selection) {
        e.preventDefault();
        //remove any other active value
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"](CSS_IS_ACTIVE, function (item) {
          item.classList.remove(CLS_IS_ACTIVE);
        }, _this3._.refs.options);
        // select it
        selection.classList.add(CLS_IS_SELECTED);
        selection.classList.add(CLS_IS_ACTIVE);

        // scroll the list so the item is visible in view.
        !__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]() && __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["bringIntoView"](selection, _this3._.refs.options.parentElement, true);
        //this._.refs.options.parentElement.scrollTop = selection.offsetTop
      }
    };

    if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
      if (_this3.is.searchable) {
        debouncedFetchFn(_this3._.refs.search.value, _this3._.refs.search, function () {
          updateSelection();
          _this3._.refs.focus.focus();
        });
      } //searchable
      else {
          //delay focus till the element is visible on screen
          setTimeout(function () {
            _this3._.refs.focus.focus();
          }, 5);
        }
    } else if (_this3.is.select) {
      updateSelection();
      _this3.is.searchable && _this3._.refs.search.focus();
    }
  });

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, wrapper, 'b8._popover.close', function (e) {
    if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
      requestAnimationFrame(function () {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["restoreScrollPosition"]();
      });
    }
    // clear suggestion when closed
    if (_this3.is.typeahead) {
      _this3._.refs.suggest.attr(ATTR_PLACEHOLDER, '');
    }
    // clear filter when closed
    if (_this3.is.select && _this3.is.searchable) {
      _this3._.refs.search.value = '';
      debouncedFetchFn(_this3._.refs.search.value, _this3._.refs.search);
    }

    // clear fetched items on close
    if (!_this3.config.data.static) {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["clearChildren"](_this3._.refs.options);
    }

    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["dispatchHooks"]('close', _this3, { text: _this3._.refs.input.value, value: _this3.el.value });
  });

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, wrapper, 'keydown', keydownHandler.bind(this));
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, wrapper, 'keyup', keyupHandler.bind(this));

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this._.refs.options, 'mousemove', function (e) {
    // if there is an active item, clear it
    var item = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](CSS_IS_ACTIVE, _this3._.refs.options);
    item && item.classList.remove(CLS_IS_ACTIVE);
  });

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, this._.refs.options, 'click', function (e) {
    var target = e.target.closest('[data-text]');
    if (target) {
      e.preventDefault();
      setValue.call(_this3, target, true);
      _this3.popover.close();
    }
  });
  if (invokeCallback) cb(this);
}

/**
 * Forces refetch of a static select
 */
function refetchCache() {
  var _this4 = this;

  this.dispatching = false;
  this._.cached = false;
  var value = this.el.value;
  fetchHandler.call(this, '', this.el, function () {
    _this4.el.value = value;
    _this4.dispatching = true;
  }, true);
}

/**
 * destroys the searchable
 */
function destroy() {
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachAllEvents"](this);
  __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["e" /* unregister */](this);
  var wrapper = this.el.closest(this.is.select ? CSS_SELECT : CSS_SEARCHABLE);
  if (wrapper) {
    wrapper.removeAttribute(ATTR_DATA_POPOVER);
    if (!this.is.select) {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["replaceElement"](wrapper, this.el);
    } else {
      wrapper.classList.remove(CLS_SEARCHABLE);
      wrapper.classList.remove(CLS_POPOVER_OWNER);
      wrapper.removeChild(this._.refs.input);
      wrapper.removeChild(this._.refs.popover);
    }
  }
  this.popover.dispose();
  this._.refs.popover = this._.refs.focus = this._.refs.search = this._.refs.options = null;
  this.el.removeAttribute('style');
  this._.scrollLock.dispose();
}

/***/ }),
/* 58 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return renderItems; });
/* unused harmony export resolveHighlightFn */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);

// regex for letters that are connectable to previous letter
var REGEX_CONN_TO_PREV = /[ابتثجحخدذرزسشصضطظعغفقكلمنهويآأإةىئ]/;
// regex for letters that are connectable to following letter
var REGEX_CONN_TO_NEXT = /[بتثجحخسشصضطظعغفقكلمنهيئ]/;

/**
 * Gets an object representing Text/Value from a data record.
 * @param {object | string} record The data record to extract values from.
 * @param {string} textKey The key of the text field.
 * @param {string} valueKey The key of the value field.
 */
var _getData = function (record, textKey, valueKey) {
  var text = void 0,
      value = void 0;
  if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](record)) {
    text = value = record;
  } else {
    text = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveVal"](record, textKey);
    value = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveVal"](record, valueKey);
  }
  return { text: text, value: value };
};
/**
 * Returns the HTML string representing an option link.
 *
 * @param {object} record The data record.
 * @param {string} textKey The data text field key
 * @param {string} valueKey The data value field key
 */
var _renderItemFn = function (record, textKey, valueKey) {
  var data = _getData(record, textKey, valueKey);
  return "<a tabindex=\"-1\" data-highlight href=\"#\">" + data.text + "</a>";
};

/**
 * Returns the HTML string representing an option `<li>` item.
 * @param {object} record The data record.
 * @param {string} textKey The data text field key.
 * @param {string} valueKey The data value field key.
 * @param {function} renderItem The function to render the option.
 */
var _renderElementFn = function (record, textKey, valueKey, groupKey, renderItem) {
  var data = _getData(record, textKey, valueKey);
  return __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]("<li data-text=\"" + data.text + "\" data-value=\"" + data.value + "\"> " + renderItem(record, textKey, valueKey, groupKey) + "</li>");
};

/**
 * Finds all elements with `data-highlight` attribute and updates
 * their text according to highlight expr.
 *
 * @param {HTMLElement} element The element to highlight
 * @param {RegExp} expression The expression used for replacement.
 */
var _highlightItemFn = function (element, expression) {
  // highlight only if the expression is not empty
  if (expression && expression.source != "()" && expression.source != "^()") {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[data-highlight]', function (node) {
      node.innerHTML = node.innerHTML.replace(expression, function (term, match, index, text) {
        var output = '';
        //prev letter can be connected to first letter in match
        if ((text[index - 1] || '').match(REGEX_CONN_TO_NEXT)) {
          output += 'ـ<b data-dehighlight class="t-primary">&zwj;';
          if (match[0].match(REGEX_CONN_TO_PREV)) {
            output += 'ـ';
          }
        } else {
          output += '<b data-dehighlight class="t-primary">';
        }
        output += match;
        //next letter can be connected at begining to last letter in match
        if ((text[index + match.length] || '').match(REGEX_CONN_TO_PREV) && match[match.length - 1].match(REGEX_CONN_TO_NEXT)) {
          output += '&zwj;</b>ـ';
        } else {
          output += '</b>';
        }
        return output;
      });
    }, element);
  }
};

var _deHighlightItemFn = function (element) {
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[data-dehighlight]', function (node) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["replaceElement"](node, document.createTextNode(node.textContent));
  }, element);
};

/* Sample Calls

  //using select
  renderItems((renderItem)=>{

     [].forEach.call(element.children, function (opt) {
       renderItem({text: opt.text, value: opt.value})
     })
  }, this.config)
  //using fetch
  renderItems((renderItem) => {
    let highlightRegExp = new RegExp(
    (mode === 'search' ? "" : "^") + "(" + Utils.escapeRegExp(value) + ")", 'i')

    for (let item of collection) {
      renderItem(item, highlightRegExp)
    }
  }, this.config)

*/

/**
 *
 * Returns a document fragment containing the rendered options elements.
 *
 * @example
 *
 * renderItems( function(callback) {
 *   for(let record of dataCollection){
 *     callback(record, highlightExpr)
 *   }
 * }
 *
 * @param {function} loopDelegate A function that is expected to iterate through the datasource, it accepts a callback function to invoke on each data item
 * @param {object} config The configuration object
 * @param {RegExp}  highlightExpr The expression used for text highlight.
 */
var renderItems = function (loopDelegate) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
      _ref$data = _ref.data;

  _ref$data = _ref$data === undefined ? {} : _ref$data;
  var _ref$data$text = _ref$data.text,
      textKey = _ref$data$text === undefined ? 'text' : _ref$data$text,
      _ref$data$value = _ref$data.value,
      valueKey = _ref$data$value === undefined ? 'value' : _ref$data$value,
      _ref$data$group = _ref$data.group,
      groupKey = _ref$data$group === undefined ? '' : _ref$data$group,
      _ref$view = _ref.view;
  _ref$view = _ref$view === undefined ? {} : _ref$view;
  var renderFn = _ref$view.render,
      _ref$view$highlight = _ref$view.highlight,
      highlightFn = _ref$view$highlight === undefined ? true : _ref$view$highlight;
  var highlightExpr = arguments[2];


  // if no render function supplied, use a default.
  renderFn = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](renderFn, _renderItemFn);
  //init highlight function
  highlightFn = resolveHighlightFn(highlightFn);

  // use a document fragment, to reduce dom construction overhead
  var docfrag = document.createDocumentFragment();
  loopDelegate(function (record) {
    var element = _renderElementFn(record, textKey, valueKey, groupKey, renderFn);
    //highlight element
    highlightFn(element, highlightExpr);
    docfrag.appendChild(element);
  }, function (group) {
    if (!!group) {
      var element = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]("<li class=\"is-title has-divider\">" + group + "</li>");
      docfrag.appendChild(element);
    }
  });
  return docfrag;
};

var resolveHighlightFn = function (highlightFn) {
  // if no highlight function supplied, use a default.
  var fn = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["NOOP"];
  if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isBool"](highlightFn)) {
    // if true, use default
    if (highlightFn) {
      fn = _highlightItemFn;
    }
  } else {
    //either func or string
    fn = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](highlightFn, _highlightItemFn);
  }
  return fn;
};

// !!! UNUSED -- REBUILDING THE DOM IS FASTER!!!
// /**
//  * Filter the child nodes of the provided element against filterExpr
//  * and used the cache to attach/dettach the items to the dom.
//  *
//  * @param {HTMLElement} element The options container to filter
//  * @param {RegExp} expr The expression to filter against.
//  * @param {array} cache The array used for caching the DOM
//  *
//  */
// export let filterItems = (element, searchExpr, highlightFn, cache, doTypeAhead = () => void (0), cb = () => void (0)) => {
//   let highlighter = resolveHighlightFn(highlightFn)
//   let firstMatch = false
//     ;[].forEach.call(element.childNodes, function (node) {
//       let record
//       if (node.nodeType === 1 || node.nodeType === 8) { //element
//         let virtualIndex = node.nodeType === 1 ? parseInt(node.getAttribute('data-index')) : parseInt(node.textContent)
//         if (!isNaN(virtualIndex)) {
//           record = cache[virtualIndex]
//         } else {
//           record = { text: node.getAttribute('data-text'), node, comment: document.createComment(cache.length) }
//           record.node.setAttribute('data-index', cache.length)
//           cache.push(record)
//         }
//       }
//       if (record) {
//         if (record.text.match(searchExpr)) {
//           if (!record.node.parentElement) {
//             Utils.replaceElement(record.comment, record.node)
//           }
//           //highlight
//           _deHighlightItemFn(record.node)
//           highlighter(record.node, searchExpr)
//           if (!firstMatch) {
//             firstMatch = true
//             doTypeAhead(record.text)
//           }
//         } else { // no match
//           if (record.node.parentElement) {
//             Utils.replaceElement(record.node, record.comment)
//           }
//         }
//       }
//     })
//   cb()
// }

/***/ }),
/* 59 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return strings; });
var strings = {
  ok: 'موافق',
  cancel: 'إلغاء',
  yes: 'نعم',
  no: 'لا',
  tryNow: 'جرّب الأن',
  search: 'بحث',
  noMatch: 'لم يتم العثور على تطابق',
  done: 'تم',
  del: 'حذف',
  fileHintFn: function (size, types) {
    return '\u0627\u0644\u062D\u062F \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u062D\u062C\u0645 \u0627\u0644\u0645\u0644\u0641 ' + size + 'MB. ' + (types ? '\u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0645\u0633\u0645\u0648\u062D\u0629 ' + types + ' \u0641\u0642\u0637.' : '');
  },
  fileBrowse: '<span class="t-primary"> إختيار </span> ملف لتحميله',
  seeMore: '&hellip;قراءة المزيد',
  addAnother: 'أضف آخر'
};

/***/ }),
/* 60 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return strings; });
var strings = {
  ok: 'Okay',
  cancel: 'Cancel',
  yes: 'Yes',
  no: 'No',
  tryNow: 'Try Now',
  search: 'Search',
  noMatch: 'No match found.',
  done: 'Done',
  del: 'Delete',
  fileHintFn: function (size, types) {
    return (size ? 'Maximum upload file size: ' + size + 'MB.' : '') + ' ' + (types ? 'File types allowed: ' + types + ' only.' : '');
  },
  fileBrowse: '<span class="t-primary"> Browse </span> file to upload',
  seeMore: '&hellip;See more',
  addAnother: 'Add Another'
};

/***/ }),
/* 61 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return strings; });
var strings = {
  ok: 'D\'accord',
  cancel: 'Annuler',
  yes: 'Oui',
  no: 'Non',
  tryNow: 'Essayez Maintenant',
  search: 'Chercher',
  noMatch: 'Aucun résultat trouvé.',
  done: 'Terminer',
  del: 'Supprimer',
  fileHintFn: function (size, types) {
    return (size ? 'La taille maximale du fichier: ' + size + 'MB.' : '') + ' ' + (types ? 'Types de fichiers autoris\xE9s: ' + types + ' uniquement.' : '');
  },
  fileBrowse: '<span class="t-primary"> Choisir </span> le fichier à télécharger',
  seeMore: '&hellip;En savoir plus',
  addAnother: 'Ajouter un autre'
};

/***/ }),
/* 62 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Nav; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_capture_capture__ = __webpack_require__(36);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__nav_core__ = __webpack_require__(63);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }







var DEFAULTS = { fixed: true };

var openNavs = [];
var Nav = function (_MixinCapture) {
  _inherits(Nav, _MixinCapture);

  _createClass(Nav, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */].$init(target, Nav);
    }
  }, {
    key: '$trackNavs',
    value: function $trackNavs() {
      document.addEventListener('b8._nav.open', function (e) {
        var control = e.detail && e.detail.control;
        if (control) {
          if (!openNavs.length) {
            openNavs.isMobile = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]();
          }
          openNavs.push(control);
        }
      });
      document.addEventListener('b8._nav.close', function (e) {
        if (!openNavs.locked) {
          var control = e.detail && e.detail.control;
          if (control) {
            var i = openNavs.indexOf(control);
            if (i > -1) {
              openNavs.splice(i, 1)[0];
            }
          }
        }
      });
      window.addEventListener('resize', function () {
        if (openNavs.length && __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]() != openNavs.isMobile) {
          openNavs.locked = true;
          while (openNavs.length) {
            openNavs.pop().uncapture(true);
          }
          openNavs.locked = false;
        }
      });
    }
  }]);

  function Nav(element, config) {
    _classCallCheck(this, Nav);

    var _this = _possibleConstructorReturn(this, (Nav.__proto__ || Object.getPrototypeOf(Nav)).call(this, element, Object.assign(DEFAULTS, config)));

    Object.assign(_this._, {
      breakpoint: 0,
      menuItems: [],
      refs: {},
      fn: {}
    });
    Object.assign(_this._.fn, {
      menu: __WEBPACK_IMPORTED_MODULE_4__nav_core__["b" /* registerMenu */].call(_this),
      search: __WEBPACK_IMPORTED_MODULE_4__nav_core__["c" /* registerSearch */].call(_this)
    });

    if (_this.config.fixed) {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"]('fixed-nav', document.body);
    }

    __WEBPACK_IMPORTED_MODULE_4__nav_core__["a" /* bindEvents */].call(_this);
    _this._.lastWidth = document.documentElement.offsetWidth;
    _this.respondToScreen();
    return _this;
  }

  _createClass(Nav, [{
    key: 'respondToScreen',
    value: function respondToScreen(e) {
      var _this2 = this;

      if (this.SearchActive) {
        return;
      }

      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
        this._.fn.menu.expand.call(this, true);
        this._.lastWidth = Number.MAX_VALUE;
        return;
      }

      requestAnimationFrame(function () {
        if (document.documentElement.offsetWidth > _this2._.lastWidth) {
          _this2._.fn.menu.expand.call(_this2);
          _this2._.fn.search.expand.call(_this2);
        } else {
          _this2._.fn.search.collapse.call(_this2);
          _this2._.fn.menu.collapse.call(_this2);
        }
        _this2._.lastWidth = document.documentElement.offsetWidth;
      });
    }
  }, {
    key: 'SearchActive',
    get: function () {
      return this._.refs.bar && this._.refs.bar.classList.contains('is-active');
    },
    set: function (activate) {
      var bar = this._.refs.bar,
          pack = this._.refs.pack,
          focus = this._.refs.focus;
      if (bar && pack) {
        if (activate) {
          bar.isMobile = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]();
          bar.classList.add('is-active');
          pack.setAttribute('data-capture', 'true');
          if (focus && focus.focus) {
            focus.focus();
          }
        } else {
          bar.classList.remove('is-active');
          pack.removeAttribute('data-capture');
          requestAnimationFrame(this.respondToScreen.bind(this));
        }
      }
    }
  }]);

  return Nav;
}(Object(__WEBPACK_IMPORTED_MODULE_3__shared_capture_capture__["a" /* MixinCapture */])(__WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */]));
__WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["a" /* SET__TYPE__ */](Nav, 'nav');

/***/ }),
/* 63 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = registerMenu;
/* harmony export (immutable) */ __webpack_exports__["c"] = registerSearch;
/* harmony export (immutable) */ __webpack_exports__["a"] = bindEvents;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);

var COLLAPSED_PLACEMENT = 'lt';

function registerMenu() {
  var collapseMenu = function () {},
      expandMenu = function () {};
  var moreMenu = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-more]', this.el);
  if (moreMenu) {
    var list = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('ul', moreMenu);
    var prev = moreMenu.previousElementSibling;
    var menuItems = [];
    while (prev && prev.tagName === 'LI') {
      //put if not excluded.
      if (prev.getAttribute('data-more-exclude') === null) {
        menuItems.push({ n: prev, w: prev.offsetWidth, p: document.createComment('ph') });
      }
      prev = prev.previousElementSibling;
    }
    menuItems.reverse();

    collapseMenu = function () {
      var offset = this.el.scrollWidth - this.el.offsetWidth,
          index = menuItems.length - 1;
      while (offset > 0 && index > 0 /*0 to exclude first item*/) {
        var _menuItems = menuItems[index--],
            item = _menuItems.n,
            width = _menuItems.w,
            ph = _menuItems.p;

        if (!ph.parentNode) {
          offset -= width;
          __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["replaceElement"](item, ph);

          // add pointer back
          if (item.classList.contains('popover-owner')) {
            item.classList.remove('has-pointer');
          }
          // change popover placement
          __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('.popover', function (popover) {
            var placement = popover.getAttribute('data-placement');
            popover.setAttribute('data-placement-o', placement);
            popover.setAttribute('data-placement', COLLAPSED_PLACEMENT);
          }, item);
          list[list.childNodes.length ? 'insertBefore' : 'appendChild'](item, list.firstChild);
        }
        //add at least 2 items
        if (offset < 0 && list.children.length == 1) {
          offset = 1;
        }
      }
      if (list.children.length > 0) {
        moreMenu.style.display = '';
        if (index > 0 && this.el.scrollWidth > this.el.offsetWidth) {
          collapseMenu.call(this);
        }
      } else {
        moreMenu.style.display = 'none';
      }
    };
    expandMenu = function () {
      var all = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

      for (var index = 0; index < menuItems.length; index++) {
        var _menuItems$index = menuItems[index],
            item = _menuItems$index.n,
            width = _menuItems$index.w,
            ph = _menuItems$index.p;
        //find first element inside more menu

        if (ph.parentNode) {
          //add back
          // add pointer back
          if (item.classList.contains('popover-owner')) {
            item.classList.add('has-pointer');
          }
          // change popover placement
          __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('.popover', function (popover) {
            var placement = popover.getAttribute('data-placement-o');
            popover.setAttribute('data-placement', placement);
          }, item);
          __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["replaceElement"](ph, item);
          if (!all && this.el.scrollWidth > this.el.offsetWidth) {
            collapseMenu.call(this);
            break;
          }
        }
      }
      moreMenu.style.display = list.children.length ? '' : 'none';
    };
  }
  return {
    expand: expandMenu,
    collapse: collapseMenu
  };
}

function registerSearch() {
  var collapseSearch = function () {},
      expandSearch = function () {};
  var bar = this._.refs.bar = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('.search-bar', this.el);
  if (bar) {
    this._.refs.pack = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('.input-pack', bar);
    this._.refs.focus = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-search-focus]', bar);
    collapseSearch = function () {
      if (bar && this.el.scrollWidth > this.el.offsetWidth) {
        if (!bar.classList.contains('is-compact')) {
          this._.breakpoint = this.el.offsetWidth;
          bar.classList.add('is-compact');
          if (bar.contains(document.activeElement) && document.activeElement.blur) {
            document.activeElement.blur();
          }
        }
      }
    };
    expandSearch = function () {
      if (bar && this._.breakpoint < this.el.offsetWidth) {
        if (bar.classList.contains('is-compact')) {
          this._.breakpoint = 0;
          bar.classList.remove('is-compact');
          collapseSearch.call(this);
        }
      }
    };
  }
  return {
    expand: expandSearch,
    collapse: collapseSearch
  };
}

// export function respondToScreen(e) {
//   if (this.SearchActive) {
//     return
//   }

//   if (Utils.isMobile()) {
//     expandMenu.call(this, true)
//     this._.lastWidth = Number.MAX_VALUE
//     return
//   }

//   requestAnimationFrame(() => {
//     if (document.documentElement.offsetWidth > this._.lastWidth) {
//       console.log('expanding ... ')
//       this._.expandMenu.call(this)
//       this._.expandSearch.call(this)
//     } else {
//       console.log('collapsing ... ')
//       this._.collapseSearch.call(this)
//       this._.collapseMenu.call(this)
//     }
//     this._.lastWidth = document.documentElement.offsetWidth
//   })
// }

function activateNav(target, selector) {
  var _this = this;

  var nav = selector ? target.closest('.nav').qs(selector) : target.closest('.nav');
  nav.classList.add('has-transition');
  nav.classList.add('is-active');
  this.capture(function () {
    deactivateNav.call(_this, target, selector);
  });
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["dispatchEvent"]('nav.open', this);
}

function deactivateNav(target, selector) {
  var nav = selector ? target.closest('.nav').qs(selector) : target.closest('.nav.is-active');
  //let nav = target.closest('.nav.is-active');
  if (nav) {
    nav.classList.remove('has-transition');
    nav.classList.remove('is-active');
  }
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["dispatchEvent"]('nav.close', this);
  this.uncapture();
}

function getToggleNav(open, selector) {
  var _this2 = this;

  return open ? function (e) {
    e.preventDefault();
    activateNav.call(_this2, e.target, selector);
  } : function (e) {
    e.preventDefault();
    deactivateNav.call(_this2, e.target);
  };
}

function toggleSearcbar(e) {
  e.preventDefault();
  this.SearchActive = !this.SearchActive;
}

function bindEvents() {
  var _this3 = this;

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[data-bars]', function (el) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this3, el, 'click', getToggleNav.call(_this3, true, '[data-toggle-bars]'));
  }, this.el);

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[data-search]', function (el) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this3, el, 'click', getToggleNav.call(_this3, true, '[data-toggle-search]'));
  }, this.el);

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[data-nav-close]', function (el) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this3, el, 'click', getToggleNav.call(_this3, false));
  }, this.el);

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[data-search-toggle]', function (element) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this3, element, 'click', toggleSearcbar.bind(_this3));
  }, this.el);

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, window, 'resize', function (e) {
    _this3.respondToScreen(e);
  });
}

/***/ }),
/* 64 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Tabs; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__ = __webpack_require__(1);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }





function bind() {
  var _this = this;

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[data-toggle-tab]', function (tabActivator) {
    //attach events
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this, tabActivator, 'click', function (e) {
      if (_this.config.prevent !== false) {
        e.preventDefault();
      }

      var tabID = tabActivator.getAttribute('data-toggle-tab');

      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["dispatchHooks"]('beforechange', _this, { activator: tabActivator, id: tabID });

      // activate/deactivate tab strip
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[data-toggle-tab]', function (activator) {
        if (activator != tabActivator) {
          activator.classList.remove('is-active');
        } else {
          activator.classList.add('is-active');
        }
      }, _this.el);

      // activate/deactivate tab content
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[data-tab]', function (tab) {
        if (tab.getAttribute('data-tab') === tabID) {
          tab.classList.add('is-active');
        } else {
          tab.classList.remove('is-active');
        }
      }, _this.el.parentElement);

      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["dispatchHooks"]('afterchange', _this, { activator: tabActivator, id: tabID });
    });
  }, this.el);
}

var Tabs = function (_UIControl) {
  _inherits(Tabs, _UIControl);

  _createClass(Tabs, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */].$init(target, Tabs);
    }
  }]);

  function Tabs(element, config) {
    _classCallCheck(this, Tabs);

    // Object.assign(this._, {
    // })
    var _this2 = _possibleConstructorReturn(this, (Tabs.__proto__ || Object.getPrototypeOf(Tabs)).call(this, element, config));

    bind.call(_this2);
    return _this2;
  }

  return Tabs;
}(__WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */]);
__WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["a" /* SET__TYPE__ */](Tabs, 'tabs');

/***/ }),
/* 65 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Gauge; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__ = __webpack_require__(1);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }






var START_ANGLE = -90,
    SVGNS = "http://www.w3.org/2000/svg",
    CLASS = 'class',
    STROKE_WIDTH = 'stroke-width',
    STROKE_LINECAP = 'stroke-linecap',
    STROKE_LINEJOIN = 'stroke-linejoin',
    FILL = 'fill',
    TRANSPARENT = 'transparent',
    TEXT_ANCHOR = 'text-anchor',
    ALIGNMENT_BASELINE = 'alignment-baseline',
    ROUND = 'round',
    MIDDLE = 'middle',
    TOPEDGE = 'top-edge',
    BASELINE = 'baseline',
    CHECK_MARK = '✓',
    CHECK_MARK_WIDTH_RATIO = .4,
    CHECK_MARK_HEIGHT_RATIO = .3,
    TIMES_MARK = '✗',
    TIMES_MARK_SIZE_RATIO = .3,
    CSS_HAS_CONTENT = 'has-content';

/**
 *
 * @param {HTMLElement} element The SVG element to use
 */
function _init(element) {
  //create the gauge
  _createGaguge(element, this.config, this._.refs);
  //read the value
  var v = this.value;
  //set the value
  this.value = v;
  //read the text
  var t = this.config.text;
  // clear the text to trigger re-draw
  this.config.text = null;
  //set the text
  this.text = t;
}

/**
 * Helper to convert from degrees to radians
 *
 * @param {number} degrees The angle in degress
 */
function _degreeToRadian(degrees) {
  return degrees * (Math.PI / 180);
}

/**
 * Helper to get the coordinates of the curve end point.
 *
 * @param {number} cx The center X coordinate
 * @param {number} cy The center Y coordinate
 * @param {number} radius The circle radius
 * @param {number} angle The desired angle in degrees.
 */
function _getCoordinates(cx, cy, radius, angle) {
  var rad = _degreeToRadian(angle);
  return {
    x: Math.round((cx + radius * Math.cos(rad)) * 1000) / 1000,
    y: Math.round((cy + radius * Math.sin(rad)) * 1000) / 1000
  };
}

/**
 * Helper to create SVG element, set its attributes and append it to a container.
 *
 * @param {string} name The element tag name
 * @param {array} attributes Array of attributes as pairs
 * @param {HTMLElement} container The element to hold the created element (optional).
 */
function _createSVGElement(name, attributes, container) {
  var svgElement = document.createElementNS(SVGNS, name);
  attributes.forEach(function (pair) {
    svgElement.setAttributeNS(null, pair[0], pair[1]);
  });
  container && container.appendChild(svgElement);
  return svgElement;
}

function _updateContent() {
  this.text.length ? Object(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"])(CSS_HAS_CONTENT, this.el) : Object(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["remClass"])(CSS_HAS_CONTENT, this.el);
  switch (this.text) {
    case CHECK_MARK:
      // Check mark to be a rectangle centered inside the circle.
      // Represneted by * in the following drawing.
      //
      // +------------*
      // |            |
      // *66%         |
      // |  33%       |
      // +---*--------+
      var width = this.config.size * CHECK_MARK_WIDTH_RATIO,
          height = this.config.size * CHECK_MARK_HEIGHT_RATIO,
          left = this.config.size * .5 - width * .5,
          top = this.config.size * .5 - height * .5;
      this._.refs.text.textContent = '';
      this._.refs.path.setAttributeNS(null, 'd', 'M' + (left + this.config.stroke / 2) + ' ' + (top + height * .666) + ' ' + (left + width * .333) + ' ' + (top + height) + ' ' + (left + width) + ' ' + top);

      break;
    case TIMES_MARK:
      // Times mark to be a square centered inside the circle.
      // Represneted by * in the following drawing.
      //
      // +------------+
      // |   *     *  |
      // |            |
      // |   *     *  |
      // +------------+
      var size = this.config.size * TIMES_MARK_SIZE_RATIO,
          topLeft = this.config.size * .5 - size * .5;
      this._.refs.text.textContent = '';
      this._.refs.path.setAttributeNS(null, 'd', 'M' + topLeft + ' ' + topLeft + ' ' + (topLeft + size) + ' ' + (topLeft + size) + 'M' + topLeft + ' ' + (topLeft + size) + ' ' + (topLeft + size) + ' ' + topLeft);

      //let offset = this.config.stroke / 3
      //+ + - - + - - +
      //this._.refs.path.setAttributeNS(null, 'd', `M${topLeft + offset} ${topLeft + offset} ${topLeft + size - offset} ${topLeft + size - offset}M${topLeft + offset} ${topLeft + size - offset} ${topLeft + size - offset} ${topLeft + offset}`)

      break;
    default:
      this._.refs.path.setAttributeNS(null, 'd', '');
      this._.refs.text.textContent = this.text.length > 10 ? this.text.substr(0, 9) + '...' : this.text;
      break;
  }
}
/**
 * Helper to create the gauge elements.
 *
 * @param {HTMLElement} element The SVG element to use.
 * @param {object} config The gauge configuration.
 * @param {object} refs An object to hold references to gauge elements.
 */
function _createGaguge(element, config, refs) {

  var cx = config.size / 2,
      cy = cx,
      r = cx - config.stroke;

  //set dimensions
  element.setAttributeNS(null, 'viewBox', '0 0 ' + config.size + ' ' + config.size);
  element.setAttributeNS(null, 'preserveAspectRatio', 'xMidYMid meet');

  // debug paths.
  // _createSVGElement('rect', [
  //   ['width', config.size],
  //   ['height', config.size],
  //   ['fill', 'transparent'],
  //   ['stroke', 'red'],
  //   ['stroke-width', config.stroke]
  // ], element)
  //  _createSVGElement('path', [
  //   ['stroke-width', 5],
  //   ['stroke', 'red'],
  //   ['d', `M0,0 L0,${config.size} M0,${config.size} L${config.size},${config.size} M${config.size},${config.size} L${config.size},0 M${config.size},0 L0,0`]
  // ], element)

  // _createSVGElement('path', [
  //   ['stroke-width', 5],
  //   ['stroke', 'black'],
  //   ['d', `M${config.size / 2},0 L${config.size / 2},${config.size}Z M0,${config.size / 2} L${config.size},${config.size / 2}`]
  // ], element)


  //create the circle
  refs.circle = _createSVGElement('circle', [[CLASS, 'circle'], ['cx', cx], ['cy', cy], ['r', r], [STROKE_WIDTH, config.stroke], [FILL, TRANSPARENT]], element);

  //create the arc
  refs.arc = _createSVGElement('path', [[CLASS, 'arc'], [STROKE_WIDTH, config.stroke], [STROKE_LINECAP, config.strokeCap], [FILL, TRANSPARENT]], element);

  //compute font-size
  var fontSize = config.size * .25,
      fontAttribute = ["style", 'font-size:' + fontSize + 'px;line-height:1;'];
  //create the dividend
  refs.dividend = _createSVGElement('text', [[CLASS, 'dividend'], ['x', cx], ['y', '50%'], ['dy', fontSize / 3], [TEXT_ANCHOR, MIDDLE],
  //[ALIGNMENT_BASELINE, BASELINE],
  fontAttribute], element);

  //set text
  refs.dividend.textContent = config.min;

  // create text element

  var textFontSize = config.size * 0.15,
      textFontAttribute = ['style', 'font-size:' + textFontSize + 'px;line-height:1;'];
  //create the text element
  refs.text = _createSVGElement('text', [[CLASS, 'text'], ['x', cx], ['y', '50%'], ['dy', textFontSize / 3], [TEXT_ANCHOR, MIDDLE],
  //[ALIGNMENT_BASELINE, BASELINE],
  textFontAttribute], element);

  //create the extra path for custom shapes
  refs.path = _createSVGElement('path', [[CLASS, 'path'], [STROKE_WIDTH, config.stroke / 2], [STROKE_LINECAP, config.strokeCap], [STROKE_LINEJOIN, config.strokeJoin]], element);

  if (config.mode === 'rank') {
    //create the divider
    refs.divider = _createSVGElement('path', [[CLASS, 'divider'], [STROKE_WIDTH, config.stroke / 2], [STROKE_LINECAP, config.strokeCap], [FILL, TRANSPARENT],
    //divier line is half the size and centered in the middle.
    // +------------+
    // |            |
    // |25% ---- 25%|
    // |            |
    // +------------+
    ['d', 'M' + config.size * .25 + ' ' + config.size * .5 + 'L' + config.size * .75 + ' ' + config.size * .5 + 'Z']], element);

    //create the divisor
    refs.divisor = _createSVGElement('text', [[CLASS, 'divisor'], ['x', cx], ['y', '50%'], ['dy', fontSize], [TEXT_ANCHOR, MIDDLE], [ALIGNMENT_BASELINE, TOPEDGE], fontAttribute], element);

    //set text
    refs.divisor.textContent = config.max;

    //update dividend text location to go above the divider
    refs.dividend.setAttributeNS(null, ALIGNMENT_BASELINE, TOPEDGE);
    refs.dividend.setAttributeNS(null, 'dy', fontSize / -4);
  }
}

/**
 * Helper to update the gauge value and apply range configuration.
 *
 * @param {number} value The current gauge value
 */
function _update(value) {
  var percent = Math.min(Math.abs((value - this.config.min) / (this.config.max - this.config.min)), 1);

  // apply ranges
  if (this.config.range instanceof Array) {
    var lowerBound = 0;
    this.config.range.forEach(function (current, index, array) {
      var next = array[index + 1],
          className = current[1],
          upperBound = current[0];
      //console.log(`className:${className}, Precent: ${percent} >= ${lowerBound} && ${percent} <= ${upperBound} => ${percent >= lowerBound && percent <= upperBound ? 'add' : 'remove'} `)
      if (className) {
        percent >= lowerBound && percent <= upperBound ? Object(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"])(className, this.el) : Object(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["remClass"])(className, this.el);
      }
      lowerBound = upperBound + 0.01;
    }, this);
  }
  // set text
  this._.refs.dividend.textContent = this.config.mode != 'rank' ? value + '%' : value;

  // draw the curve
  switch (percent) {
    case 0:
      this._.refs.arc.style.display = 'none';
      break;
    case 1:
      percent = .9999;
    default:
      this._.refs.arc.style.display = '';
      var cx = this.config.size / 2,
          cy = cx,
          r = cx - this.config.stroke,
          p = _getCoordinates(cx, cy, r, percent * 360 + START_ANGLE);
      this._.refs.arc.setAttributeNS(null, 'd', 'M' + cx + ' ' + this.config.stroke + ' A' + r + ' ' + r + ' 0 ' + (percent < .5 ? "0" : "1") + ' 1 ' + p.x + ' ' + p.y);
      break;
  }
}

var Gauge = function (_UIControl) {
  _inherits(Gauge, _UIControl);

  _createClass(Gauge, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */].$init(target, Gauge);
    }
  }, {
    key: '$animate',
    value: function $animate(options) {
      // https://github.com/naikus/svg-gauge/blob/master/src/gauge.js
      var duration = options.duration || 1,
          currentIteration = 1,
          iterations = 60 * duration,
          start = options.start || 0,
          end = options.end,
          change = end - start,
          step = options.step,
          easing = options.easing || function easeInOutCubic(pos) {
        // https://github.com/danro/easing-js/blob/master/easing.js
        if ((pos /= 0.5) < 1) return 0.5 * Math.pow(pos, 3);
        return 0.5 * (Math.pow(pos - 2, 3) + 2);
      };

      function animate() {
        var progress = currentIteration++ / iterations;
        var value = change * easing(progress) + start;
        step(value);
        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      }
      // start!
      requestAnimationFrame(animate);
    }
  }]);

  function Gauge(element, config) {
    _classCallCheck(this, Gauge);

    var _this = _possibleConstructorReturn(this, (Gauge.__proto__ || Object.getPrototypeOf(Gauge)).call(this, element, Object.assign({
      mode: 'percent',
      text: '',
      size: 126,
      stroke: 5,
      strokeCap: ROUND,
      strokeJoin: ROUND,
      min: +element.getAttribute('aria-valuemin') || 0,
      max: +element.getAttribute('aria-valuemax') || 100,
      range: [[0, ''], [.69, 'is-danger'], [.99, 'is-success'], [1, 'is-primary']]
    }, config)));

    Object.assign(_this._, {
      refs: {}
    });

    _init.bind(_this)(element);

    return _this;
  }

  _createClass(Gauge, [{
    key: 'text',
    get: function () {
      return this.config.text;
    },
    set: function (val) {
      if (val != this.config.text) {
        this.config.text = val;
        _updateContent.call(this);
      }
    }
  }, {
    key: 'value',
    get: function () {
      return +this.el.getAttribute('aria-valuenow');
    },
    set: function (val) {
      var _this2 = this;

      val = Math.max(Math.min(val, this.config.max), this.config.min);
      if (this.config.animate != false) {
        Gauge.$animate(Object.assign(this.config.animate || {}, {
          start: this.value,
          end: val,
          step: function (v) {
            _update.bind(_this2)(Math.round(v));
          }
        }));
      } else {
        _update.bind(this)(val);
      }
      this.el.setAttribute('aria-valuenow', val);
    }
  }]);

  return Gauge;
}(__WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */]);
__WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["a" /* SET__TYPE__ */](Gauge, 'gauge');

/***/ }),
/* 66 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Slider; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ui_scripts__ = __webpack_require__(30);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_data_registry__ = __webpack_require__(2);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }





var ATTR_DATA_SLIDE = 'data-slide',
    ATTR_DATA_CLONE = 'data-clone',
    CLS_IS_VISIBLE = 'is-visible',
    CLS_SLIDER_CONTENT = 'slider-content',
    CLS_NO_TRANS = 'no-transition',
    SLIDE = 'slide',
    ITEM = 'item',
    DEFAULTS = {
  arrows: true,
  autoplay: 3,
  data: [],
  dots: true,
  caption: true,
  selector: '.box',
  content: false
},
    _itemTemplateFn = function (type, index, imageUrl) {
  return '\n<div class="slider-' + type + ' ' + (index == 0 ? CLS_IS_VISIBLE : '') + '" ' + ATTR_DATA_SLIDE + '="' + index + '">\n  <div class="slider-image" style="background-image: url(\'' + imageUrl + '\')"></div>\n</div>\n';
},
    _arrowTemplateFn = function (direction) {
  return '<a class="slider-arrow icon is-arrow-' + direction + ' is-64"></a>';
},
    _arrowsTemplate = '\n<div class="slider-arrows d">\n  ' + _arrowTemplateFn('left') + '\n  ' + _arrowTemplateFn('right') + '\n</div>\n',
    _dotsContainerTempalte = '<div class="slider-dots d"></div>',
    _dotTemplateFn = function (index) {
  return '<a class="slider-dot ' + (index == 0 ? 'is-active' : '') + '" data-dot="' + index + '"></a>';
},
    _captionTemplateFn = function (txt, url) {
  return '<' + (url ? 'a href="' + url + '"' : 'span') + ' class="slider-caption">' + txt + '</' + (url ? 'a' : 'span') + '>';
};

function stopAutoplay() {
  window.clearTimeout(this._.timer);
}

function startAutoplay() {
  var _this = this;

  stopAutoplay.call(this);
  if (this.config.autoplay > 0) {
    this._.timer = setTimeout(function () {
      _this.next();
    }, this.config.autoplay * 1000);
  }
}

function bind() {
  var _this2 = this;

  var node = void 0,
      dot = void 0,
      container = document.createElement('div'),
      dotsContainer = void 0,
      arrowsContainer = void 0;

  // build arrows
  if (this.config.arrows) {
    this.el.classList.add('has-arrows');
    arrowsContainer = __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["htmlToElement"](_arrowsTemplate);
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["prependElement"](arrowsContainer, this.el);
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](this, arrowsContainer, 'click', function (e) {
      e.target.classList.contains('is-arrow-right') ? _this2.next() : _this2.prev();
    });
  }

  // build dots
  if (this.config.dots) {
    dotsContainer = __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["htmlToElement"](_dotsContainerTempalte);
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["prependElement"](dotsContainer, this.el);
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](this, dotsContainer, 'click', function (e) {
      dot = e.target;
      if (dot.classList.contains('slider-dot')) _this2.transtion(__WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["get"]('[' + ATTR_DATA_SLIDE + '="' + dot.attr('data-dot') + '"]', _this2.el));
    });
  }

  // query or build slides
  if (this.isContent || !__WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["isArray"](this.config.data) || !this.config.data.length) {
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["find"]('.slider-' + (this.isContent ? SLIDE : ITEM), function (item, i) {
      item.attr(ATTR_DATA_SLIDE, i);
      dotsContainer && dotsContainer.appendChild(__WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["htmlToElement"](_dotTemplateFn(i)));
    }, this.el);
  } else {
    //build image slider
    var data = this.config.data;
    for (var i = 0; i < data.length; i++) {
      var _data$i = data[i],
          img = _data$i.img,
          txt = _data$i.txt,
          url = _data$i.url;

      node = __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["htmlToElement"](_itemTemplateFn(this.isContent ? SLIDE : ITEM, i, img));
      // add caption if enabled.
      this.config.caption && txt && node.appendChild(__WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["htmlToElement"](_captionTemplateFn(txt, url)));
      container.appendChild(node);
      dotsContainer && dotsContainer.appendChild(__WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["htmlToElement"](_dotTemplateFn(i)));
    } // for
  }

  // clone or move content
  if (this.isContent) {
    cloneSlides(this.first, this.last);
    this.transtion(this.first);
  } else {
    // add class and append related nodes.
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["find"](this.config.selector, function (content) {
      content.classList.add(CLS_SLIDER_CONTENT);
    }, this.el);
    this.el.classList.add('slider');
    this.el.appendChild(container);
  }

  //suspend autoplay when hovering marked elements.
  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["find"]('[data-slider-suspend]', function (suspend) {
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](_this2, suspend, 'mouseenter', function () {
      return stopAutoplay.call(_this2);
    });
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](_this2, suspend, 'mouseleave', function () {
      return startAutoplay.call(_this2);
    });
  }, this.el);

  startAutoplay.call(this);
}

/**
 * Helper to clone first/last slides.
 *
 * @param {*} first
 * @param {*} last
 */
function cloneSlides(first, last) {
  var parent = first.parentElement;
  var clone = first.cloneNode(true);
  clone.attr(ATTR_DATA_CLONE, 1);
  clone.removeAttribute(ATTR_DATA_SLIDE);
  parent.appendChild(clone);

  clone = last.cloneNode(true);
  clone.attr(ATTR_DATA_CLONE, 2);
  clone.removeAttribute(ATTR_DATA_SLIDE);
  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["prependElement"](clone, parent);
  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["addClass"](CLS_IS_VISIBLE, first);
}

/**
 * Helper for transforming the slider row
 *
 * @param {*} element
 * @param {*} index
 */
function translate(element, index) {
  element.style.transform = 'translateX(' + (index + 2) * (__WEBPACK_IMPORTED_MODULE_1__ui_scripts__["rtl"] ? 100 : -100) + '%)';
}

/**
 * Helper to move the element without transition to the clone then invoke the actual transtion.
 *
 * @param {*} to
 * @param {*} from
 * @param {*} right
 */
function fakeTransition(to, from, right) {
  var _this3 = this;

  if (to.attr(ATTR_DATA_CLONE)) {
    right = right || +(from || this.current).attr(ATTR_DATA_SLIDE) > +to.attr(ATTR_DATA_SLIDE);
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["addClass"](CLS_NO_TRANS, this.content);
    requestAnimationFrame(function () {
      if (right) {
        translate(_this3.content, -2);
        __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["movClasses"](from || _this3.current, _this3.first, true, CLS_IS_VISIBLE);
        requestAnimationFrame(function () {
          _this3.transtion(_this3.first, to);
        });
      } else {
        translate(_this3.content, +_this3.last.attr(ATTR_DATA_SLIDE));
        __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["movClasses"](from || _this3.current, _this3.last, true, CLS_IS_VISIBLE);
        requestAnimationFrame(function () {
          _this3.transtion(_this3.last, to);
        });
      }
    });
    return true;
  }
  return false;
}

/**
 * Helper to query elements and first time, then grab them from refs
 *
 * @param {*} key
 * @param {*} selector
 * @param {*} fallback
 */
function ref(key, selector) {
  var fallback = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["NOOP"];

  return this._.refs[key] || (this._.refs[key] = __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["get"](selector, this.el) || fallback());
}

/**
 * Image / Content Slider.
 *
*/
var Slider = function (_UIControl) {
  _inherits(Slider, _UIControl);

  _createClass(Slider, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_0__shared_base_ui_control__["a" /* UIControl */].$init(target, Slider);
    }
  }]);

  function Slider(element, config) {
    _classCallCheck(this, Slider);

    var _this4 = _possibleConstructorReturn(this, (Slider.__proto__ || Object.getPrototypeOf(Slider)).call(this, element, Object.assign({}, DEFAULTS, config)));

    _this4._.refs = {};
    bind.call(_this4);
    return _this4;
  }

  _createClass(Slider, [{
    key: 'transtion',
    value: function transtion(to, from, right) {
      stopAutoplay.call(this);
      if (!this.isContent || !fakeTransition.call(this, to, from, right)) {
        __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["remClass"](CLS_NO_TRANS, this.content);
        __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["movClasses"](from || this.current, to, true, CLS_IS_VISIBLE);
        if (this.isContent) {
          translate(this.content, +to.attr(ATTR_DATA_SLIDE) - 1);
        }
        if (this.config.dots) {
          __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["movClasses"](__WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["get"]('.slider-dot.is-active', this.el), __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["get"]('.slider-dot[data-dot="' + to.getAttribute(ATTR_DATA_SLIDE) + '"]', this.el), true, 'is-active');
        }
        startAutoplay.call(this);
      }
    }
  }, {
    key: 'next',
    value: function next() {
      this.transtion(this.current.nextElementSibling || this.first, undefined, true);
    }
  }, {
    key: 'prev',
    value: function prev() {
      this.transtion(this.current.previousElementSibling || this.last, undefined, false);
    }
  }, {
    key: 'isContent',
    get: function () {
      return this.config.content;
    }
  }, {
    key: 'content',
    get: function () {
      return ref.call(this, 'c', '.' + CLS_SLIDER_CONTENT);
    }
  }, {
    key: 'firstClone',
    get: function () {
      return ref.call(this, 'c1', '[' + ATTR_DATA_CLONE + '="1"]');
    }
  }, {
    key: 'lastClone',
    get: function () {
      return ref.call(this, 'c2', '[' + ATTR_DATA_CLONE + '="2"]');
    }
  }, {
    key: 'first',
    get: function () {
      return ref.call(this, 'f', '[' + ATTR_DATA_SLIDE + ']');
    }
  }, {
    key: 'current',
    get: function () {
      return __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["get"]('[' + ATTR_DATA_SLIDE + '].' + CLS_IS_VISIBLE, this.el) || this.first;
    }
  }, {
    key: 'last',
    get: function () {
      var _this5 = this;

      return ref.call(this, 'l', '[' + ATTR_DATA_SLIDE + ']:last-child', function () {
        return _this5.firstClone.previousElementSibling;
      });
    }
  }]);

  return Slider;
}(__WEBPACK_IMPORTED_MODULE_0__shared_base_ui_control__["a" /* UIControl */]);

__WEBPACK_IMPORTED_MODULE_3__shared_data_registry__["a" /* SET__TYPE__ */](Slider, 'slider');

/***/ }),
/* 67 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Loader; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__ = __webpack_require__(1);
var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }





var DEFAULTS = {
  active: false,
  light: true
},
    CSS_IS_LIGHT = 'is-light',
    CSS_IS_LOADING = 'is-loading',
    _template = '<div class="loader"><div class="spinner" role="progressbar"></div></div>',
    docEl = document.documentElement;

function handler(element, loader) {

  var top = '',
      lHeight = loader.offsetHeight,
      eHeight = element.offsetHeight;

  if (lHeight < eHeight) {

    var dTop = pageYOffset,
        dBot = dTop + docEl.clientHeight,
        eTop = element.offsetTop + docEl.offsetTop,
        lowerBound = (lHeight / 2 + 10) / eHeight * 100,
        upperBound = 100 - lowerBound;

    var p = element.offsetParent;
    while (p) {
      eTop += p.offsetTop;
      p = p.offsetParent;
    }

    var eBot = eTop + element.clientHeight,
        vTop = eTop < dTop ? dTop : eTop,
        vBot = eBot > dBot ? dBot : eBot,
        vHeight = vBot - vTop;

    // console.log(`
    //   document Top ${dTop}
    //   document Bottom ${dBot}

    //   element Top ${eTop}
    //   element Bottom ${eBot}

    //   visible Top ${vTop}
    //   visible Bottom ${vBot}

    //   visible ${visible}
    // `)
    top = Math.min(upperBound, Math.max(lowerBound, (vHeight / 2 - (eTop - vTop)) / eHeight * 100)) + '%';
  }
  loader.style.top = top;
}

var Loader = function (_UIControl) {
  _inherits(Loader, _UIControl);

  _createClass(Loader, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */].$init(target, Loader);
    }
  }]);

  function Loader(element) {
    var config = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    _classCallCheck(this, Loader);

    var _this = _possibleConstructorReturn(this, (Loader.__proto__ || Object.getPrototypeOf(Loader)).call(this, element, Object.assign({}, DEFAULTS, config)));

    if (_this.config.light) {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"](CSS_IS_LIGHT, _this.el);
    }
    _this._.loader = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](_template);
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["prependElement"](_this._.loader, _this.el);
    _this.Active = _this.config.active;
    return _this;
  }

  _createClass(Loader, [{
    key: 'dispose',
    value: function dispose() {
      _get(Loader.prototype.__proto__ || Object.getPrototypeOf(Loader.prototype), 'dispose', this).call(this);
      this.Active = false;
      this.el.removeChild(this._.loader);
    }
  }, {
    key: 'Active',
    get: function () {
      return this.el.classList.contains(CSS_IS_LOADING);
    },
    set: function (value) {
      var _this2 = this;

      if (value) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"](CSS_IS_LOADING, this.el);
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](this, window, 'scroll', function () {
          return handler(_this2.el, _this2._.loader);
        });
        //invoke once
        handler(this.el, this._.loader);
      } else {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](this, window, 'scroll', { suppress: true });
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["remClass"](CSS_IS_LOADING, this.el);
      }
    }
  }, {
    key: 'Light',
    get: function () {
      return this.el.classList.contains(CSS_IS_LIGHT);
    },
    set: function (value) {
      value ? __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"](CSS_IS_LIGHT, this.el) : __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["remClass"](CSS_IS_LIGHT, this.el);
    }
  }]);

  return Loader;
}(__WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */]);

__WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["a" /* SET__TYPE__ */](Loader, 'loader');

/***/ }),
/* 68 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Swiper; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ui_scripts__ = __webpack_require__(30);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_resizeFire_resizeFire__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__shared_scrollLock_scrollLock__ = __webpack_require__(37);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }








var ATTR_ACTIVE = 'data-swiper-active',
    LIMIT_PERCENT = 0.2,
    // The percent of swiper that must remain visible
CLS_HAS_TRANSITION = 'has-transition',
    EVT_TOUCH_MOVE = 'touchmove',
    EVT_TOUCH_START = 'touchstart';

var movable = null,
    offsetX = 0,
    xProp = 'pageX',
    startTime = void 0,
    endTime = void 0,
    startPos = void 0,
    isMobile = void 0;

function resizeHandler(e) {
  isMobile = __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["isMobile"]();
  if (isMobile) {
    var current = __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["get"]('[' + ATTR_ACTIVE + ']', this.el);
    current && setTransformX(this.el, computeX(current));
  } else {
    this.el.removeAttribute('style');
  }
}

function attachEvents() {
  var _this = this;

  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["addClass"]('no-overflow', this.el.parentElement);
  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](this, document.documentElement, 'mousemove', move);
  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](this, document.documentElement, EVT_TOUCH_MOVE, move, { passive: false });
  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](this, document.documentElement, 'mouseup', endMove);
  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](this, document.documentElement, 'touchend', endMove);

  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](this, this.el, 'mousedown', beginMove);
  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](this, this.el, EVT_TOUCH_START, beginMove, { passive: false });

  __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["attachEvent"](this, this.el, __WEBPACK_IMPORTED_MODULE_5__shared_scrollLock_scrollLock__["b" /* WHEEL_EVENT_NAME */], function (e) {
    if (isMobile) {
      e.preventDefault();
      var delta = event.wheelDelta || -1 * event.detail || -1 * event.deltaY;
      if (!movable) {
        __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["addClass"](CLS_HAS_TRANSITION, _this.el);
        var reflow = _this.el.offsetWidth * _this.el.offsetLeft || 1;
        reflow && moveTo(delta < 0, _this.el);
      }
    }
  });
}

function computeX(element) {
  var offset = __WEBPACK_IMPORTED_MODULE_1__ui_scripts__["rtl"] ? element.parentElement.offsetWidth - element.offsetWidth : 0;
  return offset - element.offsetLeft;
}

function getTransformX(element) {
  return element.style.transform && parseInt(element.style.transform.match(/(\-?\d+)/g)[0], 10) || 0;
}

function setTransformX(element, x) {
  if (isMobile) {
    var parentOffsetWidth = element.parentElement.offsetWidth;
    var limit = __WEBPACK_IMPORTED_MODULE_1__ui_scripts__["rtl"] ? Math.max(-1 * (parentOffsetWidth * (1 - LIMIT_PERCENT)), Math.min(x, element.scrollWidth - parentOffsetWidth * LIMIT_PERCENT)) : Math.max(parentOffsetWidth * LIMIT_PERCENT - element.scrollWidth, Math.min(x, parentOffsetWidth * (1 - LIMIT_PERCENT)));
    element.style.transform = 'translateX(' + limit + 'px)';
  } else {
    element.removeAttribute('style');
  }
}

function resolveEvent(event) {
  var type = event.type;
  if (type === EVT_TOUCH_MOVE || type === EVT_TOUCH_START) {
    if (type === EVT_TOUCH_START) xProp = 'clientX';else event.preventDefault();
    return event.targetTouches[0];
  } else if (event.button === 0) {
    return event;
  }
}

function beginMove(event) {
  startTime = new Date().getTime();
  if (isMobile) {
    var e = resolveEvent(event),
        left = 0;
    if (e) {
      var currentTarget = event.currentTarget;
      __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["remClass"](CLS_HAS_TRANSITION, currentTarget);
      if (currentTarget.style.transform) {
        left = getTransformX(currentTarget);
      }
      offsetX = e[xProp] - left;
      startPos = Math.abs(getTransformX(currentTarget));
      moveElement(e, movable = currentTarget);
    }
  }
}

function moveElement(event, element) {
  setTransformX(element, event[xProp] - offsetX);
}

function move(event) {
  if (movable) {
    var e = resolveEvent(event);
    if (e) {
      moveElement(e, movable);
    }
  }
}

function moveTo(element) {
  var container = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : movable;

  var current = __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["get"]('[' + ATTR_ACTIVE + ']', container);
  if (current) {
    current.removeAttribute(ATTR_ACTIVE);
    current = !__WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["isBool"](element) ? element : (element ? current.nextElementSibling : current.previousElementSibling) || current;
    current.attr(ATTR_ACTIVE, true);
    setTransformX(container, computeX(current));
  }
}

function endMove(event) {
  endTime = new Date().getTime();
  if (movable) {
    __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["addClass"](CLS_HAS_TRANSITION, movable);
    var reflow = movable.offsetWidth * movable.offsetLeft || 1;
    if (reflow) {
      var x = getTransformX(movable),
          speed = (Math.abs(x) - Math.abs(startPos)) / (endTime - startTime);
      if (Math.abs(speed) > 0.2 && Math.abs(speed) < 1.5) {
        if (__WEBPACK_IMPORTED_MODULE_1__ui_scripts__["rtl"] && x < 0 || !__WEBPACK_IMPORTED_MODULE_1__ui_scripts__["rtl"] && x > 0) {
          moveTo(movable.firstElementChild);
        } else {
          moveTo(speed > 0);
        }
      } else {
        var children = movable.children,
            sum = 0,
            target = null;
        for (var i = 0; i < children.length; i++) {
          sum += children[i].offsetWidth;
          // out of range, go to first
          if (__WEBPACK_IMPORTED_MODULE_1__ui_scripts__["rtl"] && x < 0 || !__WEBPACK_IMPORTED_MODULE_1__ui_scripts__["rtl"] && x > 0) {
            target = movable.firstElementChild;
            break;
          }
          if (Math.abs(speed) > 1.5) {
            if (Math.abs(children[i].offsetLeft) >= Math.abs(x) + movable.parentElement.offsetWidth && speed > 0) {
              target = children[i + 1];
              break;
            } else if (Math.abs(children[i].offsetLeft) >= Math.abs(Math.abs(x) - movable.parentElement.offsetWidth) && speed < 0) {
              target = children[i - 1];
              break;
            }
          } else {
            if (sum >= Math.abs(x)) {
              if (Math.abs(x) - sum < -1 * children[i].offsetWidth / 2) target = children[i];else target = children[i + 1];
              break;
            }
          }
        }
        // out of range, go to last
        if (!target) {
          target = movable.lastElementChild;
        }
        moveTo(target);
      }
    }
    movable = null;
  }
}

var Swiper = function (_UIControl) {
  _inherits(Swiper, _UIControl);

  _createClass(Swiper, null, [{
    key: '$init',
    value: function $init(target) {
      __WEBPACK_IMPORTED_MODULE_0__shared_base_ui_control__["a" /* UIControl */].$init(target, Swiper);
    }
  }]);

  function Swiper(element, config) {
    _classCallCheck(this, Swiper);

    var _this2 = _possibleConstructorReturn(this, (Swiper.__proto__ || Object.getPrototypeOf(Swiper)).call(this, element, config));

    var resizeFire = new __WEBPACK_IMPORTED_MODULE_4__shared_resizeFire_resizeFire__["a" /* ResizeFire */]();
    //mark first item as active
    _this2.el.firstElementChild.attr(ATTR_ACTIVE, true);

    attachEvents.call(_this2);

    var debounced = __WEBPACK_IMPORTED_MODULE_2__shared_utils_main__["debounce"](resizeHandler.bind(_this2), 100);
    resizeFire.attach(_this2.el, debounced, _this2.el.parentElement);
    //call once
    debounced();
    return _this2;
  }

  return Swiper;
}(__WEBPACK_IMPORTED_MODULE_0__shared_base_ui_control__["a" /* UIControl */]);
__WEBPACK_IMPORTED_MODULE_3__shared_data_registry__["a" /* SET__TYPE__ */](Swiper, 'swiper');

/***/ }),
/* 69 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export DEFAULTS */
/* harmony export (immutable) */ __webpack_exports__["a"] = required;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);


var DEFAULTS = {
  vals: [], // a list of values item must be in
  not: false, // negate the condition
  msg: undefined, // msg to use when invalid
  msgs: { // specialized msgs to use when invalid
    in: undefined, //msg to use when `vals` is used.
    is: undefined //msg to use otherwise.
  }
};

function required(value, messages, attribute, config) {
  !config._ && __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["merge"](config, __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["merge"](true, {}, DEFAULTS, config, { _: true }));

  var _config$msgs = config.msgs;
  _config$msgs = _config$msgs === undefined ? {} : _config$msgs;
  var msg_in = _config$msgs.in,
      msg_is = _config$msgs.is;

  // check among a list

  if (config.vals.length) {
    var found = config.vals.indexOf(value) !== -1;
    if (!found || config.not && found) {
      messages.push(msg_in || config.msg);
    }
  } else if (!value.length) {
    // empty not allowed, error
    messages.push(msg_is || config.msg);
  }
}

/***/ }),
/* 70 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export DEFAULTS */
/* harmony export (immutable) */ __webpack_exports__["a"] = range;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__validator_regex__ = __webpack_require__(41);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__ = __webpack_require__(0);



var DEFAULTS = {
  type: 's', // data type: (s:string), (i:integer), (f:float).
  min: undefined, // min value or min length
  max: undefined, // max value or max length
  is: undefined, // exact value or exact length
  msg: undefined, // default msg to use when invalid
  msgs: { // specialized msgs to use when invalid
    min: undefined, //msg to use when value or length is less than `min`.
    max: undefined, //msg to use when value or length is greater than `max`.
    is: undefined //msg to use when value or length is not equal to `is`.
  }
};

function range(value, messages, attribute, config) {
  !config._ && __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["merge"](config, __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["merge"](true, {}, DEFAULTS, config, { _: true }));

  if (config.type !== 's') {
    var pattern = config.type === 'i' ? __WEBPACK_IMPORTED_MODULE_0__validator_regex__["a" /* PATTERNS */].integer : __WEBPACK_IMPORTED_MODULE_0__validator_regex__["a" /* PATTERNS */].float;
    if (!value.match(pattern)) {
      messages.push(config.msg);
      return;
    }
  }

  var _config$msgs = config.msgs;
  _config$msgs = _config$msgs === undefined ? {} : _config$msgs;
  var msg_min = _config$msgs.min,
      msg_max = _config$msgs.max,
      msg_is = _config$msgs.is;


  switch (config.type) {
    case 'f':
      value = parseFloat(value);
      break;
    case 'i':
      value = parseInt(value);
      break;
    default:
      value = value.length;
  }

  if (config.min !== undefined && value < config.min) {
    messages.push(msg_min || config.msg);
  }

  if (config.max !== undefined && value > config.max) {
    messages.push(msg_max || config.msg);
  }

  if (config.is !== undefined && value != config.is) {
    messages.push(msg_is || config.msg);
  }
}

/***/ }),
/* 71 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export DEFAULTS */
/* harmony export (immutable) */ __webpack_exports__["a"] = compare;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__validate_form__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__ = __webpack_require__(0);



var DEFAULTS = {
  to: { v: undefined, id: undefined }, // the `compareTo` settings, either v for value or id for element.
  op: '==', // the compare operator
  msg: undefined, // default msg to use when invalid
  msgs: { // specialized msgs to use when comparison fails.
    '==': undefined,
    '!=': undefined,
    '>': undefined,
    '>=': undefined,
    '<': undefined,
    '<=': undefined
  }
};

function compare(value, messages, attribute, config) {
  !config._ && __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["merge"](config, __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["merge"](true, {}, DEFAULTS, config, { _: true }));

  var compareToValue = config.to.v != undefined ? config.to.v : Object(__WEBPACK_IMPORTED_MODULE_0__validate_form__["b" /* ValidatorGetValue */])(__WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["get"]('#' + config.to.id));
  if (attribute.trim) {
    compareToValue = Object(__WEBPACK_IMPORTED_MODULE_0__validate_form__["c" /* ValidatorTrim */])(compareToValue);
  }

  var _config$msg = config.msg,
      msg = _config$msg === undefined ? '' : _config$msg,
      _config$msgs = config.msgs,
      msgs = _config$msgs === undefined ? {} : _config$msgs;


  switch (config.op) {
    case '==':
      if (value != compareToValue) {
        messages.push(msgs['=='] || msg);
      }
      break;
    case '!=':
      if (value == compareToValue) {
        messages.push(msgs['!='] || msg);
      }
      break;
    case '>':
      if (parseFloat(value) <= parseFloat(compareToValue)) {
        messages.push(msgs['>'] || msg);
      }
      break;
    case '>=':
      if (parseFloat(value) < parseFloat(compareToValue)) {
        messages.push(msgs['>='] || msg);
      }
      break;
    case '<':
      if (parseFloat(value) >= parseFloat(compareToValue)) {
        messages.push(msgs['<'] || msg);
      }
      break;
    case '<=':
      if (parseFloat(value) > parseFloat(compareToValue)) {
        messages.push(msgs['<='] || msg);
      }
      break;
  }
}

/***/ }),
/* 72 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export DEFAULTS */
/* harmony export (immutable) */ __webpack_exports__["a"] = captcha;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);


var DEFAULTS = {
  msg: undefined // default msg to use when invalid
};

function captcha(value, messages, attribute, config) {
  !config._ && __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["merge"](config, __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["merge"](true, {}, DEFAULTS, config, { _: true }));

  if (!grecaptcha.getResponse()) {
    messages.push(config.msg);
  }
}

/***/ }),
/* 73 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = transform;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__validate_form__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_utils_main__ = __webpack_require__(0);



var REGEX_BLOCK = /\{([^\{\}]+)\}/g,
    MODIFIERS = {
  'l': function (v) {
    return v.toLowerCase();
  },
  'u': function (v) {
    return v.toUpperCase();
  },
  's-': function (v) {
    return slugify(v, '-');
  },
  's+': function (v) {
    return slugify(v, '+');
  }

},

// IMPORTANT: This must incudes all modifiers listed above
REGEX_VAR = /§(\w+(\.(u|l|s\+|s\-))?)/g,
    LOCALS = {};

//url = '§b/{type≈specialties»specialties/search/§keyword/}{type≈learning»courses/learning-search/?search_type=learning&keyword=§keyword}'

//transforms the url based on conditionl blocks
// url: The url string
//include: a function to check if the block is to be included
//resolve: a function to resolve the value

//resolves local data, when not found resumes to user data
function _resolveFn(key) {
  if (!LOCALS.b) {
    LOCALS.l = document.documentElement.lang;
    LOCALS.o = location.origin;
    LOCALS.b = LOCALS.o + '/' + LOCALS.l;
  }
  return LOCALS[key] || Object(__WEBPACK_IMPORTED_MODULE_0__validate_form__["c" /* ValidatorTrim */])(Object(__WEBPACK_IMPORTED_MODULE_0__validate_form__["b" /* ValidatorGetValue */])(__WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["get"]('#' + key)));
}

//decides if the key is to be included
function _includeFn(key, value) {
  var negate = false;
  if (key[key.length - 1] == '!') {
    key = key.substr(0, key.length - 1);
    negate = true;
  }
  var result = Object(__WEBPACK_IMPORTED_MODULE_0__validate_form__["c" /* ValidatorTrim */])(Object(__WEBPACK_IMPORTED_MODULE_0__validate_form__["b" /* ValidatorGetValue */])(__WEBPACK_IMPORTED_MODULE_1__shared_utils_main__["get"]('#' + key))) === value;
  return negate ? !result : result;
}

function slugify(v, c) {
  return encodeURIComponent(v.replace(/[~!@$%^*()_=\{\}\[\]\|\:"; \'<\>,\?\\\/\s]+/g, " ")).replace(/%20/g, c).toLowerCase().trim();
}

function process(text, include) {
  var m = text.match(/[^≈»]+/g),
      result = '';
  if (m.length == 1) {
    // no condition
    result = m[0];
  } else {
    m.length === 2 && m.splice(1, 0, ''); // no value
    var key = m[0],
        value = m[1],
        segment = m[2];
    if (include(key, value)) result = segment;
  }
  return result;
}

/**
 * Helper to transform url based on a given tempalte.
 *
 * @param {String} url The url template
 * @param {Function} include A callback to decide if the block is to be included or not.
 * @param {Function} resolve A callback to resolve the value of the variable.
 */
function transform(url) {
  var include = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : _includeFn;
  var resolve = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : _resolveFn;

  while (url.match(REGEX_BLOCK)) {
    url = url.replace(REGEX_BLOCK, function (val, match) {
      return process(match, include);
    }).replace(REGEX_VAR, function (m, k) {
      // replace variables
      var modifyFn = function (v) {
        return v;
      },
          modifier = k.split('.');
      if (modifier.length == 2) {
        k = modifier[0];
        modifyFn = MODIFIERS[modifier[1].toLowerCase()] || modifyFn;
      }
      return modifyFn(resolve(k, m));
    });
  }
  var condition = url.split('«');
  if (condition.length == 2) {
    return process('' + condition[1], include) == 'stop' ? false : condition[0];
  }
  return url;
}

/***/ }),
/* 74 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = $init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__ui_shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ui_shared_i18n_res__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__ui_shared_base_ui_control__ = __webpack_require__(1);




var _tmplSpacer = '<i class="trim-spacer"></i>',
    _tmplExpanderFn = function () {
  var text = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : __WEBPACK_IMPORTED_MODULE_1__ui_shared_i18n_res__["a" /* res */].seeMore;
  return '<a class="trim-expander" href="#">' + text + '</a>';
};

/**
 *  Helper to compute line height (delayed)
 *
 * @param {HTMLElement} element The element to compute line height for.
 * @param {Function} callback The function to invoke when line height is computed.
 * @param {CSSStyleDeclaration} style The computed element styles.
 * @param {Number} retries The current retries count, will stop when it reaches zero.
 */
function computeLineHeight(element, callback, style) {
  var retries = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 5;

  style = style || getComputedStyle(element);
  var lineHeight = parseFloat(style.lineHeight);
  if (isNaN(lineHeight) && retries > 0) {
    setTimeout(function () {
      computeLineHeight(element, callback, style, --retries);
    }, 200);
  } else {
    callback(lineHeight, lineHeight / parseFloat(style.fontSize));
  }
}

/**
 * Helper to remove spacer and expander from element.
 *
 * @param {HTMLElement} element
 * @param {HTMLElement} spacer
 * @param {HTMLElement} expander
 */
function untrim(element, spacer, expander) {
  spacer.parentElement && element.removeChild(spacer);
  expander.parentElement && element.removeChild(expander);
}

/**
 * Helper o add spacer and expander to element.
 *
 * @param {HTMLElement} element
 * @param {HTMLElement} spacer
 * @param {HTMLElement} expander
 */
function trim(element, spacer, expander) {
  element.insertAdjacentElement('afterbegin', expander);
  element.insertAdjacentElement('afterbegin', spacer);
}

/**
 * Helper to trim/untrim text
 *
 * @param {HTMLElement} element
 * @param {HTMLElement} spacer
 * @param {HTMLElement} expander
 */
function toggle(element, spacer, expander) {
  if (element.scrollHeight <= element.clientHeight) {
    untrim(element, spacer, expander);
  } else {
    trim(element, spacer, expander);
  }
}

/**
 * Module Helper to trim multiline text.
 *
 * @param {HTMLElement} element
 * @param {Object} config
 */
function typeTrim(element) {
  var config = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var _config$lines = config.lines,
      lines = _config$lines === undefined ? 3 : _config$lines,
      text = config.text,
      maxHeight = element.style.maxHeight,
      spacer = Object(__WEBPACK_IMPORTED_MODULE_0__ui_shared_utils_main__["htmlToElement"])(_tmplSpacer),
      expander = Object(__WEBPACK_IMPORTED_MODULE_0__ui_shared_utils_main__["htmlToElement"])(_tmplExpanderFn(text));

  //ensure a minimum of 1 line

  lines = Math.max(1, lines);
  //set class
  Object(__WEBPACK_IMPORTED_MODULE_0__ui_shared_utils_main__["addClass"])('t-trim', element);

  computeLineHeight(element, function (lineHeight, em) {
    //compute offset height when this element consists of only one line.
    var whiteSpace = element.style.whiteSpace;
    element.style.whiteSpace = "nowrap";
    var offsetHeight = element.offsetHeight;
    element.style.whiteSpace = whiteSpace;

    //default trim
    trim(element, spacer, expander, '');

    //set heights
    var gap = lineHeight - offsetHeight;
    element.style.maxHeight = lineHeight * lines - gap * lines-- + 'px';
    spacer.style.height = lineHeight * lines - gap * lines + 'px';

    //invoke toggle to hide expander in case text is less than computed height
    toggle(element, spacer, expander);
  });

  //resize hanlder
  function resize(e) {
    toggle(element, spacer, expander);
  }

  //expand hanlder
  function expand(e) {
    e.preventDefault();

    //detach events
    expander.removeEventListener('click', expand);
    window.removeEventListener('resize', resize);

    //undo trim
    untrim(element, spacer, expander);
    element.style.maxHeight = maxHeight;
    Object(__WEBPACK_IMPORTED_MODULE_0__ui_shared_utils_main__["remClass"])('t-trim', element);
  }
  //attach events
  window.addEventListener('resize', resize);
  expander.addEventListener('click', expand);
}

/**
* Module helper to lazy load images
*
* @param {HTMLElement} container The element to search in (optional).
*/
function $init(container) {
  __WEBPACK_IMPORTED_MODULE_2__ui_shared_base_ui_control__["a" /* UIControl */].$initHelper(container, 'trim', typeTrim);
}

/***/ }),
/* 75 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = $init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__ = __webpack_require__(1);


var ATTR = 'msg-close',
    SELECTOR = '.' + ATTR;

function message(element, config) {
  element.addEventListener('click', function (e) {
    var target = config.selector ? e.target.closest(config.selector) : e.target.closest('div');
    if (config.mode === 'display') {
      target && (target.style.display = 'none');
    } else {
      target && target.parentElement && target.parentElement.removeChild(target);
    }
  });
}

function $init(container) {
  __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__["a" /* UIControl */].$initHelper(container, ATTR, message, { query: SELECTOR });
}

/***/ }),
/* 76 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = $init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__ = __webpack_require__(1);



var _readyStateTemplate = '<span class="u-none" data-for="done" data-fnph></span>';
var DATA_STATE = 'data-state';
var DATA_FOR = 'data-for';

function toggleState(file, to) {
  var writeName = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

  var from = file.getAttribute(DATA_STATE);
  file.setAttribute(DATA_STATE, to);

  var span = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[' + DATA_FOR + '="' + from + '"]', file.parentElement);
  if (span) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"]('u-none', span);
  }

  span = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[' + DATA_FOR + '="' + to + '"]', file.parentElement);
  if (span) {
    B8.remClass('u-none', span);
    if (span.getAttribute('data-fnph') != null) {
      var first = file.files[0];
      span.innerHTML = ' ' + (first ? first.name : file.value);
    }
  }
}

function file(element, config) {
  var label = element.nextElementSibling;
  var doneElement = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[' + DATA_FOR + '="done"]', label);
  if (!doneElement) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('.file-content', function (content) {
      content.appendChild(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](_readyStateTemplate));
    }, label);
  }

  element.addEventListener('change', function (e) {
    if (element.value) {
      toggleState(element, 'done');
    } else {
      toggleState(element, 'ready');
    }
  });
}

/**
* Module helper to toggle file input state
*
* @param {HTMLElement} container The element to search in (optional).
*/
function $init(container) {
  __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__["a" /* UIControl */].$initHelper(container, 'file', file);
}

/***/ }),
/* 77 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = $init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__ = __webpack_require__(1);



function lazyLoad(element, config) {
  element.src = config.src;
}

/**
* Module helper to lazy load images
*
* @param {HTMLElement} container The element to search in (optional).
*/
function $init(container) {
  __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__["a" /* UIControl */].$initHelper(container, 'src', lazyLoad, { tag: 'img' });
}

/***/ }),
/* 78 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = $init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__ = __webpack_require__(1);



function imgFit(element) {
  Object(__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"])('img', function (img) {
    img.style.width = img.style.height = 'auto';
    img.style.maxWidth = '100%';
  }, element);
}

/**
* Module helper to auto size images
*
* @param {HTMLElement} container The element to search in (optional).
*/
function $init(container) {
  __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__["a" /* UIControl */].$initHelper(container, 'img-fit', imgFit);
}

/***/ }),
/* 79 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = $init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__modal__ = __webpack_require__(31);




var DEFAULTS = {
  resolveUrl: function (img) {
    return img.src.replace('gallery_thumb', 'gallery'); //.replace('.com/', '.com/800x800/')
  }
};

function lightbox(element, config) {
  config = Object.assign({}, DEFAULTS, config);
  var urls = [];
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('img', function (img) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"]('has-pointer-d', img);
    urls.push(config.resolveUrl(img));
  }, element);
  element.addEventListener('click', function (e) {
    if (e.target.tagName === 'IMG' && !__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
      new __WEBPACK_IMPORTED_MODULE_2__modal__["d" /* Modal */]({
        closable: true,
        closableByDimmer: true
      }).showGallery(urls, config.resolveUrl(e.target));
    }
  });
}

/**
* Module helper to make a list of images viewed in a lightbox
*
* @param {HTMLElement} container The element to search in (optional).
*/
function $init(container) {
  __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__["a" /* UIControl */].$initHelper(container, 'lightbox', lightbox);
}

/***/ }),
/* 80 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["h"] = updateElement;
/* unused harmony export getElement */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return build; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return init; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return open; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return close; });
/* unused harmony export isOpen */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return toggleLoading; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return openGallery; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return closeGallery; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__image_image_remap__ = __webpack_require__(42);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__ui_scripts__ = __webpack_require__(30);



/*modal requires tab index in order for the click event to fire before body focus*/
var _template = '\n<div class="modal" tabindex="0">\n  <div class="modal-wrap">\n    <div class="modal-dialog has-attachments" tabindex="0" data-capture>\n      <button class="js-tabtrap"></button>\n      <div class="loader"><div class="spinner" role="progressbar"></div></div>\n      <a href="#" class="modal-close is-attached is-outer d" data-position="tr"></a>\n      <div class="is-attached is-outer p40r d" data-position="lc">\n        <a href="#" class="modal-prev"></a>\n      </div>\n      <div class="is-attached is-outer p40l d" data-position="rc">\n        <a href="#" class="modal-next"></a>\n      </div>\n      <div class="modal-banner"></div>\n      <div class="modal-head"></div>\n      <div class="modal-body"></div>\n      <div class="modal-gallery"></div>\n      <div class="modal-foot"></div>\n      <button class="js-tabtrap"></button>\n    </div>\n  </div>\n</div>\n',
    _instance = void 0,
    //holds the current dialog instance
_elements = void 0,
    //holds the dialog key elements
_placeholders = { //holds the dialog key elements placeholders
  close: document.createComment('close'),
  prev: document.createComment('prev'),
  next: document.createComment('next'),
  banner: document.createComment('banner'),
  head: document.createComment('head'),
  body: document.createComment('body'),
  gallery: document.createComment('gallery'),
  foot: document.createComment('foot')
},
    _activeElement = void 0,
    //holds the last active element to return focus to.
_cancelKeyup = true,
    //prevent handling key up when dialog is being opened by a key stroke.
_usedKeys = [],
    //holds the list of used keys.
_isOpen = false,
    // indicates if the dialog is open or not
_isBlocked = false,
    _isForwardTab = true,
    _galleryIndex = -1,
    // holds current gallery image index
_galleryImages = [],
    // holds gallery image urls
_galleryCurrent = void 0; // holds the current gallery image node


/**
 * Creates the dialog required DOM if not already created.
 */
function build() {
  if (!_elements) {
    var modal = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](_template);
    _elements = {
      modal: modal,
      wrap: modal.qs('.modal-wrap'),
      dialog: modal.qs('.modal-dialog'),
      close: modal.qs('.modal-close'),
      prev: modal.qs('.modal-prev').parentElement,
      next: modal.qs('.modal-next').parentElement,
      banner: modal.qs('.modal-banner'),
      head: modal.qs('.modal-head'),
      body: modal.qs('.modal-body'),
      gallery: modal.qs('.modal-gallery'),
      foot: modal.qs('.modal-foot'),
      reset: [modal.qs('.js-tabtrap:first-child'), modal.qs('.js-tabtrap:last-child')]
    };
  }
  clear();
  return _elements.modal;
}

/**
 * Resets the dialog instance by clearing its children and detaching all key elements
  */
function clear() {
  updateElement('close', false);
  updateElement('prev', false);
  updateElement('next', false);
  updateElement('banner', false);
  updateElement('head', false);
  updateElement('body', false);
  updateElement('gallery', false);
  updateElement('foot', false);
}

/**
 * Opens a Lightbox (Modal Image Gallery)
 *
 * @param {*} instance
 * @param {*} images
 * @param {*} currentUrl
 */
function openGallery(instance, images, currentUrl) {
  if (images.length) {
    clear();
    _galleryImages = images;
    if (!_galleryCurrent) {
      var nodes = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<div><div></div><div></div></div>');
      updateElement('gallery', nodes);
      _galleryCurrent = nodes.firstElementChild;
    }
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"]('has-gallery', getElement('modal'));
    instance.show({
      callback: function () {
        galleryNext(instance, currentUrl, function () {
          updateElement('close', true);
          updateElement('prev', true);
          updateElement('next', true);
        });
        return true;
      }
    });

    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, window, 'resize', function wResize() {
      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
        instance.hide();
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, window, 'resize');
      }
    });
  }
}
/**
 * Switched current active gallery image
 *
 * @param {*} instance
 * @param {*} url
 * @param {*} node
 * @param {*} cb
 */
function gallerySwitch(instance, url, cb) {
  var _this = this;

  var node = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : _galleryCurrent.nextElementSibling || _galleryCurrent.previousElementSibling;

  var timer = setTimeout(function () {
    instance.Waiting = true;
  }, 250);
  Object(__WEBPACK_IMPORTED_MODULE_1__image_image_remap__["b" /* getNaturalDimensions */])(url, function (width, height) {
    clearTimeout(timer);
    _galleryCurrent.style.opacity = 0;
    node.style.backgroundImage = 'url(' + url + ')';
    node.style.opacity = 1;
    var ratio = height / width,
        maxHeight = screen.height * 0.8;
    var w = Math.min(width, screen.width * 0.8),
        h = ratio * w;
    if (h > maxHeight) {
      ratio = maxHeight / h;
      h = maxHeight; // set the height to the max
      w = ratio * w;
    }
    node.parentElement.style.width = Math.floor(w) + 'px';
    node.parentElement.style.height = Math.floor(h) + 'px';
    _galleryCurrent = node;
    cb && cb.call(_this);
    instance.Waiting = false;
  });
}
/**
 * Goes to next gallery image.
 *
 * @param {*} instance
 * @param {*} currentUrl
 * @param {*} cb
 */
function galleryNext(instance, currentUrl, cb) {
  if (currentUrl) {
    _galleryIndex = _galleryImages.indexOf(currentUrl) - 1;
  }
  gallerySwitch(instance, _galleryImages[_galleryIndex = ++_galleryIndex > _galleryImages.length - 1 ? 0 : _galleryIndex], cb);
}

/**
 * Goes to previous gallery image
 *
 * @param {*} instance
 * @param {*} cb
 */
function galleryPrev(instance, cb) {
  gallerySwitch(instance, _galleryImages[_galleryIndex = --_galleryIndex < 0 ? _galleryImages.length - 1 : _galleryIndex], cb);
}

/**
 * Closes the Lightbox (Modal Image Gallery)
 *
 * @param {*} instance
 */
function closeGallery(instance) {
  _galleryCurrent = null;
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["clearChildren"](getElement('gallery'));
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["remClass"]('has-gallery', getElement('modal'));
  _galleryImages = [];
}

/**
 * Helper for toggling modal loading state.
 *
 * @param {Object} instance The modal instance
 * @param {Boolean} enable  Indicates whether to enable or disable the loading state
 */
function toggleLoading(instance, enable) {
  var dialog = getElement('dialog');
  if (enable) {
    dialog.classList.add('is-loading');
    block(instance);
  } else {
    dialog.classList.remove('is-loading');
    unblock(instance);
  }
}

var BLOCK_HANDLER = function (e) {
  e.stopPropagation();
  e.preventDefault();
};

/**
 * Helper to block all user input
 *
 * @param {Object} instance The modal instance.
 */
function block(instance) {
  if (!_isBlocked && (_isBlocked = true)) {
    var dialog = getElement('dialog');
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, dialog, 'keydown', BLOCK_HANDLER, { useCapture: true });
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, dialog, 'keyup', BLOCK_HANDLER, { useCapture: true });
  }
}

/**
 * Helper to unblock all user input
 *
 * @param {Object} instance The modal instance.
 */
function unblock(instance) {
  if (_isBlocked && !(_isBlocked = false)) {
    var dialog = getElement('dialog');
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, dialog, 'keydown');
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, dialog, 'keyup');
  }
}

/**
 * Updates a given modal key element
 *
 * @param {string} key The element key
 * @param {HTMLElement} value The child to append to the element, falsy values will clear the element and detach it.
 */
function updateElement(key, value) {
  var el = _elements[key];
  var ph = _placeholders[key];
  var parent = el.parentElement;
  if (!value) {
    parent && parent.replaceChild(ph, el);
  } else if (value instanceof HTMLElement || value instanceof Node || __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isBool"](value)) {
    // append element
    if (!__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isBool"](value)) {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["clearChildren"](el);
      el.appendChild(value);
    }
    // replace with placeholder
    if (!parent) _elements.dialog.replaceChild(el, ph);
  }
}

/**
 * Helper to get a specific modal element.
 *
 * @param {String} key The element key
 */
function getElement(key) {
  return _elements[key];
}

/**
 * Builds the modal dialog action buttons.
 *
 * @param {Array} buttons The dialog buttons configuration
 */
function buildActions(buttons, orientation) {
  _usedKeys.length = 0;
  if (buttons.length) {
    var group = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<div class="modal-btn-pack ' + (orientation === 'v' ? 'is-vertical' : '') + '"></div>');
    for (var index = 0; index < buttons.length; index++) {
      var button = buttons[index];
      //for (let button of buttons) {
      // add to the list of used keys.
      if (_usedKeys.indexOf(button.key) < 0) {
        _usedKeys.push(button.key);
      }
      button.element = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<button class="btn u-expanded-m ' + (button.type ? 'is-' + button.type : '') + ' ' + (button.classes || '') + '"> ' + button.text + '</button>');
      group.appendChild(button.element);
    }
    return group;
  }
}

/**
 * Initializes a modal instance by clearing key elements and building the actions
 *
 * @param {Modal} instance The modal instance
 */
function init(instance) {
  clear(instance);
  updateElement('close', instance.config.closable);
  updateElement('foot', buildActions(instance.config.buttons, instance.config.buttonsVertical ? 'v' : 'h'));
}

/**
 * Helper for triggering a given modal event.
 *
 * @param {Object} instance The modal instance.
 * @param {String} key The element key.
 */
function triggerEvent(instance, key) {
  var eventHandler = instance.config.on[key];
  if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](eventHandler)) {
    eventHandler.call(instance);
  }
}

/**
 * Returns true if the dialog is open
 */
function isOpen() {
  return _isOpen;
}
/**
 * Opens the modal
 *
 * @param {Modal} instance The modal instance
 */
function open(instance) {
  if (!_isOpen && (_isOpen = true)) {

    //prevent handling key up when dialog is being opened by a key stroke.
    _cancelKeyup = true;

    //trigger event
    triggerEvent(instance, 'beforeopen');

    //save active element
    _activeElement = document.activeElement;
    //bind required events.
    bindEvents(instance);
    //save scroll position
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["saveScrollPosition"]();
    //handle page overflow
    ensureNoOverflow(true);
    //attach modal to the page
    document.body.appendChild(instance.el);
    //set focus according to dialog config
    setFocus(instance);
    //restore scroll to prevent document jump
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["restoreScrollPosition"]();

    //trigger event
    triggerEvent(instance, 'afteropen');
    //Utils.dispatchEvent('modal.open', instance)

    // allow handling key up after some time to ignore key up event handling
    setTimeout(function () {
      _cancelKeyup = false;
    }, 200);
  }
}

/**
 * Closes the modal
 *
 * @param {Modal} instance The modal instance
 */
function close(instance) {
  if (_isOpen && !(_isOpen = false)) {
    //trigger event
    triggerEvent(instance, 'beforeclose');

    //unbind all events
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachAllEvents"](instance);

    //detach the modal
    document.body.removeChild(instance.el);

    // return focus to the last active element
    if (_activeElement && _activeElement.focus) {
      _activeElement.focus();
      _activeElement = null;
    }

    //restore page oveflow
    ensureNoOverflow(false);

    //trigger event
    triggerEvent(instance, 'afterclose');
    //Utils.dispatchEvent('modal.close', instance)
  }
}

/**
 * Ensures the current page does not overflow when the modal is shown
 *
 * @param {Boolean} add Whether to add or remove the no overflow behavior.
 */
function ensureNoOverflow(add) {
  if (add && !document.body.classList.contains('js-no-overflow')) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["preventBodyShift"](true);
    document.body.classList.add('js-no-overflow');
    document.body.tabIndex = 0;
  } else if (document.body.classList.contains('js-no-overflow')) {
    //last open modal or last maximized one
    document.body.removeAttribute('tabIndex');
    document.body.classList.remove('js-no-overflow');
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["preventBodyShift"](false);
  }
}

/**
 *
 *
 * @param {Object} button The button that triggered the close event
 */
function createCloseEvent(button) {
  return {
    button: button,
    cancel: false
  };
}

/**
 * Triggers callback registred with one of the buttons
 *
 * @param {Modal} instance The modal instance
 * @param {function} check A check function to test for the button
 */
function triggerCallback(instance, check) {
  for (var index = 0; index < instance.config.buttons.length; index++) {
    var button = instance.config.buttons[index];
    //for (let button of instance.config.buttons) {
    if (!button.element.disabled && check(button)) {
      var handler = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["resolveFn"](button.callback, null, instance.config.on),
          closeEvent = createCloseEvent(button);

      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](handler)) {
        var returnValue = handler.call(instance, closeEvent);
        if (typeof returnValue !== 'undefined') {
          closeEvent.cancel = !returnValue;
        }
      }
      //close the dialog only if not canceled.
      if (closeEvent.cancel === false) {
        instance.hide();
      }
      break;
    }
  }
}

/**
 * Triggers a close command
 *
 * @param {Modal} instance The modal instance
 */
function triggerClose(instance) {
  var found;
  triggerCallback(instance, function (button) {
    return found = button.invokeOnClose === true;
  });
  //none of the buttons registered as onclose callback
  //close the dialog
  if (!found && _isOpen) {
    instance.hide();
  }
}

/**
 *
 * @param {Modal} instance The modal instance
 */
function setFocus(instance, resetTarget) {
  // reset target has already been determined.
  if (resetTarget) {
    resetTarget.focus();
  } else {
    // current instance focus settings
    var focus = instance.config.focus;
    // the focus element.
    var element = focus.target;

    switch (typeof focus.target) {
      // a number means a button index
      case 'number':
        if (instance.config.buttons.length > focus.target) {
          element = instance.config.buttons[focus.target].element;
        }
        break;
      // a string means querySelector to select from dialog body contents.
      case 'string':
        element = _elements.modal.qs(focus.target);
        break;
      // a function should return the focus element.
      case 'function':
        element = focus.target.call(instance);
        break;
    }

    // if no focus element, default to first reset element.
    if ((typeof element === 'undefined' || element === null) && instance.config.buttons.length === 0) {
      element = _elements.reset[0];
    }
    // focus
    if (element && element.focus) {
      element.focus();
      // if selectable
      if (focus.select && element.select) {
        element.select();
      }
    }
  }
}

function isSkipKey(e) {
  return (document.activeElement.getAttribute('data-skip-keys') || '').split(',').map(function (v) {
    return parseInt(v);
  }).indexOf(e.keyCode) > -1;
}

/**
 * Binds required events for the dialog
 *
 * @param {Modal} instance The modal instance
 */
function bindEvents(instance) {
  var keyupHandler = function (e) {
    // do nothing if in waiting state
    if (instance.Waiting) {
      return;
    }
    //console.log('keyup handler', e)
    //hitting enter while button has focus will trigger keyup too. ignore if handled by clickHandler
    if (_cancelKeyup || e.defaultPrevented) {
      _cancelKeyup = false;
      return;
    }
    //console.log('keyup handler continuted', e)
    // if modal has no buttons and unused Esc key was pressed, close the modal
    if ((!instance.config.buttons.length || _usedKeys.indexOf(e.keyCode) < 0) && e.keyCode === __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ESC) {
      instance.hide();
      return false;
    } else if (e.keyCode !== __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ESC && !isSkipKey(e) && _usedKeys.indexOf(e.keyCode) > -1) {
      // Esc key should be handled in key down, for example if a file browse dialog is open and the user hit Esc key, then keydown event will not be fired.
      triggerCallback(instance, function (button) {
        return button.key === e.keyCode;
      });
      return false;
    }
  };

  // function next(index, dir='prev', iteration = 0) {
  //   let buttons = instance.config.buttons
  //     if(iteration++ > buttons.length) {
  //       return null
  //     }
  //     let btn = buttons[(x + 1) % buttons.length]
  //     return !btn.element.disabled ? btn : next(index+1, dir)
  // }
  var keydownHandler = function (e) {
    // do nothing if in waiting state
    if (instance.Waiting) {
      return;
    }
    //do nothing if prevented by a sub component
    if (e.defaultPrevented) {
      return;
    }
    // set Tab direction
    if (e.keyCode === __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].TAB) {
      _isForwardTab = !e.shiftKey;
    }
    if (e.keyCode === __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].LEFT || e.keyCode === __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].RIGHT) {
      if (_galleryImages.length) {
        e.preventDefault();
        switch (e.keyCode) {
          case __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].RIGHT:
            __WEBPACK_IMPORTED_MODULE_2__ui_scripts__["rtl"] ? galleryPrev(instance) : galleryNext(instance);
            break;
          case __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].LEFT:
            __WEBPACK_IMPORTED_MODULE_2__ui_scripts__["rtl"] ? galleryNext(instance) : galleryPrev(instance);
            break;
        }
      } else {
        var buttons = instance.config.buttons;
        for (var x = 0; x < buttons.length; x += 1) {
          if (document.activeElement === buttons[x].element) {
            switch (e.keyCode) {
              case __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].LEFT:
                buttons[(x || buttons.length) - 1].element.focus();
                return;
              case __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].RIGHT:
                buttons[(x + 1) % buttons.length].element.focus();
                return;
            }
          }
        }
      }
    } else if ((e.keyCode == __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ESC || e.keyCode < __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].F12 + 1 && e.keyCode > __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].F1 - 1) && !isSkipKey(e) && _usedKeys.indexOf(e.keyCode) > -1) {
      // F1-F12 must be handled in keydown event to be able to prevent them.
      // Esc key should be handled in key up, for example if a file browse dialog is open and the user hit Esc key, then keydown event will not be fired.
      // other keys are handled in keyup event.
      //console.log('else')
      e.preventDefault();
      e.stopPropagation();
      triggerCallback(instance, function (button) {
        return button.key === e.keyCode;
      });
      return false;
    }
  };

  var resetFocus = function (e) {
    // determine reset target to enable forward/backward tab cycle.
    var resetTarget = void 0,
        target = e.target,
        lastResetElement = target === _elements.reset[1] || instance.config.buttons.length === 0 && target === document.body;

    // if last reset link, then go to maximize or close
    if (lastResetElement && instance.config.closable) {
      resetTarget = _elements.close;
    }

    // if no reset target found, try finding the best button
    if (resetTarget === undefined) {
      // will reach here when tapping backwards, so go to last child
      if (target === _elements.reset[0]) {
        // focus last button if we have any
        if (instance.config.buttons.length) {
          resetTarget = instance.config.buttons[instance.config.buttons.length - 1].element;
        } else {
          //otherwise, find an element that can recieve focus.
          var tabbable = _elements.body.qsa('button:not(:disabled), [href]:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"]');
          if (tabbable.length) {
            resetTarget = tabbable[tabbable.length - 1];
          } else {
            //nothing to focus
            resetTarget = _elements.close;
          }
        }
      } else if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isNum"](instance.config.focus.target)) {
        // button focus element, go to first available button
        if (target === _elements.reset[0] && instance.config.buttons.length) {
          resetTarget = instance.config.buttons[0].element;
        } else if (lastResetElement) {
          //restart the cycle by going to first reset link
          resetTarget = _elements.reset[0];
        }
      }
    }

    // set focus
    setFocus(instance, resetTarget);
  };

  var clickHandler = function (e) {
    //console.log('click handler', e)
    var target = e.target;
    triggerCallback(instance, function (button) {
      // hitting enter while button has focus will trigger keyup too.
      // if this button caused the click, cancel keyup event
      return button.element === target && (_cancelKeyup = true);
    });
  };

  var modalClickHandler = function (e) {
    var target = e.target;
    if (target === _elements.close) {
      e.preventDefault();
    }
    if (target === _elements.next || _elements.next.contains(target)) {
      e.preventDefault();
      galleryNext(instance);
    }
    if (target === _elements.prev || _elements.prev.contains(target)) {
      e.preventDefault();
      galleryPrev(instance);
    }

    if ( /*!instance.disabled &&*/!instance.Waiting && (instance.config.closableByDimmer !== false && (target === _elements.modal || target === _elements.wrap) || target === _elements.close)) {
      triggerClose(instance);
    }
  };

  /// GLOBAL
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, document.body, 'keyup', keyupHandler);
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, document.body, 'keydown', keydownHandler);

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, document.body, 'focus', resetFocus);
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, _elements.modal, 'focus', resetFocus);
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, _elements.reset[0], 'focus', resetFocus);
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, _elements.reset[1], 'focus', resetFocus);

  /// COMMON
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, _elements.modal, 'click', modalClickHandler);

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, _elements.foot, 'click', clickHandler);
}



/***/ }),
/* 81 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = Alert;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__modal__ = __webpack_require__(31);




function Alert(config) {

  if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](config)) {
    config = { message: config };
  }

  var _config = config,
      _config$button = _config.button;
  _config$button = _config$button === undefined ? {} : _config$button;
  var _config$button$text = _config$button.text,
      okBtnText = _config$button$text === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].ok : _config$button$text,
      _config$button$type = _config$button.type,
      okBtnType = _config$button$type === undefined ? 'inverse' : _config$button$type,
      _config$button$classe = _config$button.classes,
      okBtnClasses = _config$button$classe === undefined ? '' : _config$button$classe,
      _config$focus = _config.focus;
  _config$focus = _config$focus === undefined ? {} : _config$focus;
  var _config$focus$target = _config$focus.target,
      focusTarget = _config$focus$target === undefined ? 0 : _config$focus$target,
      _config$focus$select = _config$focus.select,
      focusSelect = _config$focus$select === undefined ? false : _config$focus$select;


  var modal = new __WEBPACK_IMPORTED_MODULE_2__modal__["d" /* Modal */]({
    on: config.on || {},
    buttons: [{
      text: okBtnText,
      key: __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ESC,
      type: okBtnType,
      classes: okBtnClasses,
      outline: false,
      invokeOnClose: true,
      callback: 'ok'
    }],
    focus: {
      target: focusTarget,
      select: focusSelect
    }
  });
  modal.Header = '<h5>' + config.message + '</h5>';
  return modal.show();
}

/***/ }),
/* 82 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = Confirm;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__modal__ = __webpack_require__(31);




function Confirm(config) {

  if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](config)) {
    config = { message: config };
  }

  var _config = config,
      _config$buttons = _config.buttons;
  _config$buttons = _config$buttons === undefined ? {} : _config$buttons;
  var _config$buttons$yes = _config$buttons.yes;
  _config$buttons$yes = _config$buttons$yes === undefined ? {} : _config$buttons$yes;
  var _config$buttons$yes$t = _config$buttons$yes.text,
      yesBtnText = _config$buttons$yes$t === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].yes : _config$buttons$yes$t,
      _config$buttons$yes$t2 = _config$buttons$yes.type,
      yesBtnType = _config$buttons$yes$t2 === undefined ? '' : _config$buttons$yes$t2,
      _config$buttons$yes$c = _config$buttons$yes.classes,
      yesBtnClasses = _config$buttons$yes$c === undefined ? '' : _config$buttons$yes$c,
      _config$buttons$no = _config$buttons.no;
  _config$buttons$no = _config$buttons$no === undefined ? {} : _config$buttons$no;
  var _config$buttons$no$te = _config$buttons$no.text,
      noBtnText = _config$buttons$no$te === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].no : _config$buttons$no$te,
      _config$buttons$no$ty = _config$buttons$no.type,
      noBtnType = _config$buttons$no$ty === undefined ? 'inverse' : _config$buttons$no$ty,
      _config$buttons$no$cl = _config$buttons$no.classes,
      noBtnClasses = _config$buttons$no$cl === undefined ? '' : _config$buttons$no$cl,
      _config$focus = _config.focus;
  _config$focus = _config$focus === undefined ? {} : _config$focus;
  var _config$focus$target = _config$focus.target,
      focusTarget = _config$focus$target === undefined ? 0 : _config$focus$target,
      _config$focus$select = _config$focus.select,
      focusSelect = _config$focus$select === undefined ? false : _config$focus$select;


  var modal = new __WEBPACK_IMPORTED_MODULE_2__modal__["d" /* Modal */]({
    on: config.on || {},
    buttons: [{
      text: noBtnText,
      key: __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ESC,
      type: noBtnType,
      classes: noBtnClasses,
      outline: false,
      invokeOnClose: true,
      callback: 'cancel'
    }, {
      text: yesBtnText,
      key: __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ENTER,
      type: yesBtnType,
      classes: yesBtnClasses,
      outline: false,
      invokeOnClose: false,
      callback: 'ok'
    }],
    focus: {
      target: focusTarget,
      select: focusSelect
    }
  });
  modal.Header = '<h5>' + config.message + '</h5>';
  return modal.show();
}

/***/ }),
/* 83 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = Promo;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__modal__ = __webpack_require__(31);




function Promo(config) {
  var _config$buttons = config.buttons;
  _config$buttons = _config$buttons === undefined ? {} : _config$buttons;
  var _config$buttons$yes = _config$buttons.yes;
  _config$buttons$yes = _config$buttons$yes === undefined ? {} : _config$buttons$yes;
  var _config$buttons$yes$t = _config$buttons$yes.text,
      yesBtnText = _config$buttons$yes$t === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].tryNow : _config$buttons$yes$t,
      _config$buttons$yes$t2 = _config$buttons$yes.type,
      yesBtnType = _config$buttons$yes$t2 === undefined ? '' : _config$buttons$yes$t2,
      _config$buttons$yes$c = _config$buttons$yes.classes,
      yesBtnClasses = _config$buttons$yes$c === undefined ? '' : _config$buttons$yes$c,
      _config$buttons$no = _config$buttons.no;
  _config$buttons$no = _config$buttons$no === undefined ? {} : _config$buttons$no;
  var _config$buttons$no$te = _config$buttons$no.text,
      noBtnText = _config$buttons$no$te === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].cancel : _config$buttons$no$te,
      _config$buttons$no$ty = _config$buttons$no.type,
      noBtnType = _config$buttons$no$ty === undefined ? 'inverse' : _config$buttons$no$ty,
      _config$buttons$no$cl = _config$buttons$no.classes,
      noBtnClasses = _config$buttons$no$cl === undefined ? '' : _config$buttons$no$cl,
      _config$focus = config.focus;
  _config$focus = _config$focus === undefined ? {} : _config$focus;
  var _config$focus$target = _config$focus.target,
      focusTarget = _config$focus$target === undefined ? 0 : _config$focus$target,
      _config$focus$select = _config$focus.select,
      focusSelect = _config$focus$select === undefined ? false : _config$focus$select;


  var modal = new __WEBPACK_IMPORTED_MODULE_2__modal__["d" /* Modal */]({
    on: config.on || {},
    buttons: [{
      text: yesBtnText,
      type: yesBtnType,
      classes: yesBtnClasses,
      key: __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ENTER,
      outline: false,
      callback: 'ok'
    }, {
      text: noBtnText,
      type: noBtnType,
      classes: noBtnClasses,
      key: __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ESC,
      outline: false,
      invokeOnClose: true,
      callback: 'cancel'
    }],
    buttonsVertical: true,
    focus: {
      target: focusTarget,
      select: focusSelect
    }
  });

  modal.Header = '<h5 class="t-center">' + config.title + '</h5>';
  modal.Banner = config.imgUrl;
  modal.Body = '<p class="t-small t-boxed-d">' + config.message + '</p>';

  return modal.show();
}

/***/ }),
/* 84 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = File;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__modal__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__modal_file_addons__ = __webpack_require__(85);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__ui_scripts__ = __webpack_require__(30);






// sequence for generating new IDs.
var uploadID = 0;

var _uploadTemplateFn = function (html) {
  return '<i class="file-icon"></i> ' + html;
};
var _cmdTemplateFn = function (id) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
      text = _ref.text,
      confirm = _ref.confirm,
      _ref$yes = _ref.yes,
      yes = _ref$yes === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].yes : _ref$yes,
      _ref$no = _ref.no,
      no = _ref$no === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].no : _ref$no;

  return '\n<a href="#" class="t-xsmall is-gray toggler-active m10t" data-toggler=\'{"target":"#c' + id + '", "alt":"[data-no]"}\'>\n  <span>' + text + '</span>\n  <span></span>\n</a>\n<span id="c' + id + '" class="t-xsmall" style="display:none"> ' + confirm + '\n  <a href="#" class="m10x" data-no>' + no + '</a>&nbsp;<a href="#" class="t-mute" data-yes> ' + yes + ' </a>\n</span>\n';
};

var _templateFn = function (id, name, action, method) {
  var enctype = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 'multipart/form-data';
  var size = arguments[5];
  var accept = arguments[6];
  var types = arguments[7];
  var cmdConfig = arguments[8];
  return '\n<form action="' + (action || '') + '" method="' + (method || 'POST') + '" enctype="' + enctype + '">\n<input type="hidden" name="' + name + '_data" data-value>\n<label class="t-xsmall t-mute"> ' + __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].fileHintFn(size, types) + '</label>\n<input id="' + id + '" type="file" name="' + name + '_file" class="input" accept="' + accept + '" data-file-input data-state="ready" data-skip-keys="13">\n<label for="' + id + '" data-label>\n  <span class="file-content" data-content>\n    <i class="file-icon"></i> <span class="t-primary"> Browse </span> file to upload\n  </span>\n  <span data-progress class="file-progress" style="width:0"></span>\n</label>\n<label data-error class="t-xsmall t-danger m20b u-block"> </label>\n<div data-container></div>\n  ' + (cmdConfig ? _cmdTemplateFn(id, cmdConfig) : '') + '\n</form>\n';
};
var MIME_MAP = {
  'js': '(x-)?javascript'

  /**
     * Helper: Checks if the provided file type is within allowed types.
     *
     * @param {File} file The file object
     */
};function isAllowedType(file, acceptedRegEx) {
  var onerror = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function () {
    return void 0;
  };

  return file.type.match(acceptedRegEx) != null || onerror() && false;
}
/**
 * Helper: Checks if the provided file size is within allowed limit.
 *
 * @param {File} file The file object
 * @param {Number} maxSize The maximum allowed size in MB (0 means no unlimited).
 * @param {Function} onerror The callback to execute when file size exceeds the limit.
 */
function isAllowedSize(file, maxSize) {
  var onerror = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function () {
    return void 0;
  };

  return !maxSize || file.size / 1024 / 1024 <= maxSize || onerror() && false;
}

/**
 * Helper: Update file upload input state.
 *
 * @param {HTMLElement} input The file upload input element.
 * @param {String} state The state
 */
function updateState(input, state) {
  input.setAttribute('data-state', state);
}

function File() {
  var config = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var _config$buttons = config.buttons;
  _config$buttons = _config$buttons === undefined ? {} : _config$buttons;
  var _config$buttons$yes = _config$buttons.yes;
  _config$buttons$yes = _config$buttons$yes === undefined ? {} : _config$buttons$yes;
  var _config$buttons$yes$t = _config$buttons$yes.text,
      yesBtnText = _config$buttons$yes$t === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].done : _config$buttons$yes$t,
      _config$buttons$yes$t2 = _config$buttons$yes.type,
      yesBtnType = _config$buttons$yes$t2 === undefined ? '' : _config$buttons$yes$t2,
      _config$buttons$yes$c = _config$buttons$yes.classes,
      yesBtnClasses = _config$buttons$yes$c === undefined ? '' : _config$buttons$yes$c,
      _config$buttons$yes$i = _config$buttons$yes.invokeOnClose,
      yesInvokeOnClose = _config$buttons$yes$i === undefined ? false : _config$buttons$yes$i,
      _config$buttons$yes$k = _config$buttons$yes.key,
      yesKey = _config$buttons$yes$k === undefined ? __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ENTER : _config$buttons$yes$k,
      _config$buttons$no = _config$buttons.no;
  _config$buttons$no = _config$buttons$no === undefined ? {} : _config$buttons$no;
  var _config$buttons$no$te = _config$buttons$no.text,
      noBtnText = _config$buttons$no$te === undefined ? __WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].cancel : _config$buttons$no$te,
      _config$buttons$no$ty = _config$buttons$no.type,
      noBtnType = _config$buttons$no$ty === undefined ? 'inverse' : _config$buttons$no$ty,
      _config$buttons$no$cl = _config$buttons$no.classes,
      noBtnClasses = _config$buttons$no$cl === undefined ? '' : _config$buttons$no$cl,
      _config$buttons$no$in = _config$buttons$no.invokeOnClose,
      noInvokeOnClose = _config$buttons$no$in === undefined ? true : _config$buttons$no$in,
      _config$buttons$no$ke = _config$buttons$no.key,
      noKey = _config$buttons$no$ke === undefined ? __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ESC : _config$buttons$no$ke,
      _config$accept = config.accept,
      acceptedTypes = _config$accept === undefined ? '' : _config$accept,
      _config$size = config.size,
      maxFileSize = _config$size === undefined ? 3 : _config$size,
      _config$name = config.name,
      name = _config$name === undefined ? 'browse' : _config$name,
      _config$errors = config.errors;
  _config$errors = _config$errors === undefined ? {} : _config$errors;
  var _config$errors$size = _config$errors.size,
      sizeError = _config$errors$size === undefined ? '' : _config$errors$size,
      _config$errors$type = _config$errors.type,
      typeError = _config$errors$type === undefined ? '' : _config$errors$type,
      mimeTypesMap = config.mimeMap,
      autoHookClose = config.autoHookClose;


  var inputFileID = (name || '_fum_') + uploadID++,
      cancelBtnConfig = {
    text: noBtnText, type: noBtnType, classes: noBtnClasses, key: noKey, invokeOnClose: noInvokeOnClose, outline: false, callback: function (e) {
      var _config$on = config.on;
      _config$on = _config$on === undefined ? {} : _config$on;
      var callback = _config$on.cancel;

      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](callback)) {
        return callback.call(modal, e, B8.get('form', modal.el), config);
      }
    }
  },
      okBtnConfig = {
    text: yesBtnText, type: yesBtnType, classes: yesBtnClasses, key: yesKey, invokeOnClose: yesInvokeOnClose, outline: false, callback: function (e) {
      if (fileLabel.classList.contains('has-error')) {
        return false;
      }
      var _config$on2 = config.on;
      _config$on2 = _config$on2 === undefined ? {} : _config$on2;
      var callback = _config$on2.asyncOk;

      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](callback)) {
        e.cancel = modal.Waiting = true;
        errorLabel.innerHTML = '';
        callback.call(
        //context
        modal,
        //resolve
        function () {
          modal.Waiting = false;
          modal.hide();
        },
        //reject
        function (error) {
          errorLabel.innerHTML = error;
          modal.Waiting = false;
        },
        //form
        B8.get('form', modal.el),
        //config
        config);
      }
    }
  },
      modalConfig = {
    closableByDimmer: config.closableByDimmer,
    on: {
      afteropen: function () {
        Object(__WEBPACK_IMPORTED_MODULE_4__ui_scripts__["$bind"])(modal.el);
      },
      beforeopen: function () {
        var cmdYes = B8.get('[data-yes]', modal.el);
        if (cmdYes) __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](modal, cmdYes, 'click', function (e) {
          e.preventDefault();
          if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](config.on.cmd)) {
            config.on.cmd.call(modal, e);
          }
        });
      }
    },
    buttons: [cancelBtnConfig, okBtnConfig],
    focus: {
      target: '#' + inputFileID,
      select: false
    },
    addon: config.addon

    //merge defined map to current.
  };Object.assign(MIME_MAP, mimeTypesMap);
  var allowedTypes = acceptedTypes.replace(/\./g, ' '),
      acceptRegEx = acceptedTypes.split(',').reduce(function (acc, curr, idx, arr) {
    var ext = curr.replace(/^\s*\./, '');
    acc += MIME_MAP[ext] || __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["escapeRegExp"](ext);

    if (idx == arr.length - 1) {
      return new RegExp(acc ? '^.*\/(' + acc + ')$' : '.*');
    } else {
      return acc + '|';
    }
  }, ''),
      modal = new __WEBPACK_IMPORTED_MODULE_2__modal__["d" /* Modal */](modalConfig);

  //build modal structure.
  modal.Header = '<h5>' + config.title + '</h5>';
  modal.Body = _templateFn(inputFileID, name, config.url, config.method, config.enctype, maxFileSize, acceptedTypes, allowedTypes, config.cmdLink);

  var form = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('form', modal.el),
      fileInput = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + inputFileID, modal.el),
      fileLabel = fileInput.nextElementSibling,
      labelContent = fileLabel.firstElementChild,
      errorLabel = fileLabel.nextElementSibling;
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](modal, form, 'submit', function (e) {
    e.preventDefault();
  });

  var fileUrl = null;
  var destructAddon = function () {
    return void 0;
  };
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](modal, fileInput, 'change', function (e) {
    if (fileInput.files.length > 0) {
      destructAddon();
      fileLabel.classList.remove('has-error');
      var file = fileInput.files[0];
      updateState(fileInput, 'done');
      labelContent.innerHTML = _uploadTemplateFn(file.name);
      if (isAllowedSize(file, maxFileSize, function () {
        errorLabel.innerHTML = sizeError;
      }) && isAllowedType(file, acceptRegEx, function () {
        errorLabel.innerHTML = typeError;
      })) {

        errorLabel.innerHTML = '';
        var addon = config.addon || {};

        switch (addon.type) {
          case 'crop':
            addon = Object(__WEBPACK_IMPORTED_MODULE_3__modal_file_addons__["a" /* cropAddonBuilder */])(addon.options);
            break;
          case 'thumb':
            addon = Object(__WEBPACK_IMPORTED_MODULE_3__modal_file_addons__["b" /* thumbnailAddonBuilder */])(addon.options);
          default:
            break;
        }

        if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](addon)) {
          destructAddon = addon.call(modal, form, config) || function () {
            return void 0;
          };
        }
      } else {
        updateState(fileInput, 'error');
        fileLabel.classList.add('has-error');
      }
    } else {
      updateState(fileInput, 'ready');
      fileLabel.innerHTML = _uploadTemplateFn(__WEBPACK_IMPORTED_MODULE_1__shared_i18n_res__["a" /* res */].fileBrowse);
      destructAddon();
    }
  });
  return modal.show();
}

/***/ }),
/* 85 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = cropAddonBuilder;
/* harmony export (immutable) */ __webpack_exports__["b"] = thumbnailAddonBuilder;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);


/**
 * Helper to build cropper file addon.
 */
function cropAddonBuilder() {
  var cropper = void 0,
      fileUrl = void 0,
      cropContainer = void 0,
      cropImage = void 0,
      container = void 0;
  return function (form, config) {
    if (fileUrl) {
      URL.revokeObjectURL(fileUrl); //revoke old url
    }
    var file = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-file-input]', form).files[0];
    fileUrl = URL.createObjectURL(file);
    if (!container) {
      container = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-container]', form);
    }
    if (!cropContainer) {
      cropContainer = document.createElement('div');
      cropContainer.className = 'cropper';
    }
    if (!cropImage) {
      cropImage = document.createElement('img');
    }

    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["replaceElement"](container, cropContainer);
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["clearChildren"](cropContainer);
    cropImage.src = fileUrl;
    cropContainer.appendChild(cropImage);

    cropper = new Cropper(cropImage, {
      autoCropArea: .5,
      aspectRatio: 1,
      viewMode: 1, // restrict the minimum canvas size to fill fit the container.
      guides: false,
      center: false,
      dragMode: 'move',
      //cropBoxResizable: false,
      minCropBoxWidth: 240,
      minCropBoxHeight: 240,
      background: false,
      crop: function (e) {
        var json = {
          x: e.detail.x,
          y: e.detail.y,
          height: e.detail.height,
          width: e.detail.width,
          rotate: e.detail.rotate
        };
        var store = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-value]', form);
        if (store) {
          store.value = JSON.stringify(json);
        }
      }
    });
    return function () {
      if (cropContainer.parentElement) {
        cropper.destroy();
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["replaceElement"](cropContainer, container);
      }
    };
  };
}

/**
 * Helper to build Logo Thumbnail file addon.
 */
function thumbnailAddonBuilder() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  var fileUrl = void 0,
      thumbContainer = void 0,
      thumbImage = void 0,
      container = void 0;
  return function (form, config) {
    var _this = this;

    if (!container) {
      container = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-container]', form);
    }
    if (!thumbContainer) {
      thumbContainer = document.createElement('div');
      thumbContainer.className = 'thumb';
    }
    if (!thumbImage) {
      thumbImage = document.createElement('img');
    }
    if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](options.create)) {
      this.Waiting = true;
      options.create(form, config,
      //resolve
      function (url) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["replaceElement"](container, thumbContainer);
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["clearChildren"](thumbContainer);
        thumbImage.src = url;
        thumbImage.title = options.title || '';
        thumbContainer.appendChild(thumbImage);
        _this.Waiting = false;
      },
      //reject
      function (error) {
        var errorLabel = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('[data-error]', form);
        errorLabel && (errorLabel.innerHTML = error);
        _this.Waiting = false;
      });
    }
    return function () {
      if (thumbContainer.parentElement) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["replaceElement"](thumbContainer, container);
      }
    };
  };
}

/***/ }),
/* 86 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = $prePopulate;
/* harmony export (immutable) */ __webpack_exports__["a"] = $init;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__validate_form__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__shared_i18n_res__ = __webpack_require__(7);






var DATA_CLONABLE_DELETE = 'data-clonable-delete',
    _tmplAddLinkFn = function () {
    var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
        _ref$addText = _ref.addText,
        addText = _ref$addText === undefined ? __WEBPACK_IMPORTED_MODULE_4__shared_i18n_res__["a" /* res */].addAnother : _ref$addText;

    return '<a href="javascript:;" class="t-small"><i class="icon is-plus"></i>' + addText + '</a>';
},
    _tmplNewInptFn = function () {
    var _ref2 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
        _ref2$delText = _ref2.delText,
        delText = _ref2$delText === undefined ? __WEBPACK_IMPORTED_MODULE_4__shared_i18n_res__["a" /* res */].del : _ref2$delText;

    return '<div class="has-attachments m10t">\n                            <a ' + DATA_CLONABLE_DELETE + ' class="is-attached p40l m20t b-close is-primary d" data-position="tr" href="javascript:;"></a>\n                            <a ' + DATA_CLONABLE_DELETE + ' class="is-gray m" href="javascript:;">' + delText + '</a>\n                        </div>';
},
    PRE_POPULATE_STORE = [],
    SUFFIX = '_c',
    ERR_SUFFIX = '_em_',
    ATTR_OID = 'oid',
    CSS_HINT = '.form-hint';

/**
 * Helpr to perform actual cloning of the element
 *
 * @param {HTMLElement} element The element to clone
 * @param {HTMLElement} parent The parent node to hold the clones
 * @param {HTMLElement} form The parent html form
 * @param {HTMLElement} addLink The link used to trigger cloning
 * @param {Object} config The clonable field configuration
 * @param {Object} sequence A unique number added as an ID suffix for each clone input
 * @param {Object} data The data associated with the current clone, used to populate inputs.
 * @param {HTMLElement} nextElement The next element sibling of the cloned element.
 */
function clone(element, parent, form, addLink, config, sequence, data, nextElement) {
    //Collect Form Validation config for Element Form
    var formValidationModule = __WEBPACK_IMPORTED_MODULE_2__shared_data_registry__["d" /* resolve */](__WEBPACK_IMPORTED_MODULE_3__validate_form__["a" /* ValidateForm */], form),

    //Cloning the element
    clonedField = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](config.templateHtml),
        clonedFieldWrapper = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](_tmplNewInptFn(config)),
        originalId = void 0;
    //Update cloned element Id, and inner elements if exist
    if (clonedField.children.length) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('.input', function (item) {
            originalId = item.id;
            item.id += SUFFIX + sequence;
            //save original id to help match with validation attrs
            item.attr(ATTR_OID, originalId);
        }, clonedField);
    } else {
        clonedField.id = element.id + SUFFIX + sequence;
        //save original id to help match with validation attrs
        clonedField.attr(ATTR_OID, element.id);
    }
    //Cloning the element Form Validation config and add it to cloned field
    if (formValidationModule != null) {
        if (clonedField.children.length) {
            __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('.input', function (item) {
                cloneHint(element, item, clonedFieldWrapper, nextElement, clonedField);
                addValidationAttrs(item, formValidationModule, sequence);
            }, clonedField);
        } else {
            cloneHint(element, clonedField, clonedFieldWrapper, nextElement);
            addValidationAttrs(clonedField, formValidationModule, sequence);
        }
    }

    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["prependElement"](clonedField, clonedFieldWrapper);
    parent.appendChild(clonedFieldWrapper);

    //populate clone data

    var _loop = function (name) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[name="' + name + '"]', function (i) {
            return i.value = data[name];
        }, clonedFieldWrapper);
    };

    for (var name in data) {
        _loop(name);
    }__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('[' + DATA_CLONABLE_DELETE + ']', function (deleteLink) {
        deleteLink.addEventListener('click', function (e) {
            //Remove CloneField
            e.preventDefault();
            if (formValidationModule != null) {
                if (clonedField.childNodes && clonedField.childNodes.length) {
                    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["find"]('.input', function (item) {
                        remValidationAttrs(item, formValidationModule);
                    }, clonedField);
                } else {
                    remValidationAttrs(clonedField, formValidationModule);
                }
            }
            //Remove Clone
            parent.removeChild(clonedFieldWrapper);
            if (++config.max > 0) {
                __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["remClass"]('u-none', addLink);
            }
        });
    }, clonedFieldWrapper);

    if (--config.max <= 0) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["addClass"]('u-none', addLink);
    }
    //Init cloned field and auto focus
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["init"](clonedField, { bind: true, load: true, after: function () {
            !data /*dont focus if pre-populated*/ && clonedField.focus && clonedField.focus();
        } });
}

/**
 * Helper to clone the hint, it may exist next to the cloned element or any of the inputs inside.
 *
 * @param {HTMLElement} element The clonable field root element to locate the hint
 * @param {HTMLElement} clonedInput The cloned input node.
 * @param {HTMLElement} wrapper The cloned element wrapper.
 * @param {HTMLElement} nextElement The next element sibling of the cloned element.
 * @param {HTMLElement} cloneContainer The cloned input container node.
 */
function cloneHint(element, clonedInput, wrapper, nextElement, clonedInputContainer) {
    var hint = clonedInput.nextElementSibling;
    //next to the clonedInput, just update the id
    if (hint && hint.matches(CSS_HINT)) {
        hint.id = clonedInput.id + ERR_SUFFIX;
    } else {
        hint = nextElement || element.nextElementSibling;
        //next to the element, make a copy and prepend to wrapper
        if (hint && hint.matches(CSS_HINT) && hint.id == clonedInput.attr(ATTR_OID) + ERR_SUFFIX) {
            var hintClone = hint.cloneNode();
            hintClone.id = clonedInput.id + ERR_SUFFIX;
            __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["prependElement"](hintClone, wrapper);
        } //last resort: find by id in the clonedInput container
        else if (clonedInputContainer) {
                hint = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"]('#' + clonedInput.attr('oid') + ERR_SUFFIX, clonedInputContainer);
                if (hint && hint.matches(CSS_HINT)) {
                    hint.id = clonedInput.id + ERR_SUFFIX;
                }
            }
    }
}
/**
 * Helper to add input to parent form validation module.
 *
 * @param {HTMLElement} input The input field to add to parent form config
 * @param {Object} formValidationModule The parent form validation module.
 */
function addValidationAttrs(input, formValidationModule, counter) {
    //Get Form Validate attributes for the target
    var oid = input.attr(ATTR_OID),
        attr = formValidationModule.config.attrs.find(function (a) {
        return a.inputID == oid;
    });

    if (attr) {
        var _clone = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["merge"](true, {}, attr, {
            id: input.id,
            inputID: input.id,
            errorID: input.id + ERR_SUFFIX,
            name: /\[*\]+/.test(attr.name) ? attr.name : attr.name + "[]"
        });
        //Update related fields Ids to match the clones
        if (_clone.related && _clone.related.length) {
            _clone.related = _clone.related.map(function (r) {
                return r + SUFFIX + counter;
            });
        }
        //Update form validation config
        formValidationModule.config.attrs.push(_clone);
    }
}
/**
 * Helper to remove input from parent form validation module.
 *
 * @param {HTMLElement} input The input field to add to parent form config
 * @param {Object} formValidationModule The parent form validation module.
 */
function remValidationAttrs(input, formValidationModule) {
    for (var i = 0; i < formValidationModule.config.attrs.length; i++) {
        if (formValidationModule.config.attrs[i].id === input.id) {
            formValidationModule.config.attrs.splice(i, 1);
            break;
        }
    }
}

/**
 * Main clonable field function
 *
 * @param {HTMLElement} element The element to be cloned
 * @param {Object} config The clonable field configuration
 */
function clonableField(element) {
    var config = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    var addLink = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](_tmplAddLinkFn(config)),
        form = element.closest('form'),
        parent = element.parentNode,
        //holds reference to the parent node before initializing any module.
    id = element.id,
        template = config.template && __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["get"](config.template),
        counter = 0; //local clone counter

    // generate clone template and add it to page.
    config.templateHtml = template ? template.innerHTML : element.outerHTML;
    var nextElement = element.nextElementSibling;
    // set default max number of fields
    config.max = config.max || 3;
    // append add link to element container
    parent.appendChild(addLink);

    // add click event to AddLink
    addLink.addEventListener('click', function (e) {
        e.preventDefault();
        clone(element, parent, form, addLink, config, ++counter, config.default || {}, nextElement);
    });
    // populate clones in case data array was present
    if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isArray"](config.data)) {
        PRE_POPULATE_STORE.push(function () {
            config.data.forEach(function (data) {
                config.max && clone(element, parent, form, addLink, config, ++counter, data, nextElement);
            });
        });
    }
}

function $prePopulate() {
    var fn = void 0;
    while (fn = PRE_POPULATE_STORE.pop()) {
        fn();
    }
}
/**
* Module helper to toggle add/remove field
*
* @param {HTMLElement} container The element to search in (optional).
*/
function $init(container) {
    __WEBPACK_IMPORTED_MODULE_1__shared_base_ui_control__["a" /* UIControl */].$initHelper(container, 'clonable', clonableField);
}

/***/ }),
/* 87 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Bubble; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_data_registry__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__shared_capture_capture__ = __webpack_require__(36);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__bubble_core__ = __webpack_require__(88);
var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _get = function get(object, property, receiver) { if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { return get(parent, property, receiver); } } else if ("value" in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }







var Bubble = function (_MixinCapture) {
  _inherits(Bubble, _MixinCapture);

  function Bubble(owner) {
    var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
        _ref$buttons = _ref.buttons,
        buttons = _ref$buttons === undefined ? [] : _ref$buttons,
        _ref$focus = _ref.focus,
        focus = _ref$focus === undefined ? {} : _ref$focus,
        _ref$on = _ref.on,
        on = _ref$on === undefined ? {} : _ref$on,
        _ref$title = _ref.title,
        title = _ref$title === undefined ? false : _ref$title,
        _ref$message = _ref.message,
        message = _ref$message === undefined ? false : _ref$message,
        _ref$placement = _ref.placement,
        placement = _ref$placement === undefined ? 'rt' : _ref$placement,
        _ref$trigger = _ref.trigger,
        trigger = _ref$trigger === undefined ? 'hover' : _ref$trigger;

    _classCallCheck(this, Bubble);

    if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](owner)) {
      owner = document.qs(owner);
    }

    var config = { buttons: buttons, focus: focus, on: on, owner: owner, title: title, message: message, placement: placement, trigger: trigger };
    var element = __WEBPACK_IMPORTED_MODULE_4__bubble_core__["a" /* build */]();

    var _this = _possibleConstructorReturn(this, (Bubble.__proto__ || Object.getPrototypeOf(Bubble)).call(this, element, config));

    owner.classList.add('popover-owner');
    if (config.trigger === 'hover') {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this, owner, 'click', function (e) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]() && _this.show();
      });
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this, owner, 'mouseenter', function (e) {
        !__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]() && _this.show();
      });
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this, owner, 'mouseleave', function (e) {
        !__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]() && _this.hide();
      });
    } else {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](_this, owner, 'click', function (e) {
        _this.show();
      });
    }
    return _this;
  }

  _createClass(Bubble, [{
    key: 'show',
    value: function show() {
      __WEBPACK_IMPORTED_MODULE_4__bubble_core__["d" /* show */](this);
      return this;
    }
  }, {
    key: 'hide',
    value: function hide() {
      __WEBPACK_IMPORTED_MODULE_4__bubble_core__["c" /* hide */](this);
      return this;
    }
  }, {
    key: 'renderActions',
    value: function renderActions() {
      this.Footer = __WEBPACK_IMPORTED_MODULE_4__bubble_core__["b" /* buildActions */](this.config.buttons);
      return this;
    }
  }, {
    key: 'dispose',
    value: function dispose() {
      this.hide();
      _get(Bubble.prototype.__proto__ || Object.getPrototypeOf(Bubble.prototype), 'dispose', this).call(this);
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](this, this.Owner, 'click');
      if (this.config.trigger === 'hover') {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](_singleton, _singleton.Owner, 'mouseenter');
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](_singleton, _singleton.Owner, 'mouseleave');
      }
    }
  }, {
    key: 'Owner',
    get: function () {
      return this._.cfg.owner;
    }
  }, {
    key: 'Header',
    set: function (element) {
      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](element)) {
        element = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](element);
      }
      __WEBPACK_IMPORTED_MODULE_4__bubble_core__["e" /* updateElement */]('head', element);
    }
  }, {
    key: 'Body',
    set: function (element) {
      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](element)) {
        element = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](element);
      }
      __WEBPACK_IMPORTED_MODULE_4__bubble_core__["e" /* updateElement */]('body', element);
    }
  }, {
    key: 'Footer',
    set: function (element) {
      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](element)) {
        element = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](element);
      }
      __WEBPACK_IMPORTED_MODULE_4__bubble_core__["e" /* updateElement */]('foot', element);
    }
  }]);

  return Bubble;
}(Object(__WEBPACK_IMPORTED_MODULE_3__shared_capture_capture__["a" /* MixinCapture */])(__WEBPACK_IMPORTED_MODULE_2__shared_base_ui_control__["a" /* UIControl */], { mode: '*' }));

__WEBPACK_IMPORTED_MODULE_1__shared_data_registry__["a" /* SET__TYPE__ */](Bubble, 'bubble');

/***/ }),
/* 88 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return build; });
/* unused harmony export init */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return buildActions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return updateElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return show; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return hide; });
/* unused harmony export isOpen */
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__shared_blurfix_blurfix__ = __webpack_require__(39);



var _template = '\n<div class="popover is-pointing is-padded is-wide" tabindex="0" data-placement="rt">\n  <button class="js-tabtrap"></button>\n  <div class="bubble" tabindex="0">\n    <div data-head></div>\n    <div data-body></div>\n    <div data-foot></div>\n  </div>\n  <button class="js-tabtrap"></button>\n</div>\n';
var _instance = void 0,
    _elements = void 0,
    _placeholders = { //holds the bubble key elements placeholders
  head: document.createComment('head'),
  body: document.createComment('body'),
  foot: document.createComment('foot')
},
    _cancelKeyup = false,
    _usedKeys = [],
    _isOpen = false,
    _blurFix = new __WEBPACK_IMPORTED_MODULE_1__shared_blurfix_blurfix__["a" /* BlurFix */]();

function build() {
  if (!_elements) {
    var root = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"](_template);
    _elements = {
      root: root,
      bubble: root.qs('.bubble'),
      head: root.qs('[data-head]'),
      body: root.qs('[data-body]'),
      foot: root.qs('[data-foot]'),
      reset: [root.qs('.js-tabtrap:first-child'), root.qs('.js-tabtrap:last-child')]
    };
  }
  clear();
  return _elements.root;
}

function updateElement(key, value) {
  var el = _elements[key];
  var ph = _placeholders[key];
  var parent = el.parentElement;
  if (!value) {
    parent && parent.replaceChild(ph, el);
  } else if (value instanceof HTMLElement) {
    __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["clearChildren"](el);
    el.appendChild(value);
    if (!parent) _elements.bubble.replaceChild(el, ph);
  }
}
function clear() {
  updateElement('head', false);
  updateElement('body', false);
  updateElement('foot', false);
}

function buildActions(buttons) {
  _usedKeys.length = 0;
  if (buttons.length) {
    var group = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<div class="t-right"></div>');
    for (var x = 0; x < buttons.length; x++) {
      var button = buttons[x];
      //for (let button of buttons) {
      // add to the list of used keys.
      if (_usedKeys.indexOf(button.key) < 0) {
        _usedKeys.push(button.key);
      }
      button.element = __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<button class="btn ' + (button.type ? 'is-' + button.type : '') + ' ' + (button.style ? 'is-' + button.style : '') + '"> ' + button.label + '</button>');
      group.appendChild(button.element);
    }
    return group;
  }
}

function init(instance) {
  _elements.root.setAttribute('data-placement', instance.config.placement);
  updateElement('head', instance.config.title ? __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<h5>' + instance.config.title + '</h5>') : false);
  updateElement('body', instance.config.message ? __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["htmlToElement"]('<p class="t-small"> ' + instance.config.message + '</p>') : false);
  updateElement('foot', buildActions(instance.config.buttons));
}

function triggerEvent(instance, key) {
  var eventHandler = instance.config.on[key];
  if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](eventHandler)) {
    eventHandler.call(instance);
  }
}

function isOpen() {
  return _isOpen;
}

function show(instance) {
  if (!_isOpen && (_isOpen = true)) {
    init(instance);
    //trigger event
    triggerEvent(instance, 'beforeopen');

    //bind required events.
    bindEvents(instance);

    //attach bubble to owner
    instance.Owner.appendChild(instance.el);
    // enable transition
    instance.el.classList.add('has-transition');
    //reflow
    instance.__reflow = instance.el.offsetWidth * instance.el.offsetHeight;
    //activate
    instance.Owner.classList.add('is-active');

    //set focus according to bubble config
    setFocus(instance);

    // capture outside clicks
    instance.capture(function () {
      if (_isOpen) // only if open or else a button callback might be called twice
        triggerClose(instance);
    }, function () {
      if (_isOpen) // only if open or else a button callback might be called twice
        return triggerClose(instance, true);
      return true;
    });

    // allow handling key up.
    _cancelKeyup = false;

    //trigger event
    triggerEvent(instance, 'afteropen');
    //Utils.dispatchEvent('modal.open', instance)

    _blurFix.attach(instance.el);
  }
}

function hide(instance) {
  if (_isOpen && !(_isOpen = false)) {
    //trigger event
    triggerEvent(instance, 'beforeclose');

    instance.uncapture();

    //unbind all events
    unbindEvents(instance);

    //detach the bubble
    if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isMobile"]()) {
      __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, instance.el, 'transitionend', function (e) {
        __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, instance.el, 'transitionend');
        instance.Owner.removeChild(instance.el);
      });
    } else {
      instance.Owner.removeChild(instance.el);
    }
    instance.Owner.classList.remove('is-active');

    //trigger event
    triggerEvent(instance, 'afterclose');
    //Utils.dispatchEvent('modal.close', instance)

    _blurFix.detach(instance.el);
  }
}

function createCloseEvent(button, uncaptured) {
  return {
    button: button,
    cancel: false,
    delegated: uncaptured //window.event.target === document.body
  };
}

function handleReturn(returnValue, closeEvent) {
  if (typeof returnValue !== 'undefined') {
    closeEvent.cancel = !returnValue;
  }
}

function triggerCallback(instance, check, uncaptured) {
  for (var index = 0; index < instance.config.buttons.length; index++) {
    var button = instance.config.buttons[index];
    //for (let button of instance.config.buttons) {
    if (!button.element.disabled && check(button)) {
      var closeEvent = createCloseEvent(button, uncaptured);
      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](button.callback)) {
        handleReturn(button.callback.call(instance, closeEvent), closeEvent);
      } else if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isStr"](button.callback)) {
        var handler = instance.config.on[button.callback];
        if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isFn"](handler)) {
          handleReturn(handler.call(instance, closeEvent), closeEvent);
        }
      }
      //close the bubble only if not canceled.
      if (closeEvent.cancel === false) {
        instance.hide();
        return true;
      }
      break;
    }
  }
  return false;
}

function triggerClose(instance, uncaptured) {
  var found = void 0;
  var closed = triggerCallback(instance, function (button) {
    return found = button.invokeOnClose === true;
  }, uncaptured);
  //none of the buttons registered as onclose callback
  //close the bubble
  if (!found && _isOpen) {
    instance.hide();
    closed = true;
  }
  return closed;
}

function setFocus(instance, resetTarget) {
  // reset target has already been determined.
  if (resetTarget) {
    resetTarget.focus();
  } else {
    // current instance focus settings
    var focus = instance.config.focus;
    // the focus element.
    var element = focus.target;

    switch (typeof focus.target) {
      // a number means a button index
      case 'number':
        if (instance.config.buttons.length > focus.target) {
          element = instance.config.buttons[focus.target].element;
        }
        break;
      // a string means querySelector to select from bubble body contents.
      case 'string':
        element = _elements.modal.qs(focus.target);
        break;
      // a function should return the focus element.
      case 'function':
        element = focus.target.call(instance);
        break;
    }

    // if no focus element, default to first reset element.
    if ((typeof element === 'undefined' || element === null) && instance.config.buttons.length === 0) {
      element = _elements.reset[0];
    }
    // focus
    if (element && element.focus) {
      element.focus();
      // if selectable
      if (focus.select && element.select) {
        element.select();
      }
    }
  }
}

function bindEvents(instance) {
  //prevent handling key up when bubble is being opened by a key stroke.
  _cancelKeyup = true;

  var keyupHandler = function (e) {
    //hitting enter while button has focus will trigger keyup too.
    //ignore if handled by clickHandler
    if (_cancelKeyup) {
      _cancelKeyup = false;
      return;
    }
    // if modal has no buttons and Esc key was pressed, close the modal
    if (!instance.config.buttons.length && e.keyCode === __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].ESC) {
      instance.hide();
      return false;
    } else if (_usedKeys.indexOf(e.keyCode) > -1) {
      triggerCallback(instance, function (button) {
        return button.key === e.keyCode;
      });
      return false;
    }
  };

  var keydownHandler = function (e) {
    if (e.keyCode === __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].LEFT || e.keyCode === __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].RIGHT) {
      var buttons = instance.config.buttons;
      for (var x = 0; x < buttons.length; x += 1) {
        if (document.activeElement === buttons[x].element) {
          switch (e.keyCode) {
            case __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].LEFT:
              buttons[(x || buttons.length) - 1].element.focus();
              return;
            case __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].RIGHT:
              buttons[(x + 1) % buttons.length].element.focus();
              return;
          }
        }
      }
    } else if (e.keyCode < __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].F12 + 1 && e.keyCode > __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["KEYS"].F1 - 1 && _usedKeys.indexOf(e.keyCode) > -1) {
      // F1-F12 must be handled in keydown event to be able to prevent them.
      // other keys are handled in keyup event.
      e.preventDefault();
      e.stopPropagation();
      triggerCallback(instance, function (button) {
        return button.key === e.keyCode;
      });
      return false;
    }
  };

  var resetFocus = function (e) {
    // determine reset target to enable forward/backward tab cycle.
    var resetTarget = void 0,
        target = e.target;
    var lastResetElement = target === _elements.reset[1] || instance.config.buttons.length === 0 && target === document.body;
    if (lastResetElement) {
      resetTarget = _elements.bubble;
    }

    // if no reset target found, try finding the best button
    if (resetTarget === undefined) {
      if (__WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["isNum"](instance.config.focus.target)) {
        // button focus element, go to first available button
        if (target === _elements.reset[0] && instance.config.buttons.length) {
          resetTarget = instance.config.buttons[0].element;
        } else if (lastResetElement) {
          //restart the cycle by going to first reset link
          resetTarget = _elements.reset[0];
        }
      } else {
        // will reach here when tapping backwards, so go to last child
        // The focus element SHOULD NOT be a button (logically!).
        if (target === _elements.reset[0] && instance.config.buttons.length) {
          resetTarget = instance.config.buttons[instance.config.buttons.length - 1].element;
        }
      }
    }

    // set focus
    setFocus(instance, resetTarget);
  };

  var clickHandler = function (e) {
    e.stopPropagation();
    var target = e.target;
    triggerCallback(instance, function (button) {
      // if this button caused the click, cancel keyup event
      return button.element === target && (_cancelKeyup = true);
    });
  };

  var bubbleClickHandler = function (e) {
    e.stopPropagation();
  };

  /// GLOBAL
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, document.body, 'keyup', keyupHandler);
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, document.body, 'keydown', keydownHandler);

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, document.body, 'focus', resetFocus);
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, _elements.reset[0], 'focus', resetFocus);
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, _elements.reset[1], 'focus', resetFocus);

  /// COMMON
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, _elements.bubble, 'click', bubbleClickHandler);
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["attachEvent"](instance, _elements.foot, 'click', clickHandler);
}

/**
 * Unbinds all bubble events.
 *
 * @param {Modal} instance The modal instance
 */
function unbindEvents(instance) {
  //Utils.detachAllEvents(instance)

  /// GLOBAL
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, document.body, 'keyup');
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, document.body, 'keydown');

  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, document.body, 'focus');
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, _elements.reset[0], 'focus');
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, _elements.reset[1], 'focus');

  /// COMMON
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, _elements.bubble, 'click');
  __WEBPACK_IMPORTED_MODULE_0__shared_utils_main__["detachEvent"](instance, _elements.foot, 'click');
}



/***/ })
/******/ ]);
//# sourceMappingURL=B8.js.map
;
